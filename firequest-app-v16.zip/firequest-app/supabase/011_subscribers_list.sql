-- v16: control room "Subscribers" page (FireQuest admins only).
-- One row per family plan with its payment state, problems first.
create or replace function public.subscribers_list()
returns json language plpgsql stable security definer set search_path = public as $$
begin
  if not exists (select 1 from public.staff where user_id = auth.uid() and role = 'admin') then
    raise exception 'Not authorised';
  end if;
  return (
    select coalesce(json_agg(row_to_json(x) order by x.rank, x.holder_name), '[]'::json)
    from (
      select s.id,
             coalesce(nullif(trim(p.full_name), ''), p.email, 'Unknown') as holder_name,
             p.phone as holder_phone,
             p.email as holder_email,
             (select count(*) from public.subscription_members m where m.subscription_id = s.id) as members,
             st.state,
             private.billing_label(st.state) as label,
             case st.state
               when 'payment_failed' then 1 when 'overdue' then 2 when 'lapsed' then 3 when 'unpaid' then 4
               when 'active' then 5 when 'cancelled_paid' then 6 when 'test' then 7 else 8 end as rank,
             private.billing_paid_until(s) as paid_until,
             s.next_billing_date,
             s.monthly_amount,
             s.last_payment_at,
             s.last_payment_amount,
             s.payment_failed_at,
             s.cancelled_at,
             s.card_expiry,
             coalesce(s.payfast_mode, 'sandbox') as payfast_mode,
             s.created_at
        from public.subscriptions s
        join public.profiles p on p.id = s.owner_id
        cross join lateral (select private.billing_state(s) as state) st
    ) x);
end $$;

revoke all on function public.subscribers_list() from public, anon;
grant execute on function public.subscribers_list() to authenticated;
