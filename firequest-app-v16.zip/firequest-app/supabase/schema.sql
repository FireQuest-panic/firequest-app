-- =====================================================================
-- FireQuest Panic – database schema (Supabase / PostgreSQL)
--
-- Run this ONCE on a new, empty Supabase project:
--   Supabase dashboard → SQL Editor → New query → paste this file → Run
--
-- What it creates
--   * Client data: profiles, medical_profiles, emergency_contacts
--   * Control room: staff, alerts, alert_locations, alert_events
--   * Settings: app_settings (test mode is ON by default)
--   * Family plans, crash detection, PayFast billing, profile details (appended below)
--   * Security: row-level security on every table, plus functions that
--     are the ONLY way to raise, update, cancel or handle an alert.
-- =====================================================================

create extension if not exists pgcrypto with schema extensions;

-- ---------------------------------------------------------------------
-- Types
-- ---------------------------------------------------------------------
create type public.alert_type as enum ('medical', 'vehicle', 'fire');
create type public.alert_status as enum (
  'new', 'acknowledged', 'dispatched', 'on_scene', 'closed', 'cancelled'
);

-- ---------------------------------------------------------------------
-- Settings (single row)
-- ---------------------------------------------------------------------
create table public.app_settings (
  id          int primary key default 1 check (id = 1),
  test_mode   boolean not null default true,
  control_room_phone text not null default '',
  updated_at  timestamptz not null default now()
);
insert into public.app_settings (id) values (1);

-- ---------------------------------------------------------------------
-- Client data
-- ---------------------------------------------------------------------
create table public.profiles (
  id                    uuid primary key references auth.users (id) on delete cascade,
  email                 text,
  full_name             text not null default '',
  phone                 text not null default '',
  id_number             text,
  date_of_birth         date,
  gender                text,
  home_address          text,
  vehicle_make          text,
  vehicle_model         text,
  vehicle_colour        text,
  vehicle_registration  text,
  consent_at            timestamptz,          -- POPIA consent to process & share health info
  onboarded_at          timestamptz,          -- set when registration is complete
  created_at            timestamptz not null default now(),
  updated_at            timestamptz not null default now()
);

create table public.medical_profiles (
  user_id             uuid primary key references public.profiles (id) on delete cascade,
  blood_type          text,
  allergies           text[] not null default '{}',
  conditions          text,
  medication          text,
  medical_aid_scheme  text,
  medical_aid_plan    text,
  medical_aid_number  text,
  doctor_name         text,
  doctor_phone        text,
  updated_at          timestamptz not null default now()
);

create table public.emergency_contacts (
  id            uuid primary key default gen_random_uuid(),
  user_id       uuid not null references public.profiles (id) on delete cascade,
  name          text not null,
  relationship  text,
  phone         text not null,
  created_at    timestamptz not null default now()
);
create index emergency_contacts_user_idx on public.emergency_contacts (user_id);

-- Cancel PINs live in a schema the public API cannot reach.
create schema if not exists private;
revoke all on schema private from public, anon, authenticated;

create table private.cancel_pins (
  user_id     uuid primary key references auth.users (id) on delete cascade,
  pin_hash    text not null,
  updated_at  timestamptz not null default now()
);

-- ---------------------------------------------------------------------
-- Control room
-- ---------------------------------------------------------------------
create table public.staff (
  user_id       uuid primary key references auth.users (id) on delete cascade,
  display_name  text not null,
  role          text not null default 'operator' check (role in ('operator', 'admin')),
  created_at    timestamptz not null default now()
);

create table public.alerts (
  id                   uuid primary key default gen_random_uuid(),
  user_id              uuid not null references public.profiles (id) on delete cascade,
  type                 public.alert_type not null,
  status               public.alert_status not null default 'new',
  is_test              boolean not null default true,
  lat                  double precision,
  lng                  double precision,
  accuracy_m           real,
  location_updated_at  timestamptz,
  operator_id          uuid references public.staff (user_id),
  outcome              text,
  created_at           timestamptz not null default now(),
  acknowledged_at      timestamptz,
  dispatched_at        timestamptz,
  on_scene_at          timestamptz,
  closed_at            timestamptz,
  cancelled_at         timestamptz
);
create index alerts_user_status_idx on public.alerts (user_id, status);
create index alerts_status_created_idx on public.alerts (status, created_at desc);

create table public.alert_locations (
  id           bigint generated always as identity primary key,
  alert_id     uuid not null references public.alerts (id) on delete cascade,
  lat          double precision not null,
  lng          double precision not null,
  accuracy_m   real,
  recorded_at  timestamptz not null default now()
);
create index alert_locations_alert_idx on public.alert_locations (alert_id, recorded_at desc);

create table public.alert_events (
  id          bigint generated always as identity primary key,
  alert_id    uuid not null references public.alerts (id) on delete cascade,
  actor_id    uuid,
  actor_kind  text not null check (actor_kind in ('client', 'operator', 'system')),
  event       text not null,
  note        text,
  created_at  timestamptz not null default now()
);
create index alert_events_alert_idx on public.alert_events (alert_id, created_at);

-- ---------------------------------------------------------------------
-- Helper functions
-- ---------------------------------------------------------------------
create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end $$;

create trigger profiles_updated_at before update on public.profiles
  for each row execute function public.set_updated_at();
create trigger medical_profiles_updated_at before update on public.medical_profiles
  for each row execute function public.set_updated_at();

create or replace function public.is_staff()
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.staff where user_id = auth.uid());
$$;

-- Staff may only see a client's personal and medical details while that
-- client has an open alert, or for 24 hours after an alert was raised.
create or replace function public.staff_can_view(p_user_id uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select public.is_staff() and exists (
    select 1 from public.alerts a
    where a.user_id = p_user_id
      and (a.status not in ('closed', 'cancelled') or a.created_at > now() - interval '24 hours')
  );
$$;

create or replace function public.owns_alert(p_alert_id uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.alerts where id = p_alert_id and user_id = auth.uid());
$$;

create or replace function public.status_rank(s public.alert_status)
returns int language sql immutable as $$
  select case s
    when 'new' then 0 when 'acknowledged' then 1 when 'dispatched' then 2
    when 'on_scene' then 3 else 4 end;
$$;

-- Create a profile row automatically when someone signs up.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, email, full_name, phone)
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data ->> 'full_name', ''),
    coalesce(new.raw_user_meta_data ->> 'phone', '')
  )
  on conflict (id) do nothing;
  return new;
end $$;

create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- ---------------------------------------------------------------------
-- Row-level security
-- ---------------------------------------------------------------------
alter table public.app_settings       enable row level security;
alter table public.profiles           enable row level security;
alter table public.medical_profiles   enable row level security;
alter table public.emergency_contacts enable row level security;
alter table public.staff              enable row level security;
alter table public.alerts             enable row level security;
alter table public.alert_locations    enable row level security;
alter table public.alert_events       enable row level security;

-- Settings: anyone signed in can read; changes only from the SQL editor.
create policy "settings readable" on public.app_settings
  for select to authenticated using (true);

-- Profiles
create policy "own profile read" on public.profiles
  for select to authenticated using (id = auth.uid() or public.staff_can_view(id));
create policy "own profile insert" on public.profiles
  for insert to authenticated with check (id = auth.uid());
create policy "own profile update" on public.profiles
  for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

-- Medical profile
create policy "own medical read" on public.medical_profiles
  for select to authenticated using (user_id = auth.uid() or public.staff_can_view(user_id));
create policy "own medical insert" on public.medical_profiles
  for insert to authenticated with check (user_id = auth.uid());
create policy "own medical update" on public.medical_profiles
  for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

-- Emergency contacts
create policy "own contacts read" on public.emergency_contacts
  for select to authenticated using (user_id = auth.uid() or public.staff_can_view(user_id));
create policy "own contacts insert" on public.emergency_contacts
  for insert to authenticated with check (user_id = auth.uid());
create policy "own contacts update" on public.emergency_contacts
  for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "own contacts delete" on public.emergency_contacts
  for delete to authenticated using (user_id = auth.uid());

-- Staff list: visible to staff (and each person can see their own row).
create policy "staff read" on public.staff
  for select to authenticated using (user_id = auth.uid() or public.is_staff());

-- Alerts: clients see their own, staff see all. No direct writes –
-- every change goes through the functions below.
create policy "alerts read" on public.alerts
  for select to authenticated using (user_id = auth.uid() or public.is_staff());
create policy "alert locations read" on public.alert_locations
  for select to authenticated using (public.owns_alert(alert_id) or public.is_staff());
create policy "alert events read" on public.alert_events
  for select to authenticated using (public.owns_alert(alert_id) or public.is_staff());

-- ---------------------------------------------------------------------
-- Client functions
-- ---------------------------------------------------------------------
create or replace function public.set_cancel_pin(p_pin text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'Not signed in'; end if;
  if p_pin !~ '^[0-9]{4,6}$' then raise exception 'PIN must be 4 to 6 digits'; end if;
  insert into private.cancel_pins (user_id, pin_hash, updated_at)
  values (auth.uid(), extensions.crypt(p_pin, extensions.gen_salt('bf')), now())
  on conflict (user_id) do update set pin_hash = excluded.pin_hash, updated_at = now();
end $$;

create or replace function public.has_cancel_pin()
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from private.cancel_pins where user_id = auth.uid());
$$;

-- Raise an alert. If the client already has an open alert, that alert is
-- returned instead of creating a duplicate.
create or replace function public.raise_alert(
  p_type public.alert_type,
  p_lat double precision default null,
  p_lng double precision default null,
  p_accuracy real default null
) returns public.alerts
language plpgsql security definer set search_path = public as $$
declare
  v_uid   uuid := auth.uid();
  v_alert public.alerts;
begin
  if v_uid is null then raise exception 'Not signed in'; end if;

  select * into v_alert from public.alerts
   where user_id = v_uid and status not in ('closed', 'cancelled')
   order by created_at desc limit 1;

  if found then
    insert into public.alert_events (alert_id, actor_id, actor_kind, event, note)
    values (v_alert.id, v_uid, 'client', 'pressed_again', p_type::text);
  else
    insert into public.alerts (user_id, type, is_test)
    values (v_uid, p_type, (select test_mode from public.app_settings where id = 1))
    returning * into v_alert;

    insert into public.alert_events (alert_id, actor_id, actor_kind, event, note)
    values (v_alert.id, v_uid, 'client', 'raised', p_type::text);
  end if;

  if p_lat is not null and p_lng is not null then
    update public.alerts
       set lat = p_lat, lng = p_lng, accuracy_m = p_accuracy, location_updated_at = now()
     where id = v_alert.id
     returning * into v_alert;
    insert into public.alert_locations (alert_id, lat, lng, accuracy_m)
    values (v_alert.id, p_lat, p_lng, p_accuracy);
  end if;

  return v_alert;
end $$;

create or replace function public.update_alert_location(
  p_alert_id uuid,
  p_lat double precision,
  p_lng double precision,
  p_accuracy real default null
) returns void
language plpgsql security definer set search_path = public as $$
begin
  update public.alerts
     set lat = p_lat, lng = p_lng, accuracy_m = p_accuracy, location_updated_at = now()
   where id = p_alert_id and user_id = auth.uid()
     and status not in ('closed', 'cancelled');
  if found then
    insert into public.alert_locations (alert_id, lat, lng, accuracy_m)
    values (p_alert_id, p_lat, p_lng, p_accuracy);
  end if;
end $$;

-- Cancel with the client's PIN. Returns true when cancelled.
create or replace function public.cancel_alert(p_alert_id uuid, p_pin text)
returns boolean
language plpgsql security definer set search_path = public as $$
declare
  v_uid  uuid := auth.uid();
  v_hash text;
begin
  if not exists (
    select 1 from public.alerts
     where id = p_alert_id and user_id = v_uid and status not in ('closed', 'cancelled')
  ) then
    return false;
  end if;

  select pin_hash into v_hash from private.cancel_pins where user_id = v_uid;

  if v_hash is not null and extensions.crypt(p_pin, v_hash) = v_hash then
    update public.alerts set status = 'cancelled', cancelled_at = now() where id = p_alert_id;
    insert into public.alert_events (alert_id, actor_id, actor_kind, event)
    values (p_alert_id, v_uid, 'client', 'cancelled_by_client');
    return true;
  end if;

  insert into public.alert_events (alert_id, actor_id, actor_kind, event)
  values (p_alert_id, v_uid, 'client', 'cancel_wrong_pin');
  return false;
end $$;

-- ---------------------------------------------------------------------
-- Control room function
-- Actions: acknowledge, dispatch, on_scene, close, note,
--          navigate_opened, route_sent, called_client
-- ---------------------------------------------------------------------
create or replace function public.operator_update_alert(
  p_alert_id uuid,
  p_action text,
  p_note text default null
) returns public.alerts
language plpgsql security definer set search_path = public as $$
declare
  v_uid   uuid := auth.uid();
  v_alert public.alerts;
  v_new   public.alert_status;
begin
  if not public.is_staff() then raise exception 'Not authorised'; end if;

  select * into v_alert from public.alerts where id = p_alert_id for update;
  if not found then raise exception 'Alert not found'; end if;

  if p_action in ('acknowledge', 'dispatch', 'on_scene', 'close') then
    if v_alert.status in ('closed', 'cancelled') then
      raise exception 'This alert is already %', v_alert.status;
    end if;

    v_new := case p_action
      when 'acknowledge' then 'acknowledged'
      when 'dispatch'    then 'dispatched'
      when 'on_scene'    then 'on_scene'
      else 'closed' end;

    update public.alerts set
      status          = case when public.status_rank(v_new) > public.status_rank(status) then v_new else status end,
      operator_id     = coalesce(operator_id, v_uid),
      acknowledged_at = coalesce(acknowledged_at, now()),
      dispatched_at   = case when p_action = 'dispatch' then coalesce(dispatched_at, now()) else dispatched_at end,
      on_scene_at     = case when p_action = 'on_scene' then coalesce(on_scene_at, now()) else on_scene_at end,
      closed_at       = case when p_action = 'close' then now() else closed_at end,
      outcome         = case when p_action = 'close' then p_note else outcome end
    where id = p_alert_id
    returning * into v_alert;
  elsif p_action not in ('note', 'navigate_opened', 'route_sent', 'called_client') then
    raise exception 'Unknown action %', p_action;
  end if;

  insert into public.alert_events (alert_id, actor_id, actor_kind, event, note)
  values (p_alert_id, v_uid, 'operator', p_action, p_note);

  return v_alert;
end $$;

-- Only signed-in users may call the functions.
revoke execute on function
  public.set_cancel_pin(text),
  public.has_cancel_pin(),
  public.raise_alert(public.alert_type, double precision, double precision, real),
  public.update_alert_location(uuid, double precision, double precision, real),
  public.cancel_alert(uuid, text),
  public.operator_update_alert(uuid, text, text)
from public, anon;

grant execute on function
  public.set_cancel_pin(text),
  public.has_cancel_pin(),
  public.raise_alert(public.alert_type, double precision, double precision, real),
  public.update_alert_location(uuid, double precision, double precision, real),
  public.cancel_alert(uuid, text),
  public.operator_update_alert(uuid, text, text)
to authenticated;

-- Helper functions: fixed search path, and not callable by anonymous visitors.
alter function public.set_updated_at() set search_path = public;
alter function public.status_rank(public.alert_status) set search_path = public;

revoke execute on function
  public.handle_new_user(),
  public.is_staff(),
  public.owns_alert(uuid),
  public.staff_can_view(uuid),
  public.status_rank(public.alert_status),
  public.set_updated_at()
from public, anon;

revoke execute on function public.handle_new_user() from authenticated;

grant execute on function
  public.is_staff(),
  public.owns_alert(uuid),
  public.staff_can_view(uuid),
  public.status_rank(public.alert_status)
to authenticated;

-- ---------------------------------------------------------------------
-- Table permissions (row-level security above decides WHICH rows)
-- ---------------------------------------------------------------------
revoke all on all tables in schema public from anon, authenticated;
grant usage on schema public to authenticated;
grant select on public.app_settings, public.staff, public.alerts,
                public.alert_locations, public.alert_events to authenticated;
grant select, insert, update on public.profiles, public.medical_profiles to authenticated;
grant select, insert, update, delete on public.emergency_contacts to authenticated;

-- ---------------------------------------------------------------------
-- Live updates for the monitor and the client's alert screen
-- ---------------------------------------------------------------------
alter publication supabase_realtime add table public.alerts, public.alert_events;

-- =====================================================================
-- FireQuest – family plans (up to 4 people per subscription)
-- Each person has their own login. The account holder shares an invite
-- code; others join with it. Everything goes through the functions below.
-- (Already included at the end of schema.sql for new installs.)
-- =====================================================================

create table public.subscriptions (
  id           uuid primary key default gen_random_uuid(),
  owner_id     uuid not null unique references public.profiles (id) on delete cascade,
  plan         text not null default 'family',
  max_members  int not null default 4 check (max_members between 1 and 10),
  invite_code  text not null unique,
  status       text not null default 'active',
  created_at   timestamptz not null default now()
);

create table public.subscription_members (
  subscription_id  uuid not null references public.subscriptions (id) on delete cascade,
  user_id          uuid not null unique references public.profiles (id) on delete cascade,
  role             text not null default 'member' check (role in ('owner', 'member')),
  joined_at        timestamptz not null default now(),
  primary key (subscription_id, user_id)
);

-- No direct access from the apps: only the functions below.
alter table public.subscriptions        enable row level security;
alter table public.subscription_members enable row level security;
revoke all on public.subscriptions, public.subscription_members from anon, authenticated;

-- Random, easy-to-read 6-character code (no 0/O, 1/I/L).
create or replace function private.new_invite_code()
returns text language plpgsql security definer set search_path = public as $$
declare
  chars text := 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
  code  text;
  b     bytea;
begin
  loop
    b := extensions.gen_random_bytes(6);
    code := '';
    for i in 0..5 loop
      code := code || substr(chars, (get_byte(b, i) % length(chars)) + 1, 1);
    end loop;
    exit when not exists (select 1 from public.subscriptions where invite_code = code);
  end loop;
  return code;
end $$;

-- Everyone belongs to exactly one plan; a new person gets their own.
create or replace function private.ensure_subscription(p_uid uuid)
returns uuid language plpgsql security definer set search_path = public as $$
declare
  v_sub uuid;
begin
  select subscription_id into v_sub from public.subscription_members where user_id = p_uid;
  if v_sub is null then
    insert into public.subscriptions (owner_id, invite_code)
    values (p_uid, private.new_invite_code())
    returning id into v_sub;
    insert into public.subscription_members (subscription_id, user_id, role)
    values (v_sub, p_uid, 'owner');
  end if;
  return v_sub;
end $$;

create or replace function public.my_subscription()
returns json language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
  v_sub uuid;
  v_res json;
begin
  if v_uid is null then raise exception 'Not signed in'; end if;
  v_sub := private.ensure_subscription(v_uid);
  select json_build_object(
    'id', s.id,
    'max_members', s.max_members,
    'is_owner', s.owner_id = v_uid,
    'invite_code', case when s.owner_id = v_uid then s.invite_code end,
    'owner_name', (select full_name from public.profiles where id = s.owner_id),
    'members', (
      select coalesce(json_agg(json_build_object(
               'user_id', m.user_id, 'name', p.full_name, 'phone', p.phone,
               'email', p.email, 'role', m.role, 'is_me', m.user_id = v_uid)
             order by m.role desc, m.joined_at), '[]'::json)
      from public.subscription_members m
      join public.profiles p on p.id = m.user_id
      where m.subscription_id = s.id)
  ) into v_res
  from public.subscriptions s where s.id = v_sub;
  return v_res;
end $$;

create or replace function public.join_subscription(p_code text)
returns json language plpgsql security definer set search_path = public as $$
declare
  v_uid     uuid := auth.uid();
  v_target  public.subscriptions;
  v_current uuid;
  v_count   int;
  v_others  int;
begin
  if v_uid is null then raise exception 'Not signed in'; end if;

  select * into v_target from public.subscriptions
   where invite_code = upper(regexp_replace(coalesce(p_code, ''), '\s', '', 'g'))
   for update;
  if not found then raise exception 'That family code was not found. Check it and try again.'; end if;

  select subscription_id into v_current from public.subscription_members where user_id = v_uid;
  if v_current = v_target.id then raise exception 'You are already on this family plan.'; end if;

  select count(*) into v_count from public.subscription_members where subscription_id = v_target.id;
  if v_count >= v_target.max_members then
    raise exception 'This family plan is full (% people).', v_target.max_members;
  end if;

  if v_current is not null then
    if exists (select 1 from public.subscriptions where id = v_current and owner_id = v_uid) then
      select count(*) into v_others from public.subscription_members
       where subscription_id = v_current and user_id <> v_uid;
      if v_others > 0 then
        raise exception 'You manage a family plan with other people on it. Remove them first.';
      end if;
      delete from public.subscriptions where id = v_current;
    else
      delete from public.subscription_members where user_id = v_uid;
    end if;
  end if;

  insert into public.subscription_members (subscription_id, user_id, role)
  values (v_target.id, v_uid, 'member');
  return public.my_subscription();
end $$;

create or replace function public.remove_subscription_member(p_user_id uuid)
returns json language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
  v_sub uuid;
begin
  select id into v_sub from public.subscriptions where owner_id = v_uid;
  if v_sub is null then raise exception 'Only the plan holder can remove people.'; end if;
  if p_user_id = v_uid then raise exception 'You cannot remove yourself.'; end if;
  delete from public.subscription_members where subscription_id = v_sub and user_id = p_user_id;
  if not found then raise exception 'That person is not on your family plan.'; end if;
  return public.my_subscription();
end $$;

create or replace function public.leave_subscription()
returns json language plpgsql security definer set search_path = public as $$
declare
  v_uid   uuid := auth.uid();
  v_owner boolean;
begin
  select s.owner_id = v_uid into v_owner
    from public.subscription_members m
    join public.subscriptions s on s.id = m.subscription_id
   where m.user_id = v_uid;
  if v_owner is null then raise exception 'You are not on a family plan.'; end if;
  if v_owner then raise exception 'The plan holder cannot leave. Remove the other people instead.'; end if;
  delete from public.subscription_members where user_id = v_uid;
  return public.my_subscription();
end $$;

create or replace function public.new_subscription_code()
returns json language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
begin
  update public.subscriptions set invite_code = private.new_invite_code() where owner_id = v_uid;
  if not found then raise exception 'Only the plan holder can change the code.'; end if;
  return public.my_subscription();
end $$;

-- For the control room: the other people on the alerting client's plan.
create or replace function public.alert_family(p_alert_id uuid)
returns json language plpgsql stable security definer set search_path = public as $$
declare
  v_owner uuid;
  v_res   json;
begin
  if not public.is_staff() then raise exception 'Not authorised'; end if;
  select user_id into v_owner from public.alerts where id = p_alert_id;
  if v_owner is null then return '[]'::json; end if;
  select coalesce(json_agg(json_build_object('name', p.full_name, 'phone', p.phone, 'role', m.role)
         order by m.role desc, m.joined_at), '[]'::json)
    into v_res
    from public.subscription_members m
    join public.profiles p on p.id = m.user_id
   where m.subscription_id = (select subscription_id from public.subscription_members where user_id = v_owner)
     and m.user_id <> v_owner;
  return v_res;
end $$;

revoke execute on function
  public.my_subscription(),
  public.join_subscription(text),
  public.remove_subscription_member(uuid),
  public.leave_subscription(),
  public.new_subscription_code(),
  public.alert_family(uuid)
from public, anon;

grant execute on function
  public.my_subscription(),
  public.join_subscription(text),
  public.remove_subscription_member(uuid),
  public.leave_subscription(),
  public.new_subscription_code(),
  public.alert_family(uuid)
to authenticated;

revoke execute on function private.new_invite_code(), private.ensure_subscription(uuid) from public, anon, authenticated;


-- =====================================================================
-- FireQuest – family plans, version 2: personal invites
-- * Nobody becomes a plan holder automatically any more. A person starts
--   a plan (free while test_mode is on; through PayFast later).
-- * Only the plan holder adds people: name, cellphone number, relationship.
-- * Each invited person gets their own code. It works once, only for the
--   cellphone number the holder entered, and expires after 7 days.
-- * Members cannot invite anyone, and cannot start their own plan while
--   they are on someone else's.
-- Run after 002_family_plans.sql. (Also included in schema.sql.)
-- =====================================================================

-- The old shared code is retired: it let anyone with the code join.
alter table public.subscriptions alter column invite_code drop not null;
update public.subscriptions set invite_code = null;
alter table public.subscriptions alter column status set default 'test';
update public.subscriptions set status = 'test';

-- Plans that only ever held their owner were created automatically: remove them.
delete from public.subscriptions s
 where (select count(*) from public.subscription_members m where m.subscription_id = s.id) <= 1;

-- How each person is related to the plan holder.
alter table public.subscription_members add column if not exists relationship text
  check (relationship in ('holder', 'spouse', 'child', 'parent', 'other'));
update public.subscription_members set relationship = 'holder' where role = 'owner';

create table if not exists public.family_invites (
  id              uuid primary key default gen_random_uuid(),
  subscription_id uuid not null references public.subscriptions (id) on delete cascade,
  name            text not null check (length(trim(name)) between 1 and 80),
  phone           text not null,
  relationship    text not null check (relationship in ('spouse', 'child', 'parent', 'other')),
  code            text not null unique,
  created_at      timestamptz not null default now(),
  expires_at      timestamptz not null default now() + interval '7 days'
);
alter table public.family_invites enable row level security;
revoke all on public.family_invites from anon, authenticated;

-- Last 9 digits of a phone number, so 082 123 4567, 0821234567 and
-- +27 82 123 4567 all match. Null when there are fewer than 9 digits.
create or replace function private.phone_key(p text)
returns text language sql immutable set search_path = public as $$
  select case when length(d) >= 9 then right(d, 9) end
    from (select regexp_replace(coalesce(p, ''), '\D', '', 'g') as d) x
$$;

-- Random, easy-to-read 6-character code (no 0/O, 1/I/L).
create or replace function private.new_family_code()
returns text language plpgsql security definer set search_path = public as $$
declare
  chars  text := 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
  v_code text;
  b      bytea;
begin
  loop
    b := extensions.gen_random_bytes(6);
    v_code := '';
    for i in 0..5 loop
      v_code := v_code || substr(chars, (get_byte(b, i) % length(chars)) + 1, 1);
    end loop;
    exit when not exists (select 1 from public.family_invites f where f.code = v_code);
  end loop;
  return v_code;
end $$;

drop function if exists public.new_subscription_code();
drop function if exists private.ensure_subscription(uuid);
drop function if exists private.new_invite_code();

create or replace function public.my_subscription()
returns json language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
  v_sub uuid;
  v_res json;
begin
  if v_uid is null then raise exception 'Not signed in'; end if;
  select subscription_id into v_sub from public.subscription_members where user_id = v_uid;
  if v_sub is null then
    return json_build_object('in_plan', false, 'is_owner', false, 'max_members', 4,
                             'members', '[]'::json, 'invites', '[]'::json, 'spots_left', 0);
  end if;

  delete from public.family_invites where subscription_id = v_sub and expires_at < now();

  select json_build_object(
    'in_plan', true,
    'id', s.id,
    'status', s.status,
    'max_members', s.max_members,
    'is_owner', s.owner_id = v_uid,
    'owner_name', (select full_name from public.profiles where id = s.owner_id),
    'members', (
      select coalesce(json_agg(json_build_object(
               'user_id', m.user_id, 'name', p.full_name, 'phone', p.phone, 'email', p.email,
               'role', m.role, 'relationship', m.relationship, 'is_me', m.user_id = v_uid)
             order by m.role desc, m.joined_at), '[]'::json)
        from public.subscription_members m
        join public.profiles p on p.id = m.user_id
       where m.subscription_id = s.id),
    'invites', case when s.owner_id = v_uid then (
      select coalesce(json_agg(json_build_object(
               'id', i.id, 'name', i.name, 'phone', i.phone, 'relationship', i.relationship,
               'code', i.code, 'expires_at', i.expires_at)
             order by i.created_at), '[]'::json)
        from public.family_invites i
       where i.subscription_id = s.id) else '[]'::json end,
    'spots_left', s.max_members
      - (select count(*) from public.subscription_members m where m.subscription_id = s.id)
      - (select count(*) from public.family_invites i where i.subscription_id = s.id)
  ) into v_res
  from public.subscriptions s where s.id = v_sub;
  return v_res;
end $$;

-- Start a family plan with yourself as holder. Free while test_mode is on;
-- once FireQuest is live, plans are started through PayFast instead.
create or replace function public.start_subscription()
returns json language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
  v_sub uuid;
begin
  if v_uid is null then raise exception 'Not signed in'; end if;
  if not coalesce((select test_mode from public.app_settings where id = 1), false) then
    raise exception 'Family plans are started by subscribing with PayFast.';
  end if;
  if exists (select 1 from public.subscription_members where user_id = v_uid) then
    raise exception 'You are already on a family plan.';
  end if;
  insert into public.subscriptions (owner_id, status) values (v_uid, 'test') returning id into v_sub;
  insert into public.subscription_members (subscription_id, user_id, role, relationship)
  values (v_sub, v_uid, 'owner', 'holder');
  return public.my_subscription();
end $$;

-- Holder only: add a family member by name, cellphone number and relationship.
create or replace function public.invite_family_member(p_name text, p_phone text, p_relationship text)
returns json language plpgsql security definer set search_path = public as $$
declare
  v_uid  uuid := auth.uid();
  v_sub  public.subscriptions;
  v_name text := trim(coalesce(p_name, ''));
  v_key  text := private.phone_key(p_phone);
  v_used int;
  v_inv  uuid;
begin
  if v_uid is null then raise exception 'Not signed in'; end if;
  select * into v_sub from public.subscriptions where owner_id = v_uid for update;
  if not found then raise exception 'Only the plan holder can add family members.'; end if;
  if v_name = '' then raise exception 'Enter their name.'; end if;
  if length(v_name) > 80 then raise exception 'That name is too long.'; end if;
  if v_key is null then raise exception 'Enter their cellphone number, for example 082 123 4567.'; end if;
  if coalesce(p_relationship, '') not in ('spouse', 'child', 'parent', 'other') then
    raise exception 'Choose how they are related to you.';
  end if;

  delete from public.family_invites where subscription_id = v_sub.id and expires_at < now();

  if exists (select 1 from public.subscription_members m join public.profiles p on p.id = m.user_id
              where m.subscription_id = v_sub.id and private.phone_key(p.phone) = v_key) then
    raise exception 'Someone with that cellphone number is already on your plan.';
  end if;
  if exists (select 1 from public.family_invites
              where subscription_id = v_sub.id and private.phone_key(phone) = v_key) then
    raise exception 'That number already has an invite waiting. Tap "Send again", or cancel it first.';
  end if;

  select (select count(*) from public.subscription_members where subscription_id = v_sub.id)
       + (select count(*) from public.family_invites where subscription_id = v_sub.id)
    into v_used;
  if v_used >= v_sub.max_members then
    raise exception 'Your plan is full (% people, counting invites that are still waiting).', v_sub.max_members;
  end if;

  insert into public.family_invites (subscription_id, name, phone, relationship, code)
  values (v_sub.id, v_name, trim(p_phone), p_relationship, private.new_family_code())
  returning id into v_inv;

  return (public.my_subscription()::jsonb || jsonb_build_object('new_invite_id', v_inv))::json;
end $$;

-- Holder only: cancel an invite that has not been used yet.
create or replace function public.cancel_family_invite(p_invite_id uuid)
returns json language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
begin
  if v_uid is null then raise exception 'Not signed in'; end if;
  delete from public.family_invites i
   using public.subscriptions s
   where i.id = p_invite_id and s.id = i.subscription_id and s.owner_id = v_uid;
  if not found then raise exception 'That invite was not found.'; end if;
  return public.my_subscription();
end $$;

-- Join with a personal invite code. The cellphone number on the joiner's
-- profile must match the number the holder entered.
create or replace function public.join_subscription(p_code text)
returns json language plpgsql security definer set search_path = public as $$
declare
  v_uid     uuid := auth.uid();
  v_inv     public.family_invites;
  v_target  public.subscriptions;
  v_current public.subscriptions;
  v_phone   text;
  v_count   int;
begin
  if v_uid is null then raise exception 'Not signed in'; end if;

  select * into v_inv from public.family_invites
   where code = upper(regexp_replace(coalesce(p_code, ''), '\s', '', 'g'))
   for update;
  if not found or v_inv.expires_at < now() then
    raise exception 'That code is not valid. It may already have been used, or it expired after 7 days. Ask the plan holder to send you a new invite.';
  end if;

  select * into v_target from public.subscriptions where id = v_inv.subscription_id for update;

  select phone into v_phone from public.profiles where id = v_uid;
  if private.phone_key(v_phone) is distinct from private.phone_key(v_inv.phone) then
    raise exception 'This invite is for the cellphone number ending in %. The number on your FireQuest profile is different. Ask % to check the number, or correct your number under Profile > Edit my details.',
      right(regexp_replace(v_inv.phone, '\D', '', 'g'), 4),
      coalesce(nullif((select full_name from public.profiles where id = v_target.owner_id), ''), 'the plan holder');
  end if;

  select s.* into v_current
    from public.subscription_members m join public.subscriptions s on s.id = m.subscription_id
   where m.user_id = v_uid;
  if found then
    if v_current.id = v_target.id then raise exception 'You are already on this family plan.'; end if;
    if v_current.owner_id <> v_uid then
      raise exception 'You are on another family plan. Leave it first (Account > Family plan > Leave).';
    end if;
    if exists (select 1 from public.subscription_members where subscription_id = v_current.id and user_id <> v_uid)
       or exists (select 1 from public.family_invites where subscription_id = v_current.id) then
      raise exception 'You hold your own family plan with other people on it. Remove them and cancel their invites first.';
    end if;
    if v_current.status <> 'test' then
      raise exception 'Cancel your own FireQuest subscription first.';
    end if;
    delete from public.subscriptions where id = v_current.id;
  end if;

  select count(*) into v_count from public.subscription_members where subscription_id = v_target.id;
  if v_count >= v_target.max_members then
    raise exception 'This family plan is full (% people).', v_target.max_members;
  end if;

  insert into public.subscription_members (subscription_id, user_id, role, relationship)
  values (v_target.id, v_uid, 'member', v_inv.relationship);
  delete from public.family_invites where id = v_inv.id;
  return public.my_subscription();
end $$;

-- For the control room: the other people on the alerting client's plan.
create or replace function public.alert_family(p_alert_id uuid)
returns json language plpgsql stable security definer set search_path = public as $$
declare
  v_owner uuid;
  v_res   json;
begin
  if not public.is_staff() then raise exception 'Not authorised'; end if;
  select user_id into v_owner from public.alerts where id = p_alert_id;
  if v_owner is null then return '[]'::json; end if;
  select coalesce(json_agg(json_build_object('name', p.full_name, 'phone', p.phone, 'role', m.role,
                                             'relationship', m.relationship)
         order by m.role desc, m.joined_at), '[]'::json)
    into v_res
    from public.subscription_members m
    join public.profiles p on p.id = m.user_id
   where m.subscription_id = (select subscription_id from public.subscription_members where user_id = v_owner)
     and m.user_id <> v_owner;
  return v_res;
end $$;

revoke execute on function
  public.my_subscription(),
  public.start_subscription(),
  public.invite_family_member(text, text, text),
  public.cancel_family_invite(uuid),
  public.join_subscription(text),
  public.alert_family(uuid)
from public, anon;

grant execute on function
  public.my_subscription(),
  public.start_subscription(),
  public.invite_family_member(text, text, text),
  public.cancel_family_invite(uuid),
  public.join_subscription(text),
  public.alert_family(uuid)
to authenticated;

revoke execute on function private.phone_key(text), private.new_family_code() from public, anon, authenticated;


-- =====================================================================
-- FireQuest – automatic crash detection (Android)
-- The crash-detection service on the phone keeps running when the app is
-- closed, so it cannot rely on the normal login session. When the client
-- switches crash detection on, the app registers the phone and receives a
-- long random device key. The service sends that key with a crash alert.
-- Only a SHA-256 hash of the key is stored. Switching off deletes it.
-- Run after 003_family_invites.sql. (Also included in schema.sql.)
-- =====================================================================

-- Where an alert came from: a button press, or the phone's crash detection.
alter table public.alerts add column if not exists source text not null default 'button'
  check (source in ('button', 'crash_detection'));

-- One row per phone (a person may use crash detection on up to 5 phones).
create table if not exists private.crash_devices (
  key_hash     text primary key,
  user_id      uuid not null references public.profiles (id) on delete cascade,
  created_at   timestamptz not null default now(),
  last_used_at timestamptz
);
create index if not exists crash_devices_user_idx on private.crash_devices (user_id);

-- Every detection, sent or cancelled with "I'm OK". Used to tune the detector
-- during testing. Cancelled detections store no location.
create table if not exists private.crash_detections (
  id         bigint generated always as identity primary key,
  user_id    uuid not null references public.profiles (id) on delete cascade,
  outcome    text not null check (outcome in ('alert_sent', 'cancelled')),
  simulated  boolean not null default false,
  peak_g     real,
  speed_kmh  real,
  created_at timestamptz not null default now()
);

create or replace function private.crash_device_user(p_key text)
returns uuid language sql stable security definer set search_path = public as $$
  select user_id from private.crash_devices
   where key_hash = encode(extensions.digest(coalesce(p_key, ''), 'sha256'), 'hex')
$$;

-- Signed-in client: create a device key for this phone. Keeps the 5 newest phones per person.
create or replace function public.register_crash_device()
returns text language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
  v_key text;
begin
  if v_uid is null then raise exception 'Not signed in'; end if;
  v_key := encode(extensions.gen_random_bytes(32), 'hex');
  insert into private.crash_devices (key_hash, user_id)
  values (encode(extensions.digest(v_key, 'sha256'), 'hex'), v_uid);
  delete from private.crash_devices
   where user_id = v_uid
     and key_hash not in (select key_hash from private.crash_devices
                           where user_id = v_uid order by created_at desc limit 5);
  return v_key;
end $$;

drop function if exists public.unregister_crash_device();

-- Signed-in client: switch crash detection off on one phone (that phone's key stops working).
create or replace function public.unregister_crash_device(p_key text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'Not signed in'; end if;
  delete from private.crash_devices
   where user_id = auth.uid()
     and key_hash = encode(extensions.digest(coalesce(p_key, ''), 'sha256'), 'hex');
end $$;

-- Phone service: raise a vehicle alert after a crash was detected and not cancelled.
create or replace function public.raise_crash_alert(
  p_key       text,
  p_lat       double precision default null,
  p_lng       double precision default null,
  p_accuracy  real default null,
  p_peak_g    real default null,
  p_speed_kmh real default null,
  p_simulated boolean default false
) returns uuid
language plpgsql security definer set search_path = public as $$
declare
  v_uid   uuid := private.crash_device_user(p_key);
  v_alert public.alerts;
  v_note  text;
begin
  if v_uid is null then
    raise exception 'Crash detection is not registered for this phone. Open FireQuest and switch it on again.';
  end if;
  update private.crash_devices set last_used_at = now()
   where key_hash = encode(extensions.digest(p_key, 'sha256'), 'hex');

  v_note := case when coalesce(p_simulated, false) then 'SIMULATED crash (test button)' else 'Crash detected by phone' end
         || coalesce(': ' || round(p_peak_g::numeric, 1) || ' g', '')
         || coalesce(' at ' || round(p_speed_kmh::numeric) || ' km/h', '');

  insert into private.crash_detections (user_id, outcome, simulated, peak_g, speed_kmh)
  values (v_uid, 'alert_sent', coalesce(p_simulated, false), p_peak_g, p_speed_kmh);

  -- Add to the client's open alert, except that a real crash never joins a TEST alert
  -- once FireQuest is live (test mode off).
  select * into v_alert from public.alerts
   where user_id = v_uid and status not in ('closed', 'cancelled')
     and (coalesce(p_simulated, false) or not is_test
          or coalesce((select test_mode from public.app_settings where id = 1), true))
   order by created_at desc limit 1;

  if not found then
    insert into public.alerts (user_id, type, is_test, source)
    values (v_uid, 'vehicle',
            coalesce((select test_mode from public.app_settings where id = 1), true) or coalesce(p_simulated, false),
            'crash_detection')
    returning * into v_alert;
    insert into public.alert_events (alert_id, actor_id, actor_kind, event, note)
    values (v_alert.id, v_uid, 'system', 'raised', 'vehicle');
  end if;
  insert into public.alert_events (alert_id, actor_id, actor_kind, event, note)
  values (v_alert.id, v_uid, 'system', 'crash_detected', v_note);

  if p_lat is not null and p_lng is not null then
    update public.alerts
       set lat = p_lat, lng = p_lng, accuracy_m = p_accuracy, location_updated_at = now()
     where id = v_alert.id;
    insert into public.alert_locations (alert_id, lat, lng, accuracy_m)
    values (v_alert.id, p_lat, p_lng, p_accuracy);
  end if;

  return v_alert.id;
end $$;

-- Phone service: keep the location of the open alert up to date.
create or replace function public.crash_alert_location(
  p_key      text,
  p_lat      double precision,
  p_lng      double precision,
  p_accuracy real default null
) returns void
language plpgsql security definer set search_path = public as $$
declare
  v_uid   uuid := private.crash_device_user(p_key);
  v_alert uuid;
begin
  if v_uid is null then raise exception 'Crash detection is not registered for this phone.'; end if;
  update public.alerts
     set lat = p_lat, lng = p_lng, accuracy_m = p_accuracy, location_updated_at = now()
   where id = (select id from public.alerts
                where user_id = v_uid and status not in ('closed', 'cancelled')
                order by created_at desc limit 1)
  returning id into v_alert;
  if v_alert is not null then
    insert into public.alert_locations (alert_id, lat, lng, accuracy_m)
    values (v_alert, p_lat, p_lng, p_accuracy);
  end if;
end $$;

-- Phone service: the client tapped "I'm OK" during the countdown. No alert is sent.
create or replace function public.log_crash_cancelled(
  p_key       text,
  p_peak_g    real default null,
  p_speed_kmh real default null,
  p_simulated boolean default false
) returns void
language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := private.crash_device_user(p_key);
begin
  if v_uid is null then return; end if;
  insert into private.crash_detections (user_id, outcome, simulated, peak_g, speed_kmh)
  values (v_uid, 'cancelled', coalesce(p_simulated, false), p_peak_g, p_speed_kmh);
end $$;

revoke execute on function
  public.register_crash_device(),
  public.unregister_crash_device(text),
  public.raise_crash_alert(text, double precision, double precision, real, real, real, boolean),
  public.crash_alert_location(text, double precision, double precision, real),
  public.log_crash_cancelled(text, real, real, boolean)
from public;

grant execute on function public.register_crash_device(), public.unregister_crash_device(text) to authenticated;
revoke execute on function public.register_crash_device(), public.unregister_crash_device(text) from anon;

-- The phone service calls these without a login; the device key is the proof.
grant execute on function
  public.raise_crash_alert(text, double precision, double precision, real, real, real, boolean),
  public.crash_alert_location(text, double precision, double precision, real),
  public.log_crash_cancelled(text, real, real, boolean)
to anon, authenticated;

revoke all on private.crash_devices, private.crash_detections from public, anon, authenticated;
revoke execute on function private.crash_device_user(text) from public, anon, authenticated;


-- =====================================================================
-- FireQuest – PayFast billing (one monthly subscription per family plan)
-- * The plan holder pays one monthly PayFast subscription (card debit).
-- * PayFast reports every payment to the "payfast" server function (ITN).
--   The function checks each report with PayFast, then records it here.
-- * "Paid until" decides whether the family is covered. When a debit fails
--   the holder sees "Pay now" in the app. The panic buttons always keep
--   working; the control room sees PAID / PAYMENT LATE / NOT PAID.
-- * Payments made in PayFast's sandbox (test money) stop counting as soon
--   as test mode is switched off.
-- * Anything that needs a person (a refund, a debit order that could not be
--   cancelled automatically) is listed for FireQuest admins in the app.
-- Run after 004_crash_detection.sql. (Also included in schema.sql.)
-- =====================================================================

-- Price of the Family plan (up to 4 people) and days of grace after a missed debit.
alter table public.app_settings add column if not exists plan_price numeric(10,2) not null default 199.00;
alter table public.app_settings add column if not exists grace_days int not null default 7;
alter table public.app_settings drop constraint if exists app_settings_plan_price_check;
alter table public.app_settings add constraint app_settings_plan_price_check check (plan_price >= 5);
alter table public.app_settings drop constraint if exists app_settings_grace_days_check;
alter table public.app_settings add constraint app_settings_grace_days_check check (grace_days between 0 and 30);

-- Billing details of each family plan.
alter table public.subscriptions add column if not exists paid_until timestamptz;
alter table public.subscriptions add column if not exists next_billing_date date;
alter table public.subscriptions add column if not exists billing_day int;
alter table public.subscriptions add column if not exists payfast_token text;
alter table public.subscriptions add column if not exists payfast_mode text;
alter table public.subscriptions add column if not exists monthly_amount numeric(10,2);
alter table public.subscriptions add column if not exists last_payment_at timestamptz;
alter table public.subscriptions add column if not exists last_payment_amount numeric(10,2);
alter table public.subscriptions add column if not exists payment_failed_at timestamptz;
alter table public.subscriptions add column if not exists cancelled_at timestamptz;
alter table public.subscriptions drop constraint if exists subscriptions_payfast_mode_check;
alter table public.subscriptions add constraint subscriptions_payfast_mode_check check (payfast_mode in ('sandbox', 'live'));
alter table public.subscriptions drop constraint if exists subscriptions_billing_day_check;
alter table public.subscriptions add constraint subscriptions_billing_day_check check (billing_day between 1 and 31);
update public.subscriptions set status = 'test' where status not in ('test', 'unpaid', 'active', 'cancelled');
alter table public.subscriptions drop constraint if exists subscriptions_status_check;
alter table public.subscriptions add constraint subscriptions_status_check check (status in ('test', 'unpaid', 'active', 'cancelled'));
create unique index if not exists subscriptions_payfast_token_idx on public.subscriptions (payfast_token) where payfast_token is not null;

-- Every PayFast checkout started from the app (its id is PayFast's m_payment_id).
-- "form" holds the signed PayFast form; the payment page fetches it by id.
create table if not exists private.payfast_checkouts (
  id              uuid primary key default gen_random_uuid(),
  subscription_id uuid references public.subscriptions (id) on delete set null,
  user_id         uuid references public.profiles (id) on delete set null,
  kind            text not null check (kind in ('new', 'fix')),
  amount          numeric(10,2) not null,
  mode            text not null check (mode in ('sandbox', 'live')),
  created_at      timestamptz not null default now(),
  form            jsonb,
  abandoned_at    timestamptz,
  completed_at    timestamptz,
  token           text
);
alter table private.payfast_checkouts add column if not exists form jsonb;
alter table private.payfast_checkouts add column if not exists abandoned_at timestamptz;
create index if not exists payfast_checkouts_sub_idx on private.payfast_checkouts (subscription_id, created_at desc);
create index if not exists payfast_checkouts_user_idx on private.payfast_checkouts (user_id, created_at desc);

-- Every notification PayFast sent, with what was done with it.
create table if not exists private.payfast_events (
  id              bigint generated always as identity primary key,
  received_at     timestamptz not null default now(),
  mode            text,
  valid           boolean not null,
  pf_payment_id   text,
  m_payment_id    text,
  payment_status  text,
  token           text,
  amount_gross    numeric(10,2),
  subscription_id uuid,
  outcome         text not null,
  data            jsonb
);
create index if not exists payfast_events_pf_idx on private.payfast_events (pf_payment_id);

-- Debit orders that must be stopped at PayFast (replaced by "Pay now", left over
-- from a deleted plan, or charging without being credited). The server function
-- cancels them, and retries every 15 minutes until PayFast confirms.
create table if not exists private.payfast_old_tokens (
  token           text primary key,
  mode            text not null,
  replaced_at     timestamptz not null default now(),
  cancelled_at    timestamptz,
  attempts        int not null default 0,
  last_attempt_at timestamptz,
  last_error      text
);
alter table private.payfast_old_tokens add column if not exists last_attempt_at timestamptz;

-- Things a FireQuest admin must look at in PayFast (refunds, failed cancels).
create table if not exists private.payfast_attention (
  id          bigint generated always as identity primary key,
  created_at  timestamptz not null default now(),
  kind        text not null check (kind in ('refund', 'cancel_failed', 'unknown_payment', 'plan_deleted')),
  message     text not null,
  token       text,
  pf_payment_id text,
  client      text,
  resolved_at timestamptz,
  resolved_by uuid
);
alter table private.payfast_attention add column if not exists client text;

-- A random key that only the database and the server function know; the 15-minute
-- clean-up job sends it, so nobody else can start the clean-up.
create table if not exists private.payfast_settings (
  id        int primary key default 1 check (id = 1),
  retry_key text not null default encode(extensions.gen_random_bytes(24), 'hex')
);
insert into private.payfast_settings (id) values (1) on conflict (id) do nothing;

revoke all on private.payfast_checkouts, private.payfast_events, private.payfast_old_tokens, private.payfast_attention,
  private.payfast_settings from public, anon, authenticated;

-- Who a PayFast debit order belongs to, for messages to FireQuest admins:
-- the client's name and email as PayFast reported them, or the plan holder.
create or replace function private.payfast_token_client(p_token text)
returns text language sql stable security definer set search_path = public as $$
  select coalesce(
    (select nullif(trim(coalesce(e.data ->> 'name_first', '') || ' ' || coalesce(e.data ->> 'name_last', '')
                        || coalesce(' <' || nullif(e.data ->> 'email_address', '') || '>', '')), '')
       from private.payfast_events e
      where e.token = p_token and e.valid and e.data is not null
      order by e.received_at desc limit 1),
    (select nullif(trim(coalesce(p.full_name, '') || coalesce(' <' || p.email || '>', '')), '')
       from public.subscriptions s join public.profiles p on p.id = s.owner_id
      where s.payfast_token = p_token limit 1),
    'unknown client')
$$;

-- ---------------------------------------------------------------------
-- Dates. Debits run on the same day every month (the day the debit order
-- started; shorter months use their last day). A plan is paid until the end
-- of the day after its next debit day, South African time.
-- ---------------------------------------------------------------------
create or replace function private.sa_today()
returns date language sql stable set search_path = public as $$
  select (now() at time zone 'Africa/Johannesburg')::date
$$;

create or replace function private.add_billing_month(p_date date, p_day int)
returns date language sql immutable set search_path = public as $$
  select (date_trunc('month', p_date::timestamp) + interval '1 month')::date
         + (least(p_day, extract(day from date_trunc('month', p_date::timestamp) + interval '2 months' - interval '1 day')::int) - 1)
$$;

create or replace function private.cover_until(p_next_billing date)
returns timestamptz language sql immutable set search_path = public as $$
  select ((p_next_billing + 2)::timestamp) at time zone 'Africa/Johannesburg'
$$;

-- ---------------------------------------------------------------------
-- Billing state of a plan:
--   test            free test plan (only while test mode is on)
--   active          paid, monthly debit running
--   payment_failed  still paid up, but the last debit failed
--   cancelled_paid  debit order cancelled, still paid up for now
--   overdue         paid period ended, inside the grace days
--   unpaid          never paid
--   lapsed          paid period and grace days are over
--   cancelled       debit order cancelled and paid period over
-- ---------------------------------------------------------------------
create or replace function private.billing_paid_until(s public.subscriptions)
returns timestamptz language sql stable set search_path = public as $$
  select case when coalesce(s.payfast_mode, 'sandbox') = 'sandbox'
               and not coalesce((select test_mode from public.app_settings where id = 1), true)
              then null else s.paid_until end
$$;

create or replace function private.billing_state(s public.subscriptions)
returns text language plpgsql stable set search_path = public as $$
declare
  v_test  boolean := coalesce((select test_mode from public.app_settings where id = 1), true);
  v_grace interval := make_interval(days => coalesce((select grace_days from public.app_settings where id = 1), 7));
  v_paid  timestamptz := private.billing_paid_until(s);
begin
  if s.id is null then return 'none'; end if;
  if v_paid is not null and v_paid > now() then
    if s.status = 'cancelled' then return 'cancelled_paid'; end if;
    if s.payment_failed_at is not null then return 'payment_failed'; end if;
    return 'active';
  end if;
  if v_paid is not null and v_paid + v_grace > now() and s.status <> 'cancelled' then return 'overdue'; end if;
  if v_paid is null and s.status = 'test' and v_test then return 'test'; end if;
  if s.status = 'cancelled' then return 'cancelled'; end if;
  if v_paid is null then return 'unpaid'; end if;
  return 'lapsed';
end $$;

-- Short label the control room sees.
create or replace function private.billing_label(p_state text)
returns text language sql immutable set search_path = public as $$
  select case
    when p_state in ('active', 'payment_failed', 'cancelled_paid') then 'PAID'
    when p_state = 'overdue' then 'PAYMENT LATE'
    when p_state = 'test' then 'TEST PLAN'
    when p_state = 'none' then 'NO SUBSCRIPTION'
    else 'NOT PAID' end
$$;

-- Queue a debit order to be stopped at PayFast.
create or replace function private.payfast_queue_cancel(p_token text, p_mode text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if p_token is null then return; end if;
  insert into private.payfast_old_tokens (token, mode) values (p_token, coalesce(p_mode, 'sandbox'))
  on conflict (token) do update set cancelled_at = null, attempts = 0, last_attempt_at = null, last_error = null;
end $$;

-- A plan that is deleted (person joins another family, or the account is deleted)
-- must not leave a debit order running.
create or replace function private.subscription_deleted()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if old.payfast_token is not null then
    perform private.payfast_queue_cancel(old.payfast_token, old.payfast_mode);
    if old.payfast_mode = 'live' then
      insert into private.payfast_attention (kind, message, token, client)
      values ('plan_deleted', 'A family plan with a running debit order was deleted. FireQuest is cancelling the debit order at PayFast automatically; check in PayFast that subscription '
              || old.payfast_token || ' is cancelled.', old.payfast_token,
              coalesce((select nullif(trim(coalesce(full_name, '') || coalesce(' <' || email || '>', '')), '')
                          from public.profiles where id = old.owner_id), private.payfast_token_client(old.payfast_token)));
    end if;
  end if;
  return old;
end $$;

drop trigger if exists subscription_deleted on public.subscriptions;
create trigger subscription_deleted before delete on public.subscriptions
  for each row execute function private.subscription_deleted();

-- ---------------------------------------------------------------------
-- App: billing status for the signed-in person.
-- The plan holder sees everything; family members only see who pays.
-- ---------------------------------------------------------------------
create or replace function public.my_billing()
returns json language plpgsql stable security definer set search_path = public as $$
declare
  v_uid   uuid := auth.uid();
  v_set   public.app_settings;
  v_sub   public.subscriptions;
  v_state text;
  v_paid  timestamptz;
begin
  if v_uid is null then raise exception 'Not signed in'; end if;
  select * into v_set from public.app_settings where id = 1;
  select s.* into v_sub
    from public.subscription_members m join public.subscriptions s on s.id = m.subscription_id
   where m.user_id = v_uid;
  if not found then
    return json_build_object('in_plan', false, 'is_owner', false, 'state', 'none',
                             'label', private.billing_label('none'), 'covered', false,
                             'price', v_set.plan_price, 'test_mode', v_set.test_mode);
  end if;

  v_state := private.billing_state(v_sub);
  v_paid  := private.billing_paid_until(v_sub);

  if v_sub.owner_id <> v_uid then
    return json_build_object('in_plan', true, 'is_owner', false, 'state', v_state,
      'label', private.billing_label(v_state),
      'covered', v_state in ('test', 'active', 'payment_failed', 'cancelled_paid', 'overdue'),
      'owner_name', (select full_name from public.profiles where id = v_sub.owner_id),
      'test_mode', v_set.test_mode);
  end if;

  return json_build_object(
    'in_plan', true,
    'is_owner', true,
    'state', v_state,
    'label', private.billing_label(v_state),
    'covered', v_state in ('test', 'active', 'payment_failed', 'cancelled_paid', 'overdue'),
    'price', v_set.plan_price,
    'monthly_amount', v_sub.monthly_amount,
    'paid_until', v_paid,
    'next_debit', case when v_paid is null or v_sub.status <> 'active' then null else v_sub.next_billing_date end,
    'grace_until', v_paid + make_interval(days => v_set.grace_days),
    'last_payment_at', case when v_paid is null then null else v_sub.last_payment_at end,
    'last_payment_amount', case when v_paid is null then null else v_sub.last_payment_amount end,
    'payment_failed_at', v_sub.payment_failed_at,
    'cancelled_at', v_sub.cancelled_at,
    'mode', v_sub.payfast_mode,
    'has_debit_order', v_sub.payfast_token is not null and v_sub.status = 'active',
    'test_mode', v_set.test_mode,
    'pending_since', (
      select max(c.created_at) from private.payfast_checkouts c
       where c.subscription_id = v_sub.id and c.completed_at is null and c.abandoned_at is null
         and c.created_at > now() - interval '30 minutes'
         and c.created_at > coalesce(v_sub.last_payment_at, '-infinity'::timestamptz))
  );
end $$;

-- ---------------------------------------------------------------------
-- Control room: payment status of the client who raised an alert.
-- ---------------------------------------------------------------------
create or replace function public.alert_billing(p_alert_id uuid)
returns json language plpgsql stable security definer set search_path = public as $$
declare
  v_client uuid;
  v_sub    public.subscriptions;
  v_state  text;
begin
  if not public.is_staff() then raise exception 'Not authorised'; end if;
  select user_id into v_client from public.alerts where id = p_alert_id;
  if v_client is null then return null; end if;
  select s.* into v_sub
    from public.subscription_members m join public.subscriptions s on s.id = m.subscription_id
   where m.user_id = v_client;
  v_state := private.billing_state(v_sub);
  return json_build_object(
    'state', v_state,
    'label', private.billing_label(v_state),
    'paid_until', private.billing_paid_until(v_sub),
    'holder_name', (select full_name from public.profiles where id = v_sub.owner_id),
    'client_is_holder', v_sub.owner_id = v_client);
end $$;

-- ---------------------------------------------------------------------
-- FireQuest admins: payments that need a person (refunds, failed cancels).
-- ---------------------------------------------------------------------
create or replace function public.payments_attention()
returns json language plpgsql stable security definer set search_path = public as $$
begin
  if not exists (select 1 from public.staff where user_id = auth.uid() and role = 'admin') then
    raise exception 'Not authorised';
  end if;
  return (
    select coalesce(json_agg(json_build_object('id', a.id, 'kind', a.kind, 'message', a.message,
                                               'created_at', a.created_at, 'pf_payment_id', a.pf_payment_id,
                                               'token', a.token, 'client', a.client)
                             order by a.created_at desc), '[]'::json)
      from private.payfast_attention a
     where a.resolved_at is null);
end $$;

create or replace function public.payments_attention_done(p_id bigint)
returns json language plpgsql security definer set search_path = public as $$
begin
  if not exists (select 1 from public.staff where user_id = auth.uid() and role = 'admin') then
    raise exception 'Not authorised';
  end if;
  update private.payfast_attention set resolved_at = now(), resolved_by = auth.uid()
   where id = p_id and resolved_at is null;
  return public.payments_attention();
end $$;

-- ---------------------------------------------------------------------
-- Test mode only: let the plan holder try the "payment problem" screens.
--   failed  = this month's debit failed (still paid up for 2 days)
--   late    = paid period ended yesterday (inside the grace days)
--   lapsed  = not paid for longer than the grace days
--   reset   = back to a free test plan
-- Everything set here counts as sandbox (test) payments only.
-- ---------------------------------------------------------------------
create or replace function public.billing_test(p_what text)
returns json language plpgsql security definer set search_path = public as $$
declare
  v_uid   uuid := auth.uid();
  v_sub   public.subscriptions;
  v_grace int := coalesce((select grace_days from public.app_settings where id = 1), 7);
  v_next  date;
begin
  if v_uid is null then raise exception 'Not signed in'; end if;
  if not coalesce((select test_mode from public.app_settings where id = 1), false) then
    raise exception 'Payment tests are only available in test mode.';
  end if;
  select * into v_sub from public.subscriptions where owner_id = v_uid for update;
  if not found then raise exception 'Start a family plan first.'; end if;
  if v_sub.payfast_mode = 'live' then raise exception 'This plan has real PayFast payments. Tests are not allowed on it.'; end if;

  if p_what in ('failed', 'late', 'lapsed') then
    v_next := case p_what when 'failed' then private.sa_today()
                          when 'late' then private.sa_today() - 3
                          else private.sa_today() - v_grace - 3 end;
    update public.subscriptions set
      next_billing_date = v_next,
      billing_day       = coalesce(billing_day, extract(day from v_next)::int),
      paid_until        = private.cover_until(v_next),
      payment_failed_at = now(),
      payfast_mode      = 'sandbox',
      status            = case when status = 'cancelled' then 'active' else status end,
      cancelled_at      = null
     where id = v_sub.id;
  elsif p_what = 'reset' then
    perform private.payfast_queue_cancel(v_sub.payfast_token, 'sandbox');
    update public.subscriptions set status = 'test', paid_until = null, next_billing_date = null, billing_day = null,
           payfast_token = null, payfast_mode = null, monthly_amount = null, last_payment_at = null,
           last_payment_amount = null, payment_failed_at = null, cancelled_at = null
     where id = v_sub.id;
  else
    raise exception 'Unknown test %', p_what;
  end if;
  return public.my_billing();
end $$;

-- ---------------------------------------------------------------------
-- Server function only (not reachable from the apps).
-- ---------------------------------------------------------------------

-- Start a PayFast checkout for the plan holder. Creates the plan when the person has none.
create or replace function private.payfast_start_checkout(p_uid uuid, p_mode text)
returns json language plpgsql security definer set search_path = public as $$
declare
  v_set   public.app_settings;
  v_prof  public.profiles;
  v_sub   public.subscriptions;
  v_state text;
  v_kind  text;
  v_co    uuid;
  v_email text;
begin
  if p_mode not in ('sandbox', 'live') then raise exception 'Unknown PayFast mode'; end if;
  select * into v_set from public.app_settings where id = 1;
  select * into v_prof from public.profiles where id = p_uid;
  if not found then raise exception 'Finish your FireQuest registration first.'; end if;
  if p_mode = 'sandbox' and not v_set.test_mode then
    raise exception 'Payments are being set up. Please try again later or phone FireQuest.';
  end if;
  if p_mode = 'live' and v_set.test_mode then
    raise exception 'FireQuest is still in test mode. Real payments start when FireQuest goes live.';
  end if;
  if (select count(*) from private.payfast_checkouts
       where user_id = p_uid and created_at > now() - interval '1 hour') >= 15 then
    raise exception 'Too many payment attempts. Please wait an hour or phone FireQuest.';
  end if;

  select s.* into v_sub
    from public.subscription_members m join public.subscriptions s on s.id = m.subscription_id
   where m.user_id = p_uid
     for update of s;
  if found and v_sub.owner_id <> p_uid then
    raise exception 'Your family plan is paid by %. Only the plan holder can pay.',
      coalesce(nullif((select full_name from public.profiles where id = v_sub.owner_id), ''), 'the plan holder');
  end if;
  if not found then
    insert into public.subscriptions (owner_id, status)
    values (p_uid, case when v_set.test_mode then 'test' else 'unpaid' end)
    returning * into v_sub;
    insert into public.subscription_members (subscription_id, user_id, role, relationship)
    values (v_sub.id, p_uid, 'owner', 'holder');
  end if;

  v_state := private.billing_state(v_sub);
  if v_state = 'active' and v_sub.payfast_token is not null and v_sub.payfast_mode = p_mode then
    raise exception 'Your subscription is paid and the monthly debit order is running. There is nothing to pay now.';
  end if;

  v_kind := case when v_sub.payfast_token is not null and v_sub.status = 'active' then 'fix' else 'new' end;
  insert into private.payfast_checkouts (subscription_id, user_id, kind, amount, mode)
  values (v_sub.id, p_uid, v_kind, v_set.plan_price, p_mode)
  returning id into v_co;

  select email into v_email from auth.users where id = p_uid;
  return json_build_object(
    'm_payment_id', v_co,
    'subscription_id', v_sub.id,
    'kind', v_kind,
    'amount', to_char(v_set.plan_price, 'FM999990.00'),
    'full_name', v_prof.full_name,
    'email', coalesce(v_email, v_prof.email, ''));
end $$;

-- The signed form is kept with the checkout; the payment page fetches it (for 2 hours).
create or replace function private.payfast_save_form(p_id uuid, p_form jsonb)
returns void language sql security definer set search_path = public as $$
  update private.payfast_checkouts set form = p_form where id = p_id
$$;

create or replace function private.payfast_checkout_form(p_id uuid)
returns jsonb language sql stable security definer set search_path = public as $$
  select form from private.payfast_checkouts
   where id = p_id and completed_at is null and abandoned_at is null
     and created_at > now() - interval '2 hours'
$$;

-- The client cancelled on PayFast's page: stop showing "waiting for PayFast".
create or replace function private.payfast_checkout_abandoned(p_id uuid)
returns void language sql security definer set search_path = public as $$
  update private.payfast_checkouts set abandoned_at = coalesce(abandoned_at, now())
   where id = p_id and completed_at is null
$$;

-- Token for PayFast's "update card" page (plan holder with a running debit order).
create or replace function private.payfast_card_token(p_uid uuid)
returns json language plpgsql stable security definer set search_path = public as $$
declare
  v_sub public.subscriptions;
begin
  select * into v_sub from public.subscriptions where owner_id = p_uid;
  if not found or v_sub.payfast_token is null or v_sub.status <> 'active' then
    raise exception 'There is no monthly debit order to update. Tap "Pay now" instead.';
  end if;
  return json_build_object('token', v_sub.payfast_token, 'mode', v_sub.payfast_mode);
end $$;

-- Record a PayFast notification (ITN) that the server function has already checked.
-- Returns the outcome, and a debit order to cancel at PayFast (if any).
create or replace function private.payfast_apply_itn(p_data jsonb, p_mode text, p_valid boolean, p_note text default null)
returns json language plpgsql security definer set search_path = public as $$
declare
  v_status  text := upper(coalesce(p_data ->> 'payment_status', ''));
  v_pf      text := nullif(p_data ->> 'pf_payment_id', '');
  v_mpid    text := nullif(p_data ->> 'm_payment_id', '');
  v_token   text := nullif(p_data ->> 'token', '');
  v_custom  text := nullif(p_data ->> 'custom_str1', '');
  v_price   numeric := (select plan_price from public.app_settings where id = 1);
  v_amount  numeric;
  v_co      private.payfast_checkouts;
  v_sub     public.subscriptions;
  v_outcome text;
  v_cancel  text;
  v_cmode   text;
  v_refund  boolean := false;
  v_new     boolean := false;
  v_day     int;
  v_base    date;
  v_next    date;
  v_today   date := private.sa_today();
begin
  begin
    v_amount := nullif(p_data ->> 'amount_gross', '')::numeric;
  exception when others then
    v_amount := null;
  end;

  if not coalesce(p_valid, false) then
    insert into private.payfast_events (mode, valid, pf_payment_id, m_payment_id, payment_status, token, amount_gross, outcome)
    values (p_mode, false, left(v_pf, 64), left(v_mpid, 64), left(v_status, 20), left(v_token, 64), v_amount,
            left('rejected: ' || coalesce(p_note, 'failed the PayFast checks'), 300));
    return json_build_object('outcome', 'rejected');
  end if;

  if v_mpid ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$' then
    select * into v_co from private.payfast_checkouts where id = v_mpid::uuid;
  end if;
  if v_token is not null then
    select * into v_sub from public.subscriptions where payfast_token = v_token for update;
  end if;
  if v_sub.id is null and v_co.subscription_id is not null then
    select * into v_sub from public.subscriptions where id = v_co.subscription_id for update;
  end if;
  if v_sub.id is null and v_custom ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$' then
    select * into v_sub from public.subscriptions where id = v_custom::uuid for update;
  end if;

  if v_status = 'CANCELLED' and v_token is not null then
    update private.payfast_old_tokens set cancelled_at = coalesce(cancelled_at, now()) where token = v_token;
  end if;

  if v_pf is not null and exists (
      select 1 from private.payfast_events
       where pf_payment_id = v_pf and payment_status = v_status and valid) then
    v_outcome := 'duplicate';
  elsif v_status = 'COMPLETE' then
    if v_sub.id is not null and v_token is not null and v_token = v_sub.payfast_token then
      -- A monthly debit on the current debit order.
      if v_amount is null or v_amount < least(coalesce(v_sub.monthly_amount, v_price), v_price) - 0.01 then
        v_outcome := 'ignored: monthly payment smaller than the plan price';
        v_refund := true;
      elsif v_sub.payfast_mode is distinct from p_mode then
        v_outcome := 'ignored: payment from the other PayFast mode';
      end if;
    else
      -- The first payment of a new checkout: it must be ours, unused, and the full amount.
      if v_token is not null and exists (select 1 from private.payfast_old_tokens o where o.token = v_token) then
        v_outcome := 'ignored: payment on a stopped debit order';
      elsif v_co.id is null then
        v_outcome := 'ignored: unknown checkout';
      elsif v_sub.id is null then
        v_outcome := 'ignored: the family plan no longer exists';
      elsif v_co.mode <> p_mode then
        v_outcome := 'ignored: checkout was made in the other PayFast mode';
      elsif v_sub.payfast_mode = 'live' and p_mode = 'sandbox' then
        v_outcome := 'ignored: sandbox payment on a live plan';
      elsif v_co.completed_at is not null then
        v_outcome := 'ignored: this checkout was already paid';
      elsif v_co.subscription_id is distinct from v_sub.id then
        v_outcome := 'ignored: checkout belongs to another plan';
      elsif v_amount is null or v_amount < v_co.amount - 0.01 then
        v_outcome := 'ignored: amount too low';
      else
        v_new := true;
      end if;
      if v_outcome is not null then
        v_refund := true;
        -- Money was taken but nothing is credited: stop that debit order (only ones FireQuest started).
        if v_token is not null and v_co.id is not null then
          v_cancel := v_token;
          v_cmode  := p_mode;
          perform private.payfast_queue_cancel(v_token, p_mode);
        end if;
      end if;
    end if;

    if v_outcome is null then
      if v_new then
        -- New debit order: it replaces the old one, and debits on this day each month.
        if v_token is not null and v_sub.payfast_token is not null and v_sub.payfast_token <> v_token then
          v_cancel := v_sub.payfast_token;
          v_cmode  := coalesce(v_sub.payfast_mode, p_mode);
          perform private.payfast_queue_cancel(v_cancel, v_cmode);
        end if;
        v_day := extract(day from v_today)::int;
        v_base := v_today;
        if v_sub.payfast_mode = p_mode and v_sub.next_billing_date > v_today then
          v_base := v_sub.next_billing_date;  -- still paid up: add the new month on top
        end if;
      else
        v_day := coalesce(v_sub.billing_day, extract(day from v_today)::int);
        v_base := coalesce(v_sub.next_billing_date, v_today);
        if v_base < v_today - 10 then v_base := v_today; end if;  -- a very late debit counts from today
      end if;
      v_next := private.add_billing_month(v_base, v_day);
      update public.subscriptions set
        status              = 'active',
        payfast_mode        = p_mode,
        payfast_token       = coalesce(v_token, payfast_token),
        billing_day         = v_day,
        next_billing_date   = v_next,
        paid_until          = private.cover_until(v_next),
        monthly_amount      = case when v_new then v_co.amount else monthly_amount end,
        last_payment_at     = now(),
        last_payment_amount = v_amount,
        payment_failed_at   = null,
        cancelled_at        = null
      where id = v_sub.id;
      if v_co.id is not null and v_new then
        update private.payfast_checkouts set completed_at = now(), token = v_token where id = v_co.id;
      end if;
      v_outcome := 'applied: paid';
    end if;
  elsif v_sub.id is null then
    v_outcome := 'ignored: no matching family plan';
  elsif v_status = 'FAILED' then
    if v_token is not null and v_token = v_sub.payfast_token then
      if v_sub.last_payment_at > now() - interval '20 days' then
        v_outcome := 'ignored: failed debit, but a later payment went through';
      else
        update public.subscriptions set payment_failed_at = now() where id = v_sub.id;
        v_outcome := 'applied: debit failed';
      end if;
    else
      v_outcome := 'ignored: failed payment that never started a debit order';
    end if;
  elsif v_status = 'CANCELLED' then
    if v_token is not null and v_token = v_sub.payfast_token then
      update public.subscriptions set status = 'cancelled', cancelled_at = now(), payfast_token = null where id = v_sub.id;
      v_outcome := 'applied: debit order cancelled';
    else
      v_outcome := 'ignored: an old debit order was cancelled';
    end if;
  elsif v_status = 'PENDING' then
    v_outcome := 'recorded: pending';
  else
    v_outcome := 'ignored: unknown payment status';
  end if;

  if v_refund and p_mode = 'live' then
    insert into private.payfast_attention (kind, message, token, pf_payment_id, client)
    values (case when v_co.id is null and v_sub.id is null then 'unknown_payment' else 'refund' end,
            'PayFast payment ' || coalesce(v_pf, '?') || ' of R' || coalesce(to_char(v_amount, 'FM999990.00'), '?')
              || ' was not credited to any plan (' || replace(v_outcome, 'ignored: ', '') || '). Check it in PayFast and refund it if needed.'
              || case when v_cancel is not null then ' Its debit order (subscription ' || v_cancel || ') is being cancelled automatically.' else '' end,
            v_token, v_pf,
            nullif(trim(coalesce(p_data ->> 'name_first', '') || ' ' || coalesce(p_data ->> 'name_last', '')
                        || coalesce(' <' || nullif(p_data ->> 'email_address', '') || '>', '')), ''));
  end if;

  insert into private.payfast_events
    (mode, valid, pf_payment_id, m_payment_id, payment_status, token, amount_gross, subscription_id, outcome, data)
  values (p_mode, true, v_pf, v_mpid, v_status, v_token, v_amount, v_sub.id,
          v_outcome || coalesce(' (' || p_note || ')', ''), p_data);

  return json_build_object('outcome', v_outcome, 'cancel_token', v_cancel, 'cancel_mode', v_cmode);
end $$;

-- Debit orders still waiting to be cancelled at PayFast (each retried at most every 15 minutes).
drop function if exists private.payfast_tokens_to_cancel(int);
create or replace function private.payfast_tokens_to_cancel(p_limit int default 3)
returns table (token text, mode text) language sql volatile security definer set search_path = public as $$
  update private.payfast_old_tokens o set last_attempt_at = now()
   where o.token in (
     select t.token from private.payfast_old_tokens t
      where t.cancelled_at is null and t.attempts < 30 and t.replaced_at > now() - interval '90 days'
        and (t.last_attempt_at is null or t.last_attempt_at < now() - interval '15 minutes')
      order by t.replaced_at limit p_limit
      for update skip locked)
  returning o.token, o.mode
$$;

-- Claim one debit order for an immediate cancel (false when another clean-up is already on it).
create or replace function private.payfast_claim_token(p_token text)
returns boolean language sql volatile security definer set search_path = public as $$
  with c as (
    update private.payfast_old_tokens set last_attempt_at = now()
     where token = p_token and cancelled_at is null
       and (last_attempt_at is null or last_attempt_at < now() - interval '15 minutes')
    returning 1)
  select exists (select 1 from c)
$$;

create or replace function private.payfast_retry_key_ok(p_key text)
returns boolean language sql stable security definer set search_path = public as $$
  select coalesce(p_key, '') <> '' and exists (select 1 from private.payfast_settings where id = 1 and retry_key = p_key)
$$;

create or replace function private.payfast_token_cancel_result(p_token text, p_ok boolean, p_error text default null)
returns void language plpgsql security definer set search_path = public as $$
declare
  v_row private.payfast_old_tokens;
begin
  update private.payfast_old_tokens
     set cancelled_at    = case when p_ok then coalesce(cancelled_at, now()) else cancelled_at end,
         attempts        = attempts + 1,
         last_attempt_at = now(),
         last_error      = case when p_ok then null else left(p_error, 300) end
   where token = p_token
  returning * into v_row;
  if not p_ok and v_row.attempts = 3 and v_row.mode = 'live' then
    insert into private.payfast_attention (kind, message, token, client)
    values ('cancel_failed', 'FireQuest could not cancel an old PayFast debit order automatically (3 tries: '
            || coalesce(left(p_error, 120), 'no answer') || '). In PayFast, cancel subscription ' || p_token
            || ' so the client does not pay twice.', p_token, private.payfast_token_client(p_token));
  end if;
end $$;

-- ---------------------------------------------------------------------
-- Family plans: a holder who pays for their own plan cannot join another
-- family until that debit order is cancelled. (Replaces the version in 003.)
-- ---------------------------------------------------------------------
create or replace function public.join_subscription(p_code text)
returns json language plpgsql security definer set search_path = public as $$
declare
  v_uid     uuid := auth.uid();
  v_inv     public.family_invites;
  v_target  public.subscriptions;
  v_current public.subscriptions;
  v_phone   text;
  v_count   int;
begin
  if v_uid is null then raise exception 'Not signed in'; end if;

  select * into v_inv from public.family_invites
   where code = upper(regexp_replace(coalesce(p_code, ''), '\s', '', 'g'))
   for update;
  if not found or v_inv.expires_at < now() then
    raise exception 'That code is not valid. It may already have been used, or it expired after 7 days. Ask the plan holder to send you a new invite.';
  end if;

  select * into v_target from public.subscriptions where id = v_inv.subscription_id for update;

  select phone into v_phone from public.profiles where id = v_uid;
  if private.phone_key(v_phone) is distinct from private.phone_key(v_inv.phone) then
    raise exception 'This invite is for the cellphone number ending in %. The number on your FireQuest profile is different. Ask % to check the number, or correct your number under Profile > Edit my details.',
      right(regexp_replace(v_inv.phone, '\D', '', 'g'), 4),
      coalesce(nullif((select full_name from public.profiles where id = v_target.owner_id), ''), 'the plan holder');
  end if;

  select s.* into v_current
    from public.subscription_members m join public.subscriptions s on s.id = m.subscription_id
   where m.user_id = v_uid;
  if found then
    if v_current.id = v_target.id then raise exception 'You are already on this family plan.'; end if;
    if v_current.owner_id <> v_uid then
      raise exception 'You are on another family plan. Leave it first (Account > Family plan > Leave).';
    end if;
    if exists (select 1 from public.subscription_members where subscription_id = v_current.id and user_id <> v_uid)
       or exists (select 1 from public.family_invites where subscription_id = v_current.id) then
      raise exception 'You hold your own family plan with other people on it. Remove them and cancel their invites first.';
    end if;
    if v_current.status = 'active' and v_current.payfast_token is not null then
      raise exception 'You pay for your own FireQuest plan with a monthly debit order. Ask FireQuest to cancel it first, then join this family plan.';
    end if;
    delete from public.subscriptions where id = v_current.id;
  end if;

  select count(*) into v_count from public.subscription_members where subscription_id = v_target.id;
  if v_count >= v_target.max_members then
    raise exception 'This family plan is full (% people).', v_target.max_members;
  end if;

  insert into public.subscription_members (subscription_id, user_id, role, relationship)
  values (v_target.id, v_uid, 'member', v_inv.relationship);
  delete from public.family_invites where id = v_inv.id;
  return public.my_subscription();
end $$;

-- ---------------------------------------------------------------------
-- Permissions
-- ---------------------------------------------------------------------
revoke execute on function
  public.my_billing(),
  public.alert_billing(uuid),
  public.payments_attention(),
  public.payments_attention_done(bigint),
  public.billing_test(text),
  public.join_subscription(text)
from public, anon;

grant execute on function
  public.my_billing(),
  public.alert_billing(uuid),
  public.payments_attention(),
  public.payments_attention_done(bigint),
  public.billing_test(text),
  public.join_subscription(text)
to authenticated;

revoke execute on function
  private.sa_today(),
  private.add_billing_month(date, int),
  private.cover_until(date),
  private.billing_paid_until(public.subscriptions),
  private.billing_state(public.subscriptions),
  private.billing_label(text),
  private.payfast_queue_cancel(text, text),
  private.subscription_deleted(),
  private.payfast_start_checkout(uuid, text),
  private.payfast_save_form(uuid, jsonb),
  private.payfast_checkout_form(uuid),
  private.payfast_checkout_abandoned(uuid),
  private.payfast_card_token(uuid),
  private.payfast_apply_itn(jsonb, text, boolean, text),
  private.payfast_tokens_to_cancel(int),
  private.payfast_claim_token(text),
  private.payfast_retry_key_ok(text),
  private.payfast_token_client(text),
  private.payfast_token_cancel_result(text, boolean, text)
from public, anon, authenticated;


-- =====================================================================
-- FireQuest – more profile details for responders
-- * Selfie, so responders can recognise the client. Stored in a private
--   storage bucket "selfies" as <user id>/selfie.jpg. Only the client and
--   the control room (while that client has an alert open, or for 24 hours
--   after raising one) can see it.
-- * Number of people in the household; pets at the home (inside or in the
--   yard; column pets_inside) and whether any are dangerous; insurance details.
-- * Home pin: the client drops a pin on a map at their home, because
--   addresses in remote areas are often not found by Google Maps.
-- Run after 005_payfast.sql. (Also included in schema.sql.)
-- =====================================================================

alter table public.profiles add column if not exists household_size int;
alter table public.profiles add column if not exists pets_inside int;
alter table public.profiles add column if not exists pets_dangerous boolean not null default false;
alter table public.profiles add column if not exists pets_notes text;
alter table public.profiles add column if not exists insurance_company text;
alter table public.profiles add column if not exists insurance_policy_number text;
alter table public.profiles add column if not exists insurance_phone text;
alter table public.profiles add column if not exists insurance_cover text;
-- When the selfie was last changed (empty = no selfie). The file is always <user id>/selfie.jpg.
alter table public.profiles add column if not exists selfie_updated_at timestamptz;
-- Exact position of the home, placed by the client on a map.
alter table public.profiles add column if not exists home_lat double precision;
alter table public.profiles add column if not exists home_lng double precision;
alter table public.profiles add column if not exists home_pin_at timestamptz;

alter table public.profiles drop constraint if exists profiles_household_size_check;
alter table public.profiles add constraint profiles_household_size_check check (household_size between 1 and 30);
alter table public.profiles drop constraint if exists profiles_pets_inside_check;
alter table public.profiles add constraint profiles_pets_inside_check check (pets_inside between 0 and 50);
alter table public.profiles drop constraint if exists profiles_text_lengths_check;
alter table public.profiles add constraint profiles_text_lengths_check check (
  coalesce(length(pets_notes), 0) <= 300
  and coalesce(length(insurance_company), 0) <= 120
  and coalesce(length(insurance_policy_number), 0) <= 60
  and coalesce(length(insurance_phone), 0) <= 30
  and coalesce(length(insurance_cover), 0) <= 200);
alter table public.profiles drop constraint if exists profiles_home_pin_check;
alter table public.profiles add constraint profiles_home_pin_check check (
  (home_lat is null and home_lng is null)
  or (home_lat is not null and home_lng is not null
      and home_lat between -90 and 90 and home_lng between -180 and 180));

-- Private bucket for selfies (JPEG, at most 2 MB each).
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('selfies', 'selfies', false, 2097152, array['image/jpeg'])
on conflict (id) do update set public = false, file_size_limit = 2097152, allowed_mime_types = array['image/jpeg'];

drop policy if exists "selfies: view own, or staff during an alert" on storage.objects;
drop policy if exists "selfies: upload own" on storage.objects;
drop policy if exists "selfies: replace own" on storage.objects;
drop policy if exists "selfies: delete own" on storage.objects;

create policy "selfies: view own, or staff during an alert" on storage.objects
  for select to authenticated
  using (
    bucket_id = 'selfies'
    and case
          when name = auth.uid()::text || '/selfie.jpg' then true
          when name ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/selfie\.jpg$'
            then public.staff_can_view(split_part(name, '/', 1)::uuid)
          else false
        end
  );

create policy "selfies: upload own" on storage.objects
  for insert to authenticated
  with check (bucket_id = 'selfies' and name = auth.uid()::text || '/selfie.jpg');

create policy "selfies: replace own" on storage.objects
  for update to authenticated
  using (bucket_id = 'selfies' and name = auth.uid()::text || '/selfie.jpg')
  with check (bucket_id = 'selfies' and name = auth.uid()::text || '/selfie.jpg');

create policy "selfies: delete own" on storage.objects
  for delete to authenticated
  using (bucket_id = 'selfies' and name = auth.uid()::text || '/selfie.jpg');
-- =====================================================================
-- FireQuest – control-room alarm on staff phones, also when the app is closed
-- A FireQuest staff member switches "Alarm when the app is closed" on, on
-- their phone (Control room tab). The phone then runs a background service
-- that asks FireQuest every 20 seconds for alerts nobody has acknowledged,
-- and rings loudly until one is acknowledged. Like crash detection, the
-- service uses its own device key (no login); only a hash is stored.
-- Run after 007_remove_safe_areas.sql (or 006 on a database that never had safe areas). Also included in schema.sql.
-- =====================================================================

create table if not exists private.control_room_devices (
  key_hash     text primary key,
  user_id      uuid not null references public.profiles (id) on delete cascade,
  created_at   timestamptz not null default now(),
  last_seen_at timestamptz
);
create index if not exists control_room_devices_user_idx on private.control_room_devices (user_id);
revoke all on private.control_room_devices from public, anon, authenticated;

-- Staff, signed in: register this phone. Keeps the 3 newest phones per staff member.
create or replace function public.register_control_room_device()
returns text language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
  v_key text;
begin
  if v_uid is null or not public.is_staff() then raise exception 'Only FireQuest control-room staff can do this.'; end if;
  v_key := encode(extensions.gen_random_bytes(32), 'hex');
  insert into private.control_room_devices (key_hash, user_id, last_seen_at)
  values (encode(extensions.digest(v_key, 'sha256'), 'hex'), v_uid, now());
  delete from private.control_room_devices
   where user_id = v_uid
     and key_hash not in (select key_hash from private.control_room_devices
                           where user_id = v_uid order by created_at desc limit 3);
  return v_key;
end $$;

-- Signed in: switch off on this phone.
create or replace function public.unregister_control_room_device(p_key text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'Not signed in'; end if;
  delete from private.control_room_devices
   where user_id = auth.uid()
     and key_hash = encode(extensions.digest(coalesce(p_key, ''), 'sha256'), 'hex');
end $$;

-- Phone service (device key, no login): alerts nobody has acknowledged yet.
create or replace function public.control_room_poll(p_key text)
returns json language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid;
begin
  update private.control_room_devices d set last_seen_at = now()
   where d.key_hash = encode(extensions.digest(coalesce(p_key, ''), 'sha256'), 'hex')
     and exists (select 1 from public.staff s where s.user_id = d.user_id)
  returning d.user_id into v_uid;
  if v_uid is null then return json_build_object('registered', false); end if;
  return json_build_object(
    'registered', true,
    'alerts', coalesce((
      select json_agg(json_build_object(
               'id', a.id, 'type', a.type, 'source', a.source, 'is_test', a.is_test,
               'created_at', a.created_at, 'client', coalesce(p.full_name, 'Unknown client'))
             order by a.created_at)
        from public.alerts a
        left join public.profiles p on p.id = a.user_id
       where a.status = 'new' and a.created_at > now() - interval '24 hours'), '[]'::json));
end $$;

-- Staff, signed in: which staff phones will ring (for the Control room tab).
create or replace function public.control_room_listeners()
returns json language plpgsql stable security definer set search_path = public as $$
begin
  if not public.is_staff() then raise exception 'Not authorised'; end if;
  return coalesce((
    select json_agg(json_build_object('name', coalesce(s.display_name, p.full_name), 'last_seen_at', d.last_seen_at,
                                      'mine', d.user_id = auth.uid())
           order by d.last_seen_at desc nulls last)
      from private.control_room_devices d
      join public.staff s on s.user_id = d.user_id
      left join public.profiles p on p.id = d.user_id), '[]'::json);
end $$;

revoke execute on function
  public.register_control_room_device(),
  public.unregister_control_room_device(text),
  public.control_room_poll(text),
  public.control_room_listeners()
from public, anon;
grant execute on function
  public.register_control_room_device(),
  public.unregister_control_room_device(text),
  public.control_room_listeners()
to authenticated;
-- The phone service calls this without a login; the device key is the proof.
grant execute on function public.control_room_poll(text) to anon, authenticated;
-- =====================================================================
-- FireQuest – real price and card-expiry reminders (2 Nov 2026)
-- * The family plan (up to 4 people in one household) costs R49 a month.
-- * PayFast does not tell FireQuest when a client's card expires, so the plan
--   holder types in the card's expiry month (MM/YY – never the card number).
--   The app then reminds them before it expires, so the debit order keeps
--   working. After a payment with a new card the app asks again.
-- Run after 008_control_room_alarm.sql. (Also included in schema.sql.)
-- =====================================================================

update public.app_settings set plan_price = 49.00 where id = 1;
alter table public.app_settings alter column plan_price set default 49.00;

-- First day of the month the card expires in (the card works until the end of that month).
alter table public.subscriptions add column if not exists card_expiry date;
alter table public.subscriptions add column if not exists card_expiry_set_at timestamptz;

-- Plan holder: the card on the debit order and whether the app should ask for its expiry.
create or replace function public.my_card()
returns json language plpgsql stable security definer set search_path = public as $$
declare
  v_sub public.subscriptions;
begin
  if auth.uid() is null then raise exception 'Not signed in'; end if;
  select * into v_sub from public.subscriptions where owner_id = auth.uid();
  if not found then return json_build_object('is_owner', false); end if;
  return json_build_object(
    'is_owner', true,
    'has_debit_order', v_sub.payfast_token is not null,
    'card_expiry', v_sub.card_expiry,
    -- Ask when there is a debit order and: no expiry yet, the saved card has expired, or the client
    -- paid with a (possibly new) card through PayFast after entering it.
    'ask', v_sub.payfast_token is not null
           and (v_sub.card_expiry is null
                or v_sub.card_expiry < date_trunc('month', current_date)::date
                or exists (select 1 from private.payfast_checkouts c
                            where c.subscription_id = v_sub.id and c.completed_at is not null
                              and c.completed_at > coalesce(v_sub.card_expiry_set_at, '-infinity'::timestamptz))));
end $$;

-- Plan holder: save the card's expiry month and year (null clears it).
create or replace function public.set_card_expiry(p_month int, p_year int)
returns json language plpgsql security definer set search_path = public as $$
declare
  v_year int := case when p_year between 0 and 99 then 2000 + p_year else p_year end;
  v_date date;
begin
  if auth.uid() is null then raise exception 'Not signed in'; end if;
  if not exists (select 1 from public.subscriptions where owner_id = auth.uid()) then
    raise exception 'Only the plan holder pays, so only they can enter the card expiry.';
  end if;
  if p_month is null and p_year is null then
    v_date := null;
  else
    if p_month is null or p_month not between 1 and 12 then raise exception 'The month must be between 01 and 12.'; end if;
    v_date := make_date(v_year, p_month, 1);
    if v_date < date_trunc('month', current_date)::date then raise exception 'That card has already expired. Use a card that is still valid.'; end if;
    if v_date > (current_date + interval '15 years')::date then raise exception 'Check the year – it is too far in the future.'; end if;
  end if;
  update public.subscriptions set card_expiry = v_date, card_expiry_set_at = now() where owner_id = auth.uid();
  return public.my_card();
end $$;

revoke execute on function public.my_card(), public.set_card_expiry(int, int) from public, anon;
grant execute on function public.my_card(), public.set_card_expiry(int, int) to authenticated;
