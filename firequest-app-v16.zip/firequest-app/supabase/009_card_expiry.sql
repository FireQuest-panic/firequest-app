-- =====================================================================
-- FireQuest – real price and card-expiry reminders (2 Nov 2026)
-- * The family plan (up to 4 people in one household) costs R49 a month.
-- * PayFast does not tell FireQuest when a client's card expires, so the plan
--   holder types in the card's expiry month (MM/YY – never the card number).
--   The app then reminds them before it expires, so the debit order keeps
--   working. After a payment with a new card the app asks again.
-- Run after 008_control_room_alarm.sql. (Also included in schema.sql.)
-- =====================================================================

update public.app_settings set plan_price = 49.00 where id = 1;
alter table public.app_settings alter column plan_price set default 49.00;

-- First day of the month the card expires in (the card works until the end of that month).
alter table public.subscriptions add column if not exists card_expiry date;
alter table public.subscriptions add column if not exists card_expiry_set_at timestamptz;

-- Plan holder: the card on the debit order and whether the app should ask for its expiry.
create or replace function public.my_card()
returns json language plpgsql stable security definer set search_path = public as $$
declare
  v_sub public.subscriptions;
begin
  if auth.uid() is null then raise exception 'Not signed in'; end if;
  select * into v_sub from public.subscriptions where owner_id = auth.uid();
  if not found then return json_build_object('is_owner', false); end if;
  return json_build_object(
    'is_owner', true,
    'has_debit_order', v_sub.payfast_token is not null,
    'card_expiry', v_sub.card_expiry,
    -- Ask when there is a debit order and: no expiry yet, the saved card has expired, or the client
    -- paid with a (possibly new) card through PayFast after entering it.
    'ask', v_sub.payfast_token is not null
           and (v_sub.card_expiry is null
                or v_sub.card_expiry < date_trunc('month', current_date)::date
                or exists (select 1 from private.payfast_checkouts c
                            where c.subscription_id = v_sub.id and c.completed_at is not null
                              and c.completed_at > coalesce(v_sub.card_expiry_set_at, '-infinity'::timestamptz))));
end $$;

-- Plan holder: save the card's expiry month and year (null clears it).
create or replace function public.set_card_expiry(p_month int, p_year int)
returns json language plpgsql security definer set search_path = public as $$
declare
  v_year int := case when p_year between 0 and 99 then 2000 + p_year else p_year end;
  v_date date;
begin
  if auth.uid() is null then raise exception 'Not signed in'; end if;
  if not exists (select 1 from public.subscriptions where owner_id = auth.uid()) then
    raise exception 'Only the plan holder pays, so only they can enter the card expiry.';
  end if;
  if p_month is null and p_year is null then
    v_date := null;
  else
    if p_month is null or p_month not between 1 and 12 then raise exception 'The month must be between 01 and 12.'; end if;
    v_date := make_date(v_year, p_month, 1);
    if v_date < date_trunc('month', current_date)::date then raise exception 'That card has already expired. Use a card that is still valid.'; end if;
    if v_date > (current_date + interval '15 years')::date then raise exception 'Check the year – it is too far in the future.'; end if;
  end if;
  update public.subscriptions set card_expiry = v_date, card_expiry_set_at = now() where owner_id = auth.uid();
  return public.my_card();
end $$;

revoke execute on function public.my_card(), public.set_card_expiry(int, int) from public, anon;
grant execute on function public.my_card(), public.set_card_expiry(int, int) to authenticated;
