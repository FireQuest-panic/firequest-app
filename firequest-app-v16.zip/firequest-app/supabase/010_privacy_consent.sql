-- v16: record which version of the privacy policy each person accepted.
-- The app asks again when the policy version changes.
alter table public.profiles add column if not exists privacy_version text;
alter table public.profiles add column if not exists privacy_accepted_at timestamptz;

-- People who already ticked the old consent box have not yet seen the policy,
-- so their privacy_version stays empty and the app asks them once.
