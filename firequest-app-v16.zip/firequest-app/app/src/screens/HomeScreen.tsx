import React, { useCallback, useEffect, useState } from 'react';
import { AppState, Linking, Pressable, Text, View } from 'react-native';
import { FontAwesome5, MaterialCommunityIcons } from '@expo/vector-icons';
import { colors } from '../theme';
import { AlertType, AppSettings, PanicAlert, Profile } from '../lib/types';
import { friendlyError, raiseAlert } from '../lib/data';
import { ensureLocationPermission, locationState, LocationState, quickPosition } from '../lib/location';
import { HoldButton } from '../components/HoldButton';
import { crashSupported, getCrashStatus } from '../lib/crash';
import { Billing, getBilling, homeWarning } from '../lib/billing';
import { MyCard, daysToCardExpiry, expiryLabel, getMyCard, isBirthday } from '../lib/reminders';
import { Button, ErrorText, Logo, Screen, TestBanner } from '../components/ui';

type Props = {
  profile: Profile;
  settings: AppSettings;
  controlRoomPhone: string;
  onAlertRaised: (alert: PanicAlert) => void;
  onOpenAccount: () => void;
};

function greeting(): string {
  const h = new Date().getHours();
  if (h < 12) return 'Good morning';
  if (h < 18) return 'Good afternoon';
  return 'Good evening';
}

export function HomeScreen({ profile, settings, controlRoomPhone, onAlertRaised, onOpenAccount }: Props) {
  const [loc, setLoc] = useState<LocationState>('unknown');
  const [sending, setSending] = useState<AlertType | null>(null);
  const [error, setError] = useState('');
  const [crashOn, setCrashOn] = useState(() => getCrashStatus().enabled);
  const [billing, setBilling] = useState<Billing | null>(null);
  const [card, setCard] = useState<MyCard | null>(null);

  const refreshBilling = useCallback(() => {
    getBilling().then(setBilling).catch(() => undefined);
    getMyCard().then(setCard).catch(() => undefined);
  }, []);

  const refreshLocation = useCallback(() => {
    locationState().then(setLoc);
  }, []);

  useEffect(() => {
    // Ask for location now, so the question never appears during an emergency.
    ensureLocationPermission().finally(refreshLocation);
    refreshBilling();
    const sub = AppState.addEventListener('change', (s) => {
      if (s !== 'active') return;
      refreshLocation();
      refreshBilling();
      setCrashOn(getCrashStatus().enabled);
    });
    return () => sub.remove();
  }, [refreshLocation, refreshBilling]);

  const fixLocation = async () => {
    if (loc === 'services_off') {
      Linking.sendIntent?.('android.settings.LOCATION_SOURCE_SETTINGS').catch(() => Linking.openSettings());
      return;
    }
    const granted = await ensureLocationPermission();
    if (!granted) Linking.openSettings();
    refreshLocation();
  };

  const trigger = async (type: AlertType) => {
    setError('');
    setSending(type);
    try {
      await ensureLocationPermission();
      const pos = await quickPosition();
      const alert = await raiseAlert(type, pos);
      onAlertRaised(alert);
    } catch (e) {
      setError(friendlyError(e));
    } finally {
      setSending(null);
      refreshLocation();
    }
  };

  const firstName = (profile.full_name || '').split(' ')[0];
  const cardDays = card?.is_owner && card.has_debit_order ? daysToCardExpiry(card.card_expiry) : null;
  const cardWarning =
    card?.is_owner && card.has_debit_order
      ? cardDays !== null && cardDays <= 0
        ? { text: `The card on your debit order expired (${expiryLabel(card.card_expiry)}) – tap to update it`, tone: 'bad' as const }
        : cardDays !== null && cardDays <= 30
          ? { text: `Your card expires at the end of ${expiryLabel(card.card_expiry)} – tap to update it`, tone: 'warn' as const }
          : card.ask
            ? { text: 'When does your card expire? Tap to add it, so we can remind you in time', tone: 'warn' as const }
            : null
      : null;
  const payWarning = homeWarning(billing) ?? cardWarning;
  const birthday = isBirthday(profile.date_of_birth);

  return (
    <Screen aboveTabBar>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
        <Logo size={54} />
        <View style={{ flex: 1 }}>
          <Text style={{ color: colors.muted, fontSize: 13 }}>{greeting()}</Text>
          <Text style={{ color: colors.text, fontSize: 22, fontWeight: '700' }}>{firstName || 'Welcome'}</Text>
        </View>
      </View>

      {loc === 'ok' ? (
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10, padding: 12, borderRadius: 14, backgroundColor: colors.greenDeep }}>
          <MaterialCommunityIcons name="map-marker-check" size={20} color={colors.green} />
          <Text style={{ color: colors.green, fontSize: 14, fontWeight: '600' }}>GPS on · FireQuest monitoring active</Text>
        </View>
      ) : (
        <Pressable
          accessibilityRole="button"
          onPress={fixLocation}
          style={{ flexDirection: 'row', alignItems: 'center', gap: 10, padding: 12, borderRadius: 14, backgroundColor: colors.dangerDeep }}
        >
          <MaterialCommunityIcons name="map-marker-off" size={20} color={colors.danger} />
          <Text style={{ color: colors.danger, fontSize: 14, fontWeight: '600', flex: 1 }}>
            {loc === 'services_off' ? 'Location is switched off. Tap to turn it on.' : 'FireQuest cannot see your location. Tap to allow.'}
          </Text>
        </Pressable>
      )}

      {birthday && (
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10, padding: 12, borderRadius: 14, backgroundColor: colors.goldDeep, borderWidth: 1, borderColor: colors.gold }}>
          <MaterialCommunityIcons name="cake-variant" size={22} color={colors.goldText} />
          <Text style={{ color: colors.goldText, fontSize: 14, fontWeight: '700', flex: 1 }}>
            Happy birthday{firstName ? `, ${firstName}` : ''}! Everyone at FireQuest wishes you a wonderful and safe day.
          </Text>
        </View>
      )}

      {payWarning && (
        <Pressable
          accessibilityRole="button"
          onPress={onOpenAccount}
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            gap: 10,
            padding: 12,
            borderRadius: 14,
            backgroundColor: payWarning.tone === 'bad' ? colors.dangerDeep : colors.goldDeep,
            borderWidth: 1,
            borderColor: payWarning.tone === 'bad' ? '#7A2A2E' : colors.gold,
          }}
        >
          <MaterialCommunityIcons
            name="credit-card-off-outline"
            size={20}
            color={payWarning.tone === 'bad' ? colors.danger : colors.goldText}
          />
          <Text style={{ color: payWarning.tone === 'bad' ? colors.danger : colors.goldText, fontSize: 14, fontWeight: '700', flex: 1 }}>
            {payWarning.text}
          </Text>
          <MaterialCommunityIcons name="chevron-right" size={20} color={colors.faint} />
        </Pressable>
      )}

      {settings.test_mode && <TestBanner />}

      <Text style={{ color: colors.muted, fontSize: 15 }}>
        {sending ? 'Sending your alert…' : 'Press and hold a button for 3 seconds to send an alert.'}
      </Text>

      <View style={{ gap: 14 }}>
        <HoldButton
          title="Medical"
          subtitle="Ambulance + your medical profile"
          icon={<FontAwesome5 name="star-of-life" size={28} color="#FFFFFF" />}
          background={colors.ivory}
          textColor={colors.ink}
          subtitleColor="#4A463F"
          iconBackground={colors.red}
          fillColor="rgba(212,47,53,0.28)"
          disabled={sending !== null}
          onTrigger={() => trigger('medical')}
        />
        <HoldButton
          title="Vehicle accident"
          subtitle="Crash, hijacking or breakdown"
          icon={<MaterialCommunityIcons name="car-emergency" size={32} color={colors.goldText} />}
          background={colors.gold}
          textColor={colors.ink}
          subtitleColor="#2B2412"
          iconBackground={colors.ink}
          fillColor="rgba(17,18,20,0.25)"
          disabled={sending !== null}
          onTrigger={() => trigger('vehicle')}
        />
        <HoldButton
          title="Fire & rescue"
          subtitle="Fire, flooding, trapped"
          icon={<MaterialCommunityIcons name="fire" size={34} color={colors.red} />}
          background={colors.red}
          textColor="#FFFFFF"
          subtitleColor="#FFE3E4"
          iconBackground="#FFFFFF"
          fillColor="rgba(0,0,0,0.25)"
          disabled={sending !== null}
          onTrigger={() => trigger('fire')}
        />
      </View>

      {crashSupported && (
        <Pressable
          accessibilityRole="button"
          onPress={onOpenAccount}
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            gap: 10,
            padding: 12,
            borderRadius: 14,
            backgroundColor: crashOn ? colors.greenDeep : colors.surface,
            borderWidth: 1,
            borderColor: crashOn ? colors.greenDeep : colors.border,
          }}
        >
          <MaterialCommunityIcons name="car-emergency" size={20} color={crashOn ? colors.green : colors.goldText} />
          <Text style={{ color: crashOn ? colors.green : colors.text, fontSize: 14, fontWeight: '600', flex: 1 }}>
            {crashOn ? 'Automatic crash detection is on' : 'Turn on automatic crash detection'}
          </Text>
          <MaterialCommunityIcons name="chevron-right" size={20} color={colors.faint} />
        </Pressable>
      )}

      <ErrorText>{error}</ErrorText>
      {error && controlRoomPhone ? (
        <Button title="Call FireQuest control room" variant="red" onPress={() => Linking.openURL(`tel:${controlRoomPhone}`)} />
      ) : null}

      <View style={{ flexDirection: 'row', gap: 12, alignItems: 'center', padding: 14, borderRadius: 16, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border }}>
        <MaterialCommunityIcons name="lock-outline" size={20} color={colors.muted} />
        <Text style={{ color: colors.muted, fontSize: 13, lineHeight: 19, flex: 1 }}>
          Your medical details are shared with responders only when you raise an alert.
        </Text>
      </View>
    </Screen>
  );
}
