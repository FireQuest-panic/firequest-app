import React, { useState } from 'react';
import { View } from 'react-native';
import { Profile } from '../lib/types';
import { friendlyError } from '../lib/data';
import { acceptPrivacy } from '../lib/privacy';
import { Body, Button, ErrorText, Logo, Screen, Title } from '../components/ui';
import { PrivacyConsentBox } from '../components/PrivacyConsentBox';

type Props = {
  profile: Profile;
  onAccepted: () => void;
  /** Hides the screen until the app is opened again; the panic button stays available. */
  onLater: () => void;
};

/** Asks people who registered before the current privacy policy to read and accept it. */
export function PrivacyUpdateScreen({ profile, onAccepted, onLater }: Props) {
  const [checked, setChecked] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const accept = async () => {
    if (!checked) {
      setError('Please tick the box to accept the privacy policy.');
      return;
    }
    setBusy(true);
    setError('');
    try {
      await acceptPrivacy(profile);
      onAccepted();
    } catch (e) {
      setError(friendlyError(e));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Screen>
      <View style={{ alignItems: 'center', marginBottom: 8 }}>
        <Logo size={72} />
      </View>
      <Title>Our privacy policy</Title>
      <Body>
        We have published the FireQuest Privacy Policy. It explains what information the app keeps, who we
        share it with in an emergency and your rights under POPIA. Please read it and tick the box to carry on.
      </Body>
      <PrivacyConsentBox checked={checked} onChange={setChecked} />
      <ErrorText>{error}</ErrorText>
      <View style={{ gap: 10, marginTop: 8 }}>
        <Button title="Accept and continue" onPress={accept} loading={busy} />
        <Button title="Not now" variant="plain" onPress={onLater} disabled={busy} />
      </View>
    </Screen>
  );
}
