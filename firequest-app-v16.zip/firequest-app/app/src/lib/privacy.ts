import { Linking } from 'react-native';
import { saveProfile } from './data';
import { Profile } from './types';

/** Change this (and the page's version line) whenever the policy changes: everyone is asked to accept again. */
export const PRIVACY_VERSION = '2026-11';
export const PRIVACY_URL = 'https://firequest-panic.github.io/firequest-app/privacy.html';

export function openPrivacyPolicy() {
  Linking.openURL(PRIVACY_URL).catch(() => undefined);
}

export function hasAcceptedPrivacy(profile: Pick<Profile, 'privacy_version'>): boolean {
  return profile.privacy_version === PRIVACY_VERSION;
}

/** Fields to save when the person ticks the consent box. */
export function privacyAcceptFields(profile: Pick<Profile, 'consent_at'>): Partial<Profile> {
  const now = new Date().toISOString();
  return {
    consent_at: profile.consent_at ?? now,
    privacy_version: PRIVACY_VERSION,
    privacy_accepted_at: now,
  };
}

export async function acceptPrivacy(profile: Profile): Promise<void> {
  await saveProfile(profile.id, privacyAcceptFields(profile));
}
