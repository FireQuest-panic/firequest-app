// Reminders on the phone itself (no server needed): a happy-birthday message every year and,
// for the plan holder, a warning before the debit-order card expires. Android keeps them
// after a restart.
import { Platform } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Notifications from 'expo-notifications';
import { supabase } from './supabase';

const CHANNEL = 'fq_reminders';
const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

// Show reminders also while FireQuest is open.
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowBanner: true,
    shouldShowList: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
  }),
});

let ready: Promise<boolean> | null = null;

/** Creates the Android channel and asks for permission to show notifications (once). */
function setup(): Promise<boolean> {
  if (Platform.OS !== 'android') return Promise.resolve(false);
  ready ??= (async () => {
    try {
      await Notifications.setNotificationChannelAsync(CHANNEL, {
        name: 'Reminders',
        description: 'Birthday wishes and card-expiry reminders from FireQuest.',
        importance: Notifications.AndroidImportance.DEFAULT,
      });
      const now = await Notifications.getPermissionsAsync();
      if (now.granted) return true;
      if (!now.canAskAgain) return false;
      return (await Notifications.requestPermissionsAsync()).granted;
    } catch {
      return false;
    }
  })();
  return ready;
}

async function cancelStored(key: string): Promise<void> {
  try {
    const ids = JSON.parse((await AsyncStorage.getItem(key)) ?? '[]') as string[];
    await Promise.all(ids.map((id) => Notifications.cancelScheduledNotificationAsync(id).catch(() => undefined)));
  } catch {
    // nothing stored
  }
  await AsyncStorage.removeItem(key).catch(() => undefined);
}

/** True when the date (YYYY-MM-DD) is the person's birthday today. */
export function isBirthday(dob: string | null | undefined, today = new Date()): boolean {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(dob ?? '');
  if (!m) return false;
  let month = Number(m[2]);
  let day = Number(m[3]);
  // 29 February: celebrated on 28 February in other years.
  const leap = (y: number) => (y % 4 === 0 && y % 100 !== 0) || y % 400 === 0;
  if (month === 2 && day === 29 && !leap(today.getFullYear())) day = 28;
  return today.getMonth() + 1 === month && today.getDate() === day;
}

/** Every year at 08:00 on the person's birthday: a greeting from FireQuest. */
export async function scheduleBirthday(userId: string, dob: string | null | undefined, firstName: string): Promise<void> {
  const key = `fq_birthday_${userId}`;
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(dob ?? '');
  const signature = m ? `${dob}|${firstName}` : '';
  if ((await AsyncStorage.getItem(`${key}_sig`).catch(() => null)) === signature && signature) return;
  await cancelStored(key);
  await AsyncStorage.setItem(`${key}_sig`, signature).catch(() => undefined);
  if (!m || !(await setup())) return;
  const month = Number(m[2]);
  let day = Number(m[3]);
  if (month === 2 && day === 29) day = 28; // a date that exists every year
  const id = await Notifications.scheduleNotificationAsync({
    content: {
      title: `Happy birthday${firstName ? `, ${firstName}` : ''}!`,
      body: 'Everyone at FireQuest wishes you a wonderful and safe day.',
    },
    trigger: { type: Notifications.SchedulableTriggerInputTypes.YEARLY, month: month - 1, day, hour: 8, minute: 0, channelId: CHANNEL },
  });
  await AsyncStorage.setItem(key, JSON.stringify([id])).catch(() => undefined);
}

export interface MyCard {
  is_owner: boolean;
  has_debit_order?: boolean;
  /** First day of the month the card expires in (YYYY-MM-01). */
  card_expiry?: string | null;
  /** The app should ask for the card's expiry (none yet, expired, or paid again since). */
  ask?: boolean;
}

/** Null while the database has no card-expiry support yet. */
export async function getMyCard(): Promise<MyCard | null> {
  const { data, error } = await supabase.rpc('my_card');
  if (error) return null;
  return data as MyCard;
}

export async function saveCardExpiry(month: number, year: number): Promise<MyCard> {
  const { data, error } = await supabase.rpc('set_card_expiry', { p_month: month, p_year: year });
  if (error) throw error;
  return data as MyCard;
}

/** "08/2028" style label. */
export function expiryLabel(iso: string | null | undefined): string {
  const m = /^(\d{4})-(\d{2})/.exec(iso ?? '');
  return m ? `${m[2]}/${m[1]}` : '';
}

/** Last day the card works (end of its expiry month), or null. */
export function cardLastDay(iso: string | null | undefined): Date | null {
  const m = /^(\d{4})-(\d{2})/.exec(iso ?? '');
  return m ? new Date(Number(m[1]), Number(m[2]), 0, 23, 59) : null;
}

/** Days until the card stops working (negative = expired), or null. */
export function daysToCardExpiry(iso: string | null | undefined, now = new Date()): number | null {
  const end = cardLastDay(iso);
  return end ? Math.ceil((end.getTime() - now.getTime()) / 86400000) : null;
}

/** Reminders 30 days and 7 days before the card expires (09:00). Clears them when there is no card. */
export async function scheduleCardReminders(userId: string, card: MyCard | null): Promise<void> {
  const key = `fq_card_${userId}`;
  const expiry = card?.is_owner && card.has_debit_order ? card.card_expiry ?? '' : '';
  if ((await AsyncStorage.getItem(`${key}_sig`).catch(() => null)) === expiry) return;
  await cancelStored(key);
  await AsyncStorage.setItem(`${key}_sig`, expiry).catch(() => undefined);
  const end = cardLastDay(expiry);
  if (!end || !(await setup())) return;
  const label = `${MONTHS[end.getMonth()]} ${end.getFullYear()}`;
  const ids: string[] = [];
  for (const daysBefore of [30, 7]) {
    const when = new Date(end.getFullYear(), end.getMonth(), end.getDate() - daysBefore, 9, 0);
    if (when.getTime() <= Date.now() + 60000) continue;
    ids.push(
      await Notifications.scheduleNotificationAsync({
        content: {
          title: daysBefore === 7 ? 'Your card expires in a week' : 'Your card expires soon',
          body: `The card for your FireQuest debit order expires at the end of ${label}. Open FireQuest > Account > Update card details, so your family stays covered.`,
        },
        trigger: { type: Notifications.SchedulableTriggerInputTypes.DATE, date: when, channelId: CHANNEL },
      }),
    );
  }
  await AsyncStorage.setItem(key, JSON.stringify(ids)).catch(() => undefined);
}

/** Signing out: this phone stops reminding the person who used it. */
export async function clearReminders(): Promise<void> {
  try {
    await Notifications.cancelAllScheduledNotificationsAsync();
    const keys = (await AsyncStorage.getAllKeys()).filter((k) => k.startsWith('fq_birthday_') || k.startsWith('fq_card_'));
    await AsyncStorage.multiRemove(keys);
  } catch {
    // nothing scheduled
  }
}
