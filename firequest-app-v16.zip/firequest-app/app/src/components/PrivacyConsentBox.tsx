import React from 'react';
import { Pressable, Text, View } from 'react-native';
import { colors } from '../theme';
import { openPrivacyPolicy } from '../lib/privacy';

/** The POPIA consent tick box, with a link that opens the privacy policy. */
export function PrivacyConsentBox({ checked, onChange }: { checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <View style={{ gap: 10, paddingVertical: 8 }}>
      <Pressable
        accessibilityRole="checkbox"
        accessibilityState={{ checked }}
        accessibilityLabel="I consent to FireQuest processing my personal information as described in the privacy policy"
        onPress={() => onChange(!checked)}
        style={{ flexDirection: 'row', gap: 12, alignItems: 'flex-start' }}
      >
        <View
          style={{
            width: 26,
            height: 26,
            borderRadius: 6,
            borderWidth: 2,
            borderColor: colors.gold,
            backgroundColor: checked ? colors.gold : 'transparent',
            alignItems: 'center',
            justifyContent: 'center',
            marginTop: 2,
          }}
        >
          {checked ? <Text style={{ color: colors.ink, fontWeight: '900' }}>✓</Text> : null}
        </View>
        <Text style={{ color: colors.text, fontSize: 14, lineHeight: 21, flex: 1 }}>
          I have read the{' '}
          <Text
            accessibilityRole="link"
            onPress={openPrivacyPolicy}
            style={{ color: colors.goldText, fontWeight: '700', textDecorationLine: 'underline' }}
          >
            FireQuest Privacy Policy
          </Text>{' '}
          and I consent to FireQuest processing my personal and health information as described in it,
          including sharing it with responders, emergency services and my emergency contacts when an alert
          is raised, and storing it securely in the United Kingdom. If I am under 18, my parent or guardian
          agrees to this with me.
        </Text>
      </Pressable>
      <Pressable accessibilityRole="link" onPress={openPrivacyPolicy} style={{ paddingVertical: 6, paddingLeft: 38 }}>
        <Text style={{ color: colors.goldText, fontSize: 14, fontWeight: '700' }}>Read the privacy policy ›</Text>
      </Pressable>
    </View>
  );
}
