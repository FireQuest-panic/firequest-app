import React, { useState } from 'react';
import { Alert, Text, View } from 'react-native';
import { colors } from '../theme';
import { ProfileBundle } from '../lib/types';
import { friendlyError } from '../lib/data';
import { chooseSelfie, removeSelfie } from '../lib/selfie';
import { SelfieImage } from '../components/SelfieImage';
import { openInGoogleMaps } from '../components/HomePinPicker';
import { Body, Button, Card, ErrorText, InfoRow, Logo, Screen, Title } from '../components/ui';

export function MedicalIdScreen({
  bundle,
  onEdit,
  onChanged,
}: {
  bundle: ProfileBundle;
  onEdit: () => void;
  /** Reload the profile (after the selfie changed). */
  onChanged: () => void;
}) {
  const { profile, medical, contacts } = bundle;
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const vehicle = [profile.vehicle_colour, profile.vehicle_make, profile.vehicle_model]
    .filter(Boolean)
    .join(' ');

  const run = async (fn: () => Promise<unknown>) => {
    setError('');
    setBusy(true);
    try {
      await fn();
      onChanged();
    } catch (e) {
      setError(friendlyError(e));
    } finally {
      setBusy(false);
    }
  };

  const changePhoto = () =>
    Alert.alert('Your photo', 'Responders use it to recognise you when they arrive.', [
      { text: 'Take a selfie', onPress: () => run(() => chooseSelfie(profile.id, 'camera')) },
      { text: 'Choose a photo', onPress: () => run(() => chooseSelfie(profile.id, 'library')) },
      ...(profile.selfie_updated_at
        ? [{ text: 'Remove photo', style: 'destructive' as const, onPress: () => run(() => removeSelfie(profile.id)) }]
        : []),
      { text: 'Cancel', style: 'cancel' as const },
    ]);

  const people = profile.household_size;
  const pets = profile.pets_inside;

  return (
    <Screen aboveTabBar>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
        <Logo size={48} />
        <Title>Profile</Title>
      </View>
      <Body>This is what FireQuest responders see when you raise an alert.</Body>

      <Card style={{ alignItems: 'center' }}>
        <SelfieImage userId={profile.id} updatedAt={profile.selfie_updated_at} size={128} />
        <Text style={{ color: colors.text, fontSize: 18, fontWeight: '700' }}>{profile.full_name || '—'}</Text>
        {!profile.selfie_updated_at && (
          <Body center>Add a clear photo of your face, so responders can recognise you.</Body>
        )}
        <Button
          title={profile.selfie_updated_at ? 'Change photo' : 'Take a selfie'}
          variant={profile.selfie_updated_at ? 'outline' : 'gold'}
          loading={busy}
          onPress={profile.selfie_updated_at ? changePhoto : () => run(() => chooseSelfie(profile.id, 'camera'))}
          style={{ alignSelf: 'stretch' }}
        />
        {!profile.selfie_updated_at && (
          <Button title="Choose a photo instead" variant="plain" disabled={busy} onPress={() => run(() => chooseSelfie(profile.id, 'library'))} />
        )}
        <ErrorText>{error}</ErrorText>
      </Card>

      <Card>
        <View style={{ flexDirection: 'row', gap: 12 }}>
          <View style={{ flex: 1, padding: 12, borderRadius: 12, backgroundColor: colors.surfaceRaised }}>
            <Text style={{ color: colors.muted, fontSize: 12 }}>Blood type</Text>
            <Text style={{ color: colors.text, fontSize: 24, fontWeight: '800' }}>{medical?.blood_type || '—'}</Text>
          </View>
          <View style={{ flex: 1.4, padding: 12, borderRadius: 12, backgroundColor: colors.dangerDeep }}>
            <Text style={{ color: colors.danger, fontSize: 12 }}>Allergies</Text>
            <Text style={{ color: '#FFD9DA', fontSize: 15, fontWeight: '700' }}>
              {medical?.allergies?.length ? medical.allergies.join(', ') : 'None listed'}
            </Text>
          </View>
        </View>
        <InfoRow label="Chronic conditions" value={medical?.conditions} />
        <InfoRow label="Medication" value={medical?.medication} />
        <InfoRow
          label="Medical aid"
          value={
            medical?.medical_aid_scheme
              ? [medical.medical_aid_scheme, medical.medical_aid_plan, medical.medical_aid_number].filter(Boolean).join(' · ')
              : 'No medical aid'
          }
        />
        <InfoRow label="Doctor" value={[medical?.doctor_name, medical?.doctor_phone].filter(Boolean).join(' · ')} />
      </Card>

      <Card>
        <Text style={{ color: colors.goldText, fontWeight: '700' }}>Emergency contacts</Text>
        {contacts.length ? (
          contacts.map((c) => (
            <InfoRow key={c.id ?? c.phone} label={c.relationship || 'Contact'} value={`${c.name} · ${c.phone}`} />
          ))
        ) : (
          <Body>No contacts yet.</Body>
        )}
      </Card>

      <Card>
        <Text style={{ color: colors.goldText, fontWeight: '700' }}>Household</Text>
        <InfoRow label="People living in the home" value={people ? String(people) : null} />
        <View style={{ gap: 2 }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
            <Text style={{ color: colors.muted, fontSize: 12 }}>Pets at the home</Text>
            {profile.pets_dangerous ? <Text style={dangerBadge}>DANGEROUS</Text> : null}
          </View>
          <Text style={{ color: colors.text, fontSize: 15 }}>
            {pets === null || pets === undefined ? '—' : pets === 0 ? 'None' : String(pets)}
            {profile.pets_notes ? ` · ${profile.pets_notes}` : ''}
          </Text>
        </View>
      </Card>

      <Card>
        <Text style={{ color: colors.goldText, fontWeight: '700' }}>Insurance</Text>
        <InfoRow label="Insurance company" value={profile.insurance_company} />
        <InfoRow label="Policy number" value={profile.insurance_policy_number} />
        <InfoRow label="Insurer's phone number" value={profile.insurance_phone} />
        <InfoRow label="What is insured" value={profile.insurance_cover} />
      </Card>

      <Card>
        <Text style={{ color: colors.goldText, fontWeight: '700' }}>Personal & vehicle</Text>
        <InfoRow label="Name" value={profile.full_name} />
        <InfoRow label="Mobile" value={profile.phone} />
        <InfoRow label="Home address" value={profile.home_address} />
        {profile.home_lat != null && profile.home_lng != null ? (
          <Button
            title="Home pin ✓ – view in Google Maps"
            variant="plain"
            onPress={() => openInGoogleMaps({ lat: profile.home_lat as number, lng: profile.home_lng as number })}
          />
        ) : profile.home_address ? (
          <Text style={{ color: colors.goldText, fontSize: 14 }}>Your home is not pinned on the map yet. Tap Edit my details to place the pin.</Text>
        ) : null}
        <InfoRow
          label="Vehicle"
          value={[vehicle, profile.vehicle_registration].filter(Boolean).join(' · ')}
        />
      </Card>

      <Button title="Edit my details" onPress={onEdit} />
    </Screen>
  );
}

const dangerBadge = {
  fontSize: 11,
  fontWeight: '800' as const,
  paddingHorizontal: 6,
  paddingVertical: 2,
  borderRadius: 4,
  overflow: 'hidden' as const,
  color: colors.redText,
  backgroundColor: colors.redDeep,
};
