import React, { useState } from 'react';
import { Text, View } from 'react-native';
import Constants from 'expo-constants';
import { colors } from '../theme';
import { supabase } from '../lib/supabase';
import { AppSettings, Profile } from '../lib/types';
import { friendlyError, setCancelPin } from '../lib/data';
import { Body, Button, Card, ErrorText, Field, InfoRow, Logo, Screen, Title } from '../components/ui';
import { FamilyCard } from '../components/FamilyCard';
import { BillingCard } from '../components/BillingCard';
import { PaymentsAttentionCard } from '../components/PaymentsAttentionCard';
import { CrashDetectionCard } from '../components/CrashDetectionCard';
import { disableCrashDetection } from '../lib/crash';

export function AccountScreen({
  profile,
  settings,
  controlRoomPhone,
  isAdmin = false,
}: {
  profile: Profile;
  settings: AppSettings;
  controlRoomPhone: string;
  /** FireQuest admin: also sees payment problems that need a person. */
  isAdmin?: boolean;
}) {
  const [changingPin, setChangingPin] = useState(false);
  const [pin, setPin] = useState('');
  const [pin2, setPin2] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  // Bumped when the subscription or family plan changes, so both cards reload.
  const [planVersion, setPlanVersion] = useState(0);
  const planChanged = () => setPlanVersion((v) => v + 1);

  const savePin = async () => {
    setError('');
    setNotice('');
    if (!/^[0-9]{4,6}$/.test(pin)) return setError('Your PIN must be 4 to 6 digits.');
    if (pin !== pin2) return setError('The two PINs do not match.');
    setBusy(true);
    try {
      await setCancelPin(pin);
      setNotice('Your cancel PIN has been changed.');
      setChangingPin(false);
      setPin('');
      setPin2('');
    } catch (e) {
      setError(friendlyError(e));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Screen aboveTabBar>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
        <Logo size={48} />
        <Title>Account</Title>
      </View>

      <Card>
        <InfoRow label="Name" value={profile.full_name} />
        <InfoRow label="Email" value={profile.email} />
        <InfoRow label="Mobile" value={profile.phone} />
      </Card>

      {isAdmin && <PaymentsAttentionCard />}

      <BillingCard version={planVersion} onChanged={planChanged} />

      <FamilyCard testMode={settings.test_mode} version={planVersion} onChanged={planChanged} />

      <CrashDetectionCard userId={profile.id} controlRoomPhone={controlRoomPhone} />

      <Card>
        <Text style={{ color: colors.goldText, fontWeight: '700' }}>Cancel PIN</Text>
        {changingPin ? (
          <>
            <Field label="New PIN" value={pin} onChangeText={(t) => setPin(t.replace(/[^0-9]/g, ''))} keyboardType="number-pad" secureTextEntry maxLength={6} />
            <Field label="Repeat new PIN" value={pin2} onChangeText={(t) => setPin2(t.replace(/[^0-9]/g, ''))} keyboardType="number-pad" secureTextEntry maxLength={6} />
            <ErrorText>{error}</ErrorText>
            <Button title="Save PIN" onPress={savePin} loading={busy} />
            <Button title="Cancel" variant="plain" onPress={() => setChangingPin(false)} />
          </>
        ) : (
          <>
            <Body>You need this PIN to cancel an alert.</Body>
            {notice ? <Text style={{ color: colors.green }}>{notice}</Text> : null}
            <Button title="Change PIN" variant="outline" onPress={() => setChangingPin(true)} />
          </>
        )}
      </Card>

      {settings.test_mode && (
        <Body>
          This is a FireQuest test version. Alerts reach the FireQuest control room, but no ambulance
          or fire brigade is called automatically.
        </Body>
      )}

      <View style={{ flexGrow: 1 }} />
      <Button
        title="Sign out"
        variant="outline"
        onPress={async () => {
          // A signed-out phone must not keep sending crash alerts for this person.
          await disableCrashDetection();
          await supabase.auth.signOut();
        }}
      />
      <Text style={{ color: colors.faint, fontSize: 12, textAlign: 'center' }}>
        FireQuest Panic {Constants.expoConfig?.version ?? ''} (build {Constants.expoConfig?.android?.versionCode ?? '-'})
      </Text>
    </Screen>
  );
}
