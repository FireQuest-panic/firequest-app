import React, { useCallback, useEffect, useState } from 'react';
import { ActivityIndicator, Alert, AppState, Pressable, Text, View } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { colors } from '../theme';
import { friendlyError } from '../lib/data';
import {
  ATTENTION_STATES,
  Billing,
  Tone,
  billingTest,
  getBilling,
  holderSummary,
  longDate,
  openCardUpdate,
  openCheckout,
  rand,
} from '../lib/billing';
import { Body, Button, Card, ErrorText } from './ui';

const TONE: Record<Tone, { fg: string; bg: string; border: string; icon: React.ComponentProps<typeof MaterialCommunityIcons>['name'] }> = {
  ok: { fg: colors.green, bg: colors.greenDeep, border: '#245C3B', icon: 'check-circle' },
  warn: { fg: colors.goldText, bg: colors.goldDeep, border: colors.gold, icon: 'alert' },
  bad: { fg: colors.danger, bg: colors.dangerDeep, border: '#7A2A2E', icon: 'alert-octagon' },
  test: { fg: colors.goldText, bg: colors.goldDeep, border: colors.borderStrong, icon: 'flask-outline' },
};

/**
 * Account-screen card: the family plan's PayFast subscription.
 * The plan holder can subscribe, fix a failed payment or change card.
 * Family members only see who pays.
 */
export function BillingCard({ version, onChanged }: { version: number; onChanged: () => void }) {
  const [billing, setBilling] = useState<Billing | null | undefined>(undefined);
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState('');
  const [showTests, setShowTests] = useState(false);
  // Bumped after "Pay" and whenever the app comes back to the front: checks PayFast again for 3 minutes.
  const [pollRound, setPollRound] = useState(0);

  const load = useCallback(async () => {
    try {
      setBilling(await getBilling());
    } catch (e) {
      setError(friendlyError(e));
      setBilling((cur) => (cur === undefined ? null : cur));
    }
  }, []);

  useEffect(() => {
    load();
  }, [load, version]);

  // Back from PayFast: check again.
  useEffect(() => {
    const sub = AppState.addEventListener('change', (s) => {
      if (s !== 'active') return;
      load();
      setPollRound((r) => r + 1);
    });
    return () => sub.remove();
  }, [load]);

  // While PayFast is confirming a payment, check every 5 seconds (for 3 minutes each round).
  const pending = Boolean(billing?.pending_since);
  useEffect(() => {
    if (!pending) return;
    const started = Date.now();
    const timer = setInterval(() => {
      if (Date.now() - started > 180000) {
        clearInterval(timer);
        return;
      }
      load();
    }, 5000);
    return () => clearInterval(timer);
  }, [pending, pollRound, load]);

  const pay = async () => {
    setError('');
    setBusy('pay');
    try {
      await openCheckout();
      await load();
      setPollRound((r) => r + 1);
      onChanged();
    } catch (e) {
      setError(friendlyError(e));
    } finally {
      setBusy(null);
    }
  };

  const changeCard = async () => {
    setError('');
    setBusy('card');
    try {
      const answer = await openCardUpdate();
      if (answer.unavailable && answer.message) Alert.alert('Test system', answer.message);
    } catch (e) {
      setError(friendlyError(e));
    } finally {
      setBusy(null);
    }
  };

  const runTest = async (what: 'failed' | 'late' | 'lapsed' | 'reset') => {
    setError('');
    setBusy(`test-${what}`);
    try {
      setBilling(await billingTest(what));
      onChanged();
    } catch (e) {
      setError(friendlyError(e));
    } finally {
      setBusy(null);
    }
  };

  // Database not updated for payments yet: keep the old line.
  if (billing === null && !error) {
    return (
      <Card>
        <Text style={heading}>Subscription</Text>
        <Body>Managed by FireQuest (PayFast).</Body>
      </Card>
    );
  }
  if (!billing) {
    return (
      <Card>
        <Text style={heading}>Subscription</Text>
        {error ? <ErrorText>{error}</ErrorText> : <ActivityIndicator color={colors.gold} />}
        {error ? <Button title="Try again" variant="outline" onPress={() => { setError(''); load(); }} /> : null}
      </Card>
    );
  }

  // ------------------------------------------------------------ family member
  if (billing.in_plan && !billing.is_owner) {
    return (
      <Card>
        <Text style={heading}>Subscription</Text>
        <Body>Your family plan is paid by {billing.owner_name || 'the plan holder'}. You never need to pay anything yourself.</Body>
      </Card>
    );
  }

  // ------------------------------------------------------------ plan holder (or no plan yet)
  const s = holderSummary(billing);
  const t = TONE[s.tone];
  const needsAction = ATTENTION_STATES.includes(billing.state);
  const sandbox = billing.test_mode;

  let payTitle = 'Pay now with PayFast';
  if (billing.state === 'none' || billing.state === 'unpaid') payTitle = 'Subscribe with PayFast';
  if (billing.state === 'test') payTitle = 'Try a PayFast test payment';
  if (billing.state === 'cancelled' || billing.state === 'cancelled_paid') payTitle = 'Restart my subscription';
  const showPay = billing.state !== 'active';
  const showCard = billing.has_debit_order && ['active', 'payment_failed', 'overdue'].includes(billing.state);

  const confirmPay = () => {
    const amount = rand(billing.price);
    const lines = [
      `${amount} is paid now and then every month by debit order, through PayFast's secure page.`,
      billing.has_debit_order ? 'Your old debit order is stopped automatically, so you never pay twice.' : '',
      sandbox ? 'TEST MODE: this is PayFast\'s test system. No real money moves.' : '',
    ].filter(Boolean);
    Alert.alert(payTitle, lines.join('\n\n'), [
      { text: 'Not now', style: 'cancel' },
      { text: 'Continue to PayFast', onPress: pay },
    ]);
  };

  return (
    <Card>
      <Text style={heading}>Subscription</Text>

      <View style={{ flexDirection: 'row', gap: 10, padding: 12, borderRadius: 12, backgroundColor: t.bg, borderWidth: 1, borderColor: t.border }}>
        <MaterialCommunityIcons name={t.icon} size={22} color={t.fg} />
        <View style={{ flex: 1, gap: 4 }}>
          <Text style={{ color: t.fg, fontSize: 16, fontWeight: '800' }}>{s.title}</Text>
          <Text style={{ color: colors.text, fontSize: 14, lineHeight: 20 }}>{s.text}</Text>
        </View>
      </View>

      {pending && billing.state !== 'active' ? (
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
          <ActivityIndicator color={colors.gold} />
          <Text style={{ color: colors.muted, fontSize: 14, flex: 1 }}>
            Waiting for PayFast to confirm your payment. This usually takes less than a minute.
          </Text>
        </View>
      ) : null}

      {billing.last_payment_at ? (
        <Text style={{ color: colors.muted, fontSize: 13 }}>
          Last payment: {rand(billing.last_payment_amount)} on {longDate(billing.last_payment_at)}
        </Text>
      ) : null}

      {showPay && (
        <Button
          title={payTitle}
          variant={needsAction ? 'red' : 'gold'}
          loading={busy === 'pay'}
          disabled={busy !== null}
          onPress={confirmPay}
        />
      )}
      {showPay && needsAction && billing.has_debit_order ? (
        <Text style={{ color: colors.muted, fontSize: 13, lineHeight: 18 }}>
          "Pay now" pays this month straight away with any card, and starts a new monthly debit order on that card.
        </Text>
      ) : null}
      {showCard && (
        <Button
          title="Update card details"
          variant="outline"
          loading={busy === 'card'}
          disabled={busy !== null}
          onPress={changeCard}
        />
      )}
      {billing.state === 'none' && (
        <Text style={{ color: colors.muted, fontSize: 13, lineHeight: 18 }}>
          Joining a family member's plan instead? Use the invite code under Family plan below.
        </Text>
      )}
      {sandbox && (
        <Text style={{ color: colors.goldText, fontSize: 12, lineHeight: 17 }}>
          TEST MODE: payments go to PayFast's test system (sandbox). No real money moves.
        </Text>
      )}

      <ErrorText>{error}</ErrorText>

      {sandbox && billing.in_plan && billing.mode !== 'live' && (
        <View style={{ gap: 8 }}>
          <Pressable accessibilityRole="button" onPress={() => setShowTests((v) => !v)} style={{ minHeight: 44, justifyContent: 'center' }}>
            <Text style={{ color: colors.goldText, fontWeight: '700' }}>
              {showTests ? 'Hide payment tests' : 'Test: pretend a payment problem'}
            </Text>
          </Pressable>
          {showTests && (
            <View style={{ gap: 8 }}>
              <Body>Only for testing. These change your test plan so you can see what a client sees.</Body>
              <TestButton title="This month's debit failed" busy={busy === 'test-failed'} onPress={() => runTest('failed')} />
              <TestButton title="Payment is late (grace days)" busy={busy === 'test-late'} onPress={() => runTest('late')} />
              <TestButton title="Not paid at all" busy={busy === 'test-lapsed'} onPress={() => runTest('lapsed')} />
              <TestButton title="Back to free test plan" busy={busy === 'test-reset'} onPress={() => runTest('reset')} />
            </View>
          )}
        </View>
      )}
    </Card>
  );
}

function TestButton({ title, busy, onPress }: { title: string; busy: boolean; onPress: () => void }) {
  return <Button title={busy ? 'Working…' : title} variant="outline" onPress={onPress} disabled={busy} />;
}

const heading = { color: colors.goldText, fontWeight: '700' as const, fontSize: 15 };
