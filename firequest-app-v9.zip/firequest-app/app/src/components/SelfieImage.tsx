import React, { useEffect, useState } from 'react';
import { Image, View } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { colors } from '../theme';
import { selfieUrl } from '../lib/selfie';

/** Round photo of a client (or a person icon when there is no selfie). */
export function SelfieImage({
  userId,
  updatedAt,
  size = 96,
}: {
  userId: string;
  updatedAt: string | null | undefined;
  size?: number;
}) {
  const [url, setUrl] = useState<string | null>(null);

  useEffect(() => {
    let alive = true;
    setUrl(null);
    selfieUrl(userId, updatedAt)
      .then((u) => alive && setUrl(u))
      .catch(() => undefined);
    return () => {
      alive = false;
    };
  }, [userId, updatedAt]);

  const box = {
    width: size,
    height: size,
    borderRadius: size / 2,
    borderWidth: 2,
    borderColor: colors.gold,
    backgroundColor: colors.surfaceRaised,
    overflow: 'hidden' as const,
    alignItems: 'center' as const,
    justifyContent: 'center' as const,
  };

  return (
    <View style={box} accessibilityRole="image" accessibilityLabel={url ? 'Photo of the client' : 'No photo yet'}>
      {url ? (
        <Image source={{ uri: url }} style={{ width: size, height: size }} resizeMode="cover" />
      ) : (
        <MaterialCommunityIcons name="account" size={size * 0.6} color={colors.faint} />
      )}
    </View>
  );
}
