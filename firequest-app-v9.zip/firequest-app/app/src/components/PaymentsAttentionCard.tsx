import React, { useCallback, useEffect, useState } from 'react';
import { Alert, AppState, Pressable, Text, View } from 'react-native';
import { colors } from '../theme';
import { supabase } from '../lib/supabase';
import { friendlyError } from '../lib/data';
import { longDate } from '../lib/billing';
import { Body, Card, ErrorText } from './ui';

interface AttentionItem {
  id: number;
  kind: 'refund' | 'cancel_failed' | 'unknown_payment' | 'plan_deleted';
  message: string;
  created_at: string;
  pf_payment_id: string | null;
  token: string | null;
  client: string | null;
}

const TITLES: Record<AttentionItem['kind'], string> = {
  refund: 'Payment not credited – check for a refund',
  cancel_failed: 'Old debit order not stopped',
  unknown_payment: 'Unknown PayFast payment',
  plan_deleted: 'Plan deleted with a debit order',
};

/** FireQuest admins only: PayFast problems that need a person (shown in Account). */
export function PaymentsAttentionCard() {
  const [items, setItems] = useState<AttentionItem[] | null>(null);
  const [error, setError] = useState('');

  const load = useCallback(async () => {
    const { data, error: e } = await supabase.rpc('payments_attention');
    if (e) {
      // Older database or not an admin: show nothing.
      setItems(null);
      return;
    }
    setItems((data as AttentionItem[]) ?? []);
  }, []);

  useEffect(() => {
    load();
    const sub = AppState.addEventListener('change', (s) => s === 'active' && load());
    return () => sub.remove();
  }, [load]);

  const done = (item: AttentionItem) =>
    Alert.alert('Mark as sorted out?', 'Only do this once you have checked it in PayFast.', [
      { text: 'Not yet', style: 'cancel' },
      {
        text: 'Sorted out',
        onPress: async () => {
          setError('');
          const { data, error: e } = await supabase.rpc('payments_attention_done', { p_id: item.id });
          if (e) setError(friendlyError(e));
          else setItems((data as AttentionItem[]) ?? []);
        },
      },
    ]);

  if (items === null) return null;

  return (
    <Card style={items.length ? { borderColor: '#7A2A2E' } : undefined}>
      <Text style={{ color: items.length ? colors.danger : colors.goldText, fontWeight: '700', fontSize: 15 }}>
        Payments needing attention (admin){items.length ? ` · ${items.length}` : ''}
      </Text>
      {items.length === 0 ? (
        <Body>Nothing to check in PayFast right now.</Body>
      ) : (
        items.map((it) => (
          <View key={it.id} style={{ gap: 4, padding: 12, borderRadius: 12, backgroundColor: colors.redDeep }}>
            <Text style={{ color: colors.danger, fontWeight: '700' }}>{TITLES[it.kind]}</Text>
            {it.client ? <Text style={{ color: colors.text, fontSize: 14, fontWeight: '700' }}>Client: {it.client}</Text> : null}
            <Text style={{ color: colors.text, fontSize: 14, lineHeight: 20 }}>{it.message}</Text>
            {it.pf_payment_id ? <Text selectable style={{ color: colors.muted, fontSize: 12 }}>PayFast payment: {it.pf_payment_id}</Text> : null}
            {it.token ? <Text selectable style={{ color: colors.muted, fontSize: 12 }}>PayFast subscription: {it.token}</Text> : null}
            <Text style={{ color: colors.muted, fontSize: 12 }}>{longDate(it.created_at)}</Text>
            <Pressable accessibilityRole="button" onPress={() => done(it)} style={{ minHeight: 44, justifyContent: 'center' }}>
              <Text style={{ color: colors.goldText, fontWeight: '700' }}>Mark as sorted out</Text>
            </Pressable>
          </View>
        ))
      )}
      <ErrorText>{error}</ErrorText>
    </Card>
  );
}
