import React, { useMemo, useRef, useState } from 'react';
import { ActivityIndicator, Alert, Linking, Modal, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { WebView } from 'react-native-webview';
import type { WebViewMessageEvent } from 'react-native-webview';
import * as Location from 'expo-location';
import { colors } from '../theme';
import { pinMapHtml } from '../map/pinMapHtml';
import { ensureLocationPermission, quickPosition } from '../lib/location';
import { Button } from './ui';

export type HomePin = { lat: number; lng: number };

/** Opens Google Maps at a pin, so the client (or the control room) can check it there. */
export function googleMapsPinUrl(pin: HomePin): string {
  return `https://www.google.com/maps/search/?api=1&query=${pin.lat.toFixed(6)},${pin.lng.toFixed(6)}`;
}

export function openInGoogleMaps(pin: HomePin) {
  Linking.openURL(googleMapsPinUrl(pin)).catch(() => undefined);
}

/** Rough position of a typed address (OpenStreetMap search), to start the map nearby. */
async function findAddress(address: string): Promise<HomePin | null> {
  const q = address.trim();
  if (q.length < 5) return null;
  try {
    const r = await fetch(
      `https://nominatim.openstreetmap.org/search?format=json&limit=1&countrycodes=za&q=${encodeURIComponent(q)}`,
      { headers: { 'User-Agent': 'FireQuest-Panic-App/1.0 (https://firequest-panic.github.io/firequest-app/)', 'Accept-Language': 'en' } },
    );
    if (!r.ok) return null;
    const list = (await r.json()) as { lat: string; lon: string }[];
    if (!list.length) return null;
    const lat = parseFloat(list[0].lat);
    const lng = parseFloat(list[0].lon);
    return Number.isFinite(lat) && Number.isFinite(lng) ? { lat, lng } : null;
  } catch {
    return null;
  }
}

/**
 * Full-screen map: the client moves the map until the red pin is exactly on their home.
 * Starts at the saved pin, else the typed address, else the phone's location.
 */
export function HomePinPicker({
  visible,
  initial,
  address,
  onCancel,
  onConfirm,
}: {
  visible: boolean;
  initial: HomePin | null;
  address: string;
  onCancel: () => void;
  onConfirm: (pin: HomePin) => void;
}) {
  const web = useRef<WebView>(null);
  const html = useMemo(pinMapHtml, []);
  const [center, setCenter] = useState<{ lat: number; lng: number; zoom: number } | null>(null);
  const [hint, setHint] = useState('');
  const [locating, setLocating] = useState(false);

  const goTo = (pin: HomePin, zoom: number) => {
    web.current?.injectJavaScript(`window.fqSetView(${pin.lat}, ${pin.lng}, ${zoom}); true;`);
  };

  const start = async () => {
    if (initial) {
      goTo(initial, 18);
      setHint('');
      return;
    }
    setHint('Looking for your address…');
    const found = await findAddress(address);
    if (found) {
      goTo(found, 16);
      setHint('This is roughly where your address is. Move the map until the pin is exactly on your home.');
      return;
    }
    const here = await quickPosition(4000);
    if (here) {
      goTo(here, 17);
      setHint("Your address was not found on the map, so it starts where your phone is. Move the map to your home.");
    } else {
      setHint('Your address was not found on the map. Zoom in and move the map to your home.');
    }
  };

  const useMyLocation = async () => {
    setLocating(true);
    try {
      if (!(await ensureLocationPermission())) {
        Alert.alert('Location is off', 'Allow FireQuest to use your location, or move the map by hand.');
        return;
      }
      const fix = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Highest });
      goTo({ lat: fix.coords.latitude, lng: fix.coords.longitude }, 19);
      setHint('The pin is where your phone is now. Check that it is on your home.');
    } catch {
      Alert.alert('No GPS fix', 'Your phone could not find its position. Go outside or near a window, or move the map by hand.');
    } finally {
      setLocating(false);
    }
  };

  const onMessage = (e: WebViewMessageEvent) => {
    try {
      const m = JSON.parse(e.nativeEvent.data) as { type: string; lat: number; lng: number; zoom: number };
      setCenter({ lat: m.lat, lng: m.lng, zoom: m.zoom });
      if (m.type === 'ready') start();
    } catch {
      // ignore
    }
  };

  const confirm = () => {
    if (!center) return;
    if (center.zoom < 16) {
      Alert.alert('Zoom in closer', 'Zoom in until you can see your house, then put the pin exactly on it.');
      return;
    }
    onConfirm({ lat: center.lat, lng: center.lng });
  };

  return (
    <Modal visible={visible} animationType="slide" onRequestClose={onCancel}>
      <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }}>
        <View style={{ padding: 14, gap: 4 }}>
          <Text style={{ color: colors.text, fontSize: 20, fontWeight: '800' }}>Put the pin on your home</Text>
          <Text style={{ color: colors.muted, fontSize: 14, lineHeight: 20 }}>
            {hint || 'Move the map with your finger until the red pin is exactly on your house. Pinch to zoom in.'}
          </Text>
        </View>
        <View style={{ flex: 1 }}>
          {visible && (
            <WebView
              ref={web}
              originWhitelist={['*']}
              source={{ html, baseUrl: 'https://firequest-panic.github.io/firequest-app/' }}
              onMessage={onMessage}
              javaScriptEnabled
              domStorageEnabled
              setBuiltInZoomControls={false}
              style={{ flex: 1, backgroundColor: colors.bg }}
              startInLoadingState
              renderLoading={() => (
                <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.bg }}>
                  <ActivityIndicator color={colors.gold} size="large" />
                </View>
              )}
            />
          )}
        </View>
        <View style={{ padding: 14, gap: 8 }}>
          <Button title="This is my home" onPress={confirm} disabled={!center} />
          <View style={{ flexDirection: 'row', gap: 8 }}>
            <Button title="I'm at home now" variant="outline" onPress={useMyLocation} loading={locating} style={{ flex: 1 }} />
            <Button title="Cancel" variant="outline" onPress={onCancel} style={{ flex: 1 }} />
          </View>
        </View>
      </SafeAreaView>
    </Modal>
  );
}
