import { Linking } from 'react-native';
import { FunctionsHttpError } from '@supabase/supabase-js';
import { supabase } from './supabase';

/**
 * Billing state of the family plan (worked out by the database):
 *   none            not on any plan
 *   test            free test plan (test mode only)
 *   active          paid, monthly debit order running
 *   payment_failed  still paid up, but the last debit failed
 *   cancelled_paid  debit order cancelled, still paid up for now
 *   overdue         paid period ended, inside the grace days
 *   unpaid          never paid
 *   lapsed          paid period and grace days are over
 *   cancelled       debit order cancelled and paid period over
 */
export type BillingState =
  | 'none'
  | 'test'
  | 'active'
  | 'payment_failed'
  | 'cancelled_paid'
  | 'overdue'
  | 'unpaid'
  | 'lapsed'
  | 'cancelled';

export interface Billing {
  in_plan: boolean;
  is_owner: boolean;
  state: BillingState;
  /** PAID / PAYMENT LATE / NOT PAID / TEST PLAN / NO SUBSCRIPTION – what the control room sees. */
  label: string;
  covered: boolean;
  test_mode: boolean;
  owner_name?: string;
  price?: number;
  monthly_amount?: number | null;
  paid_until?: string | null;
  grace_until?: string | null;
  last_payment_at?: string | null;
  last_payment_amount?: number | null;
  payment_failed_at?: string | null;
  cancelled_at?: string | null;
  mode?: 'sandbox' | 'live' | null;
  has_debit_order?: boolean;
  pending_since?: string | null;
}

/** States where the plan holder must do something. */
export const ATTENTION_STATES: BillingState[] = ['payment_failed', 'overdue', 'lapsed', 'unpaid', 'cancelled', 'cancelled_paid'];

/** Billing status, or null while the database has not been updated for payments yet. */
export async function getBilling(): Promise<Billing | null> {
  const { data, error } = await supabase.rpc('my_billing');
  if (error) {
    if (/my_billing/.test(error.message) || error.code === 'PGRST202') return null;
    throw error;
  }
  return (data as Billing | null) ?? null;
}

interface PayfastAnswer {
  url?: string;
  unavailable?: boolean;
  message?: string;
  kind?: 'new' | 'fix';
  mode?: 'sandbox' | 'live';
}

async function callPayfast(action: 'checkout' | 'card_update'): Promise<PayfastAnswer> {
  const { data, error } = await supabase.functions.invoke('payfast', { body: { action } });
  if (error) {
    let message = '';
    if (error instanceof FunctionsHttpError) {
      try {
        const body = await error.context.json();
        message = typeof body?.error === 'string' ? body.error : '';
      } catch {
        // not JSON
      }
    }
    throw new Error(message || 'Could not reach FireQuest payments. Check your connection and try again.');
  }
  return (data as PayfastAnswer) ?? {};
}

/** Opens PayFast's secure payment page (first payment now, then monthly). */
export async function openCheckout(): Promise<PayfastAnswer> {
  const answer = await callPayfast('checkout');
  if (!answer.url) throw new Error('PayFast did not answer. Please try again.');
  await Linking.openURL(answer.url);
  return answer;
}

/** Opens PayFast's page for changing the card on the monthly debit order (live system only). */
export async function openCardUpdate(): Promise<PayfastAnswer> {
  const answer = await callPayfast('card_update');
  if (answer.url) await Linking.openURL(answer.url);
  return answer;
}

/** Test mode only: pretend a payment problem, to try the screens. */
export async function billingTest(what: 'failed' | 'late' | 'lapsed' | 'reset'): Promise<Billing> {
  const { data, error } = await supabase.rpc('billing_test', { p_what: what });
  if (error) throw error;
  return data as Billing;
}

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

export function longDate(iso: string | null | undefined): string {
  if (!iso) return '';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '';
  return `${d.getDate()} ${MONTHS[d.getMonth()]} ${d.getFullYear()}`;
}

/** Last day of cover: "paid until" is midnight at the start of the next day. */
export function coverDate(iso: string | null | undefined): string {
  if (!iso) return '';
  const t = Date.parse(iso);
  return Number.isNaN(t) ? '' : longDate(new Date(t - 1000).toISOString());
}

export function rand(amount: number | string | null | undefined): string {
  const n = Number(amount);
  if (!Number.isFinite(n)) return '';
  return `R${n.toFixed(2)}`;
}

export type Tone = 'ok' | 'warn' | 'bad' | 'test';

/** Plain-language status for the plan holder. */
export function holderSummary(b: Billing): { title: string; text: string; tone: Tone } {
  const price = rand(b.monthly_amount ?? b.price);
  const until = coverDate(b.paid_until);
  switch (b.state) {
    case 'test':
      return {
        title: 'Free test plan',
        text: 'During testing your family plan is free. You can try a PayFast test payment; no real money moves.',
        tone: 'test',
      };
    case 'active':
      return {
        title: 'Paid – thank you',
        text: `You and your family are covered until ${until}. ${price} is debited from your card every month through PayFast.`,
        tone: 'ok',
      };
    case 'payment_failed':
      return {
        title: 'Your last payment did not go through',
        text: `Your bank declined this month's debit. You are still covered until ${until}. Please fix the payment so your family stays covered.`,
        tone: 'warn',
      };
    case 'overdue':
      return {
        title: 'Payment overdue',
        text: `Your paid period ended on ${until}. Please pay by ${coverDate(b.grace_until)} to stay covered. Your panic buttons still work.`,
        tone: 'warn',
      };
    case 'lapsed':
      return {
        title: 'Not paid',
        text: 'Your FireQuest subscription is not paid. Your panic buttons still work, but the control room sees NOT PAID when you raise an alert. Pay now to restore your cover.',
        tone: 'bad',
      };
    case 'cancelled_paid':
      return {
        title: 'Debit order cancelled',
        text: `Your monthly debit order was cancelled. You are covered until ${until}. Restart it to stay covered.`,
        tone: 'warn',
      };
    case 'cancelled':
      return {
        title: 'Subscription cancelled',
        text: 'Your FireQuest debit order was cancelled and your paid period is over. Restart it to be covered again.',
        tone: 'bad',
      };
    case 'unpaid':
      return {
        title: 'Not paid yet',
        text: `Subscribe with PayFast to activate your family plan: ${price} a month by debit order.`,
        tone: 'bad',
      };
    default:
      return {
        title: 'No subscription yet',
        text: `The FireQuest Family plan covers you and up to 3 family members for ${price} a month, by debit order through PayFast.`,
        tone: b.test_mode ? 'test' : 'bad',
      };
  }
}

/** One-line warning for the home screen, or null when all is well. Plan holders only. */
export function homeWarning(b: Billing | null): { text: string; tone: Tone } | null {
  if (!b) return null;
  if (!b.in_plan) return b.test_mode ? null : { text: 'You have no FireQuest subscription yet – tap to subscribe', tone: 'bad' };
  if (!b.is_owner) return null;
  switch (b.state) {
    case 'payment_failed':
      return { text: 'Your last FireQuest payment failed – tap to fix it', tone: 'warn' };
    case 'overdue':
      return { text: 'Your FireQuest payment is overdue – tap to pay', tone: 'warn' };
    case 'cancelled_paid':
      return { text: 'Your FireQuest debit order was cancelled – tap to restart it', tone: 'warn' };
    case 'lapsed':
    case 'unpaid':
    case 'cancelled':
      return { text: 'Your FireQuest subscription is not paid – tap to pay', tone: 'bad' };
    default:
      return null;
  }
}
