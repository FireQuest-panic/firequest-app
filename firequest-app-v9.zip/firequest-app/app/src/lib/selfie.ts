import * as ImagePicker from 'expo-image-picker';
import { manipulateAsync, SaveFormat } from 'expo-image-manipulator';
import { supabase } from './supabase';

/** Every client's selfie lives at selfies/<user id>/selfie.jpg (private bucket). */
export const selfiePath = (userId: string) => `${userId}/selfie.jpg`;

const B64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';

function base64ToArrayBuffer(b64: string): ArrayBuffer {
  const clean = b64.replace(/[^A-Za-z0-9+/]/g, '');
  const bytes = new Uint8Array(Math.floor((clean.length * 3) / 4));
  let p = 0;
  for (let i = 0; i < clean.length; i += 4) {
    const a = B64.indexOf(clean[i]);
    const b = B64.indexOf(clean[i + 1]);
    const c = i + 2 < clean.length ? B64.indexOf(clean[i + 2]) : -1;
    const d = i + 3 < clean.length ? B64.indexOf(clean[i + 3]) : -1;
    bytes[p++] = (a << 2) | (b >> 4);
    if (c >= 0) bytes[p++] = ((b & 15) << 4) | (c >> 2);
    if (d >= 0) bytes[p++] = ((c & 3) << 6) | d;
  }
  return bytes.buffer.slice(0, p);
}

/**
 * Take a selfie with the front camera (or pick a photo), shrink it to 640 px,
 * and save it for this client. Returns false when the person cancelled.
 */
export async function chooseSelfie(userId: string, source: 'camera' | 'library'): Promise<boolean> {
  const options: ImagePicker.ImagePickerOptions = {
    mediaTypes: ['images'],
    allowsEditing: true,
    aspect: [1, 1],
    quality: 0.8,
  };
  let result: ImagePicker.ImagePickerResult;
  if (source === 'camera') {
    const perm = await ImagePicker.requestCameraPermissionsAsync();
    if (!perm.granted) {
      throw new Error('FireQuest needs the camera for your selfie. Allow the camera in your phone settings, or choose a photo instead.');
    }
    result = await ImagePicker.launchCameraAsync({ ...options, cameraType: ImagePicker.CameraType.front });
  } else {
    result = await ImagePicker.launchImageLibraryAsync(options);
  }
  if (result.canceled || !result.assets?.length) return false;

  const small = await manipulateAsync(result.assets[0].uri, [{ resize: { width: 640 } }], {
    compress: 0.7,
    format: SaveFormat.JPEG,
    base64: true,
  });
  if (!small.base64) throw new Error('The photo could not be read. Please try again.');

  const { error } = await supabase.storage
    .from('selfies')
    .upload(selfiePath(userId), base64ToArrayBuffer(small.base64), { contentType: 'image/jpeg', upsert: true });
  if (error) throw error;
  const saved = await supabase.from('profiles').update({ selfie_updated_at: new Date().toISOString() }).eq('id', userId);
  if (saved.error) throw saved.error;
  return true;
}

/** Remove this client's selfie. */
export async function removeSelfie(userId: string): Promise<void> {
  const { error } = await supabase.storage.from('selfies').remove([selfiePath(userId)]);
  if (error) throw error;
  const saved = await supabase.from('profiles').update({ selfie_updated_at: null }).eq('id', userId);
  if (saved.error) throw saved.error;
}

/** A short-lived link to show a selfie (the bucket is private). Null when there is none or it may not be seen. */
export async function selfieUrl(userId: string, updatedAt: string | null | undefined): Promise<string | null> {
  if (!updatedAt) return null;
  const { data, error } = await supabase.storage.from('selfies').createSignedUrl(selfiePath(userId), 3600);
  if (error || !data?.signedUrl) return null;
  // A new address after every change, so the phone never shows an old photo from its cache.
  return `${data.signedUrl}&v=${encodeURIComponent(updatedAt)}`;
}
