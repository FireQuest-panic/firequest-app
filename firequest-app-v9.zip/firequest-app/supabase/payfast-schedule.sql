-- FireQuest – run the PayFast clean-up every 15 minutes.
-- Calls the "payfast" server function, which cancels any old debit order that
-- could not be cancelled straight away (so a client never pays twice).
-- Run once, after 005_payfast.sql. Change the address if you use another Supabase project.
-- If the scheduler cannot be switched on, the rest still works; the clean-up then only
-- runs when PayFast sends a notification.
do $$
begin
  create extension if not exists pg_cron with schema pg_catalog;
  create extension if not exists pg_net;
  perform cron.schedule(
    'payfast-retry',
    '*/15 * * * *',
    $job$select net.http_post(url := 'https://pwlgbvzslpidlidhjzeo.supabase.co/functions/v1/payfast/retry', body := '{}'::jsonb, headers := jsonb_build_object('Content-Type', 'application/json', 'x-retry-key', (select retry_key from private.payfast_settings where id = 1)), timeout_milliseconds := 60000)$job$
  );
exception when others then
  raise notice 'PayFast clean-up schedule not set up: %', sqlerrm;
end $$;
