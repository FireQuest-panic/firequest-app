-- =====================================================================
-- FireQuest – PayFast billing (one monthly subscription per family plan)
-- * The plan holder pays one monthly PayFast subscription (card debit).
-- * PayFast reports every payment to the "payfast" server function (ITN).
--   The function checks each report with PayFast, then records it here.
-- * "Paid until" decides whether the family is covered. When a debit fails
--   the holder sees "Pay now" in the app. The panic buttons always keep
--   working; the control room sees PAID / PAYMENT LATE / NOT PAID.
-- * Payments made in PayFast's sandbox (test money) stop counting as soon
--   as test mode is switched off.
-- * Anything that needs a person (a refund, a debit order that could not be
--   cancelled automatically) is listed for FireQuest admins in the app.
-- Run after 004_crash_detection.sql. (Also included in schema.sql.)
-- =====================================================================

-- Price of the Family plan (up to 4 people) and days of grace after a missed debit.
alter table public.app_settings add column if not exists plan_price numeric(10,2) not null default 199.00;
alter table public.app_settings add column if not exists grace_days int not null default 7;
alter table public.app_settings drop constraint if exists app_settings_plan_price_check;
alter table public.app_settings add constraint app_settings_plan_price_check check (plan_price >= 5);
alter table public.app_settings drop constraint if exists app_settings_grace_days_check;
alter table public.app_settings add constraint app_settings_grace_days_check check (grace_days between 0 and 30);

-- Billing details of each family plan.
alter table public.subscriptions add column if not exists paid_until timestamptz;
alter table public.subscriptions add column if not exists next_billing_date date;
alter table public.subscriptions add column if not exists billing_day int;
alter table public.subscriptions add column if not exists payfast_token text;
alter table public.subscriptions add column if not exists payfast_mode text;
alter table public.subscriptions add column if not exists monthly_amount numeric(10,2);
alter table public.subscriptions add column if not exists last_payment_at timestamptz;
alter table public.subscriptions add column if not exists last_payment_amount numeric(10,2);
alter table public.subscriptions add column if not exists payment_failed_at timestamptz;
alter table public.subscriptions add column if not exists cancelled_at timestamptz;
alter table public.subscriptions drop constraint if exists subscriptions_payfast_mode_check;
alter table public.subscriptions add constraint subscriptions_payfast_mode_check check (payfast_mode in ('sandbox', 'live'));
alter table public.subscriptions drop constraint if exists subscriptions_billing_day_check;
alter table public.subscriptions add constraint subscriptions_billing_day_check check (billing_day between 1 and 31);
update public.subscriptions set status = 'test' where status not in ('test', 'unpaid', 'active', 'cancelled');
alter table public.subscriptions drop constraint if exists subscriptions_status_check;
alter table public.subscriptions add constraint subscriptions_status_check check (status in ('test', 'unpaid', 'active', 'cancelled'));
create unique index if not exists subscriptions_payfast_token_idx on public.subscriptions (payfast_token) where payfast_token is not null;

-- Every PayFast checkout started from the app (its id is PayFast's m_payment_id).
-- "form" holds the signed PayFast form; the payment page fetches it by id.
create table if not exists private.payfast_checkouts (
  id              uuid primary key default gen_random_uuid(),
  subscription_id uuid references public.subscriptions (id) on delete set null,
  user_id         uuid references public.profiles (id) on delete set null,
  kind            text not null check (kind in ('new', 'fix')),
  amount          numeric(10,2) not null,
  mode            text not null check (mode in ('sandbox', 'live')),
  created_at      timestamptz not null default now(),
  form            jsonb,
  abandoned_at    timestamptz,
  completed_at    timestamptz,
  token           text
);
alter table private.payfast_checkouts add column if not exists form jsonb;
alter table private.payfast_checkouts add column if not exists abandoned_at timestamptz;
create index if not exists payfast_checkouts_sub_idx on private.payfast_checkouts (subscription_id, created_at desc);
create index if not exists payfast_checkouts_user_idx on private.payfast_checkouts (user_id, created_at desc);

-- Every notification PayFast sent, with what was done with it.
create table if not exists private.payfast_events (
  id              bigint generated always as identity primary key,
  received_at     timestamptz not null default now(),
  mode            text,
  valid           boolean not null,
  pf_payment_id   text,
  m_payment_id    text,
  payment_status  text,
  token           text,
  amount_gross    numeric(10,2),
  subscription_id uuid,
  outcome         text not null,
  data            jsonb
);
create index if not exists payfast_events_pf_idx on private.payfast_events (pf_payment_id);

-- Debit orders that must be stopped at PayFast (replaced by "Pay now", left over
-- from a deleted plan, or charging without being credited). The server function
-- cancels them, and retries every 15 minutes until PayFast confirms.
create table if not exists private.payfast_old_tokens (
  token           text primary key,
  mode            text not null,
  replaced_at     timestamptz not null default now(),
  cancelled_at    timestamptz,
  attempts        int not null default 0,
  last_attempt_at timestamptz,
  last_error      text
);
alter table private.payfast_old_tokens add column if not exists last_attempt_at timestamptz;

-- Things a FireQuest admin must look at in PayFast (refunds, failed cancels).
create table if not exists private.payfast_attention (
  id          bigint generated always as identity primary key,
  created_at  timestamptz not null default now(),
  kind        text not null check (kind in ('refund', 'cancel_failed', 'unknown_payment', 'plan_deleted')),
  message     text not null,
  token       text,
  pf_payment_id text,
  client      text,
  resolved_at timestamptz,
  resolved_by uuid
);
alter table private.payfast_attention add column if not exists client text;

-- A random key that only the database and the server function know; the 15-minute
-- clean-up job sends it, so nobody else can start the clean-up.
create table if not exists private.payfast_settings (
  id        int primary key default 1 check (id = 1),
  retry_key text not null default encode(extensions.gen_random_bytes(24), 'hex')
);
insert into private.payfast_settings (id) values (1) on conflict (id) do nothing;

revoke all on private.payfast_checkouts, private.payfast_events, private.payfast_old_tokens, private.payfast_attention,
  private.payfast_settings from public, anon, authenticated;

-- Who a PayFast debit order belongs to, for messages to FireQuest admins:
-- the client's name and email as PayFast reported them, or the plan holder.
create or replace function private.payfast_token_client(p_token text)
returns text language sql stable security definer set search_path = public as $$
  select coalesce(
    (select nullif(trim(coalesce(e.data ->> 'name_first', '') || ' ' || coalesce(e.data ->> 'name_last', '')
                        || coalesce(' <' || nullif(e.data ->> 'email_address', '') || '>', '')), '')
       from private.payfast_events e
      where e.token = p_token and e.valid and e.data is not null
      order by e.received_at desc limit 1),
    (select nullif(trim(coalesce(p.full_name, '') || coalesce(' <' || p.email || '>', '')), '')
       from public.subscriptions s join public.profiles p on p.id = s.owner_id
      where s.payfast_token = p_token limit 1),
    'unknown client')
$$;

-- ---------------------------------------------------------------------
-- Dates. Debits run on the same day every month (the day the debit order
-- started; shorter months use their last day). A plan is paid until the end
-- of the day after its next debit day, South African time.
-- ---------------------------------------------------------------------
create or replace function private.sa_today()
returns date language sql stable set search_path = public as $$
  select (now() at time zone 'Africa/Johannesburg')::date
$$;

create or replace function private.add_billing_month(p_date date, p_day int)
returns date language sql immutable set search_path = public as $$
  select (date_trunc('month', p_date::timestamp) + interval '1 month')::date
         + (least(p_day, extract(day from date_trunc('month', p_date::timestamp) + interval '2 months' - interval '1 day')::int) - 1)
$$;

create or replace function private.cover_until(p_next_billing date)
returns timestamptz language sql immutable set search_path = public as $$
  select ((p_next_billing + 2)::timestamp) at time zone 'Africa/Johannesburg'
$$;

-- ---------------------------------------------------------------------
-- Billing state of a plan:
--   test            free test plan (only while test mode is on)
--   active          paid, monthly debit running
--   payment_failed  still paid up, but the last debit failed
--   cancelled_paid  debit order cancelled, still paid up for now
--   overdue         paid period ended, inside the grace days
--   unpaid          never paid
--   lapsed          paid period and grace days are over
--   cancelled       debit order cancelled and paid period over
-- ---------------------------------------------------------------------
create or replace function private.billing_paid_until(s public.subscriptions)
returns timestamptz language sql stable set search_path = public as $$
  select case when coalesce(s.payfast_mode, 'sandbox') = 'sandbox'
               and not coalesce((select test_mode from public.app_settings where id = 1), true)
              then null else s.paid_until end
$$;

create or replace function private.billing_state(s public.subscriptions)
returns text language plpgsql stable set search_path = public as $$
declare
  v_test  boolean := coalesce((select test_mode from public.app_settings where id = 1), true);
  v_grace interval := make_interval(days => coalesce((select grace_days from public.app_settings where id = 1), 7));
  v_paid  timestamptz := private.billing_paid_until(s);
begin
  if s.id is null then return 'none'; end if;
  if v_paid is not null and v_paid > now() then
    if s.status = 'cancelled' then return 'cancelled_paid'; end if;
    if s.payment_failed_at is not null then return 'payment_failed'; end if;
    return 'active';
  end if;
  if v_paid is not null and v_paid + v_grace > now() and s.status <> 'cancelled' then return 'overdue'; end if;
  if v_paid is null and s.status = 'test' and v_test then return 'test'; end if;
  if s.status = 'cancelled' then return 'cancelled'; end if;
  if v_paid is null then return 'unpaid'; end if;
  return 'lapsed';
end $$;

-- Short label the control room sees.
create or replace function private.billing_label(p_state text)
returns text language sql immutable set search_path = public as $$
  select case
    when p_state in ('active', 'payment_failed', 'cancelled_paid') then 'PAID'
    when p_state = 'overdue' then 'PAYMENT LATE'
    when p_state = 'test' then 'TEST PLAN'
    when p_state = 'none' then 'NO SUBSCRIPTION'
    else 'NOT PAID' end
$$;

-- Queue a debit order to be stopped at PayFast.
create or replace function private.payfast_queue_cancel(p_token text, p_mode text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if p_token is null then return; end if;
  insert into private.payfast_old_tokens (token, mode) values (p_token, coalesce(p_mode, 'sandbox'))
  on conflict (token) do update set cancelled_at = null, attempts = 0, last_attempt_at = null, last_error = null;
end $$;

-- A plan that is deleted (person joins another family, or the account is deleted)
-- must not leave a debit order running.
create or replace function private.subscription_deleted()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if old.payfast_token is not null then
    perform private.payfast_queue_cancel(old.payfast_token, old.payfast_mode);
    if old.payfast_mode = 'live' then
      insert into private.payfast_attention (kind, message, token, client)
      values ('plan_deleted', 'A family plan with a running debit order was deleted. FireQuest is cancelling the debit order at PayFast automatically; check in PayFast that subscription '
              || old.payfast_token || ' is cancelled.', old.payfast_token,
              coalesce((select nullif(trim(coalesce(full_name, '') || coalesce(' <' || email || '>', '')), '')
                          from public.profiles where id = old.owner_id), private.payfast_token_client(old.payfast_token)));
    end if;
  end if;
  return old;
end $$;

drop trigger if exists subscription_deleted on public.subscriptions;
create trigger subscription_deleted before delete on public.subscriptions
  for each row execute function private.subscription_deleted();

-- ---------------------------------------------------------------------
-- App: billing status for the signed-in person.
-- The plan holder sees everything; family members only see who pays.
-- ---------------------------------------------------------------------
create or replace function public.my_billing()
returns json language plpgsql stable security definer set search_path = public as $$
declare
  v_uid   uuid := auth.uid();
  v_set   public.app_settings;
  v_sub   public.subscriptions;
  v_state text;
  v_paid  timestamptz;
begin
  if v_uid is null then raise exception 'Not signed in'; end if;
  select * into v_set from public.app_settings where id = 1;
  select s.* into v_sub
    from public.subscription_members m join public.subscriptions s on s.id = m.subscription_id
   where m.user_id = v_uid;
  if not found then
    return json_build_object('in_plan', false, 'is_owner', false, 'state', 'none',
                             'label', private.billing_label('none'), 'covered', false,
                             'price', v_set.plan_price, 'test_mode', v_set.test_mode);
  end if;

  v_state := private.billing_state(v_sub);
  v_paid  := private.billing_paid_until(v_sub);

  if v_sub.owner_id <> v_uid then
    return json_build_object('in_plan', true, 'is_owner', false, 'state', v_state,
      'label', private.billing_label(v_state),
      'covered', v_state in ('test', 'active', 'payment_failed', 'cancelled_paid', 'overdue'),
      'owner_name', (select full_name from public.profiles where id = v_sub.owner_id),
      'test_mode', v_set.test_mode);
  end if;

  return json_build_object(
    'in_plan', true,
    'is_owner', true,
    'state', v_state,
    'label', private.billing_label(v_state),
    'covered', v_state in ('test', 'active', 'payment_failed', 'cancelled_paid', 'overdue'),
    'price', v_set.plan_price,
    'monthly_amount', v_sub.monthly_amount,
    'paid_until', v_paid,
    'next_debit', case when v_paid is null or v_sub.status <> 'active' then null else v_sub.next_billing_date end,
    'grace_until', v_paid + make_interval(days => v_set.grace_days),
    'last_payment_at', case when v_paid is null then null else v_sub.last_payment_at end,
    'last_payment_amount', case when v_paid is null then null else v_sub.last_payment_amount end,
    'payment_failed_at', v_sub.payment_failed_at,
    'cancelled_at', v_sub.cancelled_at,
    'mode', v_sub.payfast_mode,
    'has_debit_order', v_sub.payfast_token is not null and v_sub.status = 'active',
    'test_mode', v_set.test_mode,
    'pending_since', (
      select max(c.created_at) from private.payfast_checkouts c
       where c.subscription_id = v_sub.id and c.completed_at is null and c.abandoned_at is null
         and c.created_at > now() - interval '30 minutes'
         and c.created_at > coalesce(v_sub.last_payment_at, '-infinity'::timestamptz))
  );
end $$;

-- ---------------------------------------------------------------------
-- Control room: payment status of the client who raised an alert.
-- ---------------------------------------------------------------------
create or replace function public.alert_billing(p_alert_id uuid)
returns json language plpgsql stable security definer set search_path = public as $$
declare
  v_client uuid;
  v_sub    public.subscriptions;
  v_state  text;
begin
  if not public.is_staff() then raise exception 'Not authorised'; end if;
  select user_id into v_client from public.alerts where id = p_alert_id;
  if v_client is null then return null; end if;
  select s.* into v_sub
    from public.subscription_members m join public.subscriptions s on s.id = m.subscription_id
   where m.user_id = v_client;
  v_state := private.billing_state(v_sub);
  return json_build_object(
    'state', v_state,
    'label', private.billing_label(v_state),
    'paid_until', private.billing_paid_until(v_sub),
    'holder_name', (select full_name from public.profiles where id = v_sub.owner_id),
    'client_is_holder', v_sub.owner_id = v_client);
end $$;

-- ---------------------------------------------------------------------
-- FireQuest admins: payments that need a person (refunds, failed cancels).
-- ---------------------------------------------------------------------
create or replace function public.payments_attention()
returns json language plpgsql stable security definer set search_path = public as $$
begin
  if not exists (select 1 from public.staff where user_id = auth.uid() and role = 'admin') then
    raise exception 'Not authorised';
  end if;
  return (
    select coalesce(json_agg(json_build_object('id', a.id, 'kind', a.kind, 'message', a.message,
                                               'created_at', a.created_at, 'pf_payment_id', a.pf_payment_id,
                                               'token', a.token, 'client', a.client)
                             order by a.created_at desc), '[]'::json)
      from private.payfast_attention a
     where a.resolved_at is null);
end $$;

create or replace function public.payments_attention_done(p_id bigint)
returns json language plpgsql security definer set search_path = public as $$
begin
  if not exists (select 1 from public.staff where user_id = auth.uid() and role = 'admin') then
    raise exception 'Not authorised';
  end if;
  update private.payfast_attention set resolved_at = now(), resolved_by = auth.uid()
   where id = p_id and resolved_at is null;
  return public.payments_attention();
end $$;

-- ---------------------------------------------------------------------
-- Test mode only: let the plan holder try the "payment problem" screens.
--   failed  = this month's debit failed (still paid up for 2 days)
--   late    = paid period ended yesterday (inside the grace days)
--   lapsed  = not paid for longer than the grace days
--   reset   = back to a free test plan
-- Everything set here counts as sandbox (test) payments only.
-- ---------------------------------------------------------------------
create or replace function public.billing_test(p_what text)
returns json language plpgsql security definer set search_path = public as $$
declare
  v_uid   uuid := auth.uid();
  v_sub   public.subscriptions;
  v_grace int := coalesce((select grace_days from public.app_settings where id = 1), 7);
  v_next  date;
begin
  if v_uid is null then raise exception 'Not signed in'; end if;
  if not coalesce((select test_mode from public.app_settings where id = 1), false) then
    raise exception 'Payment tests are only available in test mode.';
  end if;
  select * into v_sub from public.subscriptions where owner_id = v_uid for update;
  if not found then raise exception 'Start a family plan first.'; end if;
  if v_sub.payfast_mode = 'live' then raise exception 'This plan has real PayFast payments. Tests are not allowed on it.'; end if;

  if p_what in ('failed', 'late', 'lapsed') then
    v_next := case p_what when 'failed' then private.sa_today()
                          when 'late' then private.sa_today() - 3
                          else private.sa_today() - v_grace - 3 end;
    update public.subscriptions set
      next_billing_date = v_next,
      billing_day       = coalesce(billing_day, extract(day from v_next)::int),
      paid_until        = private.cover_until(v_next),
      payment_failed_at = now(),
      payfast_mode      = 'sandbox',
      status            = case when status = 'cancelled' then 'active' else status end,
      cancelled_at      = null
     where id = v_sub.id;
  elsif p_what = 'reset' then
    perform private.payfast_queue_cancel(v_sub.payfast_token, 'sandbox');
    update public.subscriptions set status = 'test', paid_until = null, next_billing_date = null, billing_day = null,
           payfast_token = null, payfast_mode = null, monthly_amount = null, last_payment_at = null,
           last_payment_amount = null, payment_failed_at = null, cancelled_at = null
     where id = v_sub.id;
  else
    raise exception 'Unknown test %', p_what;
  end if;
  return public.my_billing();
end $$;

-- ---------------------------------------------------------------------
-- Server function only (not reachable from the apps).
-- ---------------------------------------------------------------------

-- Start a PayFast checkout for the plan holder. Creates the plan when the person has none.
create or replace function private.payfast_start_checkout(p_uid uuid, p_mode text)
returns json language plpgsql security definer set search_path = public as $$
declare
  v_set   public.app_settings;
  v_prof  public.profiles;
  v_sub   public.subscriptions;
  v_state text;
  v_kind  text;
  v_co    uuid;
  v_email text;
begin
  if p_mode not in ('sandbox', 'live') then raise exception 'Unknown PayFast mode'; end if;
  select * into v_set from public.app_settings where id = 1;
  select * into v_prof from public.profiles where id = p_uid;
  if not found then raise exception 'Finish your FireQuest registration first.'; end if;
  if p_mode = 'sandbox' and not v_set.test_mode then
    raise exception 'Payments are being set up. Please try again later or phone FireQuest.';
  end if;
  if p_mode = 'live' and v_set.test_mode then
    raise exception 'FireQuest is still in test mode. Real payments start when FireQuest goes live.';
  end if;
  if (select count(*) from private.payfast_checkouts
       where user_id = p_uid and created_at > now() - interval '1 hour') >= 15 then
    raise exception 'Too many payment attempts. Please wait an hour or phone FireQuest.';
  end if;

  select s.* into v_sub
    from public.subscription_members m join public.subscriptions s on s.id = m.subscription_id
   where m.user_id = p_uid
     for update of s;
  if found and v_sub.owner_id <> p_uid then
    raise exception 'Your family plan is paid by %. Only the plan holder can pay.',
      coalesce(nullif((select full_name from public.profiles where id = v_sub.owner_id), ''), 'the plan holder');
  end if;
  if not found then
    insert into public.subscriptions (owner_id, status)
    values (p_uid, case when v_set.test_mode then 'test' else 'unpaid' end)
    returning * into v_sub;
    insert into public.subscription_members (subscription_id, user_id, role, relationship)
    values (v_sub.id, p_uid, 'owner', 'holder');
  end if;

  v_state := private.billing_state(v_sub);
  if v_state = 'active' and v_sub.payfast_token is not null and v_sub.payfast_mode = p_mode then
    raise exception 'Your subscription is paid and the monthly debit order is running. There is nothing to pay now.';
  end if;

  v_kind := case when v_sub.payfast_token is not null and v_sub.status = 'active' then 'fix' else 'new' end;
  insert into private.payfast_checkouts (subscription_id, user_id, kind, amount, mode)
  values (v_sub.id, p_uid, v_kind, v_set.plan_price, p_mode)
  returning id into v_co;

  select email into v_email from auth.users where id = p_uid;
  return json_build_object(
    'm_payment_id', v_co,
    'subscription_id', v_sub.id,
    'kind', v_kind,
    'amount', to_char(v_set.plan_price, 'FM999990.00'),
    'full_name', v_prof.full_name,
    'email', coalesce(v_email, v_prof.email, ''));
end $$;

-- The signed form is kept with the checkout; the payment page fetches it (for 2 hours).
create or replace function private.payfast_save_form(p_id uuid, p_form jsonb)
returns void language sql security definer set search_path = public as $$
  update private.payfast_checkouts set form = p_form where id = p_id
$$;

create or replace function private.payfast_checkout_form(p_id uuid)
returns jsonb language sql stable security definer set search_path = public as $$
  select form from private.payfast_checkouts
   where id = p_id and completed_at is null and abandoned_at is null
     and created_at > now() - interval '2 hours'
$$;

-- The client cancelled on PayFast's page: stop showing "waiting for PayFast".
create or replace function private.payfast_checkout_abandoned(p_id uuid)
returns void language sql security definer set search_path = public as $$
  update private.payfast_checkouts set abandoned_at = coalesce(abandoned_at, now())
   where id = p_id and completed_at is null
$$;

-- Token for PayFast's "update card" page (plan holder with a running debit order).
create or replace function private.payfast_card_token(p_uid uuid)
returns json language plpgsql stable security definer set search_path = public as $$
declare
  v_sub public.subscriptions;
begin
  select * into v_sub from public.subscriptions where owner_id = p_uid;
  if not found or v_sub.payfast_token is null or v_sub.status <> 'active' then
    raise exception 'There is no monthly debit order to update. Tap "Pay now" instead.';
  end if;
  return json_build_object('token', v_sub.payfast_token, 'mode', v_sub.payfast_mode);
end $$;

-- Record a PayFast notification (ITN) that the server function has already checked.
-- Returns the outcome, and a debit order to cancel at PayFast (if any).
create or replace function private.payfast_apply_itn(p_data jsonb, p_mode text, p_valid boolean, p_note text default null)
returns json language plpgsql security definer set search_path = public as $$
declare
  v_status  text := upper(coalesce(p_data ->> 'payment_status', ''));
  v_pf      text := nullif(p_data ->> 'pf_payment_id', '');
  v_mpid    text := nullif(p_data ->> 'm_payment_id', '');
  v_token   text := nullif(p_data ->> 'token', '');
  v_custom  text := nullif(p_data ->> 'custom_str1', '');
  v_price   numeric := (select plan_price from public.app_settings where id = 1);
  v_amount  numeric;
  v_co      private.payfast_checkouts;
  v_sub     public.subscriptions;
  v_outcome text;
  v_cancel  text;
  v_cmode   text;
  v_refund  boolean := false;
  v_new     boolean := false;
  v_day     int;
  v_base    date;
  v_next    date;
  v_today   date := private.sa_today();
begin
  begin
    v_amount := nullif(p_data ->> 'amount_gross', '')::numeric;
  exception when others then
    v_amount := null;
  end;

  if not coalesce(p_valid, false) then
    insert into private.payfast_events (mode, valid, pf_payment_id, m_payment_id, payment_status, token, amount_gross, outcome)
    values (p_mode, false, left(v_pf, 64), left(v_mpid, 64), left(v_status, 20), left(v_token, 64), v_amount,
            left('rejected: ' || coalesce(p_note, 'failed the PayFast checks'), 300));
    return json_build_object('outcome', 'rejected');
  end if;

  if v_mpid ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$' then
    select * into v_co from private.payfast_checkouts where id = v_mpid::uuid;
  end if;
  if v_token is not null then
    select * into v_sub from public.subscriptions where payfast_token = v_token for update;
  end if;
  if v_sub.id is null and v_co.subscription_id is not null then
    select * into v_sub from public.subscriptions where id = v_co.subscription_id for update;
  end if;
  if v_sub.id is null and v_custom ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$' then
    select * into v_sub from public.subscriptions where id = v_custom::uuid for update;
  end if;

  if v_status = 'CANCELLED' and v_token is not null then
    update private.payfast_old_tokens set cancelled_at = coalesce(cancelled_at, now()) where token = v_token;
  end if;

  if v_pf is not null and exists (
      select 1 from private.payfast_events
       where pf_payment_id = v_pf and payment_status = v_status and valid) then
    v_outcome := 'duplicate';
  elsif v_status = 'COMPLETE' then
    if v_sub.id is not null and v_token is not null and v_token = v_sub.payfast_token then
      -- A monthly debit on the current debit order.
      if v_amount is null or v_amount < least(coalesce(v_sub.monthly_amount, v_price), v_price) - 0.01 then
        v_outcome := 'ignored: monthly payment smaller than the plan price';
        v_refund := true;
      elsif v_sub.payfast_mode is distinct from p_mode then
        v_outcome := 'ignored: payment from the other PayFast mode';
      end if;
    else
      -- The first payment of a new checkout: it must be ours, unused, and the full amount.
      if v_token is not null and exists (select 1 from private.payfast_old_tokens o where o.token = v_token) then
        v_outcome := 'ignored: payment on a stopped debit order';
      elsif v_co.id is null then
        v_outcome := 'ignored: unknown checkout';
      elsif v_sub.id is null then
        v_outcome := 'ignored: the family plan no longer exists';
      elsif v_co.mode <> p_mode then
        v_outcome := 'ignored: checkout was made in the other PayFast mode';
      elsif v_sub.payfast_mode = 'live' and p_mode = 'sandbox' then
        v_outcome := 'ignored: sandbox payment on a live plan';
      elsif v_co.completed_at is not null then
        v_outcome := 'ignored: this checkout was already paid';
      elsif v_co.subscription_id is distinct from v_sub.id then
        v_outcome := 'ignored: checkout belongs to another plan';
      elsif v_amount is null or v_amount < v_co.amount - 0.01 then
        v_outcome := 'ignored: amount too low';
      else
        v_new := true;
      end if;
      if v_outcome is not null then
        v_refund := true;
        -- Money was taken but nothing is credited: stop that debit order (only ones FireQuest started).
        if v_token is not null and v_co.id is not null then
          v_cancel := v_token;
          v_cmode  := p_mode;
          perform private.payfast_queue_cancel(v_token, p_mode);
        end if;
      end if;
    end if;

    if v_outcome is null then
      if v_new then
        -- New debit order: it replaces the old one, and debits on this day each month.
        if v_token is not null and v_sub.payfast_token is not null and v_sub.payfast_token <> v_token then
          v_cancel := v_sub.payfast_token;
          v_cmode  := coalesce(v_sub.payfast_mode, p_mode);
          perform private.payfast_queue_cancel(v_cancel, v_cmode);
        end if;
        v_day := extract(day from v_today)::int;
        v_base := v_today;
        if v_sub.payfast_mode = p_mode and v_sub.next_billing_date > v_today then
          v_base := v_sub.next_billing_date;  -- still paid up: add the new month on top
        end if;
      else
        v_day := coalesce(v_sub.billing_day, extract(day from v_today)::int);
        v_base := coalesce(v_sub.next_billing_date, v_today);
        if v_base < v_today - 10 then v_base := v_today; end if;  -- a very late debit counts from today
      end if;
      v_next := private.add_billing_month(v_base, v_day);
      update public.subscriptions set
        status              = 'active',
        payfast_mode        = p_mode,
        payfast_token       = coalesce(v_token, payfast_token),
        billing_day         = v_day,
        next_billing_date   = v_next,
        paid_until          = private.cover_until(v_next),
        monthly_amount      = case when v_new then v_co.amount else monthly_amount end,
        last_payment_at     = now(),
        last_payment_amount = v_amount,
        payment_failed_at   = null,
        cancelled_at        = null
      where id = v_sub.id;
      if v_co.id is not null and v_new then
        update private.payfast_checkouts set completed_at = now(), token = v_token where id = v_co.id;
      end if;
      v_outcome := 'applied: paid';
    end if;
  elsif v_sub.id is null then
    v_outcome := 'ignored: no matching family plan';
  elsif v_status = 'FAILED' then
    if v_token is not null and v_token = v_sub.payfast_token then
      if v_sub.last_payment_at > now() - interval '20 days' then
        v_outcome := 'ignored: failed debit, but a later payment went through';
      else
        update public.subscriptions set payment_failed_at = now() where id = v_sub.id;
        v_outcome := 'applied: debit failed';
      end if;
    else
      v_outcome := 'ignored: failed payment that never started a debit order';
    end if;
  elsif v_status = 'CANCELLED' then
    if v_token is not null and v_token = v_sub.payfast_token then
      update public.subscriptions set status = 'cancelled', cancelled_at = now(), payfast_token = null where id = v_sub.id;
      v_outcome := 'applied: debit order cancelled';
    else
      v_outcome := 'ignored: an old debit order was cancelled';
    end if;
  elsif v_status = 'PENDING' then
    v_outcome := 'recorded: pending';
  else
    v_outcome := 'ignored: unknown payment status';
  end if;

  if v_refund and p_mode = 'live' then
    insert into private.payfast_attention (kind, message, token, pf_payment_id, client)
    values (case when v_co.id is null and v_sub.id is null then 'unknown_payment' else 'refund' end,
            'PayFast payment ' || coalesce(v_pf, '?') || ' of R' || coalesce(to_char(v_amount, 'FM999990.00'), '?')
              || ' was not credited to any plan (' || replace(v_outcome, 'ignored: ', '') || '). Check it in PayFast and refund it if needed.'
              || case when v_cancel is not null then ' Its debit order (subscription ' || v_cancel || ') is being cancelled automatically.' else '' end,
            v_token, v_pf,
            nullif(trim(coalesce(p_data ->> 'name_first', '') || ' ' || coalesce(p_data ->> 'name_last', '')
                        || coalesce(' <' || nullif(p_data ->> 'email_address', '') || '>', '')), ''));
  end if;

  insert into private.payfast_events
    (mode, valid, pf_payment_id, m_payment_id, payment_status, token, amount_gross, subscription_id, outcome, data)
  values (p_mode, true, v_pf, v_mpid, v_status, v_token, v_amount, v_sub.id,
          v_outcome || coalesce(' (' || p_note || ')', ''), p_data);

  return json_build_object('outcome', v_outcome, 'cancel_token', v_cancel, 'cancel_mode', v_cmode);
end $$;

-- Debit orders still waiting to be cancelled at PayFast (each retried at most every 15 minutes).
drop function if exists private.payfast_tokens_to_cancel(int);
create or replace function private.payfast_tokens_to_cancel(p_limit int default 3)
returns table (token text, mode text) language sql volatile security definer set search_path = public as $$
  update private.payfast_old_tokens o set last_attempt_at = now()
   where o.token in (
     select t.token from private.payfast_old_tokens t
      where t.cancelled_at is null and t.attempts < 30 and t.replaced_at > now() - interval '90 days'
        and (t.last_attempt_at is null or t.last_attempt_at < now() - interval '15 minutes')
      order by t.replaced_at limit p_limit
      for update skip locked)
  returning o.token, o.mode
$$;

-- Claim one debit order for an immediate cancel (false when another clean-up is already on it).
create or replace function private.payfast_claim_token(p_token text)
returns boolean language sql volatile security definer set search_path = public as $$
  with c as (
    update private.payfast_old_tokens set last_attempt_at = now()
     where token = p_token and cancelled_at is null
       and (last_attempt_at is null or last_attempt_at < now() - interval '15 minutes')
    returning 1)
  select exists (select 1 from c)
$$;

create or replace function private.payfast_retry_key_ok(p_key text)
returns boolean language sql stable security definer set search_path = public as $$
  select coalesce(p_key, '') <> '' and exists (select 1 from private.payfast_settings where id = 1 and retry_key = p_key)
$$;

create or replace function private.payfast_token_cancel_result(p_token text, p_ok boolean, p_error text default null)
returns void language plpgsql security definer set search_path = public as $$
declare
  v_row private.payfast_old_tokens;
begin
  update private.payfast_old_tokens
     set cancelled_at    = case when p_ok then coalesce(cancelled_at, now()) else cancelled_at end,
         attempts        = attempts + 1,
         last_attempt_at = now(),
         last_error      = case when p_ok then null else left(p_error, 300) end
   where token = p_token
  returning * into v_row;
  if not p_ok and v_row.attempts = 3 and v_row.mode = 'live' then
    insert into private.payfast_attention (kind, message, token, client)
    values ('cancel_failed', 'FireQuest could not cancel an old PayFast debit order automatically (3 tries: '
            || coalesce(left(p_error, 120), 'no answer') || '). In PayFast, cancel subscription ' || p_token
            || ' so the client does not pay twice.', p_token, private.payfast_token_client(p_token));
  end if;
end $$;

-- ---------------------------------------------------------------------
-- Family plans: a holder who pays for their own plan cannot join another
-- family until that debit order is cancelled. (Replaces the version in 003.)
-- ---------------------------------------------------------------------
create or replace function public.join_subscription(p_code text)
returns json language plpgsql security definer set search_path = public as $$
declare
  v_uid     uuid := auth.uid();
  v_inv     public.family_invites;
  v_target  public.subscriptions;
  v_current public.subscriptions;
  v_phone   text;
  v_count   int;
begin
  if v_uid is null then raise exception 'Not signed in'; end if;

  select * into v_inv from public.family_invites
   where code = upper(regexp_replace(coalesce(p_code, ''), '\s', '', 'g'))
   for update;
  if not found or v_inv.expires_at < now() then
    raise exception 'That code is not valid. It may already have been used, or it expired after 7 days. Ask the plan holder to send you a new invite.';
  end if;

  select * into v_target from public.subscriptions where id = v_inv.subscription_id for update;

  select phone into v_phone from public.profiles where id = v_uid;
  if private.phone_key(v_phone) is distinct from private.phone_key(v_inv.phone) then
    raise exception 'This invite is for the cellphone number ending in %. The number on your FireQuest profile is different. Ask % to check the number, or correct your number under Profile > Edit my details.',
      right(regexp_replace(v_inv.phone, '\D', '', 'g'), 4),
      coalesce(nullif((select full_name from public.profiles where id = v_target.owner_id), ''), 'the plan holder');
  end if;

  select s.* into v_current
    from public.subscription_members m join public.subscriptions s on s.id = m.subscription_id
   where m.user_id = v_uid;
  if found then
    if v_current.id = v_target.id then raise exception 'You are already on this family plan.'; end if;
    if v_current.owner_id <> v_uid then
      raise exception 'You are on another family plan. Leave it first (Account > Family plan > Leave).';
    end if;
    if exists (select 1 from public.subscription_members where subscription_id = v_current.id and user_id <> v_uid)
       or exists (select 1 from public.family_invites where subscription_id = v_current.id) then
      raise exception 'You hold your own family plan with other people on it. Remove them and cancel their invites first.';
    end if;
    if v_current.status = 'active' and v_current.payfast_token is not null then
      raise exception 'You pay for your own FireQuest plan with a monthly debit order. Ask FireQuest to cancel it first, then join this family plan.';
    end if;
    delete from public.subscriptions where id = v_current.id;
  end if;

  select count(*) into v_count from public.subscription_members where subscription_id = v_target.id;
  if v_count >= v_target.max_members then
    raise exception 'This family plan is full (% people).', v_target.max_members;
  end if;

  insert into public.subscription_members (subscription_id, user_id, role, relationship)
  values (v_target.id, v_uid, 'member', v_inv.relationship);
  delete from public.family_invites where id = v_inv.id;
  return public.my_subscription();
end $$;

-- ---------------------------------------------------------------------
-- Permissions
-- ---------------------------------------------------------------------
revoke execute on function
  public.my_billing(),
  public.alert_billing(uuid),
  public.payments_attention(),
  public.payments_attention_done(bigint),
  public.billing_test(text),
  public.join_subscription(text)
from public, anon;

grant execute on function
  public.my_billing(),
  public.alert_billing(uuid),
  public.payments_attention(),
  public.payments_attention_done(bigint),
  public.billing_test(text),
  public.join_subscription(text)
to authenticated;

revoke execute on function
  private.sa_today(),
  private.add_billing_month(date, int),
  private.cover_until(date),
  private.billing_paid_until(public.subscriptions),
  private.billing_state(public.subscriptions),
  private.billing_label(text),
  private.payfast_queue_cancel(text, text),
  private.subscription_deleted(),
  private.payfast_start_checkout(uuid, text),
  private.payfast_save_form(uuid, jsonb),
  private.payfast_checkout_form(uuid),
  private.payfast_checkout_abandoned(uuid),
  private.payfast_card_token(uuid),
  private.payfast_apply_itn(jsonb, text, boolean, text),
  private.payfast_tokens_to_cancel(int),
  private.payfast_claim_token(text),
  private.payfast_retry_key_ok(text),
  private.payfast_token_client(text),
  private.payfast_token_cancel_result(text, boolean, text)
from public, anon, authenticated;
