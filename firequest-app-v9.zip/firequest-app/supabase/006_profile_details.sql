-- =====================================================================
-- FireQuest – more profile details for responders
-- * Selfie, so responders can recognise the client. Stored in a private
--   storage bucket "selfies" as <user id>/selfie.jpg. Only the client and
--   the control room (while that client has an alert open, or for 24 hours
--   after raising one) can see it.
-- * Number of people in the household; pets at the home (inside or in the
--   yard; column pets_inside) and whether any are dangerous; insurance details.
-- * Home pin: the client drops a pin on a map at their home, because
--   addresses in remote areas are often not found by Google Maps.
-- Run after 005_payfast.sql. (Also included in schema.sql.)
-- =====================================================================

alter table public.profiles add column if not exists household_size int;
alter table public.profiles add column if not exists pets_inside int;
alter table public.profiles add column if not exists pets_dangerous boolean not null default false;
alter table public.profiles add column if not exists pets_notes text;
alter table public.profiles add column if not exists insurance_company text;
alter table public.profiles add column if not exists insurance_policy_number text;
alter table public.profiles add column if not exists insurance_phone text;
alter table public.profiles add column if not exists insurance_cover text;
-- When the selfie was last changed (empty = no selfie). The file is always <user id>/selfie.jpg.
alter table public.profiles add column if not exists selfie_updated_at timestamptz;
-- Exact position of the home, placed by the client on a map.
alter table public.profiles add column if not exists home_lat double precision;
alter table public.profiles add column if not exists home_lng double precision;
alter table public.profiles add column if not exists home_pin_at timestamptz;

alter table public.profiles drop constraint if exists profiles_household_size_check;
alter table public.profiles add constraint profiles_household_size_check check (household_size between 1 and 30);
alter table public.profiles drop constraint if exists profiles_pets_inside_check;
alter table public.profiles add constraint profiles_pets_inside_check check (pets_inside between 0 and 50);
alter table public.profiles drop constraint if exists profiles_text_lengths_check;
alter table public.profiles add constraint profiles_text_lengths_check check (
  coalesce(length(pets_notes), 0) <= 300
  and coalesce(length(insurance_company), 0) <= 120
  and coalesce(length(insurance_policy_number), 0) <= 60
  and coalesce(length(insurance_phone), 0) <= 30
  and coalesce(length(insurance_cover), 0) <= 200);
alter table public.profiles drop constraint if exists profiles_home_pin_check;
alter table public.profiles add constraint profiles_home_pin_check check (
  (home_lat is null and home_lng is null)
  or (home_lat is not null and home_lng is not null
      and home_lat between -90 and 90 and home_lng between -180 and 180));

-- Private bucket for selfies (JPEG, at most 2 MB each).
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('selfies', 'selfies', false, 2097152, array['image/jpeg'])
on conflict (id) do update set public = false, file_size_limit = 2097152, allowed_mime_types = array['image/jpeg'];

drop policy if exists "selfies: view own, or staff during an alert" on storage.objects;
drop policy if exists "selfies: upload own" on storage.objects;
drop policy if exists "selfies: replace own" on storage.objects;
drop policy if exists "selfies: delete own" on storage.objects;

create policy "selfies: view own, or staff during an alert" on storage.objects
  for select to authenticated
  using (
    bucket_id = 'selfies'
    and case
          when name = auth.uid()::text || '/selfie.jpg' then true
          when name ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/selfie\.jpg$'
            then public.staff_can_view(split_part(name, '/', 1)::uuid)
          else false
        end
  );

create policy "selfies: upload own" on storage.objects
  for insert to authenticated
  with check (bucket_id = 'selfies' and name = auth.uid()::text || '/selfie.jpg');

create policy "selfies: replace own" on storage.objects
  for update to authenticated
  using (bucket_id = 'selfies' and name = auth.uid()::text || '/selfie.jpg')
  with check (bucket_id = 'selfies' and name = auth.uid()::text || '/selfie.jpg');

create policy "selfies: delete own" on storage.objects
  for delete to authenticated
  using (bucket_id = 'selfies' and name = auth.uid()::text || '/selfie.jpg');
