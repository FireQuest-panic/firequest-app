import React, { useCallback, useEffect, useState } from 'react';
import { ActivityIndicator, Pressable, Text, View } from 'react-native';
import { SafeAreaProvider, useSafeAreaInsets } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import * as SplashScreen from 'expo-splash-screen';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import type { Session } from '@supabase/supabase-js';
import { colors } from './theme';
import { controlRoomPhoneFromConfig, isConfigured, supabase } from './lib/supabase';
import { friendlyError, getOpenAlert, loadBundle, loadSettings } from './lib/data';
import { AppSettings, PanicAlert, ProfileBundle } from './lib/types';
import { AuthScreen } from './screens/AuthScreen';
import { OnboardingScreen } from './screens/OnboardingScreen';
import { HomeScreen } from './screens/HomeScreen';
import { AlertScreen } from './screens/AlertScreen';
import { MedicalIdScreen } from './screens/MedicalIdScreen';
import { AccountScreen } from './screens/AccountScreen';
import { Body, Button, ErrorText, Logo, Screen, Title } from './components/ui';

SplashScreen.preventAutoHideAsync().catch(() => undefined);

type Tab = 'panic' | 'medical' | 'account';

export default function App() {
  return (
    <SafeAreaProvider>
      <StatusBar style="light" />
      <View style={{ flex: 1, backgroundColor: colors.bg }}>
        <Root />
      </View>
    </SafeAreaProvider>
  );
}

function Root() {
  const [session, setSession] = useState<Session | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const [bundle, setBundle] = useState<ProfileBundle | null>(null);
  const [settings, setSettings] = useState<AppSettings>({ test_mode: true, control_room_phone: '' });
  const [openAlert, setOpenAlert] = useState<PanicAlert | null>(null);
  const [loading, setLoading] = useState(false);
  const [loadError, setLoadError] = useState('');
  const [tab, setTab] = useState<Tab>('panic');
  const [editing, setEditing] = useState(false);

  useEffect(() => {
    supabase.auth
      .getSession()
      .then(({ data }) => setSession(data.session))
      .finally(() => setAuthReady(true));
    const { data } = supabase.auth.onAuthStateChange((_event, s) => setSession(s));
    return () => data.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (authReady || !isConfigured) SplashScreen.hideAsync().catch(() => undefined);
  }, [authReady]);

  const userId = session?.user.id;

  const load = useCallback(async () => {
    if (!userId) return;
    setLoading(true);
    setLoadError('');
    try {
      const [b, st, a] = await Promise.all([loadBundle(userId), loadSettings(), getOpenAlert(userId)]);
      setBundle(b);
      setSettings(st);
      setOpenAlert(a);
    } catch (e) {
      setLoadError(friendlyError(e));
    } finally {
      setLoading(false);
    }
  }, [userId]);

  useEffect(() => {
    if (userId) {
      load();
    } else {
      setBundle(null);
      setOpenAlert(null);
      setEditing(false);
      setTab('panic');
    }
  }, [userId, load]);

  const controlRoomPhone = settings.control_room_phone || controlRoomPhoneFromConfig;

  if (!isConfigured) {
    return (
      <Screen style={{ justifyContent: 'center', alignItems: 'center' }}>
        <Logo size={160} />
        <Title>Not set up yet</Title>
        <Body center>
          This build of FireQuest is not connected to a database. Ask FireQuest for the latest
          test version.
        </Body>
      </Screen>
    );
  }

  if (!authReady) return null;
  if (!session) return <AuthScreen />;

  if (!bundle) {
    return (
      <Screen style={{ justifyContent: 'center', alignItems: 'center' }}>
        <Logo size={140} />
        {loading || !loadError ? (
          <ActivityIndicator color={colors.gold} size="large" />
        ) : (
          <>
            <ErrorText>{loadError}</ErrorText>
            <Button title="Try again" onPress={load} style={{ alignSelf: 'stretch' }} />
            <Button title="Sign out" variant="plain" onPress={() => supabase.auth.signOut()} />
          </>
        )}
      </Screen>
    );
  }

  if (!bundle.profile.onboarded_at || !bundle.hasPin) {
    return <OnboardingScreen bundle={bundle} mode="onboard" onDone={load} />;
  }

  if (openAlert) {
    return (
      <AlertScreen
        key={openAlert.id}
        initialAlert={openAlert}
        controlRoomPhone={controlRoomPhone}
        onFinished={() => {
          setOpenAlert(null);
          load();
        }}
      />
    );
  }

  if (editing) {
    return (
      <OnboardingScreen
        bundle={bundle}
        mode="edit"
        onDone={() => {
          setEditing(false);
          load();
        }}
        onCancel={() => setEditing(false)}
      />
    );
  }

  return (
    <View style={{ flex: 1 }}>
      <View style={{ flex: 1 }}>
        {tab === 'panic' && (
          <HomeScreen
            profile={bundle.profile}
            settings={settings}
            controlRoomPhone={controlRoomPhone}
            onAlertRaised={setOpenAlert}
          />
        )}
        {tab === 'medical' && <MedicalIdScreen bundle={bundle} onEdit={() => setEditing(true)} />}
        {tab === 'account' && <AccountScreen profile={bundle.profile} settings={settings} />}
      </View>
      <TabBar tab={tab} onChange={setTab} />
    </View>
  );
}

function TabBar({ tab, onChange }: { tab: Tab; onChange: (t: Tab) => void }) {
  const insets = useSafeAreaInsets();
  const items: { key: Tab; label: string; icon: React.ComponentProps<typeof MaterialCommunityIcons>['name'] }[] = [
    { key: 'panic', label: 'Panic', icon: 'shield-alert-outline' },
    { key: 'medical', label: 'Medical ID', icon: 'card-account-details-outline' },
    { key: 'account', label: 'Account', icon: 'account-circle-outline' },
  ];
  return (
    <View
      accessibilityRole="tablist"
      style={{
        flexDirection: 'row',
        borderTopWidth: 1,
        borderTopColor: '#24221F',
        backgroundColor: colors.bg,
        paddingBottom: Math.max(insets.bottom, 8),
        paddingTop: 6,
      }}
    >
      {items.map((it) => {
        const active = it.key === tab;
        return (
          <Pressable
            key={it.key}
            accessibilityRole="tab"
            accessibilityState={{ selected: active }}
            onPress={() => onChange(it.key)}
            style={{ flex: 1, alignItems: 'center', gap: 2, minHeight: 52, justifyContent: 'center' }}
          >
            <MaterialCommunityIcons name={it.icon} size={24} color={active ? colors.goldText : colors.faint} />
            <Text style={{ fontSize: 12, fontWeight: active ? '700' : '500', color: active ? colors.goldText : colors.faint }}>
              {it.label}
            </Text>
          </Pressable>
        );
      })}
    </View>
  );
}
