import React, { useEffect, useRef, useState } from 'react';
import { Linking, Modal, Text, TextInput, View } from 'react-native';
import * as Location from 'expo-location';
import { useKeepAwake } from 'expo-keep-awake';
import { FontAwesome5, MaterialCommunityIcons } from '@expo/vector-icons';
import { colors } from '../theme';
import { supabase } from '../lib/supabase';
import { cancelAlert, friendlyError, getAlert, updateAlertLocation } from '../lib/data';
import { toPos } from '../lib/location';
import { ALERT_LABELS, AlertStatus, PanicAlert } from '../lib/types';
import { Body, Button, ErrorText, Screen } from '../components/ui';

type Props = {
  initialAlert: PanicAlert;
  controlRoomPhone: string;
  onFinished: () => void;
};

const HEADINGS: Record<AlertStatus, string> = {
  new: 'Alert sent – waiting for the control room',
  acknowledged: 'The control room has your alert',
  dispatched: 'FireQuest is on the way',
  on_scene: 'The FireQuest team is with you',
  closed: 'Alert closed',
  cancelled: 'Alert cancelled',
};

const LOCATION_INTERVAL_MS = 10000;

function time(iso: string | null): string {
  if (!iso) return '';
  const d = new Date(iso);
  return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
}

export function AlertScreen({ initialAlert, controlRoomPhone, onFinished }: Props) {
  useKeepAwake();
  const [alert, setAlert] = useState<PanicAlert>(initialAlert);
  const [gpsNote, setGpsNote] = useState('Finding your location…');
  const [showCancel, setShowCancel] = useState(false);
  const [pin, setPin] = useState('');
  const [cancelBusy, setCancelBusy] = useState(false);
  const [cancelError, setCancelError] = useState('');
  const lastSent = useRef(0);
  const isOpen = !['closed', 'cancelled'].includes(alert.status);

  // Live status from the control room (realtime, with polling as a back-up).
  useEffect(() => {
    const channel = supabase
      .channel(`alert-${initialAlert.id}`)
      .on(
        'postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'alerts', filter: `id=eq.${initialAlert.id}` },
        (payload) => setAlert((prev) => ({ ...prev, ...(payload.new as PanicAlert) })),
      )
      .subscribe();
    const poll = setInterval(() => {
      getAlert(initialAlert.id)
        .then((a) => a && setAlert(a))
        .catch(() => undefined);
    }, 15000);
    return () => {
      clearInterval(poll);
      supabase.removeChannel(channel);
    };
  }, [initialAlert.id]);

  // Keep sending the phone's position while the alert is open.
  useEffect(() => {
    if (!isOpen) return;
    let sub: Location.LocationSubscription | null = null;
    let cancelled = false;
    (async () => {
      const perm = await Location.getForegroundPermissionsAsync();
      if (!perm.granted) {
        setGpsNote('Location not allowed – the control room cannot see where you are. Call them.');
        return;
      }
      sub = await Location.watchPositionAsync(
        { accuracy: Location.Accuracy.High, timeInterval: 5000, distanceInterval: 10 },
        (loc) => {
          if (cancelled) return;
          const pos = toPos(loc);
          const now = Date.now();
          setGpsNote(
            `Location shared${pos.accuracy ? ` · ±${Math.round(pos.accuracy)} m` : ''} · ${time(new Date().toISOString())}`,
          );
          if (now - lastSent.current < LOCATION_INTERVAL_MS) return;
          lastSent.current = now;
          updateAlertLocation(initialAlert.id, pos).catch(() =>
            setGpsNote('Location found, but no connection to send it. Retrying…'),
          );
        },
      );
    })().catch(() => setGpsNote('Could not start GPS. Call the control room.'));
    return () => {
      cancelled = true;
      sub?.remove();
    };
  }, [initialAlert.id, isOpen]);

  const doCancel = async () => {
    setCancelError('');
    if (!/^[0-9]{4,6}$/.test(pin)) return setCancelError('Enter your 4 to 6 digit PIN.');
    setCancelBusy(true);
    try {
      const ok = await cancelAlert(alert.id, pin);
      if (ok) {
        setShowCancel(false);
        setPin('');
        const updated = await getAlert(alert.id);
        if (updated) setAlert(updated);
      } else {
        setCancelError('Incorrect PIN. The alert is still active.');
      }
    } catch (e) {
      setCancelError(friendlyError(e));
    } finally {
      setCancelBusy(false);
    }
  };

  const steps: { label: string; at: string | null }[] = [
    { label: 'Alert sent with your location', at: alert.created_at },
    { label: 'Control room acknowledged', at: alert.acknowledged_at },
    { label: 'FireQuest team dispatched', at: alert.dispatched_at },
    { label: 'Team on scene', at: alert.on_scene_at },
  ];

  const icon =
    alert.type === 'medical' ? (
      <FontAwesome5 name="star-of-life" size={56} color={colors.red} />
    ) : alert.type === 'vehicle' ? (
      <MaterialCommunityIcons name="car-emergency" size={64} color={colors.ink} />
    ) : (
      <MaterialCommunityIcons name="fire" size={66} color={colors.red} />
    );

  return (
    <Screen>
      <View style={{ alignItems: 'center', gap: 14, paddingTop: 16 }}>
        <View
          style={{
            width: 168,
            height: 168,
            borderRadius: 84,
            borderWidth: 2,
            borderColor: isOpen ? colors.gold : colors.border,
            backgroundColor: isOpen ? '#2A1315' : colors.surface,
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <View
            style={{
              width: 124,
              height: 124,
              borderRadius: 62,
              backgroundColor: alert.type === 'vehicle' ? colors.gold : colors.ivory,
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            {icon}
          </View>
        </View>
        <Text style={{ color: colors.goldText, fontSize: 14, fontWeight: '700', letterSpacing: 1 }}>
          {ALERT_LABELS[alert.type].toUpperCase()} ALERT{isOpen ? ' ACTIVE' : ''}
          {alert.is_test ? ' · TEST' : ''}
        </Text>
        <Text
          accessibilityRole="header"
          accessibilityLiveRegion="polite"
          style={{ color: colors.text, fontSize: 28, fontWeight: '800', textAlign: 'center' }}
        >
          {HEADINGS[alert.status]}
        </Text>
        {isOpen && <Body center>Stay where you are if it is safe. Keep this screen open.</Body>}
      </View>

      <View style={{ backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1, borderRadius: 18, paddingHorizontal: 16 }}>
        {steps.map((st, i) => (
          <View
            key={st.label}
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              gap: 12,
              paddingVertical: 12,
              borderBottomWidth: i < steps.length - 1 ? 1 : 0,
              borderBottomColor: colors.border,
            }}
          >
            {st.at ? (
              <View style={{ width: 26, height: 26, borderRadius: 13, backgroundColor: '#1F8A55', alignItems: 'center', justifyContent: 'center' }}>
                <MaterialCommunityIcons name="check" size={16} color="#FFFFFF" />
              </View>
            ) : (
              <View style={{ width: 26, height: 26, borderRadius: 13, borderWidth: 2, borderColor: colors.goldText }} />
            )}
            <Text style={{ flex: 1, color: st.at ? colors.text : '#CFC9BD', fontSize: 15 }}>{st.label}</Text>
            <Text style={{ color: colors.faint, fontSize: 13 }}>{st.at ? time(st.at) : 'Pending'}</Text>
          </View>
        ))}
      </View>

      {isOpen && (
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
          <MaterialCommunityIcons name="crosshairs-gps" size={18} color={colors.muted} />
          <Text style={{ color: colors.muted, fontSize: 13, flex: 1 }}>{gpsNote}</Text>
        </View>
      )}

      <View style={{ flexGrow: 1 }} />

      {controlRoomPhone ? (
        <Button title="Call FireQuest control room" onPress={() => Linking.openURL(`tel:${controlRoomPhone}`)} />
      ) : null}
      {isOpen ? (
        <Button title="I'm safe – cancel with PIN" variant="outline" onPress={() => setShowCancel(true)} />
      ) : (
        <Button title="Back to home" variant="outline" onPress={onFinished} />
      )}

      <Modal visible={showCancel} transparent animationType="fade" onRequestClose={() => setShowCancel(false)}>
        <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.7)', justifyContent: 'center', padding: 20 }}>
          <View style={{ backgroundColor: colors.surface, borderRadius: 20, padding: 20, gap: 14, borderWidth: 1, borderColor: colors.border }}>
            <Text style={{ color: colors.text, fontSize: 22, fontWeight: '800' }}>Cancel the alert?</Text>
            <Body>Enter your PIN to confirm you are safe.</Body>
            <TextInput
              accessibilityLabel="Cancel PIN"
              value={pin}
              onChangeText={(t) => setPin(t.replace(/[^0-9]/g, ''))}
              keyboardType="number-pad"
              secureTextEntry
              maxLength={6}
              autoFocus
              style={{
                minHeight: 56,
                borderRadius: 12,
                borderWidth: 1,
                borderColor: colors.border,
                backgroundColor: colors.bg,
                color: colors.text,
                fontSize: 24,
                letterSpacing: 8,
                textAlign: 'center',
              }}
            />
            <ErrorText>{cancelError}</ErrorText>
            <Button title="Cancel alert" variant="red" onPress={doCancel} loading={cancelBusy} />
            <Button
              title="Keep alert active"
              variant="plain"
              onPress={() => {
                setShowCancel(false);
                setPin('');
                setCancelError('');
              }}
            />
          </View>
        </View>
      </Modal>
    </Screen>
  );
}
