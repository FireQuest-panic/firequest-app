// Expo configuration for the FireQuest Panic app.
// BUILD_NUMBER is set by the GitHub build so every new APK installs over the old one.
const buildNumber = parseInt(process.env.BUILD_NUMBER || '1', 10);

module.exports = {
  expo: {
    name: 'FireQuest',
    slug: 'firequest-panic',
    version: '0.1.0',
    orientation: 'portrait',
    icon: './assets/icon.png',
    userInterfaceStyle: 'dark',
    backgroundColor: '#0F0F10',
    newArchEnabled: true,
    android: {
      package: 'za.co.firequest.panic',
      versionCode: buildNumber,
      adaptiveIcon: {
        foregroundImage: './assets/adaptive-icon.png',
        backgroundColor: '#0F0F10',
      },
      permissions: ['ACCESS_COARSE_LOCATION', 'ACCESS_FINE_LOCATION', 'VIBRATE'],
      edgeToEdgeEnabled: true,
    },
    plugins: [
      [
        'expo-splash-screen',
        { image: './assets/splash-logo.png', imageWidth: 220, backgroundColor: '#0F0F10' },
      ],
      [
        'expo-location',
        {
          locationWhenInUsePermission:
            'FireQuest uses your location to send responders to you when you raise an alert.',
        },
      ],
    ],
  },
};
