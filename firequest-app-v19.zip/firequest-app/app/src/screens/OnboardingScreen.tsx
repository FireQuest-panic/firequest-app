import React, { useEffect, useState } from 'react';
import { BackHandler, KeyboardAvoidingView, Platform, Text, View } from 'react-native';
import { colors } from '../theme';
import { Medication, ProfileBundle } from '../lib/types';
import { friendlyError, saveContacts, saveMedical, saveProfile, setCancelPin } from '../lib/data';
import { Body, Button, Chip, ErrorText, Field, Logo, Screen, Title } from '../components/ui';
import { HomePin, HomePinPicker, openInGoogleMaps } from '../components/HomePinPicker';
import { PrivacyConsentBox } from '../components/PrivacyConsentBox';
import { dobFromSaId, joinAllergy, saIdError, splitAllergy } from '../lib/saId';
import { activeMedications, medicationLabel } from '../lib/medication';
import { hasAcceptedPrivacy, privacyAcceptFields } from '../lib/privacy';

const STEPS = ['Your details', 'Medical information', 'Emergency contacts', 'Vehicle', 'Home & insurance', 'PIN & consent'];
const BLOOD_TYPES = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-', 'Unknown'];

type Props = {
  bundle: ProfileBundle;
  mode: 'onboard' | 'edit';
  onDone: () => void;
  onCancel?: () => void;
};

const s = (v: string | null | undefined) => v ?? '';
const orNull = (v: string) => (v.trim() ? v.trim() : null);

export function OnboardingScreen({ bundle, mode, onDone, onCancel }: Props) {
  const { profile, medical } = bundle;
  const userId = profile.id;
  const [step, setStep] = useState(0);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  // Step 1 – personal
  const [fullName, setFullName] = useState(s(profile.full_name));
  const [phone, setPhone] = useState(s(profile.phone));
  const [idNumber, setIdNumber] = useState(s(profile.id_number));
  const [dob, setDob] = useState(s(profile.date_of_birth));
  const [address, setAddress] = useState(s(profile.home_address));
  const [homePin, setHomePin] = useState<HomePin | null>(
    profile.home_lat != null && profile.home_lng != null ? { lat: profile.home_lat, lng: profile.home_lng } : null,
  );
  const [pinChanged, setPinChanged] = useState(false);
  const [pickingPin, setPickingPin] = useState(false);
  // Step 2 – medical
  const [bloodType, setBloodType] = useState(s(medical?.blood_type));
  const [allergies, setAllergies] = useState<{ what: string; who: string }[]>(() => {
    const list = (medical?.allergies ?? []).map(splitAllergy);
    return list.length ? list : [{ what: '', who: '' }];
  });
  const updateAllergy = (i: number, key: 'what' | 'who', value: string) =>
    setAllergies((prev) => prev.map((a, idx) => (idx === i ? { ...a, [key]: value } : a)));
  const [conditions, setConditions] = useState(s(medical?.conditions));
  // Medication list: finished short courses are dropped when the form opens.
  const [meds, setMeds] = useState<Medication[]>(() => {
    const list = medical?.medications?.length
      ? activeMedications(medical.medications)
      : medical?.medication?.trim()
        ? [{ name: medical.medication.trim(), who: '', chronic: true, until: null }]
        : [];
    return list.length ? list : [{ name: '', who: '', chronic: true, until: null }];
  });
  const updateMed = (i: number, patch: Partial<Medication>) =>
    setMeds((prev) => prev.map((m, idx) => (idx === i ? { ...m, ...patch } : m)));
  const [scheme, setScheme] = useState(s(medical?.medical_aid_scheme));
  const [plan, setPlan] = useState(s(medical?.medical_aid_plan));
  const [member, setMember] = useState(s(medical?.medical_aid_number));
  const [doctorName, setDoctorName] = useState(s(medical?.doctor_name));
  const [doctorPhone, setDoctorPhone] = useState(s(medical?.doctor_phone));
  // Step 3 – contacts (two slots)
  const initialContacts = [0, 1].map((i) => ({
    name: s(bundle.contacts[i]?.name),
    relationship: s(bundle.contacts[i]?.relationship),
    phone: s(bundle.contacts[i]?.phone),
  }));
  const [contacts, setContacts] = useState(initialContacts);
  // Step 4 – vehicle
  const [make, setMake] = useState(s(profile.vehicle_make));
  const [model, setModel] = useState(s(profile.vehicle_model));
  const [colour, setColour] = useState(s(profile.vehicle_colour));
  const [reg, setReg] = useState(s(profile.vehicle_registration));
  // Step 5 – home and insurance
  const numText = (v: number | null | undefined) => (v === null || v === undefined ? '' : String(v));
  const [householdSize, setHouseholdSize] = useState(numText(profile.household_size));
  const [petsInside, setPetsInside] = useState(numText(profile.pets_inside));
  const [petsDangerous, setPetsDangerous] = useState(Boolean(profile.pets_dangerous));
  const [petsNotes, setPetsNotes] = useState(s(profile.pets_notes));
  const [insurer, setInsurer] = useState(s(profile.insurance_company));
  const [policy, setPolicy] = useState(s(profile.insurance_policy_number));
  const [insurerPhone, setInsurerPhone] = useState(s(profile.insurance_phone));
  const [insuredWhat, setInsuredWhat] = useState(s(profile.insurance_cover));
  // Step 6 – PIN and consent
  const [pin, setPin] = useState('');
  const [pin2, setPin2] = useState('');
  const [consent, setConsent] = useState(hasAcceptedPrivacy(profile));

  const pinRequired = mode === 'onboard' || !bundle.hasPin;

  const back = () => {
    setError('');
    if (step > 0) setStep(step - 1);
    else onCancel?.();
  };

  useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      if (step > 0 || onCancel) {
        back();
        return true;
      }
      return false;
    });
    return () => sub.remove();
  });

  const updateContact = (i: number, key: 'name' | 'relationship' | 'phone', value: string) => {
    setContacts((prev) => prev.map((c, idx) => (idx === i ? { ...c, [key]: value } : c)));
  };

  const saveStep = async (): Promise<boolean> => {
    setError('');
    if (step === 0) {
      if (!fullName.trim()) return fail('Enter your full name.');
      if (!phone.trim()) return fail('Enter your mobile number.');
      const idProblem = saIdError(idNumber);
      if (idProblem) return fail(idProblem);
      if (!dob.trim()) return fail('Enter your date of birth as YYYY-MM-DD, e.g. 1985-03-21.');
      if (!isValidDate(dob.trim())) return fail('Enter your date of birth as YYYY-MM-DD, e.g. 1985-03-21.');
      if (address.trim() && !homePin) {
        return fail('Please put a pin on your home on the map (tap "Place pin on map"), so responders can find it even if the address is not on Google Maps.');
      }
      await saveProfile(userId, {
        full_name: fullName.trim(),
        phone: phone.trim(),
        id_number: idNumber.replace(/\s/g, ''),
        date_of_birth: orNull(dob),
        home_address: orNull(address),
        ...(pinChanged && homePin
          ? { home_lat: homePin.lat, home_lng: homePin.lng, home_pin_at: new Date().toISOString() }
          : {}),
      });
    } else if (step === 1) {
      const filled = allergies.filter((a) => a.what.trim());
      const missingWho = filled.find((a) => !a.who.trim());
      if (missingWho) return fail(`Enter the name of the person who is allergic to ${missingWho.what.trim()}.`);
      const medList = meds
        .filter((m) => m.name.trim())
        .map((m) => ({ name: m.name.trim(), who: m.who.trim(), chronic: m.chronic, until: m.chronic ? null : (m.until ?? '').trim() || null }));
      const medNoWho = medList.find((m) => !m.who);
      if (medNoWho) return fail(`Enter the name of the person who takes ${medNoWho.name}.`);
      const medNoEnd = medList.find((m) => !m.chronic && (!m.until || !isValidDate(m.until)));
      if (medNoEnd) return fail(`Enter the last day of ${medNoEnd.name} as YYYY-MM-DD, or mark it as chronic.`);
      const medActive = activeMedications(medList);
      await saveMedical(userId, {
        blood_type: orNull(bloodType),
        allergies: filled.map((a) => joinAllergy(a.what, a.who)),
        conditions: orNull(conditions),
        medications: medActive,
        medication: medActive.length ? medActive.map(medicationLabel).join(', ') : null,
        medical_aid_scheme: orNull(scheme),
        medical_aid_plan: orNull(plan),
        medical_aid_number: orNull(member),
        doctor_name: orNull(doctorName),
        doctor_phone: orNull(doctorPhone),
      });
    } else if (step === 2) {
      const first = contacts[0];
      if (!first.name.trim() || !first.phone.trim()) return fail('Add at least one emergency contact with a name and phone number.');
      const second = contacts[1];
      if ((second.name.trim() && !second.phone.trim()) || (!second.name.trim() && second.phone.trim())) {
        return fail('The second contact needs both a name and a phone number (or leave both empty).');
      }
      await saveContacts(userId, contacts.map((c) => ({ ...c, relationship: c.relationship || null })));
    } else if (step === 3) {
      await saveProfile(userId, {
        vehicle_make: orNull(make),
        vehicle_model: orNull(model),
        vehicle_colour: orNull(colour),
        vehicle_registration: orNull(reg.toUpperCase()),
      });
    } else if (step === 4) {
      const people = householdSize.trim() ? parseInt(householdSize, 10) : null;
      const pets = petsInside.trim() ? parseInt(petsInside, 10) : null;
      if (people !== null && !(people >= 1 && people <= 30)) return fail('Enter how many people live in your home (1 to 30), or leave it empty.');
      if (pets !== null && !(pets >= 0 && pets <= 50)) return fail('Enter how many pets live at your home (0 to 50), or leave it empty.');
      await saveProfile(userId, {
        household_size: people,
        pets_inside: pets,
        pets_dangerous: pets ? petsDangerous : false,
        pets_notes: pets ? orNull(petsNotes) : null,
        insurance_company: orNull(insurer),
        insurance_policy_number: orNull(policy),
        insurance_phone: orNull(insurerPhone),
        insurance_cover: orNull(insuredWhat),
      });
    } else if (step === 5) {
      if (pinRequired || pin) {
        if (!/^[0-9]{4,6}$/.test(pin)) return fail('Your PIN must be 4 to 6 digits.');
        if (pin !== pin2) return fail('The two PINs do not match.');
      }
      if (!consent) return fail('Please tick the consent box so responders can receive your details.');
      if (pin) await setCancelPin(pin);
      const now = new Date().toISOString();
      await saveProfile(userId, {
        ...(hasAcceptedPrivacy(profile) ? {} : privacyAcceptFields(profile)),
        onboarded_at: profile.onboarded_at ?? now,
      });
    }
    return true;
  };

  const fail = (msg: string) => {
    setError(msg);
    return false;
  };

  const next = async () => {
    setBusy(true);
    try {
      const ok = await saveStep();
      if (!ok) return;
      if (step < STEPS.length - 1) setStep(step + 1);
      else onDone();
    } catch (e) {
      setError(friendlyError(e));
    } finally {
      setBusy(false);
    }
  };

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <Screen>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
          <Text style={{ color: colors.muted, fontSize: 14, flex: 1 }}>
            Step {step + 1} of {STEPS.length}
          </Text>
          <Logo size={44} />
        </View>
        <View style={{ flexDirection: 'row', gap: 6 }}>
          {STEPS.map((_, i) => (
            <View
              key={i}
              style={{ flex: 1, height: 4, borderRadius: 2, backgroundColor: i <= step ? colors.gold : colors.border }}
            />
          ))}
        </View>
        <Title>{STEPS[step]}</Title>

        {step === 0 && (
          <>
            <Body>So FireQuest knows who you are and where home is.</Body>
            <Field label="Full name" value={fullName} onChangeText={setFullName} autoCapitalize="words" />
            <Field label="Mobile number" value={phone} onChangeText={setPhone} keyboardType="phone-pad" />
            <Field
              label="ID number"
              value={idNumber}
              onChangeText={(v) => {
                setIdNumber(v);
                const fromId = dobFromSaId(v);
                if (v.replace(/\D/g, '').length >= 6 && fromId) setDob(fromId);
              }}
              keyboardType="number-pad"
              maxLength={13}
            />
            <Field
              label="Date of birth (filled in from your ID number)"
              value={dob}
              onChangeText={setDob}
              placeholder="YYYY-MM-DD"
              keyboardType="numbers-and-punctuation"
              maxLength={10}
            />
            <Field label="Home address (optional)" value={address} onChangeText={setAddress} multiline />
            <View style={{ gap: 8, padding: 14, borderRadius: 16, borderWidth: 1, borderColor: homePin ? '#245C3B' : colors.border }}>
              <Text style={{ color: homePin ? colors.green : colors.goldText, fontWeight: '700' }}>
                {homePin ? '✓ Your home is pinned on the map' : 'Pin your home on the map'}
              </Text>
              <Text style={{ color: colors.muted, fontSize: 14, lineHeight: 20 }}>
                {homePin
                  ? 'Check that the pin is on your house in Google Maps. Responders drive to this exact spot.'
                  : 'Addresses in farms and remote areas are often not found by Google Maps. A pin shows responders exactly where you live.'}
              </Text>
              <Button title={homePin ? 'Move the pin' : 'Place pin on map'} variant={homePin ? 'outline' : 'gold'} onPress={() => setPickingPin(true)} />
              {homePin ? <Button title="Check in Google Maps" variant="plain" onPress={() => openInGoogleMaps(homePin)} /> : null}
            </View>
            <HomePinPicker
              visible={pickingPin}
              initial={homePin}
              address={address}
              onCancel={() => setPickingPin(false)}
              onConfirm={(pin) => {
                setHomePin(pin);
                setPinChanged(true);
                setPickingPin(false);
                setError('');
              }}
            />
          </>
        )}

        {step === 1 && (
          <>
            <Body>FireQuest responders see this the moment you raise a medical alert.</Body>
            <Text style={{ color: '#CFC9BD', fontSize: 13, fontWeight: '600' }}>Blood type</Text>
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }} accessibilityRole="radiogroup">
              {BLOOD_TYPES.map((b) => (
                <Chip key={b} label={b} selected={bloodType === b} onPress={() => setBloodType(bloodType === b ? '' : b)} />
              ))}
            </View>
            <Text style={{ color: '#CFC9BD', fontSize: 13, fontWeight: '600' }}>Allergies</Text>
            {allergies.map((a, i) => (
              <View key={i} style={{ gap: 8, padding: 12, borderRadius: 14, borderWidth: 1, borderColor: colors.border }}>
                <Field
                  label={allergies.length > 1 ? `Allergy ${i + 1}` : 'Allergy (leave empty if none)'}
                  value={a.what}
                  onChangeText={(v) => updateAllergy(i, 'what', v)}
                  placeholder="e.g. Penicillin"
                />
                {a.what.trim() ? (
                  <Field
                    label="Name of the person with this allergy"
                    value={a.who}
                    onChangeText={(v) => updateAllergy(i, 'who', v)}
                    placeholder={fullName.trim() || 'Full name'}
                    autoCapitalize="words"
                  />
                ) : null}
                {allergies.length > 1 ? (
                  <Button title="Remove this allergy" variant="plain" onPress={() => setAllergies((prev) => prev.filter((_, idx) => idx !== i))} />
                ) : null}
              </View>
            ))}
            {allergies[allergies.length - 1]?.what.trim() ? (
              <Button title="+ Add another allergy" variant="outline" onPress={() => setAllergies((prev) => [...prev, { what: '', who: '' }])} />
            ) : null}
            <Field label="Chronic conditions" value={conditions} onChangeText={setConditions} placeholder="e.g. Type 1 diabetes" multiline />
            <Text style={{ color: '#CFC9BD', fontSize: 13, fontWeight: '600' }}>Current medication</Text>
            {meds.map((m, i) => (
              <View key={i} style={{ gap: 8, padding: 12, borderRadius: 14, borderWidth: 1, borderColor: colors.border }}>
                <Field
                  label={meds.length > 1 ? `Medication ${i + 1}` : 'Medication (leave empty if none)'}
                  value={m.name}
                  onChangeText={(v) => updateMed(i, { name: v })}
                  placeholder="e.g. Insulin"
                />
                {m.name.trim() ? (
                  <>
                    <Field
                      label="Name of the person who takes it"
                      value={m.who}
                      onChangeText={(v) => updateMed(i, { who: v })}
                      placeholder={fullName.trim() || 'Full name'}
                      autoCapitalize="words"
                    />
                    <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }} accessibilityRole="radiogroup">
                      <Chip label="Chronic" selected={m.chronic} onPress={() => updateMed(i, { chronic: true, until: null })} />
                      <Chip label="Short course" selected={!m.chronic} onPress={() => updateMed(i, { chronic: false })} />
                    </View>
                    {!m.chronic ? (
                      <Field
                        label="Last day of the course (it is removed after this day)"
                        value={m.until ?? ''}
                        onChangeText={(v) => updateMed(i, { until: v })}
                        placeholder="YYYY-MM-DD"
                        keyboardType="numbers-and-punctuation"
                        maxLength={10}
                      />
                    ) : null}
                  </>
                ) : null}
                {meds.length > 1 || m.name.trim() ? (
                  <Button
                    title="Remove – no longer taking it"
                    variant="plain"
                    onPress={() =>
                      setMeds((prev) => {
                        const rest = prev.filter((_, idx) => idx !== i);
                        return rest.length ? rest : [{ name: '', who: '', chronic: true, until: null }];
                      })
                    }
                  />
                ) : null}
              </View>
            ))}
            {meds[meds.length - 1]?.name.trim() ? (
              <Button
                title="+ Add another medication"
                variant="outline"
                onPress={() => setMeds((prev) => [...prev, { name: '', who: '', chronic: true, until: null }])}
              />
            ) : null}
            <Field label="Medical aid scheme" value={scheme} onChangeText={setScheme} placeholder="Leave empty if you have no medical aid" />
            <Field label="Medical aid plan" value={plan} onChangeText={setPlan} />
            <Field label="Membership number" value={member} onChangeText={setMember} autoCapitalize="characters" />
            <Field label="Doctor's name (optional)" value={doctorName} onChangeText={setDoctorName} autoCapitalize="words" />
            <Field label="Doctor's phone (optional)" value={doctorPhone} onChangeText={setDoctorPhone} keyboardType="phone-pad" />
          </>
        )}

        {step === 2 && (
          <>
            <Body>People FireQuest can contact when you raise an alert.</Body>
            {contacts.map((c, i) => (
              <View key={i} style={{ gap: 12, padding: 14, borderRadius: 16, borderWidth: 1, borderColor: colors.border }}>
                <Text style={{ color: colors.goldText, fontWeight: '700' }}>
                  Contact {i + 1}
                  {i === 1 ? ' (recommended)' : ''}
                </Text>
                <Field label="Name" value={c.name} onChangeText={(t) => updateContact(i, 'name', t)} autoCapitalize="words" />
                <Field label="Relationship" value={c.relationship} onChangeText={(t) => updateContact(i, 'relationship', t)} placeholder="e.g. Spouse, Parent" />
                <Field label="Phone" value={c.phone} onChangeText={(t) => updateContact(i, 'phone', t)} keyboardType="phone-pad" />
              </View>
            ))}
          </>
        )}

        {step === 3 && (
          <>
            <Body>Helps responders find you after a vehicle accident. You can skip this.</Body>
            <Field label="Make" value={make} onChangeText={setMake} autoCapitalize="words" placeholder="e.g. Toyota" />
            <Field label="Model" value={model} onChangeText={setModel} autoCapitalize="words" placeholder="e.g. Corolla" />
            <Field label="Colour" value={colour} onChangeText={setColour} autoCapitalize="words" />
            <Field label="Registration number" value={reg} onChangeText={setReg} autoCapitalize="characters" />
          </>
        )}

        {step === 4 && (
          <>
            <Body>Helps responders plan before they arrive at your home. You can skip anything you don't know.</Body>
            <Field
              label="How many people live in your home (including you)?"
              value={householdSize}
              onChangeText={(t) => setHouseholdSize(t.replace(/[^0-9]/g, ''))}
              keyboardType="number-pad"
              maxLength={2}
              placeholder="e.g. 4"
            />
            <Field
              label="How many pets live at your home (inside or in the yard)?"
              value={petsInside}
              onChangeText={(t) => setPetsInside(t.replace(/[^0-9]/g, ''))}
              keyboardType="number-pad"
              maxLength={2}
              placeholder="0 if none"
            />
            {parseInt(petsInside || '0', 10) > 0 && (
              <>
                <Text style={{ color: '#CFC9BD', fontSize: 13, fontWeight: '600' }}>Could any of them be dangerous to strangers?</Text>
                <View style={{ flexDirection: 'row', gap: 8 }} accessibilityRole="radiogroup">
                  <Chip label="No" selected={!petsDangerous} onPress={() => setPetsDangerous(false)} />
                  <Chip label="Yes – dangerous" selected={petsDangerous} onPress={() => setPetsDangerous(true)} />
                </View>
                <Field
                  label="About your pets (optional)"
                  value={petsNotes}
                  onChangeText={setPetsNotes}
                  placeholder="e.g. 2 dogs in the yard; the Boerboel bites strangers"
                  maxLength={300}
                  multiline
                />
              </>
            )}
            <Text style={{ color: colors.goldText, fontWeight: '700', marginTop: 8 }}>Insurance</Text>
            <Field label="Insurance company" value={insurer} onChangeText={setInsurer} autoCapitalize="words" placeholder="e.g. Santam" maxLength={120} />
            <Field label="Policy number" value={policy} onChangeText={setPolicy} autoCapitalize="characters" maxLength={60} />
            <Field label="Insurer's phone number (claims / emergency)" value={insurerPhone} onChangeText={(t) => setInsurerPhone(t.replace(/[^0-9+ ]/g, ''))} keyboardType="phone-pad" maxLength={30} />
            <Field label="What is insured?" value={insuredWhat} onChangeText={setInsuredWhat} placeholder="e.g. House, contents and car" maxLength={200} />
          </>
        )}

        {step === 5 && (
          <>
            <Body>
              {pinRequired
                ? 'Choose a 4 to 6 digit PIN. You need it to cancel an alert, so nobody else can cancel it for you.'
                : 'Leave the PIN empty to keep your current one.'}
            </Body>
            <Field label="Cancel PIN" value={pin} onChangeText={(t) => setPin(t.replace(/[^0-9]/g, ''))} keyboardType="number-pad" secureTextEntry maxLength={6} />
            <Field label="Repeat PIN" value={pin2} onChangeText={(t) => setPin2(t.replace(/[^0-9]/g, ''))} keyboardType="number-pad" secureTextEntry maxLength={6} />
            <PrivacyConsentBox checked={consent} onChange={setConsent} />
          </>
        )}

        <ErrorText>{error}</ErrorText>
        <View style={{ flexGrow: 1 }} />
        <Button
          title={step < STEPS.length - 1 ? 'Continue' : mode === 'onboard' ? 'Finish' : 'Save'}
          onPress={next}
          loading={busy}
        />
        {(step > 0 || onCancel) && <Button title={step > 0 ? 'Back' : 'Cancel'} variant="plain" onPress={back} />}
      </Screen>
    </KeyboardAvoidingView>
  );
}

function isValidDate(v: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(v)) return false;
  const d = new Date(`${v}T00:00:00Z`);
  return !Number.isNaN(d.getTime()) && d.toISOString().slice(0, 10) === v && d < new Date();
}
