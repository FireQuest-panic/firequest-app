export type AlertType = 'medical' | 'vehicle' | 'fire';
export type AlertStatus =
  | 'new'
  | 'acknowledged'
  | 'dispatched'
  | 'on_scene'
  | 'closed'
  | 'cancelled';

export interface Profile {
  id: string;
  email: string | null;
  full_name: string;
  phone: string;
  id_number: string | null;
  date_of_birth: string | null;
  gender: string | null;
  home_address: string | null;
  vehicle_make: string | null;
  vehicle_model: string | null;
  vehicle_colour: string | null;
  vehicle_registration: string | null;
  consent_at: string | null;
  onboarded_at: string | null;
  /** Version of the privacy policy the person accepted (see lib/privacy.ts). */
  privacy_version?: string | null;
  privacy_accepted_at?: string | null;
  /** People living in the home (including the client). */
  household_size?: number | null;
  /** Pets kept inside the home. */
  pets_inside?: number | null;
  pets_dangerous?: boolean | null;
  pets_notes?: string | null;
  insurance_company?: string | null;
  insurance_policy_number?: string | null;
  insurance_phone?: string | null;
  /** What is insured, e.g. "House and car". */
  insurance_cover?: string | null;
  /** When the selfie was last changed; empty when there is none. The file is selfies/<id>/selfie.jpg. */
  selfie_updated_at?: string | null;
  /** Home position placed by the client on a map (for remote addresses). */
  home_lat?: number | null;
  home_lng?: number | null;
  home_pin_at?: string | null;
}

export interface Medication {
  name: string;
  /** The person on the plan who takes it. */
  who: string;
  chronic: boolean;
  /** Last day of a short course (YYYY-MM-DD); null when chronic. */
  until: string | null;
}

export interface MedicalProfile {
  user_id: string;
  blood_type: string | null;
  allergies: string[];
  conditions: string | null;
  medication: string | null;
  /** Structured list (v19+). Short courses drop off after their last day. */
  medications?: Medication[];
  medical_aid_scheme: string | null;
  medical_aid_plan: string | null;
  medical_aid_number: string | null;
  doctor_name: string | null;
  doctor_phone: string | null;
}

export interface EmergencyContact {
  id?: string;
  user_id?: string;
  name: string;
  relationship: string | null;
  phone: string;
}

export interface PanicAlert {
  id: string;
  user_id: string;
  type: AlertType;
  status: AlertStatus;
  is_test: boolean;
  /** 'crash_detection' when the phone raised the alert by itself. */
  source?: 'button' | 'crash_detection';
  lat: number | null;
  lng: number | null;
  accuracy_m: number | null;
  location_updated_at: string | null;
  created_at: string;
  acknowledged_at: string | null;
  dispatched_at: string | null;
  on_scene_at: string | null;
  closed_at: string | null;
  cancelled_at: string | null;
}

export interface AppSettings {
  test_mode: boolean;
  control_room_phone: string;
}

export interface ProfileBundle {
  profile: Profile;
  medical: MedicalProfile | null;
  contacts: EmergencyContact[];
  hasPin: boolean;
}

export const OPEN_STATUSES: AlertStatus[] = ['new', 'acknowledged', 'dispatched', 'on_scene'];

export const ALERT_LABELS: Record<AlertType, string> = {
  medical: 'Medical',
  vehicle: 'Vehicle accident',
  fire: 'Fire & rescue',
};
