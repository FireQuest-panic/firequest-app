#!/usr/bin/env bash
# Builds the FireQuest Android test app (APK) and packages the control-room monitor.
# Run by GitHub Actions; the results go into the dist/ folder.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
BUILD_NUMBER="${BUILD_NUMBER:-1}"
export BUILD_NUMBER

cd "$ROOT/app"

# Optional: repository variables override the settings in src/config.json.
if [ -n "${SUPABASE_URL:-}" ] && [ -n "${SUPABASE_KEY:-}" ]; then
  node -e "const fs=require('fs');const c=JSON.parse(fs.readFileSync('src/config.json','utf8'));c.supabaseUrl=process.env.SUPABASE_URL;c.supabaseKey=process.env.SUPABASE_KEY;if(process.env.CONTROL_ROOM_PHONE)c.controlRoomPhone=process.env.CONTROL_ROOM_PHONE;fs.writeFileSync('src/config.json',JSON.stringify(c,null,2));"
fi

echo "== Installing packages"
npm install --no-audit --no-fund --legacy-peer-deps
npx expo install --fix -- --legacy-peer-deps

echo "== Type check (report only)"
npx tsc --noEmit || echo "::warning::Type check reported problems (the build continues)"

echo "== Creating the Android project"
npx expo prebuild --platform android --no-install

echo "== Building the APK"
(cd android && ./gradlew assembleRelease --no-daemon -PreactNativeArchitectures=arm64-v8a,armeabi-v7a)

echo "== Packaging"
cd "$ROOT"
rm -rf dist && mkdir -p dist/firequest-monitor
cp monitor/index.html monitor/logo.png monitor/config.js dist/firequest-monitor/
(cd dist && zip -qr firequest-monitor.zip firequest-monitor && rm -rf firequest-monitor)
cp app/android/app/build/outputs/apk/release/app-release.apk dist/FireQuest.apk
ls -la dist

# Publish as the "latest" release, so this link always gives the newest app:
#   https://github.com/<owner>/<repo>/releases/latest/download/FireQuest.apk
if [ "${PUBLISH:-}" = "1" ] && [ -n "${GH_TOKEN:-}" ]; then
  echo "== Publishing release ${BUILD_NUMBER}"
  REPO="${GITHUB_REPOSITORY:-FireQuest-panic/firequest-app}"
  TAG="build-${BUILD_NUMBER}"
  if gh release view "$TAG" --repo "$REPO" >/dev/null 2>&1; then
    # Same build run again: replace the files on the existing release.
    gh release upload "$TAG" dist/FireQuest.apk dist/firequest-monitor.zip --repo "$REPO" --clobber
    gh release edit "$TAG" --repo "$REPO" --latest
  else
    gh release create "$TAG" dist/FireQuest.apk dist/firequest-monitor.zip \
      --repo "$REPO" \
      --title "FireQuest build ${BUILD_NUMBER}" \
      --latest \
      --notes "FireQuest build ${BUILD_NUMBER}

- FireQuest.apk: install on Android phones.
- firequest-monitor.zip: control-room screen for a computer (unzip, open index.html in Chrome).

Permanent link to the newest app: https://github.com/${REPO}/releases/latest/download/FireQuest.apk"
  fi
fi
