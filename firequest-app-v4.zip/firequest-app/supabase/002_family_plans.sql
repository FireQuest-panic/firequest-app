-- =====================================================================
-- FireQuest – family plans (up to 4 people per subscription)
-- Each person has their own login. The account holder shares an invite
-- code; others join with it. Everything goes through the functions below.
-- (Already included at the end of schema.sql for new installs.)
-- =====================================================================

create table public.subscriptions (
  id           uuid primary key default gen_random_uuid(),
  owner_id     uuid not null unique references public.profiles (id) on delete cascade,
  plan         text not null default 'family',
  max_members  int not null default 4 check (max_members between 1 and 10),
  invite_code  text not null unique,
  status       text not null default 'active',
  created_at   timestamptz not null default now()
);

create table public.subscription_members (
  subscription_id  uuid not null references public.subscriptions (id) on delete cascade,
  user_id          uuid not null unique references public.profiles (id) on delete cascade,
  role             text not null default 'member' check (role in ('owner', 'member')),
  joined_at        timestamptz not null default now(),
  primary key (subscription_id, user_id)
);

-- No direct access from the apps: only the functions below.
alter table public.subscriptions        enable row level security;
alter table public.subscription_members enable row level security;
revoke all on public.subscriptions, public.subscription_members from anon, authenticated;

-- Random, easy-to-read 6-character code (no 0/O, 1/I/L).
create or replace function private.new_invite_code()
returns text language plpgsql security definer set search_path = public as $$
declare
  chars text := 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
  code  text;
  b     bytea;
begin
  loop
    b := extensions.gen_random_bytes(6);
    code := '';
    for i in 0..5 loop
      code := code || substr(chars, (get_byte(b, i) % length(chars)) + 1, 1);
    end loop;
    exit when not exists (select 1 from public.subscriptions where invite_code = code);
  end loop;
  return code;
end $$;

-- Everyone belongs to exactly one plan; a new person gets their own.
create or replace function private.ensure_subscription(p_uid uuid)
returns uuid language plpgsql security definer set search_path = public as $$
declare
  v_sub uuid;
begin
  select subscription_id into v_sub from public.subscription_members where user_id = p_uid;
  if v_sub is null then
    insert into public.subscriptions (owner_id, invite_code)
    values (p_uid, private.new_invite_code())
    returning id into v_sub;
    insert into public.subscription_members (subscription_id, user_id, role)
    values (v_sub, p_uid, 'owner');
  end if;
  return v_sub;
end $$;

create or replace function public.my_subscription()
returns json language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
  v_sub uuid;
  v_res json;
begin
  if v_uid is null then raise exception 'Not signed in'; end if;
  v_sub := private.ensure_subscription(v_uid);
  select json_build_object(
    'id', s.id,
    'max_members', s.max_members,
    'is_owner', s.owner_id = v_uid,
    'invite_code', case when s.owner_id = v_uid then s.invite_code end,
    'owner_name', (select full_name from public.profiles where id = s.owner_id),
    'members', (
      select coalesce(json_agg(json_build_object(
               'user_id', m.user_id, 'name', p.full_name, 'phone', p.phone,
               'email', p.email, 'role', m.role, 'is_me', m.user_id = v_uid)
             order by m.role desc, m.joined_at), '[]'::json)
      from public.subscription_members m
      join public.profiles p on p.id = m.user_id
      where m.subscription_id = s.id)
  ) into v_res
  from public.subscriptions s where s.id = v_sub;
  return v_res;
end $$;

create or replace function public.join_subscription(p_code text)
returns json language plpgsql security definer set search_path = public as $$
declare
  v_uid     uuid := auth.uid();
  v_target  public.subscriptions;
  v_current uuid;
  v_count   int;
  v_others  int;
begin
  if v_uid is null then raise exception 'Not signed in'; end if;

  select * into v_target from public.subscriptions
   where invite_code = upper(regexp_replace(coalesce(p_code, ''), '\s', '', 'g'))
   for update;
  if not found then raise exception 'That family code was not found. Check it and try again.'; end if;

  select subscription_id into v_current from public.subscription_members where user_id = v_uid;
  if v_current = v_target.id then raise exception 'You are already on this family plan.'; end if;

  select count(*) into v_count from public.subscription_members where subscription_id = v_target.id;
  if v_count >= v_target.max_members then
    raise exception 'This family plan is full (% people).', v_target.max_members;
  end if;

  if v_current is not null then
    if exists (select 1 from public.subscriptions where id = v_current and owner_id = v_uid) then
      select count(*) into v_others from public.subscription_members
       where subscription_id = v_current and user_id <> v_uid;
      if v_others > 0 then
        raise exception 'You manage a family plan with other people on it. Remove them first.';
      end if;
      delete from public.subscriptions where id = v_current;
    else
      delete from public.subscription_members where user_id = v_uid;
    end if;
  end if;

  insert into public.subscription_members (subscription_id, user_id, role)
  values (v_target.id, v_uid, 'member');
  return public.my_subscription();
end $$;

create or replace function public.remove_subscription_member(p_user_id uuid)
returns json language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
  v_sub uuid;
begin
  select id into v_sub from public.subscriptions where owner_id = v_uid;
  if v_sub is null then raise exception 'Only the plan holder can remove people.'; end if;
  if p_user_id = v_uid then raise exception 'You cannot remove yourself.'; end if;
  delete from public.subscription_members where subscription_id = v_sub and user_id = p_user_id;
  if not found then raise exception 'That person is not on your family plan.'; end if;
  return public.my_subscription();
end $$;

create or replace function public.leave_subscription()
returns json language plpgsql security definer set search_path = public as $$
declare
  v_uid   uuid := auth.uid();
  v_owner boolean;
begin
  select s.owner_id = v_uid into v_owner
    from public.subscription_members m
    join public.subscriptions s on s.id = m.subscription_id
   where m.user_id = v_uid;
  if v_owner is null then raise exception 'You are not on a family plan.'; end if;
  if v_owner then raise exception 'The plan holder cannot leave. Remove the other people instead.'; end if;
  delete from public.subscription_members where user_id = v_uid;
  return public.my_subscription();
end $$;

create or replace function public.new_subscription_code()
returns json language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
begin
  update public.subscriptions set invite_code = private.new_invite_code() where owner_id = v_uid;
  if not found then raise exception 'Only the plan holder can change the code.'; end if;
  return public.my_subscription();
end $$;

-- For the control room: the other people on the alerting client's plan.
create or replace function public.alert_family(p_alert_id uuid)
returns json language plpgsql stable security definer set search_path = public as $$
declare
  v_owner uuid;
  v_res   json;
begin
  if not public.is_staff() then raise exception 'Not authorised'; end if;
  select user_id into v_owner from public.alerts where id = p_alert_id;
  if v_owner is null then return '[]'::json; end if;
  select coalesce(json_agg(json_build_object('name', p.full_name, 'phone', p.phone, 'role', m.role)
         order by m.role desc, m.joined_at), '[]'::json)
    into v_res
    from public.subscription_members m
    join public.profiles p on p.id = m.user_id
   where m.subscription_id = (select subscription_id from public.subscription_members where user_id = v_owner)
     and m.user_id <> v_owner;
  return v_res;
end $$;

revoke execute on function
  public.my_subscription(),
  public.join_subscription(text),
  public.remove_subscription_member(uuid),
  public.leave_subscription(),
  public.new_subscription_code(),
  public.alert_family(uuid)
from public, anon;

grant execute on function
  public.my_subscription(),
  public.join_subscription(text),
  public.remove_subscription_member(uuid),
  public.leave_subscription(),
  public.new_subscription_code(),
  public.alert_family(uuid)
to authenticated;

revoke execute on function private.new_invite_code(), private.ensure_subscription(uuid) from public, anon, authenticated;
