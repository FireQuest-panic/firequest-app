-- FireQuest settings. Run in the Supabase SQL Editor when needed.

-- Control-room phone number shown on the "Call FireQuest control room" button.
update public.app_settings set control_room_phone = '+27XXXXXXXXX', updated_at = now() where id = 1;

-- Test mode. While true, every new alert is marked TEST in the app and the monitor.
-- Only set this to false when FireQuest is ready to go live.
-- update public.app_settings set test_mode = false, updated_at = now() where id = 1;
