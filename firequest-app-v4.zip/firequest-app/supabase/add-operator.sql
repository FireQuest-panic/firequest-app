-- Make an existing login a FireQuest control-room operator.
--
-- 1. Supabase dashboard > Authentication > Users > Add user > Create new user
--    (enter the operator's email and a password, and tick "Auto Confirm User").
-- 2. Change the email and name below, then run this in the SQL Editor.

insert into public.staff (user_id, display_name, role)
select id, 'Operator name', 'operator'
from auth.users
where email = 'operator@example.com'
on conflict (user_id) do update set display_name = excluded.display_name;
