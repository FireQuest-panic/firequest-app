# FireQuest Panic – test version (Android)

Two parts:

- **FireQuest Panic app** (`app/`): the Android app for clients. Sign in, medical profile, three hold-to-send panic buttons, live GPS, cancel with PIN.
- **FireQuest Monitor** (`monitor/`): the control-room screen. Live alert list with alarm, map, client profile, Google Maps navigation, actions and alert log.

Both use one **Supabase** database (`supabase/schema.sql`).

---

## One-time setup

### 1. Database (Supabase)

1. In your Supabase project, open **SQL Editor** > **New query**.
2. Paste everything from `supabase/schema.sql` and click **Run**. You should see "Success". Run it only once.
3. Set the control-room phone number: open `supabase/settings.sql`, put in your number, and run the first `update` line.
4. **For testing only** (optional, makes sign-up quicker): Authentication > Sign In / Providers > Email > switch off **Confirm email**. Switch it back on before going live.

### 2. Control-room operators

For each person who will use the monitor:

1. Authentication > Users > **Add user** > **Create new user**. Enter their email and a password, and tick **Auto Confirm User**.
2. Open `supabase/add-operator.sql`, change the email and name, and run it in the SQL Editor.

Operators sign in to the monitor with that email and password. Client accounts cannot open the monitor.

### 3. Settings

The database address and its public ("publishable") key are already in `app/src/config.json` and `monitor/config.js`. That key is designed to sit inside apps, and the database's security rules protect the data. **Never** put the `secret` or `service_role` key in these files.

(Optional) To point a build at a different database without changing the files, add the repository variables `SUPABASE_URL`, `SUPABASE_PUBLISHABLE_KEY` and `CONTROL_ROOM_PHONE` under GitHub > Settings > Secrets and variables > Actions > Variables.

---

## Building a new test version

The repository holds the code as **one zip file** plus the build file `.github/workflows/build.yml`. This works from a phone:

1. Upload the new `firequest-app.zip` to the repository (Add file > Upload files > Commit changes).
2. GitHub builds automatically (about 20 minutes). You can follow it on the **Actions** tab.
3. Open **Releases**. The newest release has `FireQuest-test-N.apk` (the app) and `firequest-monitor.zip` (the monitor).

The build uses whichever zip file was uploaded most recently. `build.sh` does the actual work.

## Installing on Android test phones

1. Send the `.apk` file to the tester (WhatsApp, email or Google Drive).
2. On the phone, tap the file. If Android asks, allow your browser, WhatsApp or Files app to **install unknown apps**.
3. Open **FireQuest**, create an account, complete the 5 registration steps and allow location.

A newer test build installs over the old one. The tester's account and details stay.

## Running the monitor

1. Download `firequest-monitor.zip` from the latest release on the control-room computer and unzip it.
2. Open `index.html` in **Google Chrome**.
3. Sign in with an operator account and click **Start monitoring**. This switches on the alarm sound. Keep the window open and the volume up.

---

## Test script

| # | Do this | Expect |
|---|---|---|
| 1 | Tester creates an account and completes registration | Home screen with three buttons and a "TEST MODE" banner |
| 2 | Tap a button briefly | Nothing is sent (it must be held for 3 seconds) |
| 3 | Hold **Medical** for 3 seconds | Phone shows "Alert sent". Monitor rings, the alert flashes red, the map shows the phone |
| 4 | Operator clicks **Acknowledge** | Alarm stops. Phone shows "The control room has your alert" within a few seconds |
| 5 | Operator clicks **Navigate in Google Maps** | Google Maps opens with directions to the phone |
| 6 | Tester walks 100 m with the app open | Monitor map position updates about every 10 seconds |
| 7 | Operator clicks **Dispatch FireQuest team**, then **Team on scene** | Phone timeline updates |
| 8 | Tester taps **Cancel with PIN** and enters a wrong PIN | Alert stays active. Monitor shows a red "wrong PIN" warning |
| 9 | Tester enters the right PIN | Alert cancelled on both screens |
| 10 | Repeat with **Vehicle** and **Fire** | Monitor shows the right guidance for each |

Write down anything that is confusing, slow or wrong.

---

## Limits of this test version

- **Location while the app is closed:** the phone sends its location while the alert screen is open (the screen stays on). Tracking with the screen locked comes next.
- **No automatic SMS:** emergency contacts and partner services are not messaged yet. The operator phones them.
- **Map:** uses free OpenStreetMap maps. Fine for testing; for heavy use switch to a paid map service.
- **Signing key:** test builds are signed with a shared test key. A private FireQuest key is needed before release.
- **Supabase free plan:** the project sleeps after 7 days with no activity, and has no backups. Upgrade to Pro (or a FireQuest server) before real clients rely on it.
- **Test mode:** every alert is marked TEST until `test_mode` is switched off in `supabase/settings.sql`.

## Moving clients from the Base44 app (later)

Export users from Base44 as CSV and import them into Supabase. Each client then gets a "set your password" email, because passwords cannot be copied between systems. PayFast subscriptions are matched by email address.
