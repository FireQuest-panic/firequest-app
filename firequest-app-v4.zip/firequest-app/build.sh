#!/usr/bin/env bash
# Builds the FireQuest Android test app (APK) and packages the control-room monitor.
# Run by GitHub Actions; the results go into the dist/ folder.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
BUILD_NUMBER="${BUILD_NUMBER:-1}"
export BUILD_NUMBER

cd "$ROOT/app"

# Optional: repository variables override the settings in src/config.json.
if [ -n "${SUPABASE_URL:-}" ] && [ -n "${SUPABASE_KEY:-}" ]; then
  node -e "const fs=require('fs');const c=JSON.parse(fs.readFileSync('src/config.json','utf8'));c.supabaseUrl=process.env.SUPABASE_URL;c.supabaseKey=process.env.SUPABASE_KEY;if(process.env.CONTROL_ROOM_PHONE)c.controlRoomPhone=process.env.CONTROL_ROOM_PHONE;fs.writeFileSync('src/config.json',JSON.stringify(c,null,2));"
fi

echo "== Installing packages"
npm install --no-audit --no-fund --legacy-peer-deps
npx expo install --fix -- --legacy-peer-deps

echo "== Type check (report only)"
npx tsc --noEmit || echo "::warning::Type check reported problems (the build continues)"

echo "== Creating the Android project"
npx expo prebuild --platform android --no-install

echo "== Building the APK"
(cd android && ./gradlew assembleRelease --no-daemon -PreactNativeArchitectures=arm64-v8a,armeabi-v7a)

echo "== Packaging"
cd "$ROOT"
rm -rf dist && mkdir -p dist/firequest-monitor
cp monitor/index.html monitor/logo.png monitor/config.js dist/firequest-monitor/
(cd dist && zip -qr firequest-monitor.zip firequest-monitor && rm -rf firequest-monitor)
cp app/android/app/build/outputs/apk/release/app-release.apk "dist/FireQuest-test-${BUILD_NUMBER}.apk"
ls -la dist
