// FireQuest Monitor settings (the public "publishable" key is safe to keep here;
// the database's security rules protect the data).
window.FIREQUEST_CONFIG = {
  supabaseUrl: 'https://pwlgbvzslpidlidhjzeo.supabase.co',
  supabaseKey: 'sb_publishable_eF7a_6tCE8UmLoPbPMi3RQ_T8zd8U4P',
};
