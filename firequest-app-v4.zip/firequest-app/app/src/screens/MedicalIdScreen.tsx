import React from 'react';
import { Text, View } from 'react-native';
import { colors } from '../theme';
import { ProfileBundle } from '../lib/types';
import { Body, Button, Card, InfoRow, Logo, Screen, Title } from '../components/ui';

export function MedicalIdScreen({ bundle, onEdit }: { bundle: ProfileBundle; onEdit: () => void }) {
  const { profile, medical, contacts } = bundle;
  const vehicle = [profile.vehicle_colour, profile.vehicle_make, profile.vehicle_model]
    .filter(Boolean)
    .join(' ');

  return (
    <Screen aboveTabBar>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
        <Logo size={48} />
        <Title>Medical ID</Title>
      </View>
      <Body>This is what FireQuest responders see when you raise an alert.</Body>

      <Card>
        <View style={{ flexDirection: 'row', gap: 12 }}>
          <View style={{ flex: 1, padding: 12, borderRadius: 12, backgroundColor: colors.surfaceRaised }}>
            <Text style={{ color: colors.muted, fontSize: 12 }}>Blood type</Text>
            <Text style={{ color: colors.text, fontSize: 24, fontWeight: '800' }}>{medical?.blood_type || '—'}</Text>
          </View>
          <View style={{ flex: 1.4, padding: 12, borderRadius: 12, backgroundColor: colors.dangerDeep }}>
            <Text style={{ color: colors.danger, fontSize: 12 }}>Allergies</Text>
            <Text style={{ color: '#FFD9DA', fontSize: 15, fontWeight: '700' }}>
              {medical?.allergies?.length ? medical.allergies.join(', ') : 'None listed'}
            </Text>
          </View>
        </View>
        <InfoRow label="Chronic conditions" value={medical?.conditions} />
        <InfoRow label="Medication" value={medical?.medication} />
        <InfoRow
          label="Medical aid"
          value={
            medical?.medical_aid_scheme
              ? [medical.medical_aid_scheme, medical.medical_aid_plan, medical.medical_aid_number].filter(Boolean).join(' · ')
              : 'No medical aid'
          }
        />
        <InfoRow label="Doctor" value={[medical?.doctor_name, medical?.doctor_phone].filter(Boolean).join(' · ')} />
      </Card>

      <Card>
        <Text style={{ color: colors.goldText, fontWeight: '700' }}>Emergency contacts</Text>
        {contacts.length ? (
          contacts.map((c) => (
            <InfoRow key={c.id ?? c.phone} label={c.relationship || 'Contact'} value={`${c.name} · ${c.phone}`} />
          ))
        ) : (
          <Body>No contacts yet.</Body>
        )}
      </Card>

      <Card>
        <Text style={{ color: colors.goldText, fontWeight: '700' }}>Personal & vehicle</Text>
        <InfoRow label="Name" value={profile.full_name} />
        <InfoRow label="Mobile" value={profile.phone} />
        <InfoRow label="Home address" value={profile.home_address} />
        <InfoRow
          label="Vehicle"
          value={[vehicle, profile.vehicle_registration].filter(Boolean).join(' · ')}
        />
      </Card>

      <Button title="Edit my details" onPress={onEdit} />
    </Screen>
  );
}
