import { useCallback, useEffect, useRef, useState } from 'react';
import { AppState, Vibration } from 'react-native';
import { setAudioModeAsync, useAudioPlayer } from 'expo-audio';
import { supabase } from './supabase';
import { listAlerts, StaffAlert } from './staff';

const alarmSound = require('../../assets/alarm.wav');
const VIBRATION_PATTERN = [0, 700, 500];

/**
 * Live alert feed for operators. Rings (sound + vibration) while any alert is
 * still "new" and has not been silenced. Runs only while the app is open.
 */
export function useControlRoom(enabled: boolean) {
  const [alerts, setAlerts] = useState<StaffAlert[]>([]);
  const [live, setLive] = useState(false);
  const [error, setError] = useState('');
  const [silenced, setSilenced] = useState<string[]>([]);
  const player = useAudioPlayer(alarmSound);
  const refreshTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const refresh = useCallback(async () => {
    if (!enabled) return;
    try {
      const list = await listAlerts();
      setAlerts(list);
      setError('');
    } catch (e) {
      setError('Cannot load alerts – check the internet connection.');
    }
  }, [enabled]);

  const scheduleRefresh = useCallback(() => {
    if (refreshTimer.current) clearTimeout(refreshTimer.current);
    refreshTimer.current = setTimeout(refresh, 250);
  }, [refresh]);

  useEffect(() => {
    if (!enabled) {
      setAlerts([]);
      return;
    }
    setAudioModeAsync({ playsInSilentMode: true }).catch(() => undefined);
    refresh();
    const channel = supabase
      .channel('firequest-control-room')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'alerts' }, () => scheduleRefresh())
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'alert_events' }, () => scheduleRefresh())
      .subscribe((status) => {
        setLive(status === 'SUBSCRIBED');
        if (status === 'SUBSCRIBED') scheduleRefresh();
      });
    const poll = setInterval(refresh, 15000);
    const appState = AppState.addEventListener('change', (s) => s === 'active' && refresh());
    return () => {
      clearInterval(poll);
      appState.remove();
      if (refreshTimer.current) clearTimeout(refreshTimer.current);
      supabase.removeChannel(channel);
    };
  }, [enabled, refresh, scheduleRefresh]);

  const newAlerts = alerts.filter((a) => a.status === 'new');
  const ringing = newAlerts.filter((a) => !silenced.includes(a.id));
  const shouldRing = enabled && ringing.length > 0;

  useEffect(() => {
    if (shouldRing) {
      Vibration.vibrate(VIBRATION_PATTERN, true);
      try {
        player.loop = true;
        player.seekTo(0);
        player.play();
      } catch {
        // sound is a bonus; vibration still runs
      }
    } else {
      Vibration.cancel();
      try {
        player.pause();
      } catch {
        // ignore
      }
    }
  }, [shouldRing, player]);

  useEffect(
    () => () => {
      Vibration.cancel();
    },
    [],
  );

  /** Silence only the alerts showing now – a new alert rings again. */
  const silence = useCallback(() => {
    setSilenced((prev) => [...prev, ...newAlerts.map((a) => a.id)]);
  }, [newAlerts]);

  return {
    alerts,
    live,
    error,
    newCount: newAlerts.length,
    ringingCount: ringing.length,
    silence,
    refresh,
  };
}

export type ControlRoomFeed = ReturnType<typeof useControlRoom>;
