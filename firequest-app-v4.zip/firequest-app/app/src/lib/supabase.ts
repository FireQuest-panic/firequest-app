import AsyncStorage from '@react-native-async-storage/async-storage';
import { createClient } from '@supabase/supabase-js';
import { AppState } from 'react-native';
import config from '../config.json';

export const isConfigured = Boolean(config.supabaseUrl && config.supabaseKey);
export const controlRoomPhoneFromConfig: string = config.controlRoomPhone || '';

export const supabase = createClient(
  config.supabaseUrl || 'https://not-configured.supabase.co',
  config.supabaseKey || 'not-configured',
  {
    auth: {
      storage: AsyncStorage,
      autoRefreshToken: true,
      persistSession: true,
      detectSessionInUrl: false,
    },
  },
);

// Keep the login fresh only while the app is open.
AppState.addEventListener('change', (state) => {
  if (state === 'active') {
    supabase.auth.startAutoRefresh();
  } else {
    supabase.auth.stopAutoRefresh();
  }
});
