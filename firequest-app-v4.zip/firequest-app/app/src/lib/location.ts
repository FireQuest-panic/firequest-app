import * as Location from 'expo-location';

export type Pos = { lat: number; lng: number; accuracy: number | null };

export type LocationState = 'ok' | 'denied' | 'services_off' | 'unknown';

export function toPos(l: Location.LocationObject): Pos {
  return {
    lat: l.coords.latitude,
    lng: l.coords.longitude,
    accuracy: l.coords.accuracy ?? null,
  };
}

export async function locationState(): Promise<LocationState> {
  try {
    const enabled = await Location.hasServicesEnabledAsync();
    if (!enabled) return 'services_off';
    const perm = await Location.getForegroundPermissionsAsync();
    return perm.granted ? 'ok' : 'denied';
  } catch {
    return 'unknown';
  }
}

export async function ensureLocationPermission(): Promise<boolean> {
  try {
    const current = await Location.getForegroundPermissionsAsync();
    if (current.granted) return true;
    if (!current.canAskAgain) return false;
    const req = await Location.requestForegroundPermissionsAsync();
    return req.granted;
  } catch {
    return false;
  }
}

/**
 * Get a position fast so the alert can go out immediately.
 * Uses a recent last-known fix if there is one, otherwise waits a few
 * seconds for a fresh fix. The alert screen keeps improving it afterwards.
 */
export async function quickPosition(timeoutMs = 5000): Promise<Pos | null> {
  try {
    const last = await Location.getLastKnownPositionAsync({ maxAge: 120000, requiredAccuracy: 300 });
    if (last) return toPos(last);
    const fresh = Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.High }).then(toPos);
    const timeout = new Promise<null>((resolve) => setTimeout(() => resolve(null), timeoutMs));
    return await Promise.race([fresh, timeout]);
  } catch {
    return null;
  }
}
