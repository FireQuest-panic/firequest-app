export type AlertType = 'medical' | 'vehicle' | 'fire';
export type AlertStatus =
  | 'new'
  | 'acknowledged'
  | 'dispatched'
  | 'on_scene'
  | 'closed'
  | 'cancelled';

export interface Profile {
  id: string;
  email: string | null;
  full_name: string;
  phone: string;
  id_number: string | null;
  date_of_birth: string | null;
  gender: string | null;
  home_address: string | null;
  vehicle_make: string | null;
  vehicle_model: string | null;
  vehicle_colour: string | null;
  vehicle_registration: string | null;
  consent_at: string | null;
  onboarded_at: string | null;
}

export interface MedicalProfile {
  user_id: string;
  blood_type: string | null;
  allergies: string[];
  conditions: string | null;
  medication: string | null;
  medical_aid_scheme: string | null;
  medical_aid_plan: string | null;
  medical_aid_number: string | null;
  doctor_name: string | null;
  doctor_phone: string | null;
}

export interface EmergencyContact {
  id?: string;
  user_id?: string;
  name: string;
  relationship: string | null;
  phone: string;
}

export interface PanicAlert {
  id: string;
  user_id: string;
  type: AlertType;
  status: AlertStatus;
  is_test: boolean;
  lat: number | null;
  lng: number | null;
  accuracy_m: number | null;
  location_updated_at: string | null;
  created_at: string;
  acknowledged_at: string | null;
  dispatched_at: string | null;
  on_scene_at: string | null;
  closed_at: string | null;
  cancelled_at: string | null;
}

export interface AppSettings {
  test_mode: boolean;
  control_room_phone: string;
}

export interface ProfileBundle {
  profile: Profile;
  medical: MedicalProfile | null;
  contacts: EmergencyContact[];
  hasPin: boolean;
}

export const OPEN_STATUSES: AlertStatus[] = ['new', 'acknowledged', 'dispatched', 'on_scene'];

export const ALERT_LABELS: Record<AlertType, string> = {
  medical: 'Medical',
  vehicle: 'Vehicle accident',
  fire: 'Fire & rescue',
};
