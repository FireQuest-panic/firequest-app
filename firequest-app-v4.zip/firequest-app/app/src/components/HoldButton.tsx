import React, { useEffect, useRef, useState } from 'react';
import { Animated, Easing, Pressable, StyleSheet, Text, View } from 'react-native';
import * as Haptics from 'expo-haptics';

const HOLD_MS = 3000;

type Props = {
  title: string;
  subtitle: string;
  icon: React.ReactNode;
  background: string;
  textColor: string;
  subtitleColor: string;
  iconBackground: string;
  fillColor: string;
  disabled?: boolean;
  onTrigger: () => void;
};

/** A large panic button that only fires after being held for 3 seconds. */
export function HoldButton(props: Props) {
  const progress = useRef(new Animated.Value(0)).current;
  const animation = useRef<Animated.CompositeAnimation | null>(null);
  const ticker = useRef<ReturnType<typeof setInterval> | null>(null);
  const holdingRef = useRef(false);
  const [holding, setHolding] = useState(false);
  const [secondsLeft, setSecondsLeft] = useState(3);

  const stopTicker = () => {
    if (ticker.current) clearInterval(ticker.current);
    ticker.current = null;
  };

  useEffect(() => () => stopTicker(), []);

  const start = () => {
    if (props.disabled || holdingRef.current) return;
    holdingRef.current = true;
    setHolding(true);
    setSecondsLeft(3);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium).catch(() => undefined);

    const startedAt = Date.now();
    ticker.current = setInterval(() => {
      const left = Math.max(0, Math.ceil((HOLD_MS - (Date.now() - startedAt)) / 1000));
      setSecondsLeft(left);
      Haptics.selectionAsync().catch(() => undefined);
    }, 1000);

    animation.current = Animated.timing(progress, {
      toValue: 1,
      duration: HOLD_MS,
      easing: Easing.linear,
      useNativeDriver: false,
    });
    animation.current.start(({ finished }) => {
      stopTicker();
      if (finished && holdingRef.current) {
        holdingRef.current = false;
        setHolding(false);
        progress.setValue(0);
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success).catch(() => undefined);
        props.onTrigger();
      }
    });
  };

  const release = () => {
    if (!holdingRef.current) return;
    holdingRef.current = false;
    animation.current?.stop();
    stopTicker();
    setHolding(false);
    Animated.timing(progress, { toValue: 0, duration: 200, useNativeDriver: false }).start();
  };

  const width = progress.interpolate({ inputRange: [0, 1], outputRange: ['0%', '100%'] });

  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={`${props.title} alert`}
      accessibilityHint="Press and hold for 3 seconds to send an alert to FireQuest"
      accessibilityState={{ disabled: props.disabled }}
      onPressIn={start}
      onPressOut={release}
      disabled={props.disabled}
      style={[styles.button, { backgroundColor: props.background }, props.disabled && { opacity: 0.5 }]}
    >
      <Animated.View
        pointerEvents="none"
        style={[styles.fill, { width, backgroundColor: props.fillColor }]}
      />
      <View style={[styles.iconCircle, { backgroundColor: props.iconBackground }]}>{props.icon}</View>
      <View style={styles.texts}>
        <Text style={[styles.title, { color: props.textColor }]}>{props.title}</Text>
        <Text style={[styles.subtitle, { color: props.subtitleColor }]}>
          {holding ? `Keep holding… ${secondsLeft}` : props.subtitle}
        </Text>
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  button: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
    paddingVertical: 20,
    paddingHorizontal: 18,
    borderRadius: 22,
    overflow: 'hidden',
    minHeight: 104,
  },
  fill: { position: 'absolute', left: 0, top: 0, bottom: 0 },
  iconCircle: {
    width: 60,
    height: 60,
    borderRadius: 30,
    alignItems: 'center',
    justifyContent: 'center',
  },
  texts: { flex: 1, gap: 4 },
  title: { fontSize: 25, fontWeight: '800' },
  subtitle: { fontSize: 14, fontWeight: '500' },
});
