import React, { useCallback, useEffect, useState } from 'react';
import { Alert, Pressable, Share, Text, TextInput, View } from 'react-native';
import { colors } from '../theme';
import {
  FamilyPlan,
  friendlyError,
  getFamily,
  joinFamily,
  leaveFamily,
  newFamilyCode,
  removeFamilyMember,
} from '../lib/data';
import { Body, Button, Card, ErrorText } from './ui';

/** Account-screen card: family plan for up to 4 people, each with their own login. */
export function FamilyCard() {
  const [plan, setPlan] = useState<FamilyPlan | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState('');
  const [joining, setJoining] = useState(false);
  const [code, setCode] = useState('');

  const run = useCallback(async (key: string, fn: () => Promise<FamilyPlan>) => {
    setError('');
    setBusy(key);
    try {
      setPlan(await fn());
      return true;
    } catch (e) {
      setError(friendlyError(e));
      return false;
    } finally {
      setBusy(null);
    }
  }, []);

  useEffect(() => {
    run('load', getFamily);
  }, [run]);

  if (!plan) {
    return (
      <Card>
        <Text style={heading}>Family plan</Text>
        {error ? <ErrorText>{error}</ErrorText> : <Body>Loading…</Body>}
      </Card>
    );
  }

  const count = plan.members.length;
  const full = count >= plan.max_members;

  const share = () => {
    if (!plan.invite_code) return;
    Share.share({
      message:
        `Join my FireQuest family plan:\n` +
        `1. Install the FireQuest app and create your own account.\n` +
        `2. Go to Account > Join a family plan.\n` +
        `3. Enter this code: ${plan.invite_code}`,
    }).catch(() => undefined);
  };

  const confirmRemove = (userId: string, name: string) =>
    Alert.alert('Remove from family plan?', `${name || 'This person'} will no longer be on your plan.`, [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Remove', style: 'destructive', onPress: () => run(`remove-${userId}`, () => removeFamilyMember(userId)) },
    ]);

  const confirmLeave = () =>
    Alert.alert('Leave this family plan?', `You will no longer be on ${plan.owner_name || 'the holder'}'s plan.`, [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Leave', style: 'destructive', onPress: () => run('leave', leaveFamily) },
    ]);

  return (
    <Card>
      <Text style={heading}>
        Family plan · {count} of {plan.max_members} people
      </Text>
      {!plan.is_owner && <Body>You are on {plan.owner_name || 'the holder'}'s family plan.</Body>}

      <View style={{ gap: 8 }}>
        {plan.members.map((m) => (
          <View key={m.user_id} style={{ flexDirection: 'row', alignItems: 'center', gap: 10, minHeight: 44 }}>
            <View style={{ flex: 1 }}>
              <Text style={{ color: colors.text, fontSize: 15, fontWeight: '600' }}>
                {m.name || m.email || 'Member'}
                {m.is_me ? ' (you)' : ''}
              </Text>
              <Text style={{ color: colors.muted, fontSize: 12 }}>{m.role === 'owner' ? 'Plan holder' : 'Member'}</Text>
            </View>
            {plan.is_owner && !m.is_me && (
              <Pressable
                accessibilityRole="button"
                accessibilityLabel={`Remove ${m.name}`}
                onPress={() => confirmRemove(m.user_id, m.name)}
                style={{ minHeight: 44, justifyContent: 'center', paddingHorizontal: 8 }}
              >
                <Text style={{ color: colors.redText, fontWeight: '700' }}>
                  {busy === `remove-${m.user_id}` ? 'Removing…' : 'Remove'}
                </Text>
              </Pressable>
            )}
          </View>
        ))}
      </View>

      {plan.is_owner && (
        <View style={{ gap: 10 }}>
          {full ? (
            <Body>Your plan is full. Remove someone to add another person.</Body>
          ) : (
            <>
              <Body>Invite up to {plan.max_members - count} more. Each person uses their own phone and FireQuest login.</Body>
              <View style={{ alignItems: 'center', padding: 12, borderRadius: 12, backgroundColor: colors.goldDeep, borderWidth: 1, borderColor: colors.gold }}>
                <Text style={{ color: colors.muted, fontSize: 12 }}>Family code</Text>
                <Text selectable style={{ color: colors.goldText, fontSize: 30, fontWeight: '800', letterSpacing: 6 }}>
                  {plan.invite_code}
                </Text>
              </View>
              <Button title="Share invite (WhatsApp, SMS…)" onPress={share} />
              <Button
                title="Make a new code"
                variant="plain"
                loading={busy === 'code'}
                onPress={() => run('code', newFamilyCode)}
              />
            </>
          )}
        </View>
      )}

      {!plan.is_owner && <Button title="Leave family plan" variant="outline" loading={busy === 'leave'} onPress={confirmLeave} />}

      {plan.is_owner && count === 1 && (
        <View style={{ gap: 10 }}>
          {joining ? (
            <>
              <Text style={{ color: '#CFC9BD', fontSize: 13, fontWeight: '600' }}>Code from the plan holder</Text>
              <TextInput
                accessibilityLabel="Family code"
                value={code}
                onChangeText={(t) => setCode(t.toUpperCase())}
                autoCapitalize="characters"
                maxLength={8}
                placeholder="e.g. K7M4PX"
                placeholderTextColor={colors.faint}
                style={{
                  minHeight: 52,
                  borderRadius: 12,
                  borderWidth: 1,
                  borderColor: colors.border,
                  backgroundColor: colors.bg,
                  color: colors.text,
                  fontSize: 22,
                  letterSpacing: 4,
                  textAlign: 'center',
                }}
              />
              <Button
                title="Join family plan"
                loading={busy === 'join'}
                onPress={async () => {
                  if (code.trim().length < 6) return setError('Enter the 6-character code.');
                  if (await run('join', () => joinFamily(code))) {
                    setJoining(false);
                    setCode('');
                  }
                }}
              />
              <Button title="Cancel" variant="plain" onPress={() => setJoining(false)} />
            </>
          ) : (
            <Button title="Join a family plan" variant="outline" onPress={() => setJoining(true)} />
          )}
        </View>
      )}

      <ErrorText>{error}</ErrorText>
    </Card>
  );
}

const heading = { color: colors.goldText, fontWeight: '700' as const, fontSize: 15 };
