import React from 'react';
import {
  ActivityIndicator,
  Image,
  KeyboardTypeOptions,
  Pressable,
  ScrollView,
  StyleProp,
  StyleSheet,
  Text,
  TextInput,
  View,
  ViewStyle,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { colors, radius } from '../theme';

const logoSource = require('../../assets/logo.png');

export function Screen({
  children,
  scroll = true,
  style,
  aboveTabBar = false,
}: {
  children: React.ReactNode;
  scroll?: boolean;
  style?: StyleProp<ViewStyle>;
  aboveTabBar?: boolean;
}) {
  return (
    <SafeAreaView
      style={styles.safe}
      edges={aboveTabBar ? ['top', 'left', 'right'] : ['top', 'left', 'right', 'bottom']}
    >
      {scroll ? (
        <ScrollView
          contentContainerStyle={[styles.scrollContent, style]}
          keyboardShouldPersistTaps="handled"
        >
          {children}
        </ScrollView>
      ) : (
        <View style={[styles.fill, style]}>{children}</View>
      )}
    </SafeAreaView>
  );
}

export function Logo({ size = 64 }: { size?: number }) {
  return (
    <Image
      source={logoSource}
      style={{ width: size, height: size * 0.952 }}
      resizeMode="contain"
      accessibilityLabel="FireQuest Search and Rescue"
    />
  );
}

export function Title({ children }: { children: React.ReactNode }) {
  return <Text style={styles.title}>{children}</Text>;
}

export function Body({ children, center }: { children: React.ReactNode; center?: boolean }) {
  return <Text style={[styles.body, center && { textAlign: 'center' }]}>{children}</Text>;
}

export function Field({
  label,
  value,
  onChangeText,
  placeholder,
  keyboardType,
  secureTextEntry,
  autoCapitalize = 'sentences',
  maxLength,
  multiline,
  autoComplete,
}: {
  label: string;
  value: string;
  onChangeText: (t: string) => void;
  placeholder?: string;
  keyboardType?: KeyboardTypeOptions;
  secureTextEntry?: boolean;
  autoCapitalize?: 'none' | 'sentences' | 'words' | 'characters';
  maxLength?: number;
  multiline?: boolean;
  autoComplete?: React.ComponentProps<typeof TextInput>['autoComplete'];
}) {
  return (
    <View style={styles.field}>
      <Text style={styles.label}>{label}</Text>
      <TextInput
        accessibilityLabel={label}
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        placeholderTextColor={colors.faint}
        keyboardType={keyboardType}
        secureTextEntry={secureTextEntry}
        autoCapitalize={autoCapitalize}
        maxLength={maxLength}
        multiline={multiline}
        autoComplete={autoComplete}
        style={[styles.input, multiline && { minHeight: 80, textAlignVertical: 'top', paddingTop: 12 }]}
      />
    </View>
  );
}

type ButtonVariant = 'gold' | 'outline' | 'red' | 'plain';

export function Button({
  title,
  onPress,
  variant = 'gold',
  loading,
  disabled,
  style,
}: {
  title: string;
  onPress: () => void;
  variant?: ButtonVariant;
  loading?: boolean;
  disabled?: boolean;
  style?: StyleProp<ViewStyle>;
}) {
  const v = buttonVariants[variant];
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityState={{ disabled: disabled || loading }}
      onPress={onPress}
      disabled={disabled || loading}
      style={({ pressed }) => [
        styles.button,
        v.box,
        (disabled || loading) && { opacity: 0.5 },
        pressed && { opacity: 0.8 },
        style,
      ]}
    >
      {loading ? (
        <ActivityIndicator color={v.text.color} />
      ) : (
        <Text style={[styles.buttonText, v.text]}>{title}</Text>
      )}
    </Pressable>
  );
}

const buttonVariants: Record<ButtonVariant, { box: ViewStyle; text: { color: string } }> = {
  gold: { box: { backgroundColor: colors.gold }, text: { color: colors.ink } },
  red: { box: { backgroundColor: colors.red }, text: { color: '#FFFFFF' } },
  outline: {
    box: { backgroundColor: 'transparent', borderWidth: 1, borderColor: colors.borderStrong },
    text: { color: colors.text },
  },
  plain: { box: { backgroundColor: 'transparent', minHeight: 44 }, text: { color: colors.goldText } },
};

export function Chip({
  label,
  selected,
  onPress,
}: {
  label: string;
  selected: boolean;
  onPress: () => void;
}) {
  return (
    <Pressable
      accessibilityRole="radio"
      accessibilityState={{ selected }}
      onPress={onPress}
      style={[styles.chip, selected && styles.chipSelected]}
    >
      <Text style={[styles.chipText, selected && { color: colors.text, fontWeight: '700' }]}>
        {label}
      </Text>
    </Pressable>
  );
}

export function Card({ children, style }: { children: React.ReactNode; style?: StyleProp<ViewStyle> }) {
  return <View style={[styles.card, style]}>{children}</View>;
}

export function TestBanner() {
  return (
    <View style={styles.testBanner} accessibilityRole="alert">
      <Text style={styles.testBannerText}>
        TEST MODE · Alerts go to the FireQuest control room only. No ambulance or fire brigade is
        called.
      </Text>
    </View>
  );
}

export function ErrorText({ children }: { children: React.ReactNode }) {
  if (!children) return null;
  return (
    <Text style={styles.error} accessibilityRole="alert">
      {children}
    </Text>
  );
}

export function InfoRow({ label, value }: { label: string; value?: string | null }) {
  return (
    <View style={{ gap: 2 }}>
      <Text style={styles.infoLabel}>{label}</Text>
      <Text style={styles.infoValue}>{value && value.trim() ? value : '—'}</Text>
    </View>
  );
}

export const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.bg },
  fill: { flex: 1, paddingHorizontal: 20 },
  scrollContent: { flexGrow: 1, paddingHorizontal: 20, paddingVertical: 16, gap: 16 },
  title: { color: colors.text, fontSize: 28, fontWeight: '800' },
  body: { color: colors.muted, fontSize: 15, lineHeight: 22 },
  field: { gap: 6 },
  label: { color: '#CFC9BD', fontSize: 13, fontWeight: '600' },
  input: {
    minHeight: 48,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.surface,
    color: colors.text,
    fontSize: 16,
    paddingHorizontal: 14,
  },
  button: {
    minHeight: 54,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 16,
  },
  buttonText: { fontSize: 17, fontWeight: '700' },
  chip: {
    minHeight: 44,
    minWidth: 56,
    paddingHorizontal: 12,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.surface,
    alignItems: 'center',
    justifyContent: 'center',
  },
  chipSelected: { borderWidth: 2, borderColor: colors.gold, backgroundColor: colors.goldDeep },
  chipText: { color: colors.text, fontSize: 15, fontWeight: '600' },
  card: {
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.lg,
    padding: 16,
    gap: 12,
  },
  testBanner: {
    backgroundColor: colors.goldDeep,
    borderColor: colors.gold,
    borderWidth: 1,
    borderRadius: 12,
    padding: 10,
  },
  testBannerText: { color: colors.goldText, fontSize: 13, fontWeight: '600', lineHeight: 18 },
  error: { color: colors.danger, fontSize: 14, lineHeight: 20 },
  infoLabel: { color: colors.muted, fontSize: 12 },
  infoValue: { color: colors.text, fontSize: 15 },
});
