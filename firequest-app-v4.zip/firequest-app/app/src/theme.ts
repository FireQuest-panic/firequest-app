// FireQuest brand colours, taken from the Search & Rescue badge.
export const colors = {
  bg: '#0F0F10',
  surface: '#1A1A1C',
  surfaceRaised: '#222120',
  border: '#2E2C28',
  borderStrong: '#4A4538',
  text: '#F4F1EA',
  muted: '#A8A39A',
  faint: '#8C877E',
  gold: '#B99B52',
  goldText: '#D9BE7E',
  goldDeep: '#262014',
  red: '#D42F35',
  redText: '#FF8A8E',
  redDeep: '#2E1214',
  ivory: '#F4F1EA',
  ink: '#111214',
  green: '#7EE2A8',
  greenDeep: '#13261B',
  danger: '#FFB4B7',
  dangerDeep: '#3A1416',
};

export const radius = { sm: 10, md: 14, lg: 18, xl: 22 };
