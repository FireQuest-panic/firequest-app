import { supabase } from './supabase';
import {
  AlertType,
  AppSettings,
  EmergencyContact,
  MedicalProfile,
  OPEN_STATUSES,
  PanicAlert,
  Profile,
  ProfileBundle,
} from './types';
import type { Pos } from './location';

export async function loadBundle(userId: string): Promise<ProfileBundle> {
  const [p, m, c, pin] = await Promise.all([
    supabase.from('profiles').select('*').eq('id', userId).maybeSingle(),
    supabase.from('medical_profiles').select('*').eq('user_id', userId).maybeSingle(),
    supabase.from('emergency_contacts').select('*').eq('user_id', userId).order('created_at'),
    supabase.rpc('has_cancel_pin'),
  ]);
  if (p.error) throw p.error;
  if (m.error) throw m.error;
  if (c.error) throw c.error;
  if (pin.error) throw pin.error;

  let profile = p.data as Profile | null;
  if (!profile) {
    // Normally created automatically at sign-up; create it here if missing.
    const { data: userData } = await supabase.auth.getUser();
    const meta = (userData.user?.user_metadata ?? {}) as Record<string, string>;
    const ins = await supabase
      .from('profiles')
      .insert({
        id: userId,
        email: userData.user?.email ?? null,
        full_name: meta.full_name ?? '',
        phone: meta.phone ?? '',
      })
      .select('*')
      .single();
    if (ins.error) throw ins.error;
    profile = ins.data as Profile;
  }

  return {
    profile,
    medical: (m.data as MedicalProfile | null) ?? null,
    contacts: (c.data as EmergencyContact[] | null) ?? [],
    hasPin: Boolean(pin.data),
  };
}

export async function saveProfile(userId: string, fields: Partial<Profile>): Promise<void> {
  const { error } = await supabase.from('profiles').update(fields).eq('id', userId);
  if (error) throw error;
}

export async function saveMedical(userId: string, fields: Partial<MedicalProfile>): Promise<void> {
  const { error } = await supabase
    .from('medical_profiles')
    .upsert({ ...fields, user_id: userId }, { onConflict: 'user_id' });
  if (error) throw error;
}

export async function saveContacts(userId: string, contacts: EmergencyContact[]): Promise<void> {
  const rows = contacts
    .filter((c) => c.name.trim() && c.phone.trim())
    .map((c) => ({
      user_id: userId,
      name: c.name.trim(),
      relationship: c.relationship?.trim() || null,
      phone: c.phone.trim(),
    }));
  const del = await supabase.from('emergency_contacts').delete().eq('user_id', userId);
  if (del.error) throw del.error;
  if (rows.length) {
    const ins = await supabase.from('emergency_contacts').insert(rows);
    if (ins.error) throw ins.error;
  }
}

export async function setCancelPin(pin: string): Promise<void> {
  const { error } = await supabase.rpc('set_cancel_pin', { p_pin: pin });
  if (error) throw error;
}

export async function loadSettings(): Promise<AppSettings> {
  const { data, error } = await supabase
    .from('app_settings')
    .select('test_mode, control_room_phone')
    .eq('id', 1)
    .maybeSingle();
  if (error || !data) return { test_mode: true, control_room_phone: '' };
  return data as AppSettings;
}

export async function getOpenAlert(userId: string): Promise<PanicAlert | null> {
  const { data, error } = await supabase
    .from('alerts')
    .select('*')
    .eq('user_id', userId)
    .in('status', OPEN_STATUSES)
    .order('created_at', { ascending: false })
    .limit(1)
    .maybeSingle();
  if (error) throw error;
  return (data as PanicAlert | null) ?? null;
}

export async function getAlert(id: string): Promise<PanicAlert | null> {
  const { data, error } = await supabase.from('alerts').select('*').eq('id', id).maybeSingle();
  if (error) throw error;
  return (data as PanicAlert | null) ?? null;
}

export async function raiseAlert(type: AlertType, pos: Pos | null): Promise<PanicAlert> {
  const { data, error } = await supabase.rpc('raise_alert', {
    p_type: type,
    p_lat: pos?.lat ?? null,
    p_lng: pos?.lng ?? null,
    p_accuracy: pos?.accuracy ?? null,
  });
  if (error) throw error;
  const row = Array.isArray(data) ? data[0] : data;
  if (!row) throw new Error('The alert was not created.');
  return row as PanicAlert;
}

export async function updateAlertLocation(alertId: string, pos: Pos): Promise<void> {
  const { error } = await supabase.rpc('update_alert_location', {
    p_alert_id: alertId,
    p_lat: pos.lat,
    p_lng: pos.lng,
    p_accuracy: pos.accuracy,
  });
  if (error) throw error;
}

export async function cancelAlert(alertId: string, pin: string): Promise<boolean> {
  const { data, error } = await supabase.rpc('cancel_alert', { p_alert_id: alertId, p_pin: pin });
  if (error) throw error;
  return data === true;
}

export function friendlyError(e: unknown): string {
  const msg = e instanceof Error ? e.message : typeof e === 'object' && e && 'message' in e
    ? String((e as { message: unknown }).message)
    : String(e);
  if (/network|fetch|timed out|timeout/i.test(msg)) {
    return 'No connection to FireQuest. Check your mobile data or Wi-Fi.';
  }
  if (/invalid login credentials/i.test(msg)) return 'Email or password is incorrect.';
  if (/email not confirmed/i.test(msg)) return 'Please confirm your email address first (check your inbox).';
  if (/already registered/i.test(msg)) return 'An account with this email already exists. Sign in instead.';
  return msg;
}
