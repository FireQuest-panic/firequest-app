import React, { useCallback, useEffect, useState } from 'react';
import { BackHandler, Linking, Pressable, Text, TextInput, View } from 'react-native';
import { useKeepAwake } from 'expo-keep-awake';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { colors } from '../theme';
import { ALERT_LABELS, OPEN_STATUSES } from '../lib/types';
import { friendlyError } from '../lib/data';
import {
  AlertDetail,
  EVENT_LABELS,
  hhmm,
  loadAlertDetail,
  navigationUrl,
  operatorAction,
  STATUS_LABELS,
  STATUS_RANK,
  StaffAlert,
  timeAgo,
} from '../lib/staff';
import type { ControlRoomFeed } from '../lib/useControlRoom';
import { Body, Button, Card, ErrorText, InfoRow, Logo, Screen, Title } from '../components/ui';

const TYPE_COLOR: Record<string, string> = {
  medical: colors.text,
  vehicle: colors.goldText,
  fire: colors.redText,
};

export function ControlRoomScreen({ feed, operatorName }: { feed: ControlRoomFeed; operatorName: string }) {
  useKeepAwake();
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const selected = feed.alerts.find((a) => a.id === selectedId) ?? null;

  useEffect(() => {
    if (!selectedId) return;
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      setSelectedId(null);
      return true;
    });
    return () => sub.remove();
  }, [selectedId]);

  if (selected) {
    return <AlertDetailView alert={selected} feed={feed} onBack={() => setSelectedId(null)} />;
  }

  const active = feed.alerts
    .filter((a) => OPEN_STATUSES.includes(a.status))
    .sort((x, y) => STATUS_RANK[x.status] - STATUS_RANK[y.status] || +new Date(y.created_at) - +new Date(x.created_at));
  const closed = feed.alerts.filter((a) => !OPEN_STATUSES.includes(a.status));

  return (
    <Screen aboveTabBar>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
        <Logo size={48} />
        <View style={{ flex: 1 }}>
          <Title>Control room</Title>
          <Text style={{ color: colors.muted, fontSize: 13 }}>Operator: {operatorName}</Text>
        </View>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
          <View style={{ width: 9, height: 9, borderRadius: 5, backgroundColor: feed.live ? '#3FCB80' : colors.red }} />
          <Text style={{ color: colors.muted, fontSize: 13 }}>{feed.live ? 'Live' : 'Connecting…'}</Text>
        </View>
      </View>

      {feed.ringingCount > 0 && (
        <Button title={`Silence alarm (${feed.ringingCount} new)`} variant="red" onPress={feed.silence} />
      )}
      <ErrorText>{feed.error}</ErrorText>
      <Text style={{ color: colors.muted, fontSize: 12 }}>
        Keep this screen open and the volume up. The alarm only sounds while the app is open.
      </Text>

      <Text style={sectionLabel}>ACTIVE ALERTS · {active.length}</Text>
      {active.length ? active.map((a) => <AlertRow key={a.id} alert={a} onPress={() => setSelectedId(a.id)} />) : <Body>No active alerts.</Body>}

      <Text style={sectionLabel}>CLOSED · LAST 24 HOURS</Text>
      {closed.length ? closed.map((a) => <AlertRow key={a.id} alert={a} onPress={() => setSelectedId(a.id)} />) : <Body>None.</Body>}
    </Screen>
  );
}

const sectionLabel = { color: colors.muted, fontSize: 12, fontWeight: '700' as const, letterSpacing: 1, marginTop: 4 };

function AlertRow({ alert, onPress }: { alert: StaffAlert; onPress: () => void }) {
  const isNew = alert.status === 'new';
  const open = OPEN_STATUSES.includes(alert.status);
  return (
    <Pressable
      accessibilityRole="button"
      onPress={onPress}
      style={{
        padding: 14,
        borderRadius: 14,
        borderWidth: isNew ? 2 : 1,
        borderColor: isNew ? colors.red : colors.border,
        backgroundColor: isNew ? colors.redDeep : colors.surface,
        gap: 4,
      }}
    >
      <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
        <Text style={{ color: TYPE_COLOR[alert.type], fontWeight: '800', fontSize: 12 }}>
          {ALERT_LABELS[alert.type].toUpperCase()}
          {alert.is_test ? ' · TEST' : ''}
        </Text>
        <Text style={{ color: colors.muted, fontSize: 12 }}>{open ? timeAgo(alert.created_at) : hhmm(alert.created_at)}</Text>
      </View>
      <Text style={{ color: colors.text, fontSize: 17, fontWeight: '700' }}>{alert.profiles?.full_name || 'Unknown client'}</Text>
      <Text style={{ color: isNew ? colors.redText : colors.muted, fontSize: 13, fontWeight: isNew ? '700' : '400' }}>
        {STATUS_LABELS[alert.status]}
      </Text>
    </Pressable>
  );
}

function guidance(alert: StaffAlert, detail: AlertDetail | null): string {
  if (alert.type === 'medical') {
    return detail?.medical?.medical_aid_scheme
      ? 'Medical aid on file: phone the available private ambulance partner and give the medical aid details below.'
      : 'No medical aid on file: notify government EMS on 10177.';
  }
  if (alert.type === 'fire') return 'Notify the local fire brigade with the address and location link.';
  return 'If anyone is injured, arrange an ambulance as for a medical alert. Ask about fire, entrapment or hazards.';
}

function AlertDetailView({ alert, feed, onBack }: { alert: StaffAlert; feed: ControlRoomFeed; onBack: () => void }) {
  const [detail, setDetail] = useState<AlertDetail | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState('');
  const [note, setNote] = useState('');
  const [closing, setClosing] = useState(false);
  const [outcome, setOutcome] = useState('');

  const reload = useCallback(() => {
    loadAlertDetail(alert)
      .then(setDetail)
      .catch((e) => setError(friendlyError(e)));
  }, [alert]);

  // Reload when the alert changes (status, location) and every 15 seconds.
  useEffect(() => {
    reload();
    const t = setInterval(reload, 15000);
    return () => clearInterval(t);
  }, [reload, alert.status, alert.location_updated_at]);

  const act = async (action: string, actionNote: string | null = null) => {
    setError('');
    setBusy(action);
    try {
      await operatorAction(alert.id, action, actionNote);
      await feed.refresh();
      reload();
      return true;
    } catch (e) {
      setError(friendlyError(e));
      return false;
    } finally {
      setBusy(null);
    }
  };

  const log = (action: string) => {
    operatorAction(alert.id, action).catch(() => undefined);
  };

  const open = OPEN_STATUSES.includes(alert.status);
  const hasLoc = alert.lat != null && alert.lng != null;
  const navUrl = hasLoc ? navigationUrl(alert.lat as number, alert.lng as number) : '';
  const stale =
    open && alert.location_updated_at && Date.now() - new Date(alert.location_updated_at).getTime() > 2 * 60 * 1000;
  const p = detail?.profile;
  const m = detail?.medical;
  const wrongPins = detail?.events.filter((e) => e.event === 'cancel_wrong_pin').length ?? 0;
  const vehicle = p ? [p.vehicle_colour, p.vehicle_make, p.vehicle_model].filter(Boolean).join(' ') : '';
  const phone = p?.phone || alert.profiles?.phone || '';

  const sendRoute = () => {
    const msg = `FireQuest ${ALERT_LABELS[alert.type]} alert${alert.is_test ? ' (TEST)' : ''}. Navigate: ${navUrl}`;
    log('route_sent');
    Linking.openURL(`whatsapp://send?text=${encodeURIComponent(msg)}`).catch(() =>
      Linking.openURL(`https://wa.me/?text=${encodeURIComponent(msg)}`),
    );
  };

  return (
    <Screen aboveTabBar>
      <Pressable accessibilityRole="button" onPress={onBack} style={{ flexDirection: 'row', alignItems: 'center', gap: 6, minHeight: 44 }}>
        <MaterialCommunityIcons name="arrow-left" size={22} color={colors.goldText} />
        <Text style={{ color: colors.goldText, fontSize: 16, fontWeight: '600' }}>All alerts</Text>
      </Pressable>

      <View style={{ gap: 4 }}>
        <Text style={{ color: TYPE_COLOR[alert.type], fontWeight: '800', fontSize: 13, letterSpacing: 1 }}>
          {ALERT_LABELS[alert.type].toUpperCase()} ALERT{alert.is_test ? ' · TEST' : ''}
        </Text>
        <Title>{p?.full_name || alert.profiles?.full_name || 'Unknown client'}</Title>
        <Text style={{ color: colors.muted, fontSize: 14 }}>
          {STATUS_LABELS[alert.status]} · raised {hhmm(alert.created_at)} ({timeAgo(alert.created_at)})
        </Text>
      </View>

      {wrongPins > 0 && (
        <Card style={{ borderColor: '#7A2A2E', backgroundColor: colors.redDeep }}>
          <Text style={{ color: colors.danger, fontWeight: '700' }}>
            Warning: a wrong cancel PIN was entered {wrongPins} time(s). Phone the client to check they are safe.
          </Text>
        </Card>
      )}
      {alert.is_test && (
        <Card style={{ borderColor: colors.gold, backgroundColor: colors.goldDeep }}>
          <Text style={{ color: colors.goldText, fontWeight: '700' }}>TEST ALERT – do not call ambulance or fire services.</Text>
        </Card>
      )}
      <Card>
        <Text style={{ color: colors.text, fontSize: 14, lineHeight: 20 }}>{guidance(alert, detail)}</Text>
      </Card>

      <Card>
        <Text style={{ color: colors.goldText, fontWeight: '700' }}>Location</Text>
        {hasLoc ? (
          <>
            <Text style={{ color: stale ? colors.danger : colors.text, fontSize: 14 }}>
              {(alert.lat as number).toFixed(5)}, {(alert.lng as number).toFixed(5)}
              {alert.accuracy_m ? ` · ±${Math.round(alert.accuracy_m)} m` : ''} · updated {timeAgo(alert.location_updated_at)}
              {stale ? ' – may be out of date, phone the client' : ''}
            </Text>
            <Pressable
              accessibilityRole="button"
              onPress={() => {
                log('navigate_opened');
                Linking.openURL(navUrl);
              }}
              style={{ minHeight: 54, borderRadius: 14, backgroundColor: '#17784A', flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8 }}
            >
              <MaterialCommunityIcons name="navigation-variant" size={22} color="#FFFFFF" />
              <Text style={{ color: '#FFFFFF', fontSize: 17, fontWeight: '700' }}>Navigate in Google Maps</Text>
            </Pressable>
            <Button title="Send route to team (WhatsApp)" variant="outline" onPress={sendRoute} />
          </>
        ) : (
          <Body>Waiting for the client's GPS location…</Body>
        )}
      </Card>

      {open ? (
        <View style={{ gap: 10 }}>
          {alert.status === 'new' && (
            <Button title="Acknowledge" onPress={() => act('acknowledge')} loading={busy === 'acknowledge'} />
          )}
          {STATUS_RANK[alert.status] < STATUS_RANK.dispatched && (
            <Button title="Dispatch FireQuest team" variant="red" onPress={() => act('dispatch')} loading={busy === 'dispatch'} />
          )}
          {alert.status === 'dispatched' && (
            <Button title="Team on scene" onPress={() => act('on_scene')} loading={busy === 'on_scene'} />
          )}
          {phone ? (
            <Button
              title={`Call client (${phone})`}
              variant="outline"
              onPress={() => {
                log('called_client');
                Linking.openURL(`tel:${phone}`);
              }}
            />
          ) : null}
          {closing ? (
            <Card>
              <Text style={{ color: '#CFC9BD', fontSize: 13, fontWeight: '600' }}>Outcome (required to close)</Text>
              <TextInput
                accessibilityLabel="Outcome"
                value={outcome}
                onChangeText={setOutcome}
                placeholder="e.g. Patient transported; false alarm"
                placeholderTextColor={colors.faint}
                multiline
                style={inputStyle}
              />
              <Button
                title="Confirm close"
                variant="outline"
                loading={busy === 'close'}
                onPress={async () => {
                  if (!outcome.trim()) return setError('Write a short outcome before closing the alert.');
                  if (await act('close', outcome.trim())) setClosing(false);
                }}
              />
            </Card>
          ) : (
            <Button title="Close alert" variant="outline" onPress={() => setClosing(true)} />
          )}
        </View>
      ) : (
        <Card>
          <Text style={{ color: colors.text }}>
            {STATUS_LABELS[alert.status]}
            {alert.outcome ? ` – ${alert.outcome}` : ''}
          </Text>
        </Card>
      )}
      <ErrorText>{error}</ErrorText>

      <Card>
        <View style={{ flexDirection: 'row', gap: 10 }}>
          <View style={{ flex: 1, padding: 12, borderRadius: 12, backgroundColor: colors.surfaceRaised }}>
            <Text style={{ color: colors.muted, fontSize: 12 }}>Blood type</Text>
            <Text style={{ color: colors.text, fontSize: 22, fontWeight: '800' }}>{m?.blood_type || '—'}</Text>
          </View>
          <View style={{ flex: 1.4, padding: 12, borderRadius: 12, backgroundColor: colors.dangerDeep }}>
            <Text style={{ color: colors.danger, fontSize: 12 }}>Allergies</Text>
            <Text style={{ color: '#FFD9DA', fontSize: 15, fontWeight: '700' }}>
              {m?.allergies?.length ? m.allergies.join(', ') : 'None listed'}
            </Text>
          </View>
        </View>
        <InfoRow label="Conditions" value={m?.conditions} />
        <InfoRow label="Medication" value={m?.medication} />
        <View style={{ gap: 2 }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
            <Text style={{ color: colors.muted, fontSize: 12 }}>Medical aid</Text>
            <Text
              style={{
                fontSize: 11,
                fontWeight: '800',
                paddingHorizontal: 6,
                paddingVertical: 2,
                borderRadius: 4,
                color: m?.medical_aid_scheme ? colors.green : colors.redText,
                backgroundColor: m?.medical_aid_scheme ? colors.greenDeep : colors.redDeep,
              }}
            >
              {m?.medical_aid_scheme ? 'COVERED' : 'NO MEDICAL AID'}
            </Text>
          </View>
          <Text style={{ color: colors.text, fontSize: 15 }}>
            {m?.medical_aid_scheme
              ? [m.medical_aid_scheme, m.medical_aid_plan, m.medical_aid_number].filter(Boolean).join(' · ')
              : '—'}
          </Text>
        </View>
        <InfoRow label="Doctor" value={[m?.doctor_name, m?.doctor_phone].filter(Boolean).join(' · ')} />
      </Card>

      <Card>
        <Text style={{ color: colors.goldText, fontWeight: '700' }}>Emergency contacts</Text>
        {detail?.contacts.length ? (
          detail.contacts.map((c) => (
            <Pressable key={c.id ?? c.phone} accessibilityRole="link" onPress={() => Linking.openURL(`tel:${c.phone}`)}>
              <Text style={{ color: colors.text, fontSize: 15 }}>
                {c.name}
                {c.relationship ? ` (${c.relationship})` : ''} · <Text style={{ color: colors.goldText, textDecorationLine: 'underline' }}>{c.phone}</Text>
              </Text>
            </Pressable>
          ))
        ) : (
          <Body>—</Body>
        )}
        <InfoRow label="Home address" value={p?.home_address} />
        <InfoRow label="Vehicle" value={[vehicle, p?.vehicle_registration].filter(Boolean).join(' · ')} />
        <InfoRow label="ID number" value={p?.id_number} />
      </Card>

      <Card>
        <Text style={{ color: '#CFC9BD', fontSize: 13, fontWeight: '600' }}>Add a note</Text>
        <TextInput
          accessibilityLabel="Note"
          value={note}
          onChangeText={setNote}
          placeholder="e.g. Ambulance ETA 12 min"
          placeholderTextColor={colors.faint}
          multiline
          style={inputStyle}
        />
        <Button
          title="Save note"
          variant="outline"
          loading={busy === 'note'}
          onPress={async () => {
            if (!note.trim()) return;
            if (await act('note', note.trim())) setNote('');
          }}
        />
      </Card>

      <Card>
        <Text style={{ color: colors.muted, fontSize: 12, fontWeight: '700', letterSpacing: 1 }}>ALERT LOG</Text>
        {(detail?.events ?? []).map((e) => (
          <View key={e.id} style={{ flexDirection: 'row', gap: 10 }}>
            <Text style={{ color: colors.faint, width: 44, fontSize: 13 }}>{hhmm(e.created_at)}</Text>
            <View style={{ flex: 1 }}>
              <Text style={{ color: e.event === 'cancel_wrong_pin' ? colors.danger : colors.text, fontSize: 13, fontWeight: e.event === 'cancel_wrong_pin' ? '700' : '400' }}>
                {EVENT_LABELS[e.event] || e.event}
                {e.actor_kind === 'operator' && e.actor_id && detail?.staffNames[e.actor_id] ? ` · ${detail.staffNames[e.actor_id]}` : ''}
              </Text>
              {e.note ? <Text style={{ color: colors.muted, fontSize: 13 }}>{e.note}</Text> : null}
            </View>
          </View>
        ))}
      </Card>
    </Screen>
  );
}

const inputStyle = {
  minHeight: 64,
  borderRadius: 12,
  borderWidth: 1,
  borderColor: colors.border,
  backgroundColor: colors.bg,
  color: colors.text,
  fontSize: 15,
  paddingHorizontal: 12,
  paddingTop: 10,
  textAlignVertical: 'top' as const,
};
