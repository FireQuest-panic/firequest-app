import React, { useEffect, useState } from 'react';
import { BackHandler, KeyboardAvoidingView, Platform, Pressable, Text, View } from 'react-native';
import { colors } from '../theme';
import { ProfileBundle } from '../lib/types';
import { friendlyError, saveContacts, saveMedical, saveProfile, setCancelPin } from '../lib/data';
import { Body, Button, Chip, ErrorText, Field, Logo, Screen, Title } from '../components/ui';

const STEPS = ['Your details', 'Medical information', 'Emergency contacts', 'Vehicle', 'PIN & consent'];
const BLOOD_TYPES = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-', 'Unknown'];

type Props = {
  bundle: ProfileBundle;
  mode: 'onboard' | 'edit';
  onDone: () => void;
  onCancel?: () => void;
};

const s = (v: string | null | undefined) => v ?? '';
const orNull = (v: string) => (v.trim() ? v.trim() : null);

export function OnboardingScreen({ bundle, mode, onDone, onCancel }: Props) {
  const { profile, medical } = bundle;
  const userId = profile.id;
  const [step, setStep] = useState(0);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  // Step 1 – personal
  const [fullName, setFullName] = useState(s(profile.full_name));
  const [phone, setPhone] = useState(s(profile.phone));
  const [idNumber, setIdNumber] = useState(s(profile.id_number));
  const [dob, setDob] = useState(s(profile.date_of_birth));
  const [address, setAddress] = useState(s(profile.home_address));
  // Step 2 – medical
  const [bloodType, setBloodType] = useState(s(medical?.blood_type));
  const [allergies, setAllergies] = useState((medical?.allergies ?? []).join(', '));
  const [conditions, setConditions] = useState(s(medical?.conditions));
  const [medication, setMedication] = useState(s(medical?.medication));
  const [scheme, setScheme] = useState(s(medical?.medical_aid_scheme));
  const [plan, setPlan] = useState(s(medical?.medical_aid_plan));
  const [member, setMember] = useState(s(medical?.medical_aid_number));
  const [doctorName, setDoctorName] = useState(s(medical?.doctor_name));
  const [doctorPhone, setDoctorPhone] = useState(s(medical?.doctor_phone));
  // Step 3 – contacts (two slots)
  const initialContacts = [0, 1].map((i) => ({
    name: s(bundle.contacts[i]?.name),
    relationship: s(bundle.contacts[i]?.relationship),
    phone: s(bundle.contacts[i]?.phone),
  }));
  const [contacts, setContacts] = useState(initialContacts);
  // Step 4 – vehicle
  const [make, setMake] = useState(s(profile.vehicle_make));
  const [model, setModel] = useState(s(profile.vehicle_model));
  const [colour, setColour] = useState(s(profile.vehicle_colour));
  const [reg, setReg] = useState(s(profile.vehicle_registration));
  // Step 5 – PIN and consent
  const [pin, setPin] = useState('');
  const [pin2, setPin2] = useState('');
  const [consent, setConsent] = useState(Boolean(profile.consent_at));

  const pinRequired = mode === 'onboard' || !bundle.hasPin;

  const back = () => {
    setError('');
    if (step > 0) setStep(step - 1);
    else onCancel?.();
  };

  useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      if (step > 0 || onCancel) {
        back();
        return true;
      }
      return false;
    });
    return () => sub.remove();
  });

  const updateContact = (i: number, key: 'name' | 'relationship' | 'phone', value: string) => {
    setContacts((prev) => prev.map((c, idx) => (idx === i ? { ...c, [key]: value } : c)));
  };

  const saveStep = async (): Promise<boolean> => {
    setError('');
    if (step === 0) {
      if (!fullName.trim()) return fail('Enter your full name.');
      if (!phone.trim()) return fail('Enter your mobile number.');
      if (dob.trim() && !isValidDate(dob.trim())) return fail('Enter your date of birth as YYYY-MM-DD, e.g. 1985-03-21.');
      await saveProfile(userId, {
        full_name: fullName.trim(),
        phone: phone.trim(),
        id_number: orNull(idNumber),
        date_of_birth: orNull(dob),
        home_address: orNull(address),
      });
    } else if (step === 1) {
      await saveMedical(userId, {
        blood_type: orNull(bloodType),
        allergies: allergies.split(',').map((a) => a.trim()).filter(Boolean),
        conditions: orNull(conditions),
        medication: orNull(medication),
        medical_aid_scheme: orNull(scheme),
        medical_aid_plan: orNull(plan),
        medical_aid_number: orNull(member),
        doctor_name: orNull(doctorName),
        doctor_phone: orNull(doctorPhone),
      });
    } else if (step === 2) {
      const first = contacts[0];
      if (!first.name.trim() || !first.phone.trim()) return fail('Add at least one emergency contact with a name and phone number.');
      const second = contacts[1];
      if ((second.name.trim() && !second.phone.trim()) || (!second.name.trim() && second.phone.trim())) {
        return fail('The second contact needs both a name and a phone number (or leave both empty).');
      }
      await saveContacts(userId, contacts.map((c) => ({ ...c, relationship: c.relationship || null })));
    } else if (step === 3) {
      await saveProfile(userId, {
        vehicle_make: orNull(make),
        vehicle_model: orNull(model),
        vehicle_colour: orNull(colour),
        vehicle_registration: orNull(reg.toUpperCase()),
      });
    } else if (step === 4) {
      if (pinRequired || pin) {
        if (!/^[0-9]{4,6}$/.test(pin)) return fail('Your PIN must be 4 to 6 digits.');
        if (pin !== pin2) return fail('The two PINs do not match.');
      }
      if (!consent) return fail('Please tick the consent box so responders can receive your details.');
      if (pin) await setCancelPin(pin);
      const now = new Date().toISOString();
      await saveProfile(userId, {
        consent_at: profile.consent_at ?? now,
        onboarded_at: profile.onboarded_at ?? now,
      });
    }
    return true;
  };

  const fail = (msg: string) => {
    setError(msg);
    return false;
  };

  const next = async () => {
    setBusy(true);
    try {
      const ok = await saveStep();
      if (!ok) return;
      if (step < STEPS.length - 1) setStep(step + 1);
      else onDone();
    } catch (e) {
      setError(friendlyError(e));
    } finally {
      setBusy(false);
    }
  };

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <Screen>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
          <Text style={{ color: colors.muted, fontSize: 14, flex: 1 }}>
            Step {step + 1} of {STEPS.length}
          </Text>
          <Logo size={44} />
        </View>
        <View style={{ flexDirection: 'row', gap: 6 }}>
          {STEPS.map((_, i) => (
            <View
              key={i}
              style={{ flex: 1, height: 4, borderRadius: 2, backgroundColor: i <= step ? colors.gold : colors.border }}
            />
          ))}
        </View>
        <Title>{STEPS[step]}</Title>

        {step === 0 && (
          <>
            <Body>So FireQuest knows who you are and where home is.</Body>
            <Field label="Full name" value={fullName} onChangeText={setFullName} autoCapitalize="words" />
            <Field label="Mobile number" value={phone} onChangeText={setPhone} keyboardType="phone-pad" />
            <Field label="ID number (optional)" value={idNumber} onChangeText={setIdNumber} keyboardType="number-pad" maxLength={13} />
            <Field label="Date of birth (optional)" value={dob} onChangeText={setDob} placeholder="YYYY-MM-DD" keyboardType="numbers-and-punctuation" maxLength={10} />
            <Field label="Home address (optional)" value={address} onChangeText={setAddress} multiline />
          </>
        )}

        {step === 1 && (
          <>
            <Body>FireQuest responders see this the moment you raise a medical alert.</Body>
            <Text style={{ color: '#CFC9BD', fontSize: 13, fontWeight: '600' }}>Blood type</Text>
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }} accessibilityRole="radiogroup">
              {BLOOD_TYPES.map((b) => (
                <Chip key={b} label={b} selected={bloodType === b} onPress={() => setBloodType(bloodType === b ? '' : b)} />
              ))}
            </View>
            <Field label="Allergies (separate with commas)" value={allergies} onChangeText={setAllergies} placeholder="e.g. Penicillin, Peanuts" />
            <Field label="Chronic conditions" value={conditions} onChangeText={setConditions} placeholder="e.g. Type 1 diabetes" multiline />
            <Field label="Current medication" value={medication} onChangeText={setMedication} placeholder="e.g. Insulin" multiline />
            <Field label="Medical aid scheme" value={scheme} onChangeText={setScheme} placeholder="Leave empty if you have no medical aid" />
            <Field label="Medical aid plan" value={plan} onChangeText={setPlan} />
            <Field label="Membership number" value={member} onChangeText={setMember} autoCapitalize="characters" />
            <Field label="Doctor's name (optional)" value={doctorName} onChangeText={setDoctorName} autoCapitalize="words" />
            <Field label="Doctor's phone (optional)" value={doctorPhone} onChangeText={setDoctorPhone} keyboardType="phone-pad" />
          </>
        )}

        {step === 2 && (
          <>
            <Body>People FireQuest can contact when you raise an alert.</Body>
            {contacts.map((c, i) => (
              <View key={i} style={{ gap: 12, padding: 14, borderRadius: 16, borderWidth: 1, borderColor: colors.border }}>
                <Text style={{ color: colors.goldText, fontWeight: '700' }}>
                  Contact {i + 1}
                  {i === 1 ? ' (recommended)' : ''}
                </Text>
                <Field label="Name" value={c.name} onChangeText={(t) => updateContact(i, 'name', t)} autoCapitalize="words" />
                <Field label="Relationship" value={c.relationship} onChangeText={(t) => updateContact(i, 'relationship', t)} placeholder="e.g. Spouse, Parent" />
                <Field label="Phone" value={c.phone} onChangeText={(t) => updateContact(i, 'phone', t)} keyboardType="phone-pad" />
              </View>
            ))}
          </>
        )}

        {step === 3 && (
          <>
            <Body>Helps responders find you after a vehicle accident. You can skip this.</Body>
            <Field label="Make" value={make} onChangeText={setMake} autoCapitalize="words" placeholder="e.g. Toyota" />
            <Field label="Model" value={model} onChangeText={setModel} autoCapitalize="words" placeholder="e.g. Corolla" />
            <Field label="Colour" value={colour} onChangeText={setColour} autoCapitalize="words" />
            <Field label="Registration number" value={reg} onChangeText={setReg} autoCapitalize="characters" />
          </>
        )}

        {step === 4 && (
          <>
            <Body>
              {pinRequired
                ? 'Choose a 4 to 6 digit PIN. You need it to cancel an alert, so nobody else can cancel it for you.'
                : 'Leave the PIN empty to keep your current one.'}
            </Body>
            <Field label="Cancel PIN" value={pin} onChangeText={(t) => setPin(t.replace(/[^0-9]/g, ''))} keyboardType="number-pad" secureTextEntry maxLength={6} />
            <Field label="Repeat PIN" value={pin2} onChangeText={(t) => setPin2(t.replace(/[^0-9]/g, ''))} keyboardType="number-pad" secureTextEntry maxLength={6} />
            <Pressable
              accessibilityRole="checkbox"
              accessibilityState={{ checked: consent }}
              onPress={() => setConsent(!consent)}
              style={{ flexDirection: 'row', gap: 12, alignItems: 'flex-start', paddingVertical: 8 }}
            >
              <View
                style={{
                  width: 26,
                  height: 26,
                  borderRadius: 6,
                  borderWidth: 2,
                  borderColor: colors.gold,
                  backgroundColor: consent ? colors.gold : 'transparent',
                  alignItems: 'center',
                  justifyContent: 'center',
                  marginTop: 2,
                }}
              >
                {consent ? <Text style={{ color: colors.ink, fontWeight: '900' }}>✓</Text> : null}
              </View>
              <Text style={{ color: colors.text, fontSize: 14, lineHeight: 21, flex: 1 }}>
                I consent to FireQuest processing my personal and health information, and sharing it
                with FireQuest responders, ambulance services and the fire brigade when I raise an
                alert.
              </Text>
            </Pressable>
          </>
        )}

        <ErrorText>{error}</ErrorText>
        <View style={{ flexGrow: 1 }} />
        <Button
          title={step < STEPS.length - 1 ? 'Continue' : mode === 'onboard' ? 'Finish' : 'Save'}
          onPress={next}
          loading={busy}
        />
        {(step > 0 || onCancel) && <Button title={step > 0 ? 'Back' : 'Cancel'} variant="plain" onPress={back} />}
      </Screen>
    </KeyboardAvoidingView>
  );
}

function isValidDate(v: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(v)) return false;
  const d = new Date(`${v}T00:00:00Z`);
  return !Number.isNaN(d.getTime()) && d.toISOString().slice(0, 10) === v && d < new Date();
}
