-- =====================================================================
-- FireQuest Panic – database schema (Supabase / PostgreSQL)
--
-- Run this ONCE on a new, empty Supabase project:
--   Supabase dashboard → SQL Editor → New query → paste this file → Run
--
-- What it creates
--   * Client data: profiles, medical_profiles, emergency_contacts
--   * Control room: staff, alerts, alert_locations, alert_events
--   * Settings: app_settings (test mode is ON by default)
--   * Security: row-level security on every table, plus functions that
--     are the ONLY way to raise, update, cancel or handle an alert.
-- =====================================================================

create extension if not exists pgcrypto with schema extensions;

-- ---------------------------------------------------------------------
-- Types
-- ---------------------------------------------------------------------
create type public.alert_type as enum ('medical', 'vehicle', 'fire');
create type public.alert_status as enum (
  'new', 'acknowledged', 'dispatched', 'on_scene', 'closed', 'cancelled'
);

-- ---------------------------------------------------------------------
-- Settings (single row)
-- ---------------------------------------------------------------------
create table public.app_settings (
  id          int primary key default 1 check (id = 1),
  test_mode   boolean not null default true,
  control_room_phone text not null default '',
  updated_at  timestamptz not null default now()
);
insert into public.app_settings (id) values (1);

-- ---------------------------------------------------------------------
-- Client data
-- ---------------------------------------------------------------------
create table public.profiles (
  id                    uuid primary key references auth.users (id) on delete cascade,
  email                 text,
  full_name             text not null default '',
  phone                 text not null default '',
  id_number             text,
  date_of_birth         date,
  gender                text,
  home_address          text,
  vehicle_make          text,
  vehicle_model         text,
  vehicle_colour        text,
  vehicle_registration  text,
  consent_at            timestamptz,          -- POPIA consent to process & share health info
  onboarded_at          timestamptz,          -- set when registration is complete
  created_at            timestamptz not null default now(),
  updated_at            timestamptz not null default now()
);

create table public.medical_profiles (
  user_id             uuid primary key references public.profiles (id) on delete cascade,
  blood_type          text,
  allergies           text[] not null default '{}',
  conditions          text,
  medication          text,
  medical_aid_scheme  text,
  medical_aid_plan    text,
  medical_aid_number  text,
  doctor_name         text,
  doctor_phone        text,
  updated_at          timestamptz not null default now()
);

create table public.emergency_contacts (
  id            uuid primary key default gen_random_uuid(),
  user_id       uuid not null references public.profiles (id) on delete cascade,
  name          text not null,
  relationship  text,
  phone         text not null,
  created_at    timestamptz not null default now()
);
create index emergency_contacts_user_idx on public.emergency_contacts (user_id);

-- Cancel PINs live in a schema the public API cannot reach.
create schema if not exists private;
revoke all on schema private from public, anon, authenticated;

create table private.cancel_pins (
  user_id     uuid primary key references auth.users (id) on delete cascade,
  pin_hash    text not null,
  updated_at  timestamptz not null default now()
);

-- ---------------------------------------------------------------------
-- Control room
-- ---------------------------------------------------------------------
create table public.staff (
  user_id       uuid primary key references auth.users (id) on delete cascade,
  display_name  text not null,
  role          text not null default 'operator' check (role in ('operator', 'admin')),
  created_at    timestamptz not null default now()
);

create table public.alerts (
  id                   uuid primary key default gen_random_uuid(),
  user_id              uuid not null references public.profiles (id) on delete cascade,
  type                 public.alert_type not null,
  status               public.alert_status not null default 'new',
  is_test              boolean not null default true,
  lat                  double precision,
  lng                  double precision,
  accuracy_m           real,
  location_updated_at  timestamptz,
  operator_id          uuid references public.staff (user_id),
  outcome              text,
  created_at           timestamptz not null default now(),
  acknowledged_at      timestamptz,
  dispatched_at        timestamptz,
  on_scene_at          timestamptz,
  closed_at            timestamptz,
  cancelled_at         timestamptz
);
create index alerts_user_status_idx on public.alerts (user_id, status);
create index alerts_status_created_idx on public.alerts (status, created_at desc);

create table public.alert_locations (
  id           bigint generated always as identity primary key,
  alert_id     uuid not null references public.alerts (id) on delete cascade,
  lat          double precision not null,
  lng          double precision not null,
  accuracy_m   real,
  recorded_at  timestamptz not null default now()
);
create index alert_locations_alert_idx on public.alert_locations (alert_id, recorded_at desc);

create table public.alert_events (
  id          bigint generated always as identity primary key,
  alert_id    uuid not null references public.alerts (id) on delete cascade,
  actor_id    uuid,
  actor_kind  text not null check (actor_kind in ('client', 'operator', 'system')),
  event       text not null,
  note        text,
  created_at  timestamptz not null default now()
);
create index alert_events_alert_idx on public.alert_events (alert_id, created_at);

-- ---------------------------------------------------------------------
-- Helper functions
-- ---------------------------------------------------------------------
create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end $$;

create trigger profiles_updated_at before update on public.profiles
  for each row execute function public.set_updated_at();
create trigger medical_profiles_updated_at before update on public.medical_profiles
  for each row execute function public.set_updated_at();

create or replace function public.is_staff()
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.staff where user_id = auth.uid());
$$;

-- Staff may only see a client's personal and medical details while that
-- client has an open alert, or for 24 hours after an alert was raised.
create or replace function public.staff_can_view(p_user_id uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select public.is_staff() and exists (
    select 1 from public.alerts a
    where a.user_id = p_user_id
      and (a.status not in ('closed', 'cancelled') or a.created_at > now() - interval '24 hours')
  );
$$;

create or replace function public.owns_alert(p_alert_id uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.alerts where id = p_alert_id and user_id = auth.uid());
$$;

create or replace function public.status_rank(s public.alert_status)
returns int language sql immutable as $$
  select case s
    when 'new' then 0 when 'acknowledged' then 1 when 'dispatched' then 2
    when 'on_scene' then 3 else 4 end;
$$;

-- Create a profile row automatically when someone signs up.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, email, full_name, phone)
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data ->> 'full_name', ''),
    coalesce(new.raw_user_meta_data ->> 'phone', '')
  )
  on conflict (id) do nothing;
  return new;
end $$;

create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- ---------------------------------------------------------------------
-- Row-level security
-- ---------------------------------------------------------------------
alter table public.app_settings       enable row level security;
alter table public.profiles           enable row level security;
alter table public.medical_profiles   enable row level security;
alter table public.emergency_contacts enable row level security;
alter table public.staff              enable row level security;
alter table public.alerts             enable row level security;
alter table public.alert_locations    enable row level security;
alter table public.alert_events       enable row level security;

-- Settings: anyone signed in can read; changes only from the SQL editor.
create policy "settings readable" on public.app_settings
  for select to authenticated using (true);

-- Profiles
create policy "own profile read" on public.profiles
  for select to authenticated using (id = auth.uid() or public.staff_can_view(id));
create policy "own profile insert" on public.profiles
  for insert to authenticated with check (id = auth.uid());
create policy "own profile update" on public.profiles
  for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

-- Medical profile
create policy "own medical read" on public.medical_profiles
  for select to authenticated using (user_id = auth.uid() or public.staff_can_view(user_id));
create policy "own medical insert" on public.medical_profiles
  for insert to authenticated with check (user_id = auth.uid());
create policy "own medical update" on public.medical_profiles
  for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

-- Emergency contacts
create policy "own contacts read" on public.emergency_contacts
  for select to authenticated using (user_id = auth.uid() or public.staff_can_view(user_id));
create policy "own contacts insert" on public.emergency_contacts
  for insert to authenticated with check (user_id = auth.uid());
create policy "own contacts update" on public.emergency_contacts
  for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "own contacts delete" on public.emergency_contacts
  for delete to authenticated using (user_id = auth.uid());

-- Staff list: visible to staff (and each person can see their own row).
create policy "staff read" on public.staff
  for select to authenticated using (user_id = auth.uid() or public.is_staff());

-- Alerts: clients see their own, staff see all. No direct writes –
-- every change goes through the functions below.
create policy "alerts read" on public.alerts
  for select to authenticated using (user_id = auth.uid() or public.is_staff());
create policy "alert locations read" on public.alert_locations
  for select to authenticated using (public.owns_alert(alert_id) or public.is_staff());
create policy "alert events read" on public.alert_events
  for select to authenticated using (public.owns_alert(alert_id) or public.is_staff());

-- ---------------------------------------------------------------------
-- Client functions
-- ---------------------------------------------------------------------
create or replace function public.set_cancel_pin(p_pin text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'Not signed in'; end if;
  if p_pin !~ '^[0-9]{4,6}$' then raise exception 'PIN must be 4 to 6 digits'; end if;
  insert into private.cancel_pins (user_id, pin_hash, updated_at)
  values (auth.uid(), extensions.crypt(p_pin, extensions.gen_salt('bf')), now())
  on conflict (user_id) do update set pin_hash = excluded.pin_hash, updated_at = now();
end $$;

create or replace function public.has_cancel_pin()
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from private.cancel_pins where user_id = auth.uid());
$$;

-- Raise an alert. If the client already has an open alert, that alert is
-- returned instead of creating a duplicate.
create or replace function public.raise_alert(
  p_type public.alert_type,
  p_lat double precision default null,
  p_lng double precision default null,
  p_accuracy real default null
) returns public.alerts
language plpgsql security definer set search_path = public as $$
declare
  v_uid   uuid := auth.uid();
  v_alert public.alerts;
begin
  if v_uid is null then raise exception 'Not signed in'; end if;

  select * into v_alert from public.alerts
   where user_id = v_uid and status not in ('closed', 'cancelled')
   order by created_at desc limit 1;

  if found then
    insert into public.alert_events (alert_id, actor_id, actor_kind, event, note)
    values (v_alert.id, v_uid, 'client', 'pressed_again', p_type::text);
  else
    insert into public.alerts (user_id, type, is_test)
    values (v_uid, p_type, (select test_mode from public.app_settings where id = 1))
    returning * into v_alert;

    insert into public.alert_events (alert_id, actor_id, actor_kind, event, note)
    values (v_alert.id, v_uid, 'client', 'raised', p_type::text);
  end if;

  if p_lat is not null and p_lng is not null then
    update public.alerts
       set lat = p_lat, lng = p_lng, accuracy_m = p_accuracy, location_updated_at = now()
     where id = v_alert.id
     returning * into v_alert;
    insert into public.alert_locations (alert_id, lat, lng, accuracy_m)
    values (v_alert.id, p_lat, p_lng, p_accuracy);
  end if;

  return v_alert;
end $$;

create or replace function public.update_alert_location(
  p_alert_id uuid,
  p_lat double precision,
  p_lng double precision,
  p_accuracy real default null
) returns void
language plpgsql security definer set search_path = public as $$
begin
  update public.alerts
     set lat = p_lat, lng = p_lng, accuracy_m = p_accuracy, location_updated_at = now()
   where id = p_alert_id and user_id = auth.uid()
     and status not in ('closed', 'cancelled');
  if found then
    insert into public.alert_locations (alert_id, lat, lng, accuracy_m)
    values (p_alert_id, p_lat, p_lng, p_accuracy);
  end if;
end $$;

-- Cancel with the client's PIN. Returns true when cancelled.
create or replace function public.cancel_alert(p_alert_id uuid, p_pin text)
returns boolean
language plpgsql security definer set search_path = public as $$
declare
  v_uid  uuid := auth.uid();
  v_hash text;
begin
  if not exists (
    select 1 from public.alerts
     where id = p_alert_id and user_id = v_uid and status not in ('closed', 'cancelled')
  ) then
    return false;
  end if;

  select pin_hash into v_hash from private.cancel_pins where user_id = v_uid;

  if v_hash is not null and extensions.crypt(p_pin, v_hash) = v_hash then
    update public.alerts set status = 'cancelled', cancelled_at = now() where id = p_alert_id;
    insert into public.alert_events (alert_id, actor_id, actor_kind, event)
    values (p_alert_id, v_uid, 'client', 'cancelled_by_client');
    return true;
  end if;

  insert into public.alert_events (alert_id, actor_id, actor_kind, event)
  values (p_alert_id, v_uid, 'client', 'cancel_wrong_pin');
  return false;
end $$;

-- ---------------------------------------------------------------------
-- Control room function
-- Actions: acknowledge, dispatch, on_scene, close, note,
--          navigate_opened, route_sent, called_client
-- ---------------------------------------------------------------------
create or replace function public.operator_update_alert(
  p_alert_id uuid,
  p_action text,
  p_note text default null
) returns public.alerts
language plpgsql security definer set search_path = public as $$
declare
  v_uid   uuid := auth.uid();
  v_alert public.alerts;
  v_new   public.alert_status;
begin
  if not public.is_staff() then raise exception 'Not authorised'; end if;

  select * into v_alert from public.alerts where id = p_alert_id for update;
  if not found then raise exception 'Alert not found'; end if;

  if p_action in ('acknowledge', 'dispatch', 'on_scene', 'close') then
    if v_alert.status in ('closed', 'cancelled') then
      raise exception 'This alert is already %', v_alert.status;
    end if;

    v_new := case p_action
      when 'acknowledge' then 'acknowledged'
      when 'dispatch'    then 'dispatched'
      when 'on_scene'    then 'on_scene'
      else 'closed' end;

    update public.alerts set
      status          = case when public.status_rank(v_new) > public.status_rank(status) then v_new else status end,
      operator_id     = coalesce(operator_id, v_uid),
      acknowledged_at = coalesce(acknowledged_at, now()),
      dispatched_at   = case when p_action = 'dispatch' then coalesce(dispatched_at, now()) else dispatched_at end,
      on_scene_at     = case when p_action = 'on_scene' then coalesce(on_scene_at, now()) else on_scene_at end,
      closed_at       = case when p_action = 'close' then now() else closed_at end,
      outcome         = case when p_action = 'close' then p_note else outcome end
    where id = p_alert_id
    returning * into v_alert;
  elsif p_action not in ('note', 'navigate_opened', 'route_sent', 'called_client') then
    raise exception 'Unknown action %', p_action;
  end if;

  insert into public.alert_events (alert_id, actor_id, actor_kind, event, note)
  values (p_alert_id, v_uid, 'operator', p_action, p_note);

  return v_alert;
end $$;

-- Only signed-in users may call the functions.
revoke execute on function
  public.set_cancel_pin(text),
  public.has_cancel_pin(),
  public.raise_alert(public.alert_type, double precision, double precision, real),
  public.update_alert_location(uuid, double precision, double precision, real),
  public.cancel_alert(uuid, text),
  public.operator_update_alert(uuid, text, text)
from public, anon;

grant execute on function
  public.set_cancel_pin(text),
  public.has_cancel_pin(),
  public.raise_alert(public.alert_type, double precision, double precision, real),
  public.update_alert_location(uuid, double precision, double precision, real),
  public.cancel_alert(uuid, text),
  public.operator_update_alert(uuid, text, text)
to authenticated;

-- Helper functions: fixed search path, and not callable by anonymous visitors.
alter function public.set_updated_at() set search_path = public;
alter function public.status_rank(public.alert_status) set search_path = public;

revoke execute on function
  public.handle_new_user(),
  public.is_staff(),
  public.owns_alert(uuid),
  public.staff_can_view(uuid),
  public.status_rank(public.alert_status),
  public.set_updated_at()
from public, anon;

revoke execute on function public.handle_new_user() from authenticated;

grant execute on function
  public.is_staff(),
  public.owns_alert(uuid),
  public.staff_can_view(uuid),
  public.status_rank(public.alert_status)
to authenticated;

-- ---------------------------------------------------------------------
-- Table permissions (row-level security above decides WHICH rows)
-- ---------------------------------------------------------------------
revoke all on all tables in schema public from anon, authenticated;
grant usage on schema public to authenticated;
grant select on public.app_settings, public.staff, public.alerts,
                public.alert_locations, public.alert_events to authenticated;
grant select, insert, update on public.profiles, public.medical_profiles to authenticated;
grant select, insert, update, delete on public.emergency_contacts to authenticated;

-- ---------------------------------------------------------------------
-- Live updates for the monitor and the client's alert screen
-- ---------------------------------------------------------------------
alter publication supabase_realtime add table public.alerts, public.alert_events;
