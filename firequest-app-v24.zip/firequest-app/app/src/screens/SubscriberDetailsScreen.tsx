import React, { useEffect, useState } from 'react';
import { ActivityIndicator, BackHandler, Linking, Pressable, Text, View } from 'react-native';
import { colors } from '../theme';
import { supabase } from '../lib/supabase';
import { friendlyError, relationshipLabel } from '../lib/data';
import { longDate } from '../lib/billing';
import { hasAcceptedPrivacy } from '../lib/privacy';
import { openInGoogleMaps } from '../components/HomePinPicker';
import { Card, ErrorText, InfoRow, Screen, Title } from '../components/ui';
import type { Subscriber } from './SubscribersScreen';

interface Member {
  user_id: string;
  role: string;
  relationship: string | null;
  joined_at: string | null;
  full_name: string | null;
  email: string | null;
  phone: string | null;
  id_number: string | null;
  date_of_birth: string | null;
  gender: string | null;
  home_address: string | null;
  home_lat: number | null;
  home_lng: number | null;
  vehicle_make: string | null;
  vehicle_model: string | null;
  vehicle_colour: string | null;
  vehicle_registration: string | null;
  household_size: number | null;
  pets_inside: number | null;
  pets_dangerous: boolean | null;
  pets_notes: string | null;
  insurance_company: string | null;
  insurance_policy_number: string | null;
  insurance_phone: string | null;
  insurance_cover: string | null;
  consent_at: string | null;
  privacy_version: string | null;
  onboarded_at: string | null;
  emergency_contacts: { name: string; relationship: string | null; phone: string }[];
}

interface Details {
  id: string;
  state: string;
  invite_code: string;
  created_at: string;
  members: Member[];
}

const join = (...parts: (string | null | undefined)[]) => parts.filter((p) => p && p.trim()).join(' ');

/** FireQuest admins: everyone on one family plan, with their personal details (no health information). */
export function SubscriberDetailsScreen({ subscriber, onBack }: { subscriber: Subscriber; onBack: () => void }) {
  const [details, setDetails] = useState<Details | null>(null);
  const [error, setError] = useState('');

  useEffect(() => {
    supabase.rpc('subscriber_details', { p_subscription_id: subscriber.id }).then(({ data, error: e }) => {
      if (e) setError(friendlyError(e));
      else setDetails(data as Details);
    });
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      onBack();
      return true;
    });
    return () => sub.remove();
  }, [subscriber.id, onBack]);

  return (
    <Screen aboveTabBar>
      <Pressable accessibilityRole="button" onPress={onBack} style={{ paddingVertical: 6 }}>
        <Text style={{ color: colors.goldText, fontWeight: '700', fontSize: 15 }}>‹ Subscribers</Text>
      </Pressable>
      <Title>{subscriber.holder_name}</Title>
      <Text style={{ color: colors.muted, fontSize: 13 }}>
        Plan since {longDate(details?.created_at ?? null) || '…'}
        {details ? ` · invite code ${details.invite_code}` : ''}
      </Text>
      <ErrorText>{error}</ErrorText>
      {!details && !error ? <ActivityIndicator color={colors.gold} /> : null}
      {details?.members.map((m) => <MemberCard key={m.user_id} m={m} />)}
      <Text style={{ color: colors.faint, fontSize: 12, lineHeight: 17 }}>
        Health information is not shown here. Responders see it only during an alert, as the privacy policy promises.
        Each time you open these details it is recorded.
      </Text>
    </Screen>
  );
}

function MemberCard({ m }: { m: Member }) {
  const pin = m.home_lat != null && m.home_lng != null ? { lat: m.home_lat, lng: m.home_lng } : null;
  const pets =
    m.pets_inside == null
      ? null
      : m.pets_inside === 0
        ? 'None'
        : `${m.pets_inside}${m.pets_dangerous ? ' · DANGEROUS' : ''}${m.pets_notes ? ` · ${m.pets_notes}` : ''}`;
  const consent = m.consent_at
    ? `${hasAcceptedPrivacy(m) ? 'Privacy policy accepted' : 'Old consent only'} · ${longDate(m.consent_at)}`
    : 'Not given';

  return (
    <Card style={{ gap: 10 }}>
      <View style={{ gap: 2 }}>
        <Text style={{ color: colors.goldText, fontSize: 12, fontWeight: '800', letterSpacing: 1 }}>
          {relationshipLabel(m.relationship, m.role).toUpperCase()}
        </Text>
        <Text style={{ color: colors.text, fontSize: 18, fontWeight: '700' }}>{m.full_name || 'No name yet'}</Text>
      </View>

      {m.phone ? (
        <Pressable accessibilityRole="button" onPress={() => Linking.openURL(`tel:${m.phone}`).catch(() => undefined)}>
          <Text style={{ color: colors.goldText, fontWeight: '700', paddingVertical: 4 }}>Call {m.phone}</Text>
        </Pressable>
      ) : null}
      <InfoRow label="Email" value={m.email} />
      <InfoRow label="ID number" value={m.id_number} />
      <InfoRow label="Date of birth" value={longDate(m.date_of_birth)} />
      <InfoRow label="Gender" value={m.gender} />
      <InfoRow label="Home address" value={m.home_address} />
      {pin ? (
        <Pressable accessibilityRole="button" onPress={() => openInGoogleMaps(pin)}>
          <Text style={{ color: colors.goldText, fontWeight: '700', paddingVertical: 4 }}>Open home pin in Google Maps ›</Text>
        </Pressable>
      ) : null}
      <InfoRow label="People in the home" value={m.household_size != null ? String(m.household_size) : null} />
      <InfoRow label="Pets inside" value={pets} />
      <InfoRow label="Vehicle" value={join(m.vehicle_colour, m.vehicle_make, m.vehicle_model, m.vehicle_registration && `(${m.vehicle_registration})`)} />
      <InfoRow
        label="Insurance"
        value={join(m.insurance_company, m.insurance_cover && `· ${m.insurance_cover}`, m.insurance_policy_number && `· policy ${m.insurance_policy_number}`, m.insurance_phone && `· ${m.insurance_phone}`)}
      />
      <InfoRow
        label="Emergency contacts"
        value={m.emergency_contacts.map((c) => join(c.name, c.relationship && `(${c.relationship})`, c.phone)).join('\n')}
      />
      <InfoRow label="POPIA consent" value={consent} />
      <InfoRow label="Joined the plan" value={longDate(m.joined_at)} />
    </Card>
  );
}
