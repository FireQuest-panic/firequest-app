import React, { useState } from 'react';
import { KeyboardAvoidingView, Platform, View } from 'react-native';
import { supabase } from '../lib/supabase';
import { friendlyError } from '../lib/data';
import { familySignIn, familyUseCode } from '../lib/familyLogin';
import { Body, Button, ErrorText, Field, Logo, Screen, Title } from '../components/ui';

type Mode = 'welcome' | 'signin' | 'signup' | 'family' | 'familyCode';

export function AuthScreen() {
  const [mode, setMode] = useState<Mode>('welcome');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [code, setCode] = useState('');
  const [pin, setPin] = useState('');
  const [pin2, setPin2] = useState('');

  const go = (m: Mode) => {
    setMode(m);
    setError('');
    setNotice('');
  };

  const signIn = async () => {
    setError('');
    if (!email.trim() || !password) return setError('Enter your email and password.');
    setBusy(true);
    const { error: err } = await supabase.auth.signInWithPassword({
      email: email.trim().toLowerCase(),
      password,
    });
    setBusy(false);
    if (err) setError(friendlyError(err));
  };

  const familyGo = async () => {
    setError('');
    if (mode === 'familyCode' && pin !== pin2) return setError('The two PINs are not the same.');
    setBusy(true);
    const err = mode === 'family' ? await familySignIn(phone, pin) : await familyUseCode(phone, code, pin);
    setBusy(false);
    if (err) setError(err);
  };

  const signUp = async () => {
    setError('');
    if (!fullName.trim()) return setError('Enter your full name.');
    if (!phone.trim()) return setError('Enter your mobile number.');
    if (!email.trim()) return setError('Enter your email address.');
    if (password.length < 8) return setError('Choose a password of at least 8 characters.');
    setBusy(true);
    const { data, error: err } = await supabase.auth.signUp({
      email: email.trim().toLowerCase(),
      password,
      options: { data: { full_name: fullName.trim(), phone: phone.trim() } },
    });
    setBusy(false);
    if (err) return setError(friendlyError(err));
    if (!data.session) {
      setNotice('Account created. Check your email for a confirmation link, then sign in here.');
      setMode('signin');
    }
  };

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <Screen style={{ justifyContent: mode === 'welcome' ? 'space-between' : 'flex-start' }}>
        {mode === 'welcome' ? (
          <>
            <View style={{ alignItems: 'center', gap: 24, paddingTop: 48 }}>
              <Logo size={220} />
              <View style={{ gap: 10, alignItems: 'center' }}>
                <Title>Help at the press of a button</Title>
                <Body center>
                  24/7 response to fire, medical emergencies and vehicle accidents by the FireQuest
                  team.
                </Body>
              </View>
            </View>
            <View style={{ gap: 12, paddingBottom: 8 }}>
              <Button title="Create account" onPress={() => go('signup')} />
              <Button title="I'm a FireQuest client – sign in" variant="outline" onPress={() => go('signin')} />
              <Button title="I'm a family member" variant="outline" onPress={() => go('family')} />
            </View>
          </>
        ) : mode === 'family' || mode === 'familyCode' ? (
          <>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12, paddingTop: 8 }}>
              <Logo size={56} />
              <Title>{mode === 'family' ? 'Family member' : 'Use your code'}</Title>
            </View>
            <Body>
              {mode === 'family'
                ? 'Sign in with your cellphone number and your 6-digit PIN.'
                : 'Enter the code the plan holder sent you and choose a 6-digit PIN. You will use your cellphone number and this PIN to sign in.'}
            </Body>
            <Field label="Cellphone number" value={phone} onChangeText={setPhone} keyboardType="phone-pad" placeholder="e.g. 082 123 4567" autoComplete="tel" />
            {mode === 'familyCode' && (
              <Field label="Code from the plan holder" value={code} onChangeText={(v) => setCode(v.toUpperCase())} autoCapitalize="characters" maxLength={8} placeholder="e.g. K7M2QX" />
            )}
            <Field
              label={mode === 'family' ? 'PIN' : 'Choose a 6-digit PIN'}
              value={pin}
              onChangeText={(v) => setPin(v.replace(/\D/g, ''))}
              keyboardType="number-pad"
              secureTextEntry
              maxLength={6}
            />
            {mode === 'familyCode' && (
              <Field label="Type the PIN again" value={pin2} onChangeText={(v) => setPin2(v.replace(/\D/g, ''))} keyboardType="number-pad" secureTextEntry maxLength={6} />
            )}
            <ErrorText>{error}</ErrorText>
            <Button title={mode === 'family' ? 'Sign in' : 'Continue'} onPress={familyGo} loading={busy} />
            <Button
              title={mode === 'family' ? 'First time, or got a new code? Tap here' : 'I already have a PIN – sign in'}
              variant="plain"
              onPress={() => go(mode === 'family' ? 'familyCode' : 'family')}
            />
            {mode === 'family' && <Body>Forgot your PIN? Ask the plan holder to tap "New sign-in code" next to your name.</Body>}
            <Button title="Back" variant="plain" onPress={() => go('welcome')} />
          </>
        ) : (
          <>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12, paddingTop: 8 }}>
              <Logo size={56} />
              <Title>{mode === 'signin' ? 'Sign in' : 'Create account'}</Title>
            </View>
            {notice ? <Body>{notice}</Body> : null}
            {mode === 'signup' && (
              <>
                <Field label="Full name" value={fullName} onChangeText={setFullName} autoCapitalize="words" autoComplete="name" />
                <Field label="Mobile number" value={phone} onChangeText={setPhone} keyboardType="phone-pad" placeholder="e.g. 082 123 4567" autoComplete="tel" />
              </>
            )}
            <Field label="Email" value={email} onChangeText={setEmail} keyboardType="email-address" autoCapitalize="none" autoComplete="email" />
            <Field label="Password" value={password} onChangeText={setPassword} secureTextEntry autoCapitalize="none" autoComplete={mode === 'signin' ? 'password' : 'new-password'} />
            <ErrorText>{error}</ErrorText>
            <Button
              title={mode === 'signin' ? 'Sign in' : 'Create account'}
              onPress={mode === 'signin' ? signIn : signUp}
              loading={busy}
            />
            <Button
              title={mode === 'signin' ? 'New to FireQuest? Create an account' : 'Already have an account? Sign in'}
              variant="plain"
              onPress={() => go(mode === 'signin' ? 'signup' : 'signin')}
            />
            <Button title="Back" variant="plain" onPress={() => go('welcome')} />
          </>
        )}
      </Screen>
    </KeyboardAvoidingView>
  );
}
