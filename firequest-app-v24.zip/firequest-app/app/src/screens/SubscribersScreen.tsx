import React, { useCallback, useEffect, useState } from 'react';
import { ActivityIndicator, BackHandler, Linking, Pressable, Text, View } from 'react-native';
import { colors } from '../theme';
import { supabase } from '../lib/supabase';
import { friendlyError } from '../lib/data';
import { longDate } from '../lib/billing';
import { Button, Card, Chip, ErrorText, Screen, Title } from '../components/ui';
import { SubscriberDetailsScreen } from './SubscriberDetailsScreen';

export interface Subscriber {
  id: string;
  holder_name: string;
  holder_phone: string | null;
  holder_email: string | null;
  members: number;
  state: string;
  label: string;
  paid_until: string | null;
  next_billing_date: string | null;
  monthly_amount: number | null;
  last_payment_at: string | null;
  last_payment_amount: number | null;
  payment_failed_at: string | null;
  cancelled_at: string | null;
  card_expiry: string | null;
  payfast_mode: string;
}

type Filter = 'all' | 'paid' | 'problem' | 'unpaid';

/** Groups the billing states into what the control room cares about. */
export function groupOf(state: string): Exclude<Filter, 'all'> | 'other' {
  if (state === 'active' || state === 'cancelled_paid') return 'paid';
  if (state === 'payment_failed' || state === 'overdue') return 'problem';
  if (state === 'unpaid' || state === 'lapsed' || state === 'cancelled') return 'unpaid';
  return 'other';
}

const STATE_TEXT: Record<string, string> = {
  active: 'PAID',
  cancelled_paid: 'PAID · CANCELLED',
  payment_failed: 'PAYMENT FAILED',
  overdue: 'PAYMENT LATE',
  lapsed: 'NOT PAID',
  unpaid: 'NEVER PAID',
  cancelled: 'CANCELLED',
  test: 'TEST PLAN',
};

const GROUP_COLORS = {
  paid: { fg: colors.green, bg: colors.greenDeep },
  problem: { fg: colors.goldText, bg: colors.goldDeep },
  unpaid: { fg: colors.redText, bg: colors.redDeep },
  other: { fg: colors.muted, bg: colors.surfaceRaised },
};

const rand = (n: number | null | undefined) => (n == null ? '' : `R${Number(n).toFixed(2)}`);

/** FireQuest admins: every family plan with its payment status. */
export function SubscribersScreen({ onBack }: { onBack: () => void }) {
  const [rows, setRows] = useState<Subscriber[] | null>(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [filter, setFilter] = useState<Filter>('all');
  const [open, setOpen] = useState<Subscriber | null>(null);
  const closeDetails = useCallback(() => setOpen(null), []);

  const load = useCallback(async () => {
    setBusy(true);
    setError('');
    const { data, error: e } = await supabase.rpc('subscribers_list');
    if (e) setError(friendlyError(e));
    else setRows((data as Subscriber[]) ?? []);
    setBusy(false);
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  useEffect(() => {
    if (open) return;
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      onBack();
      return true;
    });
    return () => sub.remove();
  }, [onBack, open]);

  const all = rows ?? [];
  const count = (g: Filter) => (g === 'all' ? all.length : all.filter((r) => groupOf(r.state) === g).length);
  const shown = filter === 'all' ? all : all.filter((r) => groupOf(r.state) === filter);

  if (open) return <SubscriberDetailsScreen subscriber={open} onBack={closeDetails} />;

  return (
    <Screen aboveTabBar>
      <Pressable accessibilityRole="button" onPress={onBack} style={{ paddingVertical: 6 }}>
        <Text style={{ color: colors.goldText, fontWeight: '700', fontSize: 15 }}>‹ Control room</Text>
      </Pressable>
      <Title>Subscribers</Title>

      <View style={{ flexDirection: 'row', gap: 8 }}>
        <Stat label="Paid" value={count('paid')} color={GROUP_COLORS.paid.fg} />
        <Stat label="Failed / late" value={count('problem')} color={GROUP_COLORS.problem.fg} />
        <Stat label="Not paid" value={count('unpaid')} color={GROUP_COLORS.unpaid.fg} />
      </View>

      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
        <Chip label={`All (${count('all')})`} selected={filter === 'all'} onPress={() => setFilter('all')} />
        <Chip label="Paid" selected={filter === 'paid'} onPress={() => setFilter('paid')} />
        <Chip label="Failed / late" selected={filter === 'problem'} onPress={() => setFilter('problem')} />
        <Chip label="Not paid" selected={filter === 'unpaid'} onPress={() => setFilter('unpaid')} />
      </View>

      <ErrorText>{error}</ErrorText>
      {rows === null && !error ? <ActivityIndicator color={colors.gold} /> : null}
      {rows !== null && shown.length === 0 ? (
        <Text style={{ color: colors.muted }}>No subscribers in this list.</Text>
      ) : null}
      {shown.map((r) => (
        <SubscriberRow key={r.id} row={r} onOpen={() => setOpen(r)} />
      ))}

      <Button title="Refresh" variant="outline" onPress={load} loading={busy} />
    </Screen>
  );
}

function Stat({ label, value, color }: { label: string; value: number; color: string }) {
  return (
    <Card style={{ flex: 1, alignItems: 'center', paddingVertical: 12, gap: 2 }}>
      <Text style={{ color, fontSize: 26, fontWeight: '900' }}>{value}</Text>
      <Text style={{ color: colors.muted, fontSize: 12, textAlign: 'center' }}>{label}</Text>
    </Card>
  );
}

function SubscriberRow({ row, onOpen }: { row: Subscriber; onOpen: () => void }) {
  const g = GROUP_COLORS[groupOf(row.state)];
  const lines: string[] = [];
  if (row.payment_failed_at) lines.push(`Payment failed on ${longDate(row.payment_failed_at)}`);
  if (row.last_payment_at) lines.push(`Last paid ${rand(row.last_payment_amount)} on ${longDate(row.last_payment_at)}`);
  else lines.push('No payment received yet');
  if (row.paid_until) lines.push(`Paid until ${longDate(row.paid_until)}`);
  if (row.next_billing_date && row.state !== 'cancelled' && row.state !== 'cancelled_paid')
    lines.push(`Next debit order ${longDate(row.next_billing_date)}${row.monthly_amount ? ` · ${rand(row.monthly_amount)}` : ''}`);
  if (row.cancelled_at) lines.push(`Cancelled on ${longDate(row.cancelled_at)}`);
  if (row.card_expiry) lines.push(`Card expires ${longDate(row.card_expiry).replace(/^\d+ /, '')}`);

  return (
    <Card style={{ gap: 6 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
        <Text style={{ color: colors.text, fontSize: 17, fontWeight: '700', flex: 1 }}>{row.holder_name}</Text>
        <View style={{ backgroundColor: g.bg, borderRadius: 8, paddingHorizontal: 8, paddingVertical: 4 }}>
          <Text style={{ color: g.fg, fontSize: 11, fontWeight: '800', letterSpacing: 0.5 }}>
            {STATE_TEXT[row.state] ?? row.label}
          </Text>
        </View>
      </View>
      <Text style={{ color: colors.muted, fontSize: 13 }}>
        {row.members} {row.members === 1 ? 'person' : 'people'} on the plan
        {row.payfast_mode === 'sandbox' ? ' · sandbox payments' : ''}
      </Text>
      {lines.map((l) => (
        <Text key={l} style={{ color: colors.text, fontSize: 14 }}>
          {l}
        </Text>
      ))}
      <Button title="View personal details" variant="outline" onPress={onOpen} />
      {row.holder_phone ? (
        <Pressable
          accessibilityRole="button"
          onPress={() => Linking.openURL(`tel:${row.holder_phone}`).catch(() => undefined)}
          style={{ paddingVertical: 6 }}
        >
          <Text style={{ color: colors.goldText, fontWeight: '700' }}>Call {row.holder_phone}</Text>
        </Pressable>
      ) : null}
    </Card>
  );
}
