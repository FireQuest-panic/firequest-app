import React from 'react';
import { Pressable, Text, View } from 'react-native';
import { DateTimePickerAndroid } from '@react-native-community/datetimepicker';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { colors } from '../theme';

const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

const toIso = (d: Date) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;

function fromIso(iso: string): Date | null {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso.trim());
  if (!m) return null;
  const d = new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]));
  return isNaN(d.getTime()) ? null : d;
}

/** "21 March 1985" for a YYYY-MM-DD value. */
export function displayDate(iso: string): string {
  const d = fromIso(iso);
  return d ? `${d.getDate()} ${MONTHS[d.getMonth()]} ${d.getFullYear()}` : iso;
}

/** A date box that opens the phone's calendar. The value is stored as YYYY-MM-DD. */
export function DateField({
  label,
  value,
  onChange,
  placeholder = 'Tap to choose a date',
  minimumDate,
  maximumDate,
  startDate,
}: {
  label: string;
  value: string;
  onChange: (iso: string) => void;
  placeholder?: string;
  minimumDate?: Date;
  maximumDate?: Date;
  /** Where the calendar opens when there is no value yet. */
  startDate?: Date;
}) {
  const open = () => {
    DateTimePickerAndroid.open({
      value: fromIso(value) ?? startDate ?? new Date(),
      mode: 'date',
      minimumDate,
      maximumDate,
      onChange: (event, date) => {
        if (event.type === 'set' && date) onChange(toIso(date));
      },
    });
  };

  return (
    <View style={{ gap: 6 }}>
      <Text style={{ color: '#CFC9BD', fontSize: 13, fontWeight: '600' }}>{label}</Text>
      <Pressable
        accessibilityRole="button"
        accessibilityLabel={`${label}: ${value ? displayDate(value) : 'not chosen'}. Opens a calendar.`}
        onPress={open}
        style={{
          minHeight: 48,
          borderRadius: 12,
          borderWidth: 1,
          borderColor: colors.border,
          backgroundColor: colors.surface,
          paddingHorizontal: 14,
          flexDirection: 'row',
          alignItems: 'center',
          gap: 10,
        }}
      >
        <MaterialCommunityIcons name="calendar-month" size={20} color={colors.goldText} />
        <Text style={{ color: value ? colors.text : colors.faint, fontSize: 16, flex: 1 }}>
          {value ? displayDate(value) : placeholder}
        </Text>
      </Pressable>
    </View>
  );
}
