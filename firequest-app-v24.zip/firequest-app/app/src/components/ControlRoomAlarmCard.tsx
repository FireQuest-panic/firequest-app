import React, { useCallback, useEffect, useState } from 'react';
import { ActivityIndicator, Alert, AppState, Switch, Text, View } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { colors } from '../theme';
import { friendlyError } from '../lib/data';
import { openBatterySettings } from '../lib/crash';
import {
  ControlRoomAlarmStatus,
  Listener,
  alarmStatus,
  controlRoomAlarmSupported,
  listeners,
  openFullScreenSettings,
  switchOffAlarm,
  switchOnAlarm,
} from '../lib/controlRoomAlarm';
import { Card, ErrorText } from './ui';

function ago(iso: string | null): string {
  if (!iso) return 'never';
  const s = Math.round((Date.now() - Date.parse(iso)) / 1000);
  if (s < 90) return `${Math.max(s, 0)} s ago`;
  if (s < 5400) return `${Math.round(s / 60)} min ago`;
  return `${Math.round(s / 3600)} h ago`;
}

/** Control room tab: ring on this phone for new alerts, also when FireQuest is closed. */
export function ControlRoomAlarmCard({ userId }: { userId: string }) {
  const [status, setStatus] = useState<ControlRoomAlarmStatus | null>(alarmStatus());
  const [phones, setPhones] = useState<Listener[] | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const refresh = useCallback(() => {
    setStatus(alarmStatus());
    listeners().then(setPhones);
  }, []);

  useEffect(() => {
    refresh();
    const t = setInterval(refresh, 15000);
    const sub = AppState.addEventListener('change', (s) => s === 'active' && refresh());
    return () => {
      clearInterval(t);
      sub.remove();
    };
  }, [refresh]);

  if (!controlRoomAlarmSupported) return null;
  const on = Boolean(status?.enabled && status.userId === userId);
  // A phone counts as listening when it checked in during the last 2 minutes.
  const live = (phones ?? []).filter((p) => p.last_seen_at && Date.now() - Date.parse(p.last_seen_at) < 120000);

  const turnOn = async () => {
    setError('');
    setBusy(true);
    try {
      const r = await switchOnAlarm(userId);
      if (!r.ok && r.message) setError(r.message);
    } catch (e) {
      setError(friendlyError(e));
    } finally {
      setBusy(false);
      setTimeout(refresh, 1500);
    }
  };

  const turnOff = () =>
    Alert.alert('Switch off?', 'This phone will no longer ring for new alerts when FireQuest is closed.', [
      { text: 'Keep on', style: 'cancel' },
      {
        text: 'Switch off',
        style: 'destructive',
        onPress: async () => {
          setBusy(true);
          await switchOffAlarm();
          setBusy(false);
          refresh();
        },
      },
    ]);

  // Problems that would stop the alarm working: shown only when there is one.
  const problems: { text: string; action?: { title: string; onPress: () => void } }[] = [];
  if (on && status?.lastError) problems.push({ text: status.lastError });
  if (on && status && !status.batteryUnrestricted)
    problems.push({ text: 'Battery saving may stop the alarm.', action: { title: 'Fix battery setting', onPress: () => openBatterySettings() } });
  if (on && status && status.fullScreenAllowed === false)
    problems.push({ text: 'The alarm page cannot light up the screen.', action: { title: 'Allow full screen', onPress: () => openFullScreenSettings() } });
  if (on && status && !status.notificationsEnabled) problems.push({ text: 'Notifications are off for FireQuest. Switch them on in Settings.' });
  if (phones && live.length === 0 && !(on && !status?.running))
    problems.push({ text: 'No control-room phone is listening right now.' });

  return (
    <Card style={[{ paddingVertical: 12, gap: 8 }, problems.length ? { borderColor: '#7A2A2E' } : null]}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
        <MaterialCommunityIcons name={on ? 'bell-ring' : 'bell-off'} size={22} color={on ? colors.goldText : colors.danger} />
        <View style={{ flex: 1 }}>
          <Text style={{ color: colors.text, fontWeight: '700', fontSize: 15 }}>Alarm when app is closed</Text>
          <Text style={{ color: colors.muted, fontSize: 12 }}>
            {on ? (status?.running ? `On · checked ${status.lastPollAt ? ago(new Date(status.lastPollAt).toISOString()) : '…'}` : 'Starting…') : 'Off on this phone'}
          </Text>
        </View>
        {busy ? (
          <ActivityIndicator color={colors.gold} />
        ) : (
          <Switch
            accessibilityLabel="Alarm when app is closed"
            value={on}
            onValueChange={(v) => (v ? turnOn() : turnOff())}
            trackColor={{ false: colors.borderStrong, true: colors.gold }}
            thumbColor={on ? colors.goldText : colors.muted}
          />
        )}
      </View>
      {problems.map((p) => (
        <View key={p.text} style={{ gap: 2 }}>
          <Text style={{ color: colors.danger, fontSize: 13, lineHeight: 18 }}>{p.text}</Text>
          {p.action ? (
            <Text accessibilityRole="button" onPress={p.action.onPress} style={{ color: colors.goldText, fontWeight: '700', fontSize: 13, paddingVertical: 4 }}>
              {p.action.title} ›
            </Text>
          ) : null}
        </View>
      ))}
      <ErrorText>{error}</ErrorText>
    </Card>
  );
}
