import type { Medication, MedicalProfile } from './types';

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

/** Today as YYYY-MM-DD in the phone's own time zone. */
export function todayIso(now = new Date()): string {
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
}

/** Chronic medication, and short courses whose last day has not passed. */
export function activeMedications(list: Medication[] | null | undefined, now = new Date()): Medication[] {
  const today = todayIso(now);
  return (list ?? []).filter((m) => m.name?.trim() && (m.chronic || !m.until || m.until >= today));
}

/** "Insulin (Sarah, chronic)" or "Amoxicillin (Jan, until 20 Nov)". */
export function medicationLabel(m: Medication): string {
  const parts = [m.who?.trim(), m.chronic ? 'chronic' : m.until ? `until ${shortDate(m.until)}` : ''].filter(Boolean);
  return parts.length ? `${m.name.trim()} (${parts.join(', ')})` : m.name.trim();
}

/** What responders see. Falls back to the old free-text field for profiles not yet updated. */
export function medicationText(medical: Pick<MedicalProfile, 'medication' | 'medications'> | null | undefined): string | null {
  if (!medical) return null;
  if (medical.medications && medical.medications.length) {
    const active = activeMedications(medical.medications);
    return active.length ? active.map(medicationLabel).join(', ') : null;
  }
  return medical.medication?.trim() || null;
}

function shortDate(iso: string): string {
  const [, m, d] = iso.split('-').map((x) => parseInt(x, 10));
  return m && d ? `${d} ${MONTHS[m - 1]}` : iso;
}
