/** South African ID number helpers (format YYMMDD SSSS C A Z, last digit a Luhn check digit). */

/** Date of birth (YYYY-MM-DD) from the first 6 digits, or null if they are not a real date. */
export function dobFromSaId(id: string, today = new Date()): string | null {
  const digits = id.replace(/\D/g, '');
  if (digits.length < 6) return null;
  const yy = parseInt(digits.slice(0, 2), 10);
  const mm = parseInt(digits.slice(2, 4), 10);
  const dd = parseInt(digits.slice(4, 6), 10);
  const thisYY = today.getFullYear() % 100;
  const year = yy > thisYY ? 1900 + yy : 2000 + yy;
  const d = new Date(Date.UTC(year, mm - 1, dd));
  if (d.getUTCFullYear() !== year || d.getUTCMonth() !== mm - 1 || d.getUTCDate() !== dd) return null;
  if (d.getTime() > today.getTime()) return null;
  return `${year}-${String(mm).padStart(2, '0')}-${String(dd).padStart(2, '0')}`;
}

/** Luhn check used by South African ID numbers. */
function luhnOk(digits: string): boolean {
  let sum = 0;
  for (let i = 0; i < digits.length; i++) {
    let n = parseInt(digits[digits.length - 1 - i], 10);
    if (i % 2 === 1) {
      n *= 2;
      if (n > 9) n -= 9;
    }
    sum += n;
  }
  return sum % 10 === 0;
}

/** Error message for an ID number, or null when it is a valid South African ID number. */
export function saIdError(id: string): string | null {
  const digits = id.replace(/\s/g, '');
  if (!digits) return 'Enter your ID number.';
  if (!/^\d{13}$/.test(digits)) return 'Your ID number must be 13 digits.';
  if (!dobFromSaId(digits)) return 'Check your ID number: the first 6 digits must be your date of birth (YYMMDD).';
  if (!['0', '1'].includes(digits[10])) return 'Check your ID number: one of the digits is wrong.';
  if (!luhnOk(digits)) return 'Check your ID number: one of the digits is wrong.';
  return null;
}

/** "Penicillin (Sarah)" ⇄ { what, who } – how allergies are stored in the medical profile. */
export function splitAllergy(entry: string): { what: string; who: string } {
  const m = entry.match(/^(.*?)\s*\(([^()]+)\)\s*$/);
  return m ? { what: m[1].trim(), who: m[2].trim() } : { what: entry.trim(), who: '' };
}

export function joinAllergy(what: string, who: string): string {
  return who.trim() ? `${what.trim()} (${who.trim()})` : what.trim();
}
