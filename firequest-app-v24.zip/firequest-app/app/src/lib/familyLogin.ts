import { supabase } from './supabase';

/**
 * Family members sign in with their cellphone number and a 6-digit PIN.
 * Behind the scenes the login is f<last 9 digits>@family.firequest.co.za – never shown or emailed.
 */
export function phoneKey(phone: string): string | null {
  const d = phone.replace(/\D/g, '');
  return d.length >= 9 ? d.slice(-9) : null;
}

export function familyLoginEmail(phone: string): string | null {
  const k = phoneKey(phone);
  return k ? `f${k}@family.firequest.co.za` : null;
}

export function isFamilyLogin(email: string | null | undefined): boolean {
  return Boolean(email && /@family\.firequest\.co\.za$/i.test(email));
}

export function pinProblem(pin: string): string | null {
  if (!/^\d{6}$/.test(pin)) return 'Your PIN must be exactly 6 digits.';
  if (/^(\d)\1{5}$/.test(pin) || pin === '123456' || pin === '654321') return 'That PIN is too easy to guess. Choose another one.';
  return null;
}

/** Sign in with cellphone number + PIN. Returns an error message, or null on success. */
export async function familySignIn(phone: string, pin: string): Promise<string | null> {
  const email = familyLoginEmail(phone);
  if (!email) return 'Enter your cellphone number, for example 082 123 4567.';
  if (!/^\d{6}$/.test(pin)) return 'Enter your 6-digit PIN.';
  const { error } = await supabase.auth.signInWithPassword({ email, password: pin });
  if (!error) return null;
  return /invalid/i.test(error.message)
    ? 'The cellphone number or PIN is wrong. Forgot your PIN? Ask the plan holder for a new sign-in code.'
    : 'Could not sign in. Check your internet connection and try again.';
}

/** First time (or new PIN): cellphone number + code from the plan holder + chosen PIN. */
export async function familyUseCode(phone: string, code: string, pin: string): Promise<string | null> {
  if (!phoneKey(phone)) return 'Enter your cellphone number, for example 082 123 4567.';
  if (code.replace(/\s/g, '').length < 6) return 'Enter the 6-character code you received.';
  const p = pinProblem(pin);
  if (p) return p;
  const { data, error } = await supabase.functions.invoke('family-signup', { body: { phone, code, pin } });
  if (error) {
    // The function answers 400 with { error } – read the message from the response.
    let msg = '';
    try {
      const ctx = (error as { context?: Response }).context;
      if (ctx && typeof ctx.json === 'function') msg = (await ctx.json())?.error ?? '';
    } catch {
      /* ignore */
    }
    return msg || 'Could not check the code. Check your internet connection and try again.';
  }
  if (!data?.ok) return data?.error ?? 'Could not check the code. Please try again.';
  return familySignIn(phone, pin);
}
