-- v16: control room "Subscribers" page – personal details of one family plan (FireQuest admins only).
-- Health information is NOT included: under the privacy policy only responders see it during an alert.
-- Every time an admin opens a plan's details, it is recorded.
create table if not exists private.admin_detail_views (
  id              bigint generated always as identity primary key,
  viewed_at       timestamptz not null default now(),
  admin_id        uuid not null,
  subscription_id uuid not null
);

create or replace function public.subscriber_details(p_subscription_id uuid)
returns json language plpgsql security definer set search_path = public as $$
declare
  v_sub public.subscriptions;
begin
  if not exists (select 1 from public.staff where user_id = auth.uid() and role = 'admin') then
    raise exception 'Not authorised';
  end if;
  select * into v_sub from public.subscriptions where id = p_subscription_id;
  if v_sub.id is null then raise exception 'Subscriber not found'; end if;

  insert into private.admin_detail_views (admin_id, subscription_id) values (auth.uid(), v_sub.id);

  return json_build_object(
    'id', v_sub.id,
    'state', private.billing_state(v_sub),
    'invite_code', v_sub.invite_code,
    'created_at', v_sub.created_at,
    'members', (
      select coalesce(json_agg(json_build_object(
               'user_id', p.id,
               'role', m.role,
               'relationship', m.relationship,
               'joined_at', m.joined_at,
               'full_name', p.full_name,
               'email', p.email,
               'phone', p.phone,
               'id_number', p.id_number,
               'date_of_birth', p.date_of_birth,
               'gender', p.gender,
               'home_address', p.home_address,
               'home_lat', p.home_lat,
               'home_lng', p.home_lng,
               'vehicle_make', p.vehicle_make,
               'vehicle_model', p.vehicle_model,
               'vehicle_colour', p.vehicle_colour,
               'vehicle_registration', p.vehicle_registration,
               'household_size', p.household_size,
               'pets_inside', p.pets_inside,
               'pets_dangerous', p.pets_dangerous,
               'pets_notes', p.pets_notes,
               'insurance_company', p.insurance_company,
               'insurance_policy_number', p.insurance_policy_number,
               'insurance_phone', p.insurance_phone,
               'insurance_cover', p.insurance_cover,
               'consent_at', p.consent_at,
               'privacy_version', p.privacy_version,
               'onboarded_at', p.onboarded_at,
               'emergency_contacts', (
                 select coalesce(json_agg(json_build_object('name', c.name, 'relationship', c.relationship, 'phone', c.phone)
                                          order by c.created_at), '[]'::json)
                   from public.emergency_contacts c where c.user_id = p.id))
             order by m.role desc, m.joined_at), '[]'::json)
        from public.subscription_members m
        join public.profiles p on p.id = m.user_id
       where m.subscription_id = v_sub.id));
end $$;

revoke all on function public.subscriber_details(uuid) from public, anon;
grant execute on function public.subscriber_details(uuid) to authenticated;
