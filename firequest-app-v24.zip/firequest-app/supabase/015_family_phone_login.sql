-- =====================================================================
-- v23: family members sign in with their cellphone number and a PIN.
-- * The plan holder adds a family member (name, cellphone, relationship) and
--   gets a one-time code, as before.
-- * The family member opens the app, taps "I'm a family member", and enters
--   their cellphone number, the code and a 6-digit PIN. No email needed.
-- * Behind the scenes their login is f<last 9 digits>@family.firequest.co.za
--   (never shown, never emailed). The "family-signup" edge function creates it.
-- * Forgotten PIN: the holder taps "New sign-in code" for that person.
-- =====================================================================

create table if not exists private.family_pin_codes (
  user_id    uuid primary key references auth.users (id) on delete cascade,
  code       text not null unique,
  created_at timestamptz not null default now(),
  expires_at timestamptz not null default now() + interval '7 days'
);

create table if not exists private.family_signup_attempts (
  id        bigint generated always as identity primary key,
  phone_key text not null,
  at        timestamptz not null default now()
);
create index if not exists family_signup_attempts_idx on private.family_signup_attempts (phone_key, at);

create or replace function private.family_login_email(p_phone text)
returns text language sql immutable set search_path = public as $$
  select 'f' || private.phone_key(p_phone) || '@family.firequest.co.za'
$$;

-- Edge function only, called on its own before the check so failed tries still count.
create or replace function private.family_note_attempt(p_phone text)
returns void language sql security definer set search_path = public as $$
  insert into private.family_signup_attempts (phone_key)
  select private.phone_key(p_phone) where private.phone_key(p_phone) is not null;
  delete from private.family_signup_attempts where at < now() - interval '1 day';
$$;
revoke all on function private.family_note_attempt(text) from public, anon, authenticated;

-- Edge function only. Checks a code for a cellphone number.
-- Returns kind 'invite' (new member) or 'reset' (new PIN for an existing family login).
create or replace function private.family_code_check(p_phone text, p_code text)
returns table (kind text, ref_id uuid, user_id uuid, full_name text, phone text, login_email text)
language plpgsql security definer set search_path = public as $$
declare
  v_key  text := private.phone_key(p_phone);
  v_code text := upper(regexp_replace(coalesce(p_code, ''), '\s', '', 'g'));
  v_inv  public.family_invites;
  v_pin  private.family_pin_codes;
  v_sub  public.subscriptions;
  v_existing uuid;
begin
  if v_key is null then raise exception 'Enter your cellphone number, for example 082 123 4567.'; end if;
  if (select count(*) from private.family_signup_attempts a where a.phone_key = v_key and a.at > now() - interval '1 hour') >= 10 then
    raise exception 'Too many tries. Wait an hour and try again, or ask the plan holder for a new code.';
  end if;

  select * into v_inv from public.family_invites i where i.code = v_code and i.expires_at > now();
  if found then
    if private.phone_key(v_inv.phone) is distinct from v_key then
      raise exception 'That code is not for this cellphone number. Check the number, or ask the plan holder for a new code.';
    end if;
    select * into v_sub from public.subscriptions s where s.id = v_inv.subscription_id;
    if (select count(*) from public.subscription_members m where m.subscription_id = v_sub.id) >= v_sub.max_members then
      raise exception 'This family plan is full (% people).', v_sub.max_members;
    end if;
    select u.id into v_existing from auth.users u where lower(u.email) = private.family_login_email(p_phone);
    if v_existing is not null and exists (select 1 from public.subscription_members m where m.user_id = v_existing) then
      raise exception 'This cellphone number is already on a family plan. Leave that plan first, or ask the plan holder for help.';
    end if;
    return query select 'invite'::text, v_inv.id, v_existing, v_inv.name, v_inv.phone, private.family_login_email(p_phone);
    return;
  end if;

  select * into v_pin from private.family_pin_codes c where c.code = v_code and c.expires_at > now();
  if found then
    if private.phone_key((select p.phone from public.profiles p where p.id = v_pin.user_id)) is distinct from v_key then
      raise exception 'That code is not for this cellphone number. Check the number, or ask the plan holder for a new code.';
    end if;
    return query select 'reset'::text, v_pin.user_id, v_pin.user_id, null::text, null::text,
                        (select u.email::text from auth.users u where u.id = v_pin.user_id);
    return;
  end if;

  raise exception 'That code is not valid. It may already have been used, or it expired after 7 days. Ask the plan holder for a new code.';
end $$;

-- Edge function only, after the login exists: put the person on the plan, or use up the PIN code.
create or replace function private.family_code_finish(p_kind text, p_ref uuid, p_user uuid)
returns void language plpgsql security definer set search_path = public as $$
declare
  v_inv public.family_invites;
begin
  if p_kind = 'reset' then
    delete from private.family_pin_codes where user_id = p_user;
    delete from private.family_signup_attempts a
     where a.phone_key = private.phone_key((select phone from public.profiles where id = p_user));
    return;
  end if;
  select * into v_inv from public.family_invites where id = p_ref for update;
  if not found then raise exception 'That code has already been used.'; end if;
  update public.profiles
     set full_name = case when coalesce(full_name, '') = '' then v_inv.name else full_name end,
         phone = v_inv.phone,
         email = null
   where id = p_user;
  insert into public.subscription_members (subscription_id, user_id, role, relationship)
  values (v_inv.subscription_id, p_user, 'member', v_inv.relationship)
  on conflict do nothing;
  delete from public.family_invites where id = v_inv.id;
  delete from private.family_signup_attempts where phone_key = private.phone_key(v_inv.phone);
end $$;

revoke all on function private.family_code_check(text, text) from public, anon, authenticated;
revoke all on function private.family_code_finish(text, uuid, uuid) from public, anon, authenticated;

-- Plan holder: a new one-time sign-in code for a family member who forgot their PIN.
create or replace function public.family_new_pin_code(p_user_id uuid)
returns json language plpgsql security definer set search_path = public as $$
declare
  v_uid  uuid := auth.uid();
  v_code text;
  v_exp  timestamptz := now() + interval '7 days';
begin
  if v_uid is null then raise exception 'Not signed in'; end if;
  if not exists (select 1 from public.subscription_members m join public.subscriptions s on s.id = m.subscription_id
                  where m.user_id = p_user_id and s.owner_id = v_uid and m.role = 'member') then
    raise exception 'That person is not on your family plan.';
  end if;
  if not exists (select 1 from auth.users u where u.id = p_user_id and u.email like '%@family.firequest.co.za') then
    raise exception 'This person signs in with their own email address and password, not a PIN.';
  end if;
  loop
    v_code := private.new_family_code();
    exit when not exists (select 1 from private.family_pin_codes c where c.code = v_code);
  end loop;
  insert into private.family_pin_codes (user_id, code, expires_at) values (p_user_id, v_code, v_exp)
  on conflict (user_id) do update set code = excluded.code, created_at = now(), expires_at = excluded.expires_at;
  return json_build_object('code', v_code, 'expires_at', v_exp,
                           'name', (select full_name from public.profiles where id = p_user_id),
                           'phone', (select phone from public.profiles where id = p_user_id));
end $$;

revoke all on function public.family_new_pin_code(uuid) from public, anon;
grant execute on function public.family_new_pin_code(uuid) to authenticated;
