-- v19: medications as a list – each with the person's name and chronic or a short course with a last day.
-- [{ "name": "Insulin", "who": "Sarah", "chronic": true, "until": null },
--  { "name": "Amoxicillin", "who": "Jan", "chronic": false, "until": "2026-11-20" }]
-- The old text column "medication" is kept, filled with the active list for older app versions.
alter table public.medical_profiles add column if not exists medications jsonb not null default '[]'::jsonb;
