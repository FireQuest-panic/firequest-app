-- v20: chronic conditions as a list, each with the person's name:
-- [{ "name": "Type 1 diabetes", "who": "Sarah" }]
-- The text column "conditions" is kept in step ("Type 1 diabetes (Sarah), Asthma (Jan)") for display.
alter table public.medical_profiles add column if not exists conditions_list jsonb not null default '[]'::jsonb;
