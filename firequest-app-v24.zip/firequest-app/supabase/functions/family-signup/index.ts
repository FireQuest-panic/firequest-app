// FireQuest – family members sign in with cellphone number + PIN (no email).
// POST { phone, code, pin }
//  * code from the plan holder's invite  -> creates the login and joins the plan
//  * code from "New sign-in code"        -> sets a new PIN on the existing login
// Answers { ok: true, email } (the hidden login name the app signs in with) or { error }.
// Deploy with verify_jwt = false: the person is not signed in yet. The code is the proof.
import postgres from 'npm:postgres@3.4.5';

const env = (k: string) => Deno.env.get(k) ?? '';
const sql = postgres(env('SUPABASE_DB_URL'), { prepare: false, max: 1, idle_timeout: 20, connect_timeout: 15 });

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, apikey, content-type, x-client-info',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

const json = (status: number, body: unknown) =>
  new Response(JSON.stringify(body), { status, headers: { ...CORS, 'Content-Type': 'application/json' } });

async function authAdmin(method: string, path: string, body: unknown): Promise<{ ok: boolean; data: any }> {
  const key = env('SUPABASE_SERVICE_ROLE_KEY');
  const res = await fetch(`${env('SUPABASE_URL')}/auth/v1/admin/users${path}`, {
    method,
    headers: { apikey: key, Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  const data = await res.json().catch(() => ({}));
  return { ok: res.ok, data };
}

/** Message raised by our SQL functions, or a general one. */
function sqlMessage(e: unknown): string {
  const m = (e as { message?: string })?.message ?? '';
  return m && !/connect|timeout|ECONN|password authentication/i.test(m) ? m : 'Something went wrong. Please try again.';
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: CORS });
  if (req.method !== 'POST') return json(405, { error: 'Method not allowed' });

  let phone = '', code = '', pin = '';
  try {
    const b = await req.json();
    phone = String(b?.phone ?? '').slice(0, 30);
    code = String(b?.code ?? '').slice(0, 20);
    pin = String(b?.pin ?? '');
  } catch {
    return json(400, { error: 'Something went wrong. Please try again.' });
  }
  if (!/^\d{6}$/.test(pin)) return json(400, { error: 'Choose a PIN of exactly 6 digits.' });
  if (/^(\d)\1{5}$/.test(pin) || pin === '123456' || pin === '654321') {
    return json(400, { error: 'That PIN is too easy to guess. Choose another one.' });
  }

  try {
    await sql`select private.family_note_attempt(${phone})`;
    const [c] = await sql`select * from private.family_code_check(${phone}, ${code})`;
    if (!c) return json(400, { error: 'That code is not valid.' });

    let userId: string = c.user_id;
    if (userId) {
      const r = await authAdmin('PUT', `/${userId}`, { password: pin, email_confirm: true });
      if (!r.ok) return json(500, { error: 'Could not set your PIN. Please try again.' });
    } else {
      const r = await authAdmin('POST', '', {
        email: c.login_email,
        password: pin,
        email_confirm: true,
        user_metadata: { full_name: c.full_name ?? '', phone: c.phone ?? '', family_login: true },
      });
      if (!r.ok || !r.data?.id) return json(500, { error: 'Could not create your login. Please try again.' });
      userId = r.data.id;
    }

    await sql`select private.family_code_finish(${c.kind}, ${c.ref_id}, ${userId})`;
    return json(200, { ok: true, email: c.login_email });
  } catch (e) {
    return json(400, { error: sqlMessage(e) });
  }
});
