# FireQuest Panic – test version (Android)

Two parts:

- **FireQuest Panic app** (`app/`): the Android app for clients. Sign in, medical profile, three hold-to-send panic buttons, live GPS, cancel with PIN.
- **FireQuest Monitor** (`monitor/`): the control-room screen. Live alert list with alarm, map, client profile, Google Maps navigation, actions and alert log.

Both use one **Supabase** database (`supabase/schema.sql`).

---

## One-time setup

### 1. Database (Supabase)

1. In your Supabase project, open **SQL Editor** > **New query**.
2. Paste everything from `supabase/schema.sql` and click **Run**. You should see "Success". Run it only once.
3. Set the control-room phone number: open `supabase/settings.sql`, put in your number, and run the first `update` line.
4. **For testing only** (optional, makes sign-up quicker): Authentication > Sign In / Providers > Email > switch off **Confirm email**. Switch it back on before going live.

### 2. Control-room operators

For each person who will use the monitor:

1. Authentication > Users > **Add user** > **Create new user**. Enter their email and a password, and tick **Auto Confirm User**.
2. Open `supabase/add-operator.sql`, change the email and name, and run it in the SQL Editor.

Operators sign in to the monitor with that email and password. Client accounts cannot open the monitor.

### 3. Settings

The database address and its public ("publishable") key are already in `app/src/config.json` and `monitor/config.js`. That key is designed to sit inside apps, and the database's security rules protect the data. **Never** put the `secret` or `service_role` key in these files.

(Optional) To point a build at a different database without changing the files, add the repository variables `SUPABASE_URL`, `SUPABASE_PUBLISHABLE_KEY` and `CONTROL_ROOM_PHONE` under GitHub > Settings > Secrets and variables > Actions > Variables.

---

## Building a new test version

The repository holds the code as **one zip file** plus the build file `.github/workflows/build.yml`. This works from a phone:

1. Upload the new `firequest-app.zip` to the repository (Add file > Upload files > Commit changes).
2. GitHub builds automatically (about 20 minutes). You can follow it on the **Actions** tab.
3. Open **Releases**. The newest release ("FireQuest build N", marked **Latest**) has `FireQuest.apk` (the app) and `firequest-monitor.zip` (the monitor).

The build uses whichever zip file was uploaded most recently. `build.sh` does the actual work, including publishing the release, so the build file never needs to change. Editing only the build file does not start a build.

**Download page** (share this one): https://firequest-panic.github.io/firequest-app/
- Built from the `site/` folder and published to the `gh-pages` branch by every build.
- One-time setup: Settings > Pages > Source "Deploy from a branch", branch `gh-pages`, folder `/ (root)`, Save.
- On Android phones the Download button hands the download to Samsung Internet, because Chrome can get stuck at 100% on app files. Phones without Samsung Internet get the normal download.
- Add `?code=ABC123` to show a family code on the page. Family invites from the app do this automatically (`downloadUrl` in `app/src/config.json`).

## Automatic crash detection (Android)

- Switched on per phone: **Account > Automatic crash detection > Turn on**. Android asks for location ("Allow all the time") and notifications. For reliability, also allow FireQuest to run without battery restrictions (the card has a button).
- A native background service (`app/modules/crash-detector`, Kotlin) keeps running when the app is closed and restarts after a reboot or update. Android shows a small "Crash detection is on" notification while it runs.
- **Idle:** cheap network location only. When the phone moves at driving speed (25 km/h or more), it switches to GPS every second plus the motion sensor at 100 readings a second.
- **Crash rule:** at least 3 readings of 3 g or more within 0.3 s while driving 25 km/h or faster, not after free fall (a dropped phone), followed by the vehicle stopping (or GPS going silent). Rules and tests: `CrashDetector.kt`.
- **Countdown:** the phone rings loudly at full alarm volume with a 30-second countdown, "I'M OK" and "SEND HELP NOW". If nobody responds, it sends a Vehicle accident alert with the location (marked AUTO-DETECTED CRASH in the control room). It keeps retrying without signal and updates the location for 15 minutes.
- The service does not use the login session. Switching on registers the phone and stores a random device key on it (only a hash is kept in the database). Switching off or signing out deletes it. Database: `supabase/004_crash_detection.sql`.
- **Test without a crash:** Account > Test: simulate a crash. If not cancelled, it sends a TEST alert.
- Every detection (sent or cancelled) is logged in `private.crash_detections` (peak g, speed, no location for cancelled ones) to tune the rules during testing.

## Family plans

- Nobody is a plan holder automatically. A person subscribes under **Account > Subscription** (PayFast), or, while `test_mode` is on, taps **Account > Family plan > Start a free test family plan**.
- Only the holder can add people: **Add a family member** > name, cellphone number, relationship. The app then shares a WhatsApp invite with a personal code.
- The code works once, only for that cellphone number (the number on the joiner's FireQuest profile must match), and expires after 7 days.
- Members can see who is on the plan and can leave. They cannot invite anyone.
- Database: `supabase/003_family_invites.sql` (run after `002_family_plans.sql`; already included in `schema.sql`).

## Payments (PayFast)

One monthly PayFast subscription (debit from a card) per family plan, paid by the plan holder. Family members never pay or see payment screens.

**How it works**
- **Account > Subscription** in the app shows the status and the right button: *Subscribe with PayFast*, *Pay now*, *Update card details* or *Restart my subscription*.
- The app asks the server function `payfast` (Supabase Edge Function, `supabase/functions/payfast/index.ts`) for a signed checkout. The phone's browser opens `site/pay.html`, which sends the client to PayFast's secure page. The first payment is taken immediately, then every month (`subscription_type=1`, monthly, no end date).
- PayFast reports every payment to `…/functions/v1/payfast/itn` (ITN). The function checks the signature, the merchant and asks PayFast to confirm the notification (`/eng/query/validate`) before anything is recorded. The database then moves **paid until** on by one month.
- After paying, PayFast shows `site/paid.html` with an **Open FireQuest** button.

**When a payment fails**
- PayFast retries a failed debit for 5 days and then locks the subscription. The app shows the plan holder a red/amber warning on the home screen and in Account:
  - **Pay now** (works with any card): pays this month straight away and starts a new monthly debit order. The server then cancels the old debit order at PayFast automatically, so nobody pays twice. If that cancel fails it is retried every 15 minutes (`supabase/payfast-schedule.sql`, see `private.payfast_old_tokens`); after 3 failed tries a FireQuest admin is told.
  - **Update card details** (live system only): PayFast's own secure page for changing the card on the existing debit order.
- Grace period: `grace_days` (default 7) after "paid until". During it the control room sees **PAYMENT LATE**; after it **NOT PAID**.
- **The panic buttons always keep working.** The control room (phone and computer) shows PAID / PAYMENT LATE / NOT PAID / TEST PLAN / NO SUBSCRIPTION on every alert, and FireQuest decides how to respond.

**Test mode (now):** with no secrets set, the function uses PayFast's public sandbox account (merchant 10000100, test money only). The plan holder can also use **Account > Subscription > Test: pretend a payment problem** to see each state. PayFast's sandbox has no card-update page.

**Price:** `plan_price` in `app_settings` (placeholder R199.00 until FireQuest confirms the price). Change it with:
`update public.app_settings set plan_price = 199.00 where id = 1;`
New checkouts use the new price; existing debit orders keep their amount until changed in PayFast.

**Going live (FireQuest does this, never shared with anyone):**
1. PayFast > Settings > Developer settings: set a **passphrase**, and make sure recurring billing (subscriptions) is enabled on the account.
2. Supabase > Edge Functions > Secrets: add `PAYFAST_MERCHANT_ID`, `PAYFAST_MERCHANT_KEY`, `PAYFAST_PASSPHRASE` (the same passphrase) and `PAYFAST_MODE` = `live`.
3. Switch test mode off (`supabase/settings.sql`). From then on sandbox payments no longer count: every plan must be paid for real.
4. Pay once yourself with a real card and check the status in the app, then cancel/refund that test in PayFast if needed.

**Admins:** FireQuest admins (staff with role `admin`) see **Account > Payments needing attention**: live payments that were not credited (check and refund in PayFast), old debit orders that could not be stopped automatically, and plans deleted while a debit order was running. Tap **Mark as sorted out** once handled.

**Safety rules:** a payment is counted once; the first payment must match the checkout; monthly payments smaller than the plan price are not counted; a payment that is not credited has its debit order stopped (when FireQuest started it) and is listed for an admin; real payments are refused while test mode is on; sandbox payments and the test buttons never count once test mode is off. Billing day: debits run on the same day every month (the last day in shorter months); a plan is paid until the end of the day after its next debit day.

**Payment page:** `site/pay.html` only receives a checkout number and fetches the signed PayFast form from FireQuest's server (`/functions/v1/payfast/form`, valid for 2 hours), so the page cannot be used to send people to anyone else's PayFast account. The build fills in the server address.

**Records** (in the hidden `private` schema, SQL Editor only): `payfast_checkouts` (every checkout started), `payfast_events` (every notification and what was done with it), `payfast_old_tokens` (debit orders to stop and their cancellation), `payfast_attention` (items for admins).

Database: `supabase/005_payfast.sql` (already included in `schema.sql`) plus `supabase/payfast-schedule.sql` (run once; it contains this project's address). Deploying the function: Supabase > Edge Functions > `payfast`, **Verify JWT off** (PayFast cannot log in; the function checks the app's login itself).

**Direct app file** (always the newest; needs the repository to be **public**). Each release also has `FireQuest-build-N.apk`, and the download page links to that, so a phone never opens an older download by mistake:
https://github.com/FireQuest-panic/firequest-app/releases/latest/download/FireQuest.apk

## Profile details for responders

- The **Profile** tab (was "Medical ID") shows what responders see. Clients can **take a selfie** (front camera) or choose a photo. It is shrunk to 640 px and stored in the private storage bucket `selfies` as `<user id>/selfie.jpg`.
- **Edit my details** has a step **Home & insurance**: people living in the home, pets at the home – inside or in the yard (and whether any could be dangerous to strangers, with a note), and insurance company, policy number, insurer's phone number and what is insured.
- Control room (phone and computer): the selfie next to the client's name, a red **DANGEROUS PET(S)** warning, household size, pets and insurance (tap to call the insurer). The WhatsApp route message includes the household size and dangerous pets; insurance stays in the control room.
- Who can see the selfie: the client, and FireQuest staff only while that client has an alert open (or for 24 hours after raising one) – the same rule as the medical details.
- **Home pin:** after typing the home address (Edit my details > Your details), the client taps **Place pin on map** and moves a satellite map until the red pin is on their house (or taps **I'm at home now** to use the phone's GPS), then can **Check in Google Maps**. A pin is required whenever a home address is given, because farm and remote addresses are often not found by Google Maps. The control room gets **Navigate to home (client's pin)**, the computer monitor shows a 🏠 on its map, and the WhatsApp route includes the home pin link.
  - Map pictures: Esri World Imagery (satellite) and OpenStreetMap (street map), shown in the app with credits. Fine for testing; before many clients use it, get a commercial map licence (for example a Google Maps, Esri or Mapbox account).
  - The map code (Leaflet 1.9.4) is built into the app (`app/src/map/`), so only the map pictures come from the internet.
- Database: `supabase/006_profile_details.sql` (already included in `schema.sql`).

## Price, card-expiry and birthday reminders

- The family plan (up to 4 people in one household) costs **R49 a month** (`app_settings.plan_price`).
- PayFast does not tell FireQuest when a card expires, so the plan holder types the card's **expiry (MM/YY only, never the card number)** under Account > Subscription. The app asks when there is a debit order and no expiry yet, when the saved card has expired, and after paying again (maybe with a new card).
- The holder's phone then shows a reminder **30 days and 7 days before** the card expires (09:00), and the Home screen shows a warning from 30 days before.
- **Birthdays:** every person gets a "Happy birthday" notification at 08:00 on their date of birth (from their profile), and a greeting on the Home screen that day.
- Reminders are scheduled on the phone (expo-notifications), so no push-notification account is needed; Android keeps them after a restart. Signing out removes them.
- Database: `supabase/009_card_expiry.sql` (already included in `schema.sql`).

## Control-room alarm (app closed)

- **Control room tab > Alarm when FireQuest is closed > Switch on alarm on this phone** (staff only). The phone then runs a background service that asks FireQuest every 20 seconds for alerts nobody has acknowledged and sounds **FireQuest's siren at full alarm volume** with a notification – also when the app is closed or the screen is off – until someone acknowledges the alert (acknowledging in the app stops it at once; on the computer monitor within about 5 seconds). **SILENCE 2 MIN** only pauses it; a newer alert always rings.
- While the siren sounds, the phone **vibrates strongly** and the **screen lights up** with a red/white flashing alarm page over the lock screen (Android 14+: allow FireQuest's full-screen notifications – the app asks). The page closes by itself when the alert is acknowledged.
- Keep that phone **on the charger with volume up**, and allow FireQuest to run **without battery restrictions** (the app asks). It starts again by itself after a restart.
- The card lists which staff phones are listening and warns in red when none is.
- Database: `supabase/008_control_room_alarm.sql` (device keys like crash detection; already included in `schema.sql`). A database that had the safe-area test (version 10) first runs `007_remove_safe_areas.sql`; safe areas were removed on 23 Oct.

## Installing on Android test phones

1. Send the download page link to the tester (WhatsApp, email or SMS).
2. On the phone, tap the link, tap **Download FireQuest**, then **Open** and **Install**. If Android asks, allow the browser to **install unknown apps**.
3. Open **FireQuest**, create an account, complete the 5 registration steps and allow location.

A newer test build installs over the old one. The tester's account and details stay.

## Running the monitor

1. Download `firequest-monitor.zip` from the latest release on the control-room computer and unzip it.
2. Open `index.html` in **Google Chrome**.
3. Sign in with an operator account and click **Start monitoring**. This switches on the alarm sound. Keep the window open and the volume up.

---

## Test script

| # | Do this | Expect |
|---|---|---|
| 1 | Tester creates an account and completes registration | Home screen with three buttons and a "TEST MODE" banner |
| 2 | Tap a button briefly | Nothing is sent (it must be held for 2 seconds) |
| 3 | Hold **Medical** for 2 seconds | Phone shows "Alert sent". Monitor rings, the alert flashes red, the map shows the phone |
| 4 | Operator clicks **Acknowledge** | Alarm stops. Phone shows "The control room has your alert" within a few seconds |
| 5 | Operator clicks **Navigate in Google Maps** | Google Maps opens with directions to the phone |
| 6 | Tester walks 100 m with the app open | Monitor map position updates about every 10 seconds |
| 7 | Operator clicks **Dispatch FireQuest team**, then **Team on scene** | Phone timeline updates |
| 8 | Tester taps **Cancel with PIN** and enters a wrong PIN | Alert stays active. Monitor shows a red "wrong PIN" warning |
| 9 | Tester enters the right PIN | Alert cancelled on both screens |
| 10 | Repeat with **Vehicle** and **Fire** | Monitor shows the right guidance for each |
| 11 | Plan holder: Account > Subscription > **Try a PayFast test payment**, pay on the PayFast sandbox page | Back in the app within a minute: "Paid – thank you", paid until one month from today. Control room shows **PAID** on alerts |
| 12 | Account > Test: pretend a payment problem > **This month's debit failed** | Home screen shows "Your last FireQuest payment failed – tap to fix it" |
| 13 | Tap it > **Pay now with PayFast** > pay on the sandbox page | Back to "Paid – thank you", warning gone |
| 14 | Test: **Not paid at all**, then raise an alert | Control room shows **NOT PAID**; the alert still goes through |
| 15 | Profile > **Take a selfie**; Edit my details > **Home & insurance**: fill in people, pets (dangerous: Yes) and insurance | Profile shows the photo, household, DANGEROUS badge and insurance |
| 16 | Raise an alert | Control room shows the photo, a red DANGEROUS PET warning and the insurance; "Send route" includes household and dangerous pets |
| 17 | Edit my details > type a home address > **Place pin on map** > move the pin onto the house > **This is my home** > **Check in Google Maps** | Google Maps opens on the house. Without a pin the app asks for one |
| 18 | Raise an alert, then in the control room tap **Navigate to home (client's pin)** | Google Maps gives directions to the pinned house |

Write down anything that is confusing, slow or wrong.

---

## Limits of this test version

- **Location while the app is closed:** the phone sends its location while the alert screen is open (the screen stays on). Tracking with the screen locked comes next.
- **No automatic SMS:** emergency contacts and partner services are not messaged yet. The operator phones them.
- **Map:** uses free OpenStreetMap maps. Fine for testing; for heavy use switch to a paid map service.
- **Signing key:** test builds are signed with a shared test key. A private FireQuest key is needed before release.
- **Supabase free plan:** the project sleeps after 7 days with no activity, and has no backups. Upgrade to Pro (or a FireQuest server) before real clients rely on it.
- **Test mode:** every alert is marked TEST until `test_mode` is switched off in `supabase/settings.sql`.
- **Payments:** PayFast sandbox only until FireQuest adds its own merchant details (see Payments). FireQuest sends no email or SMS reminder yet when a debit fails; the app warns the plan holder.

## Moving clients from the Base44 app (later)

Export users from Base44 as CSV and import them into Supabase. Each client then gets a "set your password" email, because passwords cannot be copied between systems. PayFast subscriptions are matched by email address.
