import React, { useCallback, useEffect, useState } from 'react';
import { Alert, AppState, Text, View } from 'react-native';
import { colors } from '../theme';
import { friendlyError } from '../lib/data';
import { openBatterySettings } from '../lib/crash';
import {
  ControlRoomAlarmStatus,
  Listener,
  alarmStatus,
  controlRoomAlarmSupported,
  listeners,
  switchOffAlarm,
  switchOnAlarm,
} from '../lib/controlRoomAlarm';
import { Body, Button, Card, ErrorText } from './ui';

function ago(iso: string | null): string {
  if (!iso) return 'never';
  const s = Math.round((Date.now() - Date.parse(iso)) / 1000);
  if (s < 90) return `${Math.max(s, 0)} s ago`;
  if (s < 5400) return `${Math.round(s / 60)} min ago`;
  return `${Math.round(s / 3600)} h ago`;
}

/** Control room tab: ring on this phone for new alerts, also when FireQuest is closed. */
export function ControlRoomAlarmCard({ userId }: { userId: string }) {
  const [status, setStatus] = useState<ControlRoomAlarmStatus | null>(alarmStatus());
  const [phones, setPhones] = useState<Listener[] | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const refresh = useCallback(() => {
    setStatus(alarmStatus());
    listeners().then(setPhones);
  }, []);

  useEffect(() => {
    refresh();
    const t = setInterval(refresh, 15000);
    const sub = AppState.addEventListener('change', (s) => s === 'active' && refresh());
    return () => {
      clearInterval(t);
      sub.remove();
    };
  }, [refresh]);

  if (!controlRoomAlarmSupported) return null;
  const on = Boolean(status?.enabled && status.userId === userId);
  // A phone counts as listening when it checked in during the last 2 minutes.
  const live = (phones ?? []).filter((p) => p.last_seen_at && Date.now() - Date.parse(p.last_seen_at) < 120000);

  const turnOn = async () => {
    setError('');
    setBusy(true);
    try {
      const r = await switchOnAlarm(userId);
      if (!r.ok && r.message) setError(r.message);
    } catch (e) {
      setError(friendlyError(e));
    } finally {
      setBusy(false);
      setTimeout(refresh, 1500);
    }
  };

  const turnOff = () =>
    Alert.alert('Switch off?', 'This phone will no longer ring for new alerts when FireQuest is closed.', [
      { text: 'Keep on', style: 'cancel' },
      {
        text: 'Switch off',
        style: 'destructive',
        onPress: async () => {
          setBusy(true);
          await switchOffAlarm();
          setBusy(false);
          refresh();
        },
      },
    ]);

  return (
    <Card style={!on ? { borderColor: '#7A2A2E' } : undefined}>
      <Text style={{ color: on ? colors.goldText : colors.danger, fontWeight: '700' }}>
        Alarm when FireQuest is closed: {on ? 'ON' : 'OFF'}
      </Text>
      {on ? (
        <>
          <Text style={{ color: status?.lastError ? colors.danger : colors.green, fontSize: 14, lineHeight: 20 }}>
            {status?.lastError
              ? status.lastError
              : status?.running
                ? `This phone rings for every new alert until someone acknowledges it. Last check ${status.lastPollAt ? ago(new Date(status.lastPollAt).toISOString()) : '…'}.`
                : 'Starting…'}
          </Text>
          {!status?.batteryUnrestricted ? (
            <View style={{ gap: 4 }}>
              <Text style={{ color: colors.goldText, fontSize: 14 }}>
                Battery saving may stop the alarm. Allow FireQuest to run without battery restrictions.
              </Text>
              <Button title="Open battery setting" variant="outline" onPress={() => openBatterySettings()} />
            </View>
          ) : null}
          {status && !status.notificationsEnabled ? (
            <Text style={{ color: colors.danger, fontSize: 14 }}>Notifications are off for FireQuest – switch them on in Settings.</Text>
          ) : null}
          <Body>Keep this phone on the charger, with the volume up.</Body>
          <Button title="Switch off on this phone" variant="plain" onPress={turnOff} disabled={busy} />
        </>
      ) : (
        <>
          <Body>
            Switch this on so this phone rings loudly for every new alert – also when the FireQuest app is closed or the
            screen is off – until someone acknowledges it.
          </Body>
          <Button title="Switch on alarm on this phone" variant="red" onPress={turnOn} loading={busy} />
        </>
      )}
      {phones ? (
        <Text style={{ color: live.length ? colors.muted : colors.danger, fontSize: 13, lineHeight: 19 }}>
          {live.length
            ? `Phones that will ring: ${live.map((p) => (p.mine ? `${p.name || 'you'} (this account)` : p.name || 'operator')).join(', ')}.`
            : 'WARNING: no control-room phone is listening right now. New alerts only show while the app or the computer monitor is open.'}
        </Text>
      ) : null}
      <ErrorText>{error}</ErrorText>
    </Card>
  );
}
