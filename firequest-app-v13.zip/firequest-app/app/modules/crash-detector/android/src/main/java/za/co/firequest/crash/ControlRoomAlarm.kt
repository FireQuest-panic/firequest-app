package za.co.firequest.crash

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.util.Log
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequest
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/** Settings for the control-room alarm on a staff phone. */
class ControlRoomConfig(context: Context) {
  private val prefs = context.applicationContext.getSharedPreferences("firequest_control_room", Context.MODE_PRIVATE)
  val supabaseUrl: String get() = prefs.getString("supabaseUrl", "") ?: ""
  val supabaseKey: String get() = prefs.getString("supabaseKey", "") ?: ""
  val deviceKey: String get() = prefs.getString("deviceKey", "") ?: ""
  val userId: String get() = prefs.getString("userId", "") ?: ""
  val isComplete: Boolean get() = supabaseUrl.isNotBlank() && supabaseKey.isNotBlank() && deviceKey.isNotBlank()

  fun save(url: String, key: String, deviceKey: String, userId: String) {
    prefs.edit().putString("supabaseUrl", url.trim()).putString("supabaseKey", key.trim())
      .putString("deviceKey", deviceKey.trim()).putString("userId", userId.trim()).apply()
  }

  fun clear() {
    prefs.edit().clear().apply()
  }
}

/**
 * Control-room alarm: while switched on, this service asks FireQuest every 20 seconds for
 * alerts nobody has acknowledged, also when the app is closed. When there is one, the phone
 * rings loudly (alarm volume) and shows the alert until someone acknowledges it.
 * "Silence 2 min" stops the sound for two minutes only.
 */
class ControlRoomAlarmService : Service() {
  companion object {
    private const val TAG = "FireQuestControlRoom"
    const val ACTION_START = "za.co.firequest.crash.CONTROL_ROOM_START"
    const val ACTION_SILENCE = "za.co.firequest.crash.CONTROL_ROOM_SILENCE"
    private const val STATUS_ID = 4301
    private const val ALARM_ID = 4302
    private const val CHANNEL_STATUS = "fq_control_room_status"
    private const val CHANNEL_ALARM = "fq_control_room_alarm"
    private const val POLL_MS = 20_000L
    private const val SILENCE_MS = 2 * 60_000L
    private const val WORK = "fq_control_room_watchdog"

    @Volatile var running = false
      private set
    @Volatile var lastPollAt = 0L
      private set
    @Volatile var lastError: String? = null
      private set
    @Volatile var openAlerts = 0
      private set

    fun start(context: Context): Boolean {
      if (!ControlRoomConfig(context).isComplete) return false
      val intent = Intent(context, ControlRoomAlarmService::class.java).setAction(ACTION_START)
      return try {
        if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(intent) else context.startService(intent)
        true
      } catch (e: Exception) {
        lastError = "Could not start: ${e.message}"
        Log.w(TAG, "start failed", e)
        false
      }
    }

    fun stop(context: Context) {
      context.stopService(Intent(context, ControlRoomAlarmService::class.java))
      try { WorkManager.getInstance(context).cancelUniqueWork(WORK) } catch (_: Exception) {}
    }

    /** Every 15 minutes: start the service again if Android stopped it. */
    fun scheduleWatchdog(context: Context) {
      try {
        val req = PeriodicWorkRequest.Builder(ControlRoomWatchdog::class.java, 15, TimeUnit.MINUTES).build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(WORK, ExistingPeriodicWorkPolicy.KEEP, req)
      } catch (e: Exception) {
        Log.w(TAG, "watchdog not scheduled", e)
      }
    }

    fun status(context: Context): Map<String, Any?> {
      val config = ControlRoomConfig(context)
      val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
      val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
      return mapOf(
        "available" to true,
        "enabled" to config.isComplete,
        "userId" to config.userId,
        "running" to running,
        "lastPollAt" to lastPollAt.toDouble(),
        "openAlerts" to openAlerts,
        "notificationsEnabled" to nm.areNotificationsEnabled(),
        "batteryUnrestricted" to pm.isIgnoringBatteryOptimizations(context.packageName),
        "lastError" to lastError,
      )
    }
  }

  private val handler = Handler(Looper.getMainLooper())
  private val network = Executors.newSingleThreadExecutor()
  private var wakeLock: PowerManager.WakeLock? = null
  private var ringtone: Ringtone? = null
  private var savedAlarmVolume = -1
  private var silencedUntil = 0L
  private val alerted = HashSet<String>()
  private var polling = false

  override fun onBind(intent: Intent?): IBinder? = null

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    if (!ControlRoomConfig(this).isComplete) {
      stopSelf()
      return START_NOT_STICKY
    }
    createChannels()
    try {
      val n = statusNotification("Listening for new alerts. Keep this phone on the charger.")
      if (Build.VERSION.SDK_INT >= 34) startForeground(STATUS_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
      else startForeground(STATUS_ID, n)
    } catch (e: Exception) {
      lastError = "Could not start: ${e.message}"
      Log.w(TAG, "startForeground failed", e)
      stopSelf()
      return START_NOT_STICKY
    }
    if (intent?.action == ACTION_SILENCE) {
      silencedUntil = SystemClock.elapsedRealtime() + SILENCE_MS
      stopSound()
    }
    if (!running) {
      running = true
      lastError = null
      scheduleWatchdog(this)
      handler.post(poll)
    }
    // Restarted by Android after being stopped (START_STICKY).
    return START_STICKY
  }

  override fun onDestroy() {
    running = false
    handler.removeCallbacksAndMessages(null)
    stopSound()
    cancel(ALARM_ID)
    try { wakeLock?.release() } catch (_: Exception) {}
    network.shutdown()
    super.onDestroy()
  }

  private val poll: Runnable = object : Runnable {
    override fun run() {
      if (!running) return
      keepAwake()
      if (!polling) {
        polling = true
        try {
          network.execute { checkNow() }
        } catch (e: Exception) {
          polling = false
        }
      }
      handler.postDelayed(this, POLL_MS)
    }
  }

  private fun keepAwake() {
    // Checking every 20 seconds needs the phone to stay awake (it should be on the charger).
    try {
      if (wakeLock == null) {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "FireQuest:ControlRoom").apply { setReferenceCounted(false) }
      }
      wakeLock?.acquire(2 * 60_000L)
    } catch (e: Exception) {
      Log.w(TAG, "wake lock failed", e)
    }
  }

  private fun checkNow() {
    val config = ControlRoomConfig(this)
    try {
      val answer = JSONObject(
        CrashApi.call(config.supabaseUrl, config.supabaseKey, "control_room_poll", JSONObject().put("p_key", config.deviceKey))
      )
      lastPollAt = System.currentTimeMillis()
      if (!answer.optBoolean("registered", false)) {
        lastError = "This phone is no longer registered (or you are no longer control-room staff). Switch it on again in the app."
        config.clear()
        handler.post { stopSelf() }
        return
      }
      lastError = null
      val alerts = answer.optJSONArray("alerts") ?: JSONArray()
      handler.post { show(alerts) }
    } catch (e: Exception) {
      lastError = "No connection to FireQuest – alerts cannot arrive on this phone right now"
      Log.w(TAG, "poll failed", e)
      handler.post { showStatus("NO CONNECTION to FireQuest. New alerts cannot arrive on this phone.") }
    } finally {
      polling = false
    }
  }

  private fun show(alerts: JSONArray) {
    openAlerts = alerts.length()
    if (alerts.length() == 0) {
      alerted.clear()
      stopSound()
      cancel(ALARM_ID)
      silencedUntil = 0L
      showStatus("Listening for new alerts. Keep this phone on the charger.")
      return
    }
    val newest = alerts.getJSONObject(alerts.length() - 1)
    var fresh = false
    for (i in 0 until alerts.length()) if (alerted.add(alerts.getJSONObject(i).getString("id"))) fresh = true
    if (fresh) silencedUntil = 0L // a new alert always rings, even after "Silence"
    val title = (if (alerts.length() > 1) "${alerts.length()} NEW ALERTS – " else "NEW ALERT – ") + label(newest)
    val text = "${newest.optString("client", "Client")}${if (newest.optBoolean("is_test", false)) " (TEST)" else ""}. Open FireQuest and acknowledge."
    show(ALARM_ID, alarmNotification(title, text))
    showStatus("$title – not acknowledged yet")
    if (SystemClock.elapsedRealtime() >= silencedUntil) startSound()
  }

  private fun label(a: JSONObject): String {
    val source = a.optString("source", "")
    return when {
      source == "crash_detection" -> "AUTO-DETECTED CRASH"
      a.optString("type") == "medical" -> "MEDICAL"
      a.optString("type") == "vehicle" -> "VEHICLE ACCIDENT"
      a.optString("type") == "fire" -> "FIRE & RESCUE"
      else -> a.optString("type", "ALERT").uppercase()
    }
  }

  // ------------------------------------------------------------------ notifications

  private fun createChannels() {
    if (Build.VERSION.SDK_INT < 26) return
    val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    nm.createNotificationChannel(
      NotificationChannel(CHANNEL_STATUS, "Control room listening", NotificationManager.IMPORTANCE_LOW).apply {
        description = "Shown while this phone listens for new FireQuest alerts."
        setShowBadge(false)
      }
    )
    nm.createNotificationChannel(
      NotificationChannel(CHANNEL_ALARM, "New alerts (control room)", NotificationManager.IMPORTANCE_HIGH).apply {
        description = "A new FireQuest alert that nobody has acknowledged yet."
        setSound(null, null) // the service plays the alarm sound itself
        enableVibration(false)
        lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        setBypassDnd(true)
      }
    )
  }

  private fun builder(channel: String): Notification.Builder {
    val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, channel) else Notification.Builder(this)
    b.setSmallIcon(R.drawable.ic_fq_crash).setColor(0xFFD42F35.toInt())
    CrashNotifications.openApp(this, 31)?.let { b.setContentIntent(it) }
    return b
  }

  private fun statusNotification(text: String): Notification =
    builder(CHANNEL_STATUS)
      .setContentTitle("FireQuest control room")
      .setContentText(text)
      .setStyle(Notification.BigTextStyle().bigText(text))
      .setOngoing(true)
      .setShowWhen(false)
      .setCategory(Notification.CATEGORY_SERVICE)
      .build()

  private fun showStatus(text: String) = show(STATUS_ID, statusNotification(text))

  private fun alarmNotification(title: String, text: String): Notification {
    val silenceIntent = Intent(this, ControlRoomAlarmService::class.java).setAction(ACTION_SILENCE)
    val silence = if (Build.VERSION.SDK_INT >= 26) {
      PendingIntent.getForegroundService(this, 32, silenceIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    } else {
      PendingIntent.getService(this, 32, silenceIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }
    val b = builder(CHANNEL_ALARM)
      .setContentTitle(title)
      .setContentText(text)
      .setStyle(Notification.BigTextStyle().bigText(text))
      .setOngoing(true)
      .setAutoCancel(false)
      .setCategory(Notification.CATEGORY_ALARM)
      .setPriority(Notification.PRIORITY_MAX)
      .setVisibility(Notification.VISIBILITY_PUBLIC)
      .addAction(Notification.Action.Builder(null, "SILENCE 2 MIN", silence).build())
    CrashNotifications.openApp(this, 33)?.let { b.setFullScreenIntent(it, true) }
    return b.build()
  }

  private fun show(id: Int, n: Notification) {
    try {
      (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(id, n)
    } catch (_: SecurityException) {
      // notifications switched off: the sound still plays
    }
  }

  private fun cancel(id: Int) {
    (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(id)
  }

  // ------------------------------------------------------------------ sound

  @Suppress("DEPRECATION")
  private fun startSound() {
    if (ringtone?.isPlaying == true) return
    try {
      val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
      if (savedAlarmVolume < 0) savedAlarmVolume = audio.getStreamVolume(AudioManager.STREAM_ALARM)
      audio.setStreamVolume(AudioManager.STREAM_ALARM, audio.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0)
    } catch (_: Exception) {
    }
    try {
      val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
        ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
      ringtone = RingtoneManager.getRingtone(this, uri)?.apply {
        audioAttributes = AudioAttributes.Builder()
          .setUsage(AudioAttributes.USAGE_ALARM)
          .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
          .build()
        if (Build.VERSION.SDK_INT >= 28) isLooping = true
        play()
      }
    } catch (e: Exception) {
      Log.w(TAG, "alarm sound failed", e)
    }
    try {
      val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
      val pattern = longArrayOf(0, 800, 400)
      if (Build.VERSION.SDK_INT >= 26) vibrator.vibrate(VibrationEffect.createWaveform(pattern, 0)) else vibrator.vibrate(pattern, 0)
    } catch (_: Exception) {
    }
  }

  private fun stopSound() {
    try { ringtone?.stop() } catch (_: Exception) {}
    ringtone = null
    try { (getSystemService(Context.VIBRATOR_SERVICE) as Vibrator).cancel() } catch (_: Exception) {}
    if (savedAlarmVolume >= 0) {
      try {
        (getSystemService(Context.AUDIO_SERVICE) as AudioManager).setStreamVolume(AudioManager.STREAM_ALARM, savedAlarmVolume, 0)
      } catch (_: Exception) {}
      savedAlarmVolume = -1
    }
  }
}

/** Starts the control-room alarm again if Android stopped it. */
class ControlRoomWatchdog(context: Context, params: WorkerParameters) : Worker(context, params) {
  override fun doWork(): Result {
    if (ControlRoomConfig(applicationContext).isComplete && !ControlRoomAlarmService.running) {
      ControlRoomAlarmService.start(applicationContext)
    }
    return Result.success()
  }
}
