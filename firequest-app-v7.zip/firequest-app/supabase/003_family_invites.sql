-- =====================================================================
-- FireQuest – family plans, version 2: personal invites
-- * Nobody becomes a plan holder automatically any more. A person starts
--   a plan (free while test_mode is on; through PayFast later).
-- * Only the plan holder adds people: name, cellphone number, relationship.
-- * Each invited person gets their own code. It works once, only for the
--   cellphone number the holder entered, and expires after 7 days.
-- * Members cannot invite anyone, and cannot start their own plan while
--   they are on someone else's.
-- Run after 002_family_plans.sql. (Also included in schema.sql.)
-- =====================================================================

-- The old shared code is retired: it let anyone with the code join.
alter table public.subscriptions alter column invite_code drop not null;
update public.subscriptions set invite_code = null;
alter table public.subscriptions alter column status set default 'test';
update public.subscriptions set status = 'test';

-- Plans that only ever held their owner were created automatically: remove them.
delete from public.subscriptions s
 where (select count(*) from public.subscription_members m where m.subscription_id = s.id) <= 1;

-- How each person is related to the plan holder.
alter table public.subscription_members add column if not exists relationship text
  check (relationship in ('holder', 'spouse', 'child', 'parent', 'other'));
update public.subscription_members set relationship = 'holder' where role = 'owner';

create table if not exists public.family_invites (
  id              uuid primary key default gen_random_uuid(),
  subscription_id uuid not null references public.subscriptions (id) on delete cascade,
  name            text not null check (length(trim(name)) between 1 and 80),
  phone           text not null,
  relationship    text not null check (relationship in ('spouse', 'child', 'parent', 'other')),
  code            text not null unique,
  created_at      timestamptz not null default now(),
  expires_at      timestamptz not null default now() + interval '7 days'
);
alter table public.family_invites enable row level security;
revoke all on public.family_invites from anon, authenticated;

-- Last 9 digits of a phone number, so 082 123 4567, 0821234567 and
-- +27 82 123 4567 all match. Null when there are fewer than 9 digits.
create or replace function private.phone_key(p text)
returns text language sql immutable set search_path = public as $$
  select case when length(d) >= 9 then right(d, 9) end
    from (select regexp_replace(coalesce(p, ''), '\D', '', 'g') as d) x
$$;

-- Random, easy-to-read 6-character code (no 0/O, 1/I/L).
create or replace function private.new_family_code()
returns text language plpgsql security definer set search_path = public as $$
declare
  chars  text := 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
  v_code text;
  b      bytea;
begin
  loop
    b := extensions.gen_random_bytes(6);
    v_code := '';
    for i in 0..5 loop
      v_code := v_code || substr(chars, (get_byte(b, i) % length(chars)) + 1, 1);
    end loop;
    exit when not exists (select 1 from public.family_invites f where f.code = v_code);
  end loop;
  return v_code;
end $$;

drop function if exists public.new_subscription_code();
drop function if exists private.ensure_subscription(uuid);
drop function if exists private.new_invite_code();

create or replace function public.my_subscription()
returns json language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
  v_sub uuid;
  v_res json;
begin
  if v_uid is null then raise exception 'Not signed in'; end if;
  select subscription_id into v_sub from public.subscription_members where user_id = v_uid;
  if v_sub is null then
    return json_build_object('in_plan', false, 'is_owner', false, 'max_members', 4,
                             'members', '[]'::json, 'invites', '[]'::json, 'spots_left', 0);
  end if;

  delete from public.family_invites where subscription_id = v_sub and expires_at < now();

  select json_build_object(
    'in_plan', true,
    'id', s.id,
    'status', s.status,
    'max_members', s.max_members,
    'is_owner', s.owner_id = v_uid,
    'owner_name', (select full_name from public.profiles where id = s.owner_id),
    'members', (
      select coalesce(json_agg(json_build_object(
               'user_id', m.user_id, 'name', p.full_name, 'phone', p.phone, 'email', p.email,
               'role', m.role, 'relationship', m.relationship, 'is_me', m.user_id = v_uid)
             order by m.role desc, m.joined_at), '[]'::json)
        from public.subscription_members m
        join public.profiles p on p.id = m.user_id
       where m.subscription_id = s.id),
    'invites', case when s.owner_id = v_uid then (
      select coalesce(json_agg(json_build_object(
               'id', i.id, 'name', i.name, 'phone', i.phone, 'relationship', i.relationship,
               'code', i.code, 'expires_at', i.expires_at)
             order by i.created_at), '[]'::json)
        from public.family_invites i
       where i.subscription_id = s.id) else '[]'::json end,
    'spots_left', s.max_members
      - (select count(*) from public.subscription_members m where m.subscription_id = s.id)
      - (select count(*) from public.family_invites i where i.subscription_id = s.id)
  ) into v_res
  from public.subscriptions s where s.id = v_sub;
  return v_res;
end $$;

-- Start a family plan with yourself as holder. Free while test_mode is on;
-- once FireQuest is live, plans are started through PayFast instead.
create or replace function public.start_subscription()
returns json language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
  v_sub uuid;
begin
  if v_uid is null then raise exception 'Not signed in'; end if;
  if not coalesce((select test_mode from public.app_settings where id = 1), false) then
    raise exception 'Family plans are started by subscribing with PayFast.';
  end if;
  if exists (select 1 from public.subscription_members where user_id = v_uid) then
    raise exception 'You are already on a family plan.';
  end if;
  insert into public.subscriptions (owner_id, status) values (v_uid, 'test') returning id into v_sub;
  insert into public.subscription_members (subscription_id, user_id, role, relationship)
  values (v_sub, v_uid, 'owner', 'holder');
  return public.my_subscription();
end $$;

-- Holder only: add a family member by name, cellphone number and relationship.
create or replace function public.invite_family_member(p_name text, p_phone text, p_relationship text)
returns json language plpgsql security definer set search_path = public as $$
declare
  v_uid  uuid := auth.uid();
  v_sub  public.subscriptions;
  v_name text := trim(coalesce(p_name, ''));
  v_key  text := private.phone_key(p_phone);
  v_used int;
  v_inv  uuid;
begin
  if v_uid is null then raise exception 'Not signed in'; end if;
  select * into v_sub from public.subscriptions where owner_id = v_uid for update;
  if not found then raise exception 'Only the plan holder can add family members.'; end if;
  if v_name = '' then raise exception 'Enter their name.'; end if;
  if length(v_name) > 80 then raise exception 'That name is too long.'; end if;
  if v_key is null then raise exception 'Enter their cellphone number, for example 082 123 4567.'; end if;
  if coalesce(p_relationship, '') not in ('spouse', 'child', 'parent', 'other') then
    raise exception 'Choose how they are related to you.';
  end if;

  delete from public.family_invites where subscription_id = v_sub.id and expires_at < now();

  if exists (select 1 from public.subscription_members m join public.profiles p on p.id = m.user_id
              where m.subscription_id = v_sub.id and private.phone_key(p.phone) = v_key) then
    raise exception 'Someone with that cellphone number is already on your plan.';
  end if;
  if exists (select 1 from public.family_invites
              where subscription_id = v_sub.id and private.phone_key(phone) = v_key) then
    raise exception 'That number already has an invite waiting. Tap "Send again", or cancel it first.';
  end if;

  select (select count(*) from public.subscription_members where subscription_id = v_sub.id)
       + (select count(*) from public.family_invites where subscription_id = v_sub.id)
    into v_used;
  if v_used >= v_sub.max_members then
    raise exception 'Your plan is full (% people, counting invites that are still waiting).', v_sub.max_members;
  end if;

  insert into public.family_invites (subscription_id, name, phone, relationship, code)
  values (v_sub.id, v_name, trim(p_phone), p_relationship, private.new_family_code())
  returning id into v_inv;

  return (public.my_subscription()::jsonb || jsonb_build_object('new_invite_id', v_inv))::json;
end $$;

-- Holder only: cancel an invite that has not been used yet.
create or replace function public.cancel_family_invite(p_invite_id uuid)
returns json language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
begin
  if v_uid is null then raise exception 'Not signed in'; end if;
  delete from public.family_invites i
   using public.subscriptions s
   where i.id = p_invite_id and s.id = i.subscription_id and s.owner_id = v_uid;
  if not found then raise exception 'That invite was not found.'; end if;
  return public.my_subscription();
end $$;

-- Join with a personal invite code. The cellphone number on the joiner's
-- profile must match the number the holder entered.
create or replace function public.join_subscription(p_code text)
returns json language plpgsql security definer set search_path = public as $$
declare
  v_uid     uuid := auth.uid();
  v_inv     public.family_invites;
  v_target  public.subscriptions;
  v_current public.subscriptions;
  v_phone   text;
  v_count   int;
begin
  if v_uid is null then raise exception 'Not signed in'; end if;

  select * into v_inv from public.family_invites
   where code = upper(regexp_replace(coalesce(p_code, ''), '\s', '', 'g'))
   for update;
  if not found or v_inv.expires_at < now() then
    raise exception 'That code is not valid. It may already have been used, or it expired after 7 days. Ask the plan holder to send you a new invite.';
  end if;

  select * into v_target from public.subscriptions where id = v_inv.subscription_id for update;

  select phone into v_phone from public.profiles where id = v_uid;
  if private.phone_key(v_phone) is distinct from private.phone_key(v_inv.phone) then
    raise exception 'This invite is for the cellphone number ending in %. The number on your FireQuest profile is different. Ask % to check the number, or correct your number under Medical ID > Edit.',
      right(regexp_replace(v_inv.phone, '\D', '', 'g'), 4),
      coalesce(nullif((select full_name from public.profiles where id = v_target.owner_id), ''), 'the plan holder');
  end if;

  select s.* into v_current
    from public.subscription_members m join public.subscriptions s on s.id = m.subscription_id
   where m.user_id = v_uid;
  if found then
    if v_current.id = v_target.id then raise exception 'You are already on this family plan.'; end if;
    if v_current.owner_id <> v_uid then
      raise exception 'You are on another family plan. Leave it first (Account > Family plan > Leave).';
    end if;
    if exists (select 1 from public.subscription_members where subscription_id = v_current.id and user_id <> v_uid)
       or exists (select 1 from public.family_invites where subscription_id = v_current.id) then
      raise exception 'You hold your own family plan with other people on it. Remove them and cancel their invites first.';
    end if;
    if v_current.status <> 'test' then
      raise exception 'Cancel your own FireQuest subscription first.';
    end if;
    delete from public.subscriptions where id = v_current.id;
  end if;

  select count(*) into v_count from public.subscription_members where subscription_id = v_target.id;
  if v_count >= v_target.max_members then
    raise exception 'This family plan is full (% people).', v_target.max_members;
  end if;

  insert into public.subscription_members (subscription_id, user_id, role, relationship)
  values (v_target.id, v_uid, 'member', v_inv.relationship);
  delete from public.family_invites where id = v_inv.id;
  return public.my_subscription();
end $$;

-- For the control room: the other people on the alerting client's plan.
create or replace function public.alert_family(p_alert_id uuid)
returns json language plpgsql stable security definer set search_path = public as $$
declare
  v_owner uuid;
  v_res   json;
begin
  if not public.is_staff() then raise exception 'Not authorised'; end if;
  select user_id into v_owner from public.alerts where id = p_alert_id;
  if v_owner is null then return '[]'::json; end if;
  select coalesce(json_agg(json_build_object('name', p.full_name, 'phone', p.phone, 'role', m.role,
                                             'relationship', m.relationship)
         order by m.role desc, m.joined_at), '[]'::json)
    into v_res
    from public.subscription_members m
    join public.profiles p on p.id = m.user_id
   where m.subscription_id = (select subscription_id from public.subscription_members where user_id = v_owner)
     and m.user_id <> v_owner;
  return v_res;
end $$;

revoke execute on function
  public.my_subscription(),
  public.start_subscription(),
  public.invite_family_member(text, text, text),
  public.cancel_family_invite(uuid),
  public.join_subscription(text),
  public.alert_family(uuid)
from public, anon;

grant execute on function
  public.my_subscription(),
  public.start_subscription(),
  public.invite_family_member(text, text, text),
  public.cancel_family_invite(uuid),
  public.join_subscription(text),
  public.alert_family(uuid)
to authenticated;

revoke execute on function private.phone_key(text), private.new_family_code() from public, anon, authenticated;
