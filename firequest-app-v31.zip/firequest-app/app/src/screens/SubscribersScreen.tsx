import React, { useCallback, useEffect, useState } from 'react';
import { ActivityIndicator, BackHandler, Linking, Pressable, Text, TextInput, View } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { colors } from '../theme';
import { supabase } from '../lib/supabase';
import { friendlyError } from '../lib/data';
import { longDate } from '../lib/billing';
import { Button, Card, Chip, ErrorText, Screen, Title } from '../components/ui';
import { SubscriberDetailsScreen } from './SubscriberDetailsScreen';

export interface Subscriber {
  id: string;
  holder_name: string;
  holder_phone: string | null;
  holder_email: string | null;
  members: number;
  state: string;
  label: string;
  paid_until: string | null;
  next_billing_date: string | null;
  monthly_amount: number | null;
  last_payment_at: string | null;
  last_payment_amount: number | null;
  payment_failed_at: string | null;
  cancelled_at: string | null;
  card_expiry: string | null;
  payfast_mode: string;
  debit_day?: number | null;
  /** What PayFast said at its last daily check: ACTIVE, PAUSED, CANCELLED. */
  pf_status?: string | null;
  pf_status_reason?: string | null;
  pf_paused_at?: string | null;
  pf_checked_at?: string | null;
  /** Names, cellphone numbers and emails of everyone on the plan (for search). */
  members_text?: string | null;
}

type Filter = 'all' | 'paid' | 'problem' | 'unpaid';

/** Groups the billing states into what the control room cares about. */
export function groupOf(state: string): Exclude<Filter, 'all'> | 'other' {
  if (state === 'active' || state === 'cancelled_paid') return 'paid';
  if (state === 'payment_failed' || state === 'overdue') return 'problem';
  if (state === 'unpaid' || state === 'lapsed' || state === 'cancelled') return 'unpaid';
  return 'other';
}

const STATE_TEXT: Record<string, string> = {
  active: 'PAID',
  cancelled_paid: 'PAID · CANCELLED',
  payment_failed: 'PAYMENT FAILED',
  paused: 'PAUSED AT PAYFAST',
  overdue: 'PAYMENT LATE',
  lapsed: 'NOT PAID',
  unpaid: 'NEVER PAID',
  cancelled: 'CANCELLED',
  test: 'TEST PLAN',
};

const GROUP_COLORS = {
  paid: { fg: colors.green, bg: colors.greenDeep },
  problem: { fg: colors.goldText, bg: colors.goldDeep },
  unpaid: { fg: colors.redText, bg: colors.redDeep },
  other: { fg: colors.muted, bg: colors.surfaceRaised },
};

const rand = (n: number | null | undefined) => (n == null ? '' : `R${Number(n).toFixed(2)}`);

/** FireQuest admins: every family plan with its payment status. */
export function SubscribersScreen({ onBack }: { onBack: () => void }) {
  const [rows, setRows] = useState<Subscriber[] | null>(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [filter, setFilter] = useState<Filter>('all');
  const [query, setQuery] = useState('');
  const [open, setOpen] = useState<Subscriber | null>(null);
  const closeDetails = useCallback(() => setOpen(null), []);

  const load = useCallback(async () => {
    setBusy(true);
    setError('');
    const { data, error: e } = await supabase.rpc('subscribers_list');
    if (e) setError(friendlyError(e));
    else setRows((data as Subscriber[]) ?? []);
    setBusy(false);
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  useEffect(() => {
    if (open) return;
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      onBack();
      return true;
    });
    return () => sub.remove();
  }, [onBack, open]);

  const all = rows ?? [];
  const count = (g: Filter) => (g === 'all' ? all.length : all.filter((r) => groupOf(r.state) === g).length);
  const inGroup = filter === 'all' ? all : all.filter((r) => groupOf(r.state) === filter);
  const shown = query.trim() ? inGroup.filter((r) => matchesSearch(r, query)) : inGroup;

  if (open) return <SubscriberDetailsScreen subscriber={open} onBack={closeDetails} />;

  return (
    <Screen aboveTabBar>
      <Pressable accessibilityRole="button" onPress={onBack} style={{ paddingVertical: 6 }}>
        <Text style={{ color: colors.goldText, fontWeight: '700', fontSize: 15 }}>‹ Control room</Text>
      </Pressable>
      <Title>Subscribers</Title>

      <View style={{ flexDirection: 'row', gap: 8 }}>
        <Stat label="Paid" value={count('paid')} color={GROUP_COLORS.paid.fg} />
        <Stat label="Failed / late" value={count('problem')} color={GROUP_COLORS.problem.fg} />
        <Stat label="Not paid" value={count('unpaid')} color={GROUP_COLORS.unpaid.fg} />
      </View>

      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
        <Chip label={`All (${count('all')})`} selected={filter === 'all'} onPress={() => setFilter('all')} />
        <Chip label="Paid" selected={filter === 'paid'} onPress={() => setFilter('paid')} />
        <Chip label="Failed / late" selected={filter === 'problem'} onPress={() => setFilter('problem')} />
        <Chip label="Not paid" selected={filter === 'unpaid'} onPress={() => setFilter('unpaid')} />
      </View>

      <View
        style={{
          flexDirection: 'row',
          alignItems: 'center',
          gap: 8,
          minHeight: 52,
          paddingHorizontal: 14,
          borderRadius: 14,
          borderWidth: 1,
          borderColor: query ? colors.gold : colors.border,
          backgroundColor: colors.surface,
        }}
      >
        <MaterialCommunityIcons name="magnify" size={22} color={colors.goldText} />
        <TextInput
          accessibilityLabel="Search subscribers"
          value={query}
          onChangeText={setQuery}
          placeholder="Search name, cellphone or email"
          placeholderTextColor={colors.faint}
          autoCorrect={false}
          autoCapitalize="none"
          returnKeyType="search"
          style={{ flex: 1, color: colors.text, fontSize: 16, paddingVertical: 12 }}
        />
        {query ? (
          <Pressable accessibilityRole="button" accessibilityLabel="Clear search" onPress={() => setQuery('')} hitSlop={12}>
            <MaterialCommunityIcons name="close-circle" size={20} color={colors.muted} />
          </Pressable>
        ) : null}
      </View>

      <ErrorText>{error}</ErrorText>
      {rows === null && !error ? <ActivityIndicator color={colors.gold} /> : null}
      {rows !== null && shown.length === 0 ? (
        <Text style={{ color: colors.muted }}>
          {query.trim() ? `No one found for "${query.trim()}".` : 'No subscribers in this list.'}
        </Text>
      ) : null}
      {query.trim() && shown.length > 0 ? (
        <Text style={{ color: colors.muted, fontSize: 13 }}>
          {shown.length} found
        </Text>
      ) : null}
      {shown.map((r) => (
        <SubscriberRow key={r.id} row={r} onOpen={() => setOpen(r)} />
      ))}

      <Button title="Refresh" variant="outline" onPress={load} loading={busy} />
    </Screen>
  );
}

/** Cellphone digits without the 0 or 27 in front, so 082…, +27 82… and 27 82… all match. */
const phoneDigits = (t: string) => t.replace(/\D/g, '').replace(/^(27|0)/, '');

/**
 * Every word typed must appear in the plan holder's or a family member's name,
 * cellphone number or email (so "jan 0825" finds Jan with 082 5…).
 */
export function matchesSearch(r: Pick<Subscriber, 'holder_name' | 'holder_phone' | 'holder_email' | 'members_text'>, query: string): boolean {
  const text = [r.holder_name, r.holder_phone, r.holder_email, r.members_text].filter(Boolean).join(' ').toLowerCase();
  const phones = (text.match(/\+?\d[\d\s-]{5,}\d/g) ?? []).map(phoneDigits);
  // Only digits, spaces, + or - typed: treat it as one cellphone number.
  if (/^[\d\s+\-]+$/.test(query.trim())) {
    const d = phoneDigits(query);
    return d.length >= 3 && phones.some((p) => p.includes(d));
  }
  return query
    .toLowerCase()
    .split(/\s+/)
    .filter(Boolean)
    .every((word) => {
      if (text.includes(word)) return true;
      const d = phoneDigits(word);
      return /^\d{3,}$/.test(word.replace(/[+\-]/g, '')) && d.length >= 3 && phones.some((p) => p.includes(d));
    });
}

function Stat({ label, value, color }: { label: string; value: number; color: string }) {
  return (
    <Card style={{ flex: 1, alignItems: 'center', paddingVertical: 12, gap: 2 }}>
      <Text style={{ color, fontSize: 26, fontWeight: '900' }}>{value}</Text>
      <Text style={{ color: colors.muted, fontSize: 12, textAlign: 'center' }}>{label}</Text>
    </Card>
  );
}

function SubscriberRow({ row, onOpen }: { row: Subscriber; onOpen: () => void }) {
  const g = GROUP_COLORS[groupOf(row.state)];
  const lines: string[] = [];
  if (row.pf_paused_at)
    lines.push(`PayFast PAUSED the debit order on ${longDate(row.pf_paused_at)}${row.pf_status_reason ? ` – ${row.pf_status_reason}` : ''}`);
  if (row.payment_failed_at) lines.push(`Payment failed on ${longDate(row.payment_failed_at)}`);
  if (row.last_payment_at) lines.push(`Last paid ${rand(row.last_payment_amount)} on ${longDate(row.last_payment_at)}`);
  else lines.push('No payment received yet');
  if (row.paid_until) lines.push(`Paid until ${longDate(row.paid_until)}`);
  if (row.next_billing_date && row.state !== 'cancelled' && row.state !== 'cancelled_paid')
    lines.push(`Next debit order ${longDate(row.next_billing_date)}${row.monthly_amount ? ` · ${rand(row.monthly_amount)}` : ''}`);
  if (row.cancelled_at) lines.push(`Cancelled on ${longDate(row.cancelled_at)}`);
  if (row.debit_day) lines.push(`Debit day: ${row.debit_day} of each month`);
  if (row.pf_checked_at && row.pf_status) lines.push(`PayFast check ${longDate(row.pf_checked_at)}: ${row.pf_status}`);
  if (row.card_expiry) lines.push(`Card expires ${longDate(row.card_expiry).replace(/^\d+ /, '')}`);

  return (
    <Card style={{ gap: 6 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
        <Text style={{ color: colors.text, fontSize: 17, fontWeight: '700', flex: 1 }}>{row.holder_name}</Text>
        <View style={{ backgroundColor: g.bg, borderRadius: 8, paddingHorizontal: 8, paddingVertical: 4 }}>
          <Text style={{ color: g.fg, fontSize: 11, fontWeight: '800', letterSpacing: 0.5 }}>
            {row.pf_paused_at ? STATE_TEXT.paused : STATE_TEXT[row.state] ?? row.label}
          </Text>
        </View>
      </View>
      <Text style={{ color: colors.muted, fontSize: 13 }}>
        {row.members} {row.members === 1 ? 'person' : 'people'} on the plan
        {row.payfast_mode === 'sandbox' ? ' · sandbox payments' : ''}
      </Text>
      {lines.map((l) => (
        <Text key={l} style={{ color: colors.text, fontSize: 14 }}>
          {l}
        </Text>
      ))}
      <Button title="View personal details" variant="outline" onPress={onOpen} />
      {row.holder_phone ? (
        <Pressable
          accessibilityRole="button"
          onPress={() => Linking.openURL(`tel:${row.holder_phone}`).catch(() => undefined)}
          style={{ paddingVertical: 6 }}
        >
          <Text style={{ color: colors.goldText, fontWeight: '700' }}>Call {row.holder_phone}</Text>
        </Pressable>
      ) : null}
    </Card>
  );
}
