import React, { useCallback, useEffect, useState } from 'react';
import { Alert, Pressable, Share, Text, TextInput, View } from 'react-native';
import { colors } from '../theme';
import {
  FamilyInvite,
  FamilyMember,
  FamilyPlan,
  RELATIONSHIP_CHOICES,
  Relationship,
  cancelFamilyInvite,
  familyNewPinCode,
  friendlyError,
  getFamily,
  inviteFamilyMember,
  joinFamily,
  leaveFamily,
  relationshipLabel,
  removeFamilyMember,
  startFamily,
} from '../lib/data';
import { downloadUrl } from '../lib/supabase';
import { Body, Button, Card, Chip, ErrorText, Field } from './ui';

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const shortDate = (iso: string) => {
  const d = new Date(iso);
  return `${d.getDate()} ${MONTHS[d.getMonth()]}`;
};

function inviteMessage(inv: FamilyInvite, holderName?: string) {
  const link = downloadUrl && !/\.apk$/i.test(downloadUrl)
    ? `${downloadUrl}?code=${encodeURIComponent(inv.code)}`
    : downloadUrl;
  return (
    `Hi ${inv.name}, ${holderName ? `${holderName} has` : 'I have'} added you to a FireQuest family plan.\n\n` +
    (link ? `1. Get the FireQuest app (Android):\n${link}\n` : `1. Install the FireQuest app.\n`) +
    `2. Open FireQuest and tap "I'm a family member", then "First time, or got a new code?"\n` +
    `3. Enter your cellphone number ${inv.phone}, this code: ${inv.code}, and choose a 6-digit PIN.\n\n` +
    `You don't need an email address. Next time, sign in with your cellphone number and PIN.\n` +
    `This invite works once, only for your number, and expires on ${shortDate(inv.expires_at)}.`
  );
}

/**
 * Account-screen card. A person is either on no plan, the plan holder, or a member.
 * Only the holder can add people; each person gets their own one-time code.
 */
export function FamilyCard({
  testMode,
  version = 0,
  onChanged,
}: {
  testMode: boolean;
  /** Changes when the subscription changed elsewhere (e.g. after paying), to reload. */
  version?: number;
  onChanged?: () => void;
}) {
  const [plan, setPlan] = useState<FamilyPlan | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState('');
  const [mode, setMode] = useState<'idle' | 'join' | 'add'>('idle');
  const [code, setCode] = useState('');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [relationship, setRelationship] = useState<Exclude<Relationship, 'holder'> | null>(null);

  const run = useCallback(async (key: string, fn: () => Promise<FamilyPlan>) => {
    setError('');
    setBusy(key);
    try {
      const next = await fn();
      setPlan(next);
      if (key !== 'load') onChanged?.();
      return next;
    } catch (e) {
      setError(friendlyError(e));
      return null;
    } finally {
      setBusy(null);
    }
  }, [onChanged]);

  useEffect(() => {
    run('load', getFamily);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [version]);

  // Take the invite off the screen at once, then cancel it on the server.
  // If that fails, reload so the screen shows what is really there, with the reason.
  const cancelInvite = async (inv: FamilyInvite) => {
    setPlan((p) => (p ? { ...p, invites: p.invites.filter((i) => i.id !== inv.id), spots_left: p.spots_left + 1 } : p));
    const next = await run(`cancel-${inv.id}`, () => cancelFamilyInvite(inv.id));
    if (!next) {
      try {
        setPlan(await getFamily());
      } catch {
        /* keep the error from the cancel */
      }
    }
  };

  const share = (inv: FamilyInvite) =>
    Share.share({ message: inviteMessage(inv, plan?.owner_name) }).catch(() => undefined);

  if (!plan) {
    return (
      <Card>
        <Text style={heading}>Family plan</Text>
        {error ? <ErrorText>{error}</ErrorText> : <Body>Loading…</Body>}
      </Card>
    );
  }

  // ------------------------------------------------------------ not on a plan
  if (!plan.in_plan) {
    const confirmStart = () =>
      Alert.alert(
        'Start a family plan?',
        `You will be the plan holder and can add up to ${plan.max_members - 1} family members. ` +
          'During testing this is free. You can try a PayFast test payment under Subscription.',
        [
          { text: 'Cancel', style: 'cancel' },
          { text: 'Start plan', onPress: () => run('start', startFamily) },
        ],
      );
    return (
      <Card>
        <Text style={heading}>Family plan</Text>
        <Body>You are not on a family plan yet.</Body>
        {mode === 'join' ? (
          <View style={{ gap: 10 }}>
            <Text style={label}>Code from your invite message</Text>
            <TextInput
              accessibilityLabel="Invite code"
              value={code}
              onChangeText={(t) => setCode(t.toUpperCase())}
              autoCapitalize="characters"
              autoCorrect={false}
              maxLength={8}
              placeholder="e.g. K7M4PX"
              placeholderTextColor={colors.faint}
              style={codeInput}
            />
            <Button
              title="Join family plan"
              loading={busy === 'join'}
              onPress={async () => {
                if (code.trim().length < 6) return setError('Enter the 6-character code from your invite.');
                if (await run('join', () => joinFamily(code))) {
                  setMode('idle');
                  setCode('');
                }
              }}
            />
            <Button title="Cancel" variant="plain" onPress={() => { setMode('idle'); setError(''); }} />
          </View>
        ) : (
          <View style={{ gap: 10 }}>
            <Button title="I have an invite code" onPress={() => setMode('join')} />
            {testMode ? (
              <Button title="Start a free test family plan" variant="outline" loading={busy === 'start'} onPress={confirmStart} />
            ) : (
              <Body>To start your own family plan, subscribe under Subscription above.</Body>
            )}
          </View>
        )}
        <ErrorText>{error}</ErrorText>
      </Card>
    );
  }

  // Family member forgot their PIN: a new one-time code they use under "I'm a family member".
  const newPinCode = async (m: FamilyMember) => {
    setBusy(`pin-${m.user_id}`);
    setError('');
    try {
      const r = await familyNewPinCode(m.user_id);
      const msg =
        `Hi ${m.name || ''}, here is your new FireQuest sign-in code: ${r.code}\n\n` +
        `Open FireQuest, tap "I'm a family member", then "First time, or got a new code?". ` +
        `Enter your cellphone number, this code and a new 6-digit PIN. The code expires on ${shortDate(r.expires_at)}.`;
      Alert.alert('New sign-in code', `${m.name || 'This person'}'s code: ${r.code}\n\nSend it to them so they can choose a new PIN.`, [
        { text: 'Close', style: 'cancel' },
        { text: 'Send', onPress: () => Share.share({ message: msg }).catch(() => undefined) },
      ]);
    } catch (e) {
      setError(friendlyError(e));
    } finally {
      setBusy(null);
    }
  };

  const memberRow = (m: FamilyMember, canRemove: boolean) => (
    <View key={m.user_id} style={row}>
      <View style={{ flex: 1 }}>
        <Text style={rowName}>
          {m.name || m.email || 'Member'}
          {m.is_me ? ' (you)' : ''}
        </Text>
        <Text style={rowSub}>{relationshipLabel(m.relationship, m.role)}</Text>
      </View>
      {canRemove && !m.is_me && !m.email && (
        <Pressable
          accessibilityRole="button"
          accessibilityLabel={`New sign-in code for ${m.name}`}
          onPress={() => newPinCode(m)}
          style={smallButton}
        >
          <Text style={{ color: colors.goldText, fontWeight: '700' }}>
            {busy === `pin-${m.user_id}` ? 'Wait…' : 'New code'}
          </Text>
        </Pressable>
      )}
      {canRemove && !m.is_me && (
        <Pressable
          accessibilityRole="button"
          accessibilityLabel={`Remove ${m.name}`}
          onPress={() =>
            Alert.alert('Remove from family plan?', `${m.name || 'This person'} will no longer be on your plan.`, [
              { text: 'Cancel', style: 'cancel' },
              { text: 'Remove', style: 'destructive', onPress: () => run(`remove-${m.user_id}`, () => removeFamilyMember(m.user_id)) },
            ])
          }
          style={smallButton}
        >
          <Text style={{ color: colors.redText, fontWeight: '700' }}>
            {busy === `remove-${m.user_id}` ? 'Removing…' : 'Remove'}
          </Text>
        </Pressable>
      )}
    </View>
  );

  // ------------------------------------------------------------ member
  if (!plan.is_owner) {
    const holder = plan.owner_name || 'the plan holder';
    return (
      <Card>
        <Text style={heading}>Family plan</Text>
        <Body>You are on {holder}'s family plan. Only {holder} can add or remove people.</Body>
        <View style={{ gap: 8 }}>{plan.members.map((m) => memberRow(m, false))}</View>
        <Button
          title="Leave family plan"
          variant="outline"
          loading={busy === 'leave'}
          onPress={() =>
            Alert.alert('Leave this family plan?', `You will no longer be on ${holder}'s plan.`, [
              { text: 'Cancel', style: 'cancel' },
              { text: 'Leave', style: 'destructive', onPress: () => run('leave', leaveFamily) },
            ])
          }
        />
        <ErrorText>{error}</ErrorText>
      </Card>
    );
  }

  // ------------------------------------------------------------ plan holder
  const resetForm = () => {
    setMode('idle');
    setName('');
    setPhone('');
    setRelationship(null);
    setError('');
  };

  const addPerson = async () => {
    if (!name.trim()) return setError('Enter their name.');
    if (phone.replace(/\D/g, '').length < 9) return setError('Enter their cellphone number, for example 082 123 4567.');
    const rel = relationship;
    if (!rel) return setError('Choose how they are related to you.');
    const next = await run('add', () => inviteFamilyMember(name.trim(), phone.trim(), rel));
    if (!next) return;
    resetForm();
    const inv = next.invites.find((i) => i.id === next.new_invite_id);
    if (inv) Share.share({ message: inviteMessage(inv, next.owner_name) }).catch(() => undefined);
  };

  return (
    <Card>
      <Text style={heading}>
        Your family plan · {plan.members.length} of {plan.max_members} people
      </Text>
      <View style={{ gap: 8 }}>{plan.members.map((m) => memberRow(m, true))}</View>

      {plan.invites.length > 0 && (
        <View style={{ gap: 8 }}>
          <Text style={label}>Invites waiting</Text>
          {plan.invites.map((inv) => (
            <View key={inv.id} style={inviteBox}>
              <Text style={rowName}>
                {inv.name} · {relationshipLabel(inv.relationship)}
              </Text>
              <Text style={rowSub}>
                {inv.phone} · code {inv.code} · expires {shortDate(inv.expires_at)}
              </Text>
              <View style={{ flexDirection: 'row', gap: 16 }}>
                <Pressable accessibilityRole="button" onPress={() => share(inv)} style={smallButton}>
                  <Text style={{ color: colors.goldText, fontWeight: '700' }}>Send again</Text>
                </Pressable>
                <Pressable
                  accessibilityRole="button"
                  accessibilityLabel={`Cancel invite for ${inv.name}`}
                  onPress={() =>
                    Alert.alert('Cancel this invite?', `${inv.name}'s code will stop working.`, [
                      { text: 'Keep it', style: 'cancel' },
                      { text: 'Cancel invite', style: 'destructive', onPress: () => cancelInvite(inv) },
                    ])
                  }
                  style={smallButton}
                >
                  <Text style={{ color: colors.redText, fontWeight: '700' }}>
                    {busy === `cancel-${inv.id}` ? 'Cancelling…' : 'Cancel'}
                  </Text>
                </Pressable>
              </View>
            </View>
          ))}
          <ErrorText>{error}</ErrorText>
        </View>
      )}

      {mode === 'add' ? (
        <View style={{ gap: 4 }}>
          <Field label="Their name" value={name} onChangeText={setName} autoCapitalize="words" maxLength={80} />
          <Field
            label="Their cellphone number"
            value={phone}
            onChangeText={setPhone}
            keyboardType="phone-pad"
            placeholder="082 123 4567"
            maxLength={20}
          />
          <Text style={label}>They are your…</Text>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 8 }}>
            {RELATIONSHIP_CHOICES.map((r) => (
              <Chip key={r.value} label={r.label} selected={relationship === r.value} onPress={() => setRelationship(r.value)} />
            ))}
          </View>
          <Body>
            They must create their FireQuest account with this same cellphone number. The invite works once and expires
            after 7 days.
          </Body>
          <Button title="Add and send invite" loading={busy === 'add'} onPress={addPerson} style={{ marginTop: 8 }} />
          <Button title="Cancel" variant="plain" onPress={resetForm} />
        </View>
      ) : plan.spots_left > 0 ? (
        <View style={{ gap: 6 }}>
          <Button title="Add a family member" onPress={() => { setError(''); setMode('add'); }} />
          <Text style={[rowSub, { textAlign: 'center' }]}>
            {plan.spots_left} {plan.spots_left === 1 ? 'place' : 'places'} left. Only people you add can join.
          </Text>
        </View>
      ) : (
        <Body>Your plan is full. Remove someone or cancel an invite to add another person.</Body>
      )}

      <ErrorText>{error}</ErrorText>
    </Card>
  );
}

const heading = { color: colors.goldText, fontWeight: '700' as const, fontSize: 15 };
const label = { color: '#CFC9BD', fontSize: 13, fontWeight: '600' as const };
const row = { flexDirection: 'row' as const, alignItems: 'center' as const, gap: 10, minHeight: 44 };
const rowName = { color: colors.text, fontSize: 15, fontWeight: '600' as const };
const rowSub = { color: colors.muted, fontSize: 12 };
const smallButton = { minHeight: 44, justifyContent: 'center' as const, paddingHorizontal: 4 };
const inviteBox = {
  padding: 12,
  borderRadius: 12,
  borderWidth: 1,
  borderColor: colors.border,
  backgroundColor: colors.bg,
  gap: 2,
};
const codeInput = {
  minHeight: 52,
  borderRadius: 12,
  borderWidth: 1,
  borderColor: colors.border,
  backgroundColor: colors.bg,
  color: colors.text,
  fontSize: 22,
  letterSpacing: 4,
  textAlign: 'center' as const,
};
