import React, { useCallback, useEffect, useState } from 'react';
import { ActivityIndicator, Alert, AppState, Pressable, Text, View } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { colors } from '../theme';
import { friendlyError } from '../lib/data';
import { supabase } from '../lib/supabase';
import {
  cardUpdated,
  setDebitDay,
  ATTENTION_STATES,
  Billing,
  Tone,
  billingTest,
  getBilling,
  holderSummary,
  longDate,
  openCardUpdate,
  openCheckout,
  rand,
} from '../lib/billing';
import { Body, Button, Card, Chip, ErrorText, Field } from './ui';

/** Debit days offered: around the usual paydays. */
const DEBIT_DAYS = [1, 7, 15, 20, 25, 28];
const ordinal = (n: number) => `${n}${n % 10 === 1 && n !== 11 ? 'st' : n % 10 === 2 && n !== 12 ? 'nd' : n % 10 === 3 && n !== 13 ? 'rd' : 'th'}`;
import { MyCard, daysToCardExpiry, expiryLabel, getMyCard, saveCardExpiry, scheduleCardReminders } from '../lib/reminders';

const TONE: Record<Tone, { fg: string; bg: string; border: string; icon: React.ComponentProps<typeof MaterialCommunityIcons>['name'] }> = {
  ok: { fg: colors.green, bg: colors.greenDeep, border: '#245C3B', icon: 'check-circle' },
  warn: { fg: colors.goldText, bg: colors.goldDeep, border: colors.gold, icon: 'alert' },
  bad: { fg: colors.danger, bg: colors.dangerDeep, border: '#7A2A2E', icon: 'alert-octagon' },
  test: { fg: colors.goldText, bg: colors.goldDeep, border: colors.borderStrong, icon: 'flask-outline' },
};

/**
 * Account-screen card: the family plan's PayFast subscription.
 * The plan holder can subscribe, fix a failed payment or change card.
 * Family members only see who pays.
 */
export function BillingCard({ version, onChanged }: { version: number; onChanged: () => void }) {
  const [billing, setBilling] = useState<Billing | null | undefined>(undefined);
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState('');
  const [showTests, setShowTests] = useState(false);
  const [card, setCard] = useState<MyCard | null>(null);
  const [editExpiry, setEditExpiry] = useState(false);
  const [expiryText, setExpiryText] = useState('');
  // Bumped after "Pay" and whenever the app comes back to the front: checks PayFast again for 3 minutes.
  const [pollRound, setPollRound] = useState(0);

  const load = useCallback(async () => {
    try {
      setBilling(await getBilling());
      getMyCard().then(setCard).catch(() => undefined);
    } catch (e) {
      setError(friendlyError(e));
      setBilling((cur) => (cur === undefined ? null : cur));
    }
  }, []);

  useEffect(() => {
    load();
  }, [load, version]);

  // Back from PayFast: check again.
  // After "Update card details" the client is on PayFast's page. When they come back,
  // FireQuest unpauses the debit order and checks it with PayFast.
  const [cardPageOpen, setCardPageOpen] = useState(false);
  useEffect(() => {
    const sub = AppState.addEventListener('change', (s) => {
      if (s !== 'active') return;
      if (cardPageOpen) {
        setCardPageOpen(false);
        cardUpdated()
          .catch(() => undefined)
          .finally(() => {
            load();
            onChanged();
          });
      } else load();
      setPollRound((r) => r + 1);
    });
    return () => sub.remove();
  }, [load, cardPageOpen, onChanged]);

  const chooseDay = (day: number) => {
    if (!billing || day === billing.debit_day) return;
    Alert.alert(
      `Debit on the ${ordinal(day)}?`,
      `From now on your ${rand(billing.monthly_amount ?? billing.price)} is taken on the ${ordinal(day)} of each month. ` +
        'If your next debit moves later, the extra days are free – you stay covered.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Change date',
          onPress: async () => {
            setError('');
            setBusy('day');
            try {
              const a = await setDebitDay(day);
              await load();
              onChanged();
              if (a.run_date) Alert.alert('Debit date changed', `Your next debit is on ${longDate(a.run_date)}.`);
            } catch (e) {
              setError(friendlyError(e));
            } finally {
              setBusy(null);
            }
          },
        },
      ],
    );
  };

  // While PayFast is confirming a payment, check every 5 seconds (for 3 minutes each round).
  const pending = Boolean(billing?.pending_since);
  useEffect(() => {
    if (!pending) return;
    const started = Date.now();
    const timer = setInterval(() => {
      if (Date.now() - started > 180000) {
        clearInterval(timer);
        return;
      }
      load();
    }, 5000);
    return () => clearInterval(timer);
  }, [pending, pollRound, load]);

  const pay = async () => {
    setError('');
    setBusy('pay');
    try {
      await openCheckout();
      await load();
      setPollRound((r) => r + 1);
      onChanged();
    } catch (e) {
      setError(friendlyError(e));
    } finally {
      setBusy(null);
    }
  };

  const changeCard = async () => {
    setError('');
    setBusy('card');
    try {
      const answer = await openCardUpdate();
      if (answer.unavailable && answer.message) Alert.alert('Test system', answer.message);
      if (answer.url) setCardPageOpen(true);
    } catch (e) {
      setError(friendlyError(e));
    } finally {
      setBusy(null);
    }
  };

  const runTest = async (what: 'failed' | 'late' | 'lapsed' | 'paused' | 'reset') => {
    setError('');
    setBusy(`test-${what}`);
    try {
      setBilling(await billingTest(what));
      onChanged();
    } catch (e) {
      setError(friendlyError(e));
    } finally {
      setBusy(null);
    }
  };

  // Database not updated for payments yet: keep the old line.
  if (billing === null && !error) {
    return (
      <Card>
        <Text style={heading}>Subscription</Text>
        <Body>Managed by FireQuest (PayFast).</Body>
      </Card>
    );
  }
  if (!billing) {
    return (
      <Card>
        <Text style={heading}>Subscription</Text>
        {error ? <ErrorText>{error}</ErrorText> : <ActivityIndicator color={colors.gold} />}
        {error ? <Button title="Try again" variant="outline" onPress={() => { setError(''); load(); }} /> : null}
      </Card>
    );
  }

  // ------------------------------------------------------------ family member
  if (billing.in_plan && !billing.is_owner) {
    return (
      <Card>
        <Text style={heading}>Subscription</Text>
        <Body>Your family plan is paid by {billing.owner_name || 'the plan holder'}. You never need to pay anything yourself.</Body>
      </Card>
    );
  }

  // ------------------------------------------------------------ plan holder (or no plan yet)
  const s = holderSummary(billing);
  const t = TONE[s.tone];
  const needsAction = ATTENTION_STATES.includes(billing.state);
  const sandbox = billing.test_mode;

  let payTitle = 'Pay now with PayFast';
  if (billing.state === 'none' || billing.state === 'unpaid') payTitle = 'Subscribe with PayFast';
  if (billing.state === 'test') payTitle = 'Try a PayFast test payment';
  if (billing.state === 'cancelled' || billing.state === 'cancelled_paid') payTitle = 'Restart my subscription';
  const showPay = billing.state !== 'active';
  const showCard = billing.has_debit_order && ['active', 'payment_failed', 'overdue'].includes(billing.state);

  const confirmPay = () => {
    const amount = rand(billing.price);
    const lines = [
      `${amount} is paid now and then every month by debit order, through PayFast's secure page.`,
      billing.has_debit_order ? 'Your old debit order is stopped automatically, so you never pay twice.' : '',
      sandbox ? 'TEST MODE: this is PayFast\'s test system. No real money moves.' : '',
    ].filter(Boolean);
    Alert.alert(payTitle, lines.join('\n\n'), [
      { text: 'Not now', style: 'cancel' },
      { text: 'Continue to PayFast', onPress: pay },
    ]);
  };

  return (
    <Card>
      <Text style={heading}>Subscription</Text>

      <View style={{ flexDirection: 'row', gap: 10, padding: 12, borderRadius: 12, backgroundColor: t.bg, borderWidth: 1, borderColor: t.border }}>
        <MaterialCommunityIcons name={t.icon} size={22} color={t.fg} />
        <View style={{ flex: 1, gap: 4 }}>
          <Text style={{ color: t.fg, fontSize: 16, fontWeight: '800' }}>{s.title}</Text>
          <Text style={{ color: colors.text, fontSize: 14, lineHeight: 20 }}>{s.text}</Text>
        </View>
      </View>

      {pending && billing.state !== 'active' ? (
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
          <ActivityIndicator color={colors.gold} />
          <Text style={{ color: colors.muted, fontSize: 14, flex: 1 }}>
            Waiting for PayFast to confirm your payment. This usually takes less than a minute.
          </Text>
        </View>
      ) : null}

      {billing.last_payment_at ? (
        <Text style={{ color: colors.muted, fontSize: 13 }}>
          Last payment: {rand(billing.last_payment_amount)} on {longDate(billing.last_payment_at)}
        </Text>
      ) : null}

      {showPay && (
        <Button
          title={payTitle}
          variant={needsAction ? 'red' : 'gold'}
          loading={busy === 'pay'}
          disabled={busy !== null}
          onPress={confirmPay}
        />
      )}
      {showPay && needsAction && billing.has_debit_order ? (
        <Text style={{ color: colors.muted, fontSize: 13, lineHeight: 18 }}>
          "Pay now" pays this month straight away with any card, and starts a new monthly debit order on that card.
        </Text>
      ) : null}
      {showCard && (
        <Button
          title="Update card details"
          variant="outline"
          loading={busy === 'card'}
          disabled={busy !== null}
          onPress={changeCard}
        />
      )}
      {billing.has_debit_order && billing.state !== 'cancelled_paid' ? (
        <View style={{ gap: 8 }}>
          <Text style={{ color: colors.text, fontSize: 14, fontWeight: '700' }}>Debit order date</Text>
          <Text style={{ color: colors.muted, fontSize: 13, lineHeight: 18 }}>
            Choose a day just after your payday, so there is always money in the account.
            {billing.debit_day ? ` Now: the ${ordinal(billing.debit_day)} of each month.` : ''}
          </Text>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
            {DEBIT_DAYS.map((d) => (
              <Chip key={d} label={`${ordinal(d)}`} selected={billing.debit_day === d} onPress={() => chooseDay(d)} />
            ))}
          </View>
          {busy === 'day' ? <ActivityIndicator color={colors.gold} /> : null}
        </View>
      ) : null}
      {card?.is_owner && card.has_debit_order ? (
        <CardExpiry
          card={card}
          editing={editExpiry || Boolean(card.ask)}
          text={expiryText}
          busy={busy === 'expiry'}
          onEdit={() => {
            setExpiryText(expiryLabel(card.card_expiry).replace(/\/\d\d(\d\d)$/, '/$1'));
            setEditExpiry(true);
          }}
          onText={setExpiryText}
          onSave={async () => {
            const m = /^\s*(\d{1,2})\s*\/\s*(\d{2}|\d{4})\s*$/.exec(expiryText);
            if (!m) {
              setError('Type the expiry date as it is on your card, for example 08/28.');
              return;
            }
            setError('');
            setBusy('expiry');
            try {
              const saved = await saveCardExpiry(Number(m[1]), Number(m[2]));
              setCard(saved);
              setEditExpiry(false);
              const uid = (await supabase.auth.getSession()).data.session?.user.id;
              if (uid) scheduleCardReminders(uid, saved).catch(() => undefined);
            } catch (e) {
              setError(friendlyError(e));
            } finally {
              setBusy(null);
            }
          }}
        />
      ) : null}
      {billing.state === 'none' && (
        <Text style={{ color: colors.muted, fontSize: 13, lineHeight: 18 }}>
          Joining a family member's plan instead? Use the invite code under Family plan below.
        </Text>
      )}
      {sandbox && (
        <Text style={{ color: colors.goldText, fontSize: 12, lineHeight: 17 }}>
          TEST MODE: payments go to PayFast's test system (sandbox). No real money moves.
        </Text>
      )}

      <ErrorText>{error}</ErrorText>

      {sandbox && billing.in_plan && billing.mode !== 'live' && (
        <View style={{ gap: 8 }}>
          <Pressable accessibilityRole="button" onPress={() => setShowTests((v) => !v)} style={{ minHeight: 44, justifyContent: 'center' }}>
            <Text style={{ color: colors.goldText, fontWeight: '700' }}>
              {showTests ? 'Hide payment tests' : 'Test: pretend a payment problem'}
            </Text>
          </Pressable>
          {showTests && (
            <View style={{ gap: 8 }}>
              <Body>Only for testing. These change your test plan so you can see what a client sees.</Body>
              <TestButton title="This month's debit failed" busy={busy === 'test-failed'} onPress={() => runTest('failed')} />
              <TestButton title="PayFast paused the debit order" busy={busy === 'test-paused'} onPress={() => runTest('paused')} />
              <TestButton title="Payment is late (grace days)" busy={busy === 'test-late'} onPress={() => runTest('late')} />
              <TestButton title="Not paid at all" busy={busy === 'test-lapsed'} onPress={() => runTest('lapsed')} />
              <TestButton title="Back to free test plan" busy={busy === 'test-reset'} onPress={() => runTest('reset')} />
            </View>
          )}
        </View>
      )}
    </Card>
  );
}

/** The card's expiry (MM/YY only – never the card number), so FireQuest can remind the holder in time. */
function CardExpiry({
  card,
  editing,
  text,
  busy,
  onEdit,
  onText,
  onSave,
}: {
  card: MyCard;
  editing: boolean;
  text: string;
  busy: boolean;
  onEdit: () => void;
  onText: (t: string) => void;
  onSave: () => void;
}) {
  const days = daysToCardExpiry(card.card_expiry);
  if (!editing && card.card_expiry) {
    const soon = days !== null && days <= 30;
    return (
      <Pressable accessibilityRole="button" onPress={onEdit} style={{ minHeight: 44, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
        <Text style={{ color: soon ? colors.goldText : colors.muted, fontSize: 14, fontWeight: soon ? '700' : '400' }}>
          Card expires: {expiryLabel(card.card_expiry)}
          {soon ? (days !== null && days <= 0 ? ' – expired, update your card' : ' – update your card soon') : ''}
        </Text>
        <Text style={{ color: colors.goldText, fontWeight: '700' }}>Change</Text>
      </Pressable>
    );
  }
  return (
    <View style={{ gap: 6, padding: 12, borderRadius: 12, backgroundColor: colors.surfaceRaised }}>
      <Text style={{ color: colors.text, fontWeight: '700' }}>When does your card expire?</Text>
      <Body>
        Type the expiry date that is printed on the card you pay with (only the month and year – never the card
        number). We remind you a month and a week before it expires.
      </Body>
      <Field label="Expiry (MM/YY)" value={text} onChangeText={onText} placeholder="08/28" keyboardType="numbers-and-punctuation" maxLength={7} />
      <Button title="Save" onPress={onSave} loading={busy} />
    </View>
  );
}

function TestButton({ title, busy, onPress }: { title: string; busy: boolean; onPress: () => void }) {
  return <Button title={busy ? 'Working…' : title} variant="outline" onPress={onPress} disabled={busy} />;
}

const heading = { color: colors.goldText, fontWeight: '700' as const, fontSize: 15 };
