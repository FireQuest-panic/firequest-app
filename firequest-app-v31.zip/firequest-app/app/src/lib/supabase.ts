import AsyncStorage from '@react-native-async-storage/async-storage';
import { createClient } from '@supabase/supabase-js';
import { AppState } from 'react-native';
import config from '../config.json';

export const isConfigured = Boolean(config.supabaseUrl && config.supabaseKey);
export const controlRoomPhoneFromConfig: string = config.controlRoomPhone || '';
/** Permanent link to the newest Android app, used in family invites. */
export const downloadUrl: string = (config as { downloadUrl?: string }).downloadUrl || '';
/** Project address and public app key, for the few calls made without the login client. */
export const supabaseUrl: string = config.supabaseUrl || '';
export const supabaseKey: string = config.supabaseKey || '';

export const supabase = createClient(
  config.supabaseUrl || 'https://not-configured.supabase.co',
  config.supabaseKey || 'not-configured',
  {
    auth: {
      storage: AsyncStorage,
      autoRefreshToken: true,
      persistSession: true,
      detectSessionInUrl: false,
    },
  },
);

// Keep the login fresh only while the app is open.
AppState.addEventListener('change', (state) => {
  if (state === 'active') {
    supabase.auth.startAutoRefresh();
  } else {
    supabase.auth.stopAutoRefresh();
  }
});
