// The Smart Life smoke-alarm reader (SmokeAlarmListener) needs Android "notification access".
// Google Play Protect blocks apps with that from being installed outside the Play Store, so
// only the control-room version (FQ_CONTROL_ROOM=1) keeps it. The client app removes it.
const { withAndroidManifest } = require('expo/config-plugins');

const SERVICE = 'za.co.firequest.crash.SmokeAlarmListener';

module.exports = function withSmokeListener(config, { keep } = {}) {
  if (keep) return config;
  return withAndroidManifest(config, (c) => {
    const manifest = c.modResults.manifest;
    manifest.$ = manifest.$ || {};
    manifest.$['xmlns:tools'] = 'http://schemas.android.com/tools';
    const app = manifest.application && manifest.application[0];
    if (app) {
      app.service = (app.service || []).filter((s) => s.$['android:name'] !== SERVICE);
      app.service.push({ $: { 'android:name': SERVICE, 'tools:node': 'remove' } });
    }
    return c;
  });
};
