// Expo configuration for the FireQuest Panic app.
// BUILD_NUMBER is set by the GitHub build so every new APK installs over the old one.
const buildNumber = parseInt(process.env.BUILD_NUMBER || '1', 10);
// FQ_CONTROL_ROOM=1 builds "FireQuest Control Room": the same app plus the Smart Life
// smoke-alarm reader (see plugins/withSmokeListener.js). Clients get the normal app.
const controlRoom = process.env.FQ_CONTROL_ROOM === '1';

module.exports = {
  expo: {
    name: controlRoom ? 'FireQuest Control Room' : 'FireQuest',
    slug: 'firequest-panic',
    // Lets the PayFast "thank you" page open the app again (firequest://billing).
    scheme: 'firequest',
    version: '0.1.0',
    orientation: 'portrait',
    icon: './assets/icon.png',
    userInterfaceStyle: 'dark',
    backgroundColor: '#0F0F10',
    newArchEnabled: true,
    android: {
      package: 'za.co.firequest.panic',
      versionCode: buildNumber,
      adaptiveIcon: {
        foregroundImage: './assets/adaptive-icon.png',
        backgroundColor: '#0F0F10',
      },
      permissions: ['ACCESS_COARSE_LOCATION', 'ACCESS_FINE_LOCATION', 'VIBRATE'],
      // The alarm only plays sound; FireQuest never records audio.
      blockedPermissions: ['android.permission.RECORD_AUDIO'],
      edgeToEdgeEnabled: true,
      // Keeps the crash-detection device key (and login) off cloud backups and other phones.
      allowBackup: false,
    },
    extra: { controlRoomBuild: controlRoom },
    plugins: [
      ['./plugins/withSmokeListener', { keep: controlRoom }],
      '@react-native-community/datetimepicker',
      [
        'expo-image-picker',
        {
          cameraPermission: 'FireQuest uses the camera for your profile selfie, so responders can recognise you.',
          photosPermission: 'FireQuest lets you choose a photo of yourself for your profile.',
          microphonePermission: false,
        },
      ],
      // Birthday wishes and card-expiry reminders (scheduled on the phone).
      ['expo-notifications', { color: '#D42F35' }],
      [
        'expo-splash-screen',
        { image: './assets/splash-logo.png', imageWidth: 220, backgroundColor: '#0F0F10' },
      ],
      [
        'expo-location',
        {
          locationWhenInUsePermission:
            'FireQuest uses your location to send responders to you when you raise an alert.',
          locationAlwaysAndWhenInUsePermission:
            'FireQuest uses your location in the background for automatic crash detection while you drive.',
          isAndroidBackgroundLocationEnabled: true,
          isAndroidForegroundServiceEnabled: true,
        },
      ],
    ],
  },
};
