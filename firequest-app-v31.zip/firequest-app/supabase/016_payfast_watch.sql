-- =====================================================================
-- v26: keep debit orders running.
-- * Once a day per plan, the "payfast" server function asks PayFast for the
--   debit order's status (ACTIVE / PAUSED / CANCELLED), the reason and the next
--   debit date, and stores it here. A PAUSED debit order counts as a failed payment.
-- * After the client updates their card, the server function unpauses it.
-- * The plan holder can choose the day of the month the R49 is taken.
-- =====================================================================

alter table public.subscriptions add column if not exists pf_status text;
alter table public.subscriptions add column if not exists pf_status_reason text;
alter table public.subscriptions add column if not exists pf_run_date date;
alter table public.subscriptions add column if not exists pf_checked_at timestamptz;
alter table public.subscriptions add column if not exists pf_check_error text;
alter table public.subscriptions add column if not exists pf_paused_at timestamptz;

-- Same as before, plus: a debit order PayFast has paused counts as a failed payment.
create or replace function private.billing_state(s public.subscriptions)
returns text language plpgsql stable set search_path = public as $$
declare
  v_test  boolean := coalesce((select test_mode from public.app_settings where id = 1), true);
  v_grace interval := make_interval(days => coalesce((select grace_days from public.app_settings where id = 1), 7));
  v_paid  timestamptz := private.billing_paid_until(s);
begin
  if s.id is null then return 'none'; end if;
  if v_paid is not null and v_paid > now() then
    if s.status = 'cancelled' then return 'cancelled_paid'; end if;
    if s.payment_failed_at is not null or s.pf_paused_at is not null then return 'payment_failed'; end if;
    return 'active';
  end if;
  if v_paid is not null and v_paid + v_grace > now() and s.status <> 'cancelled' then return 'overdue'; end if;
  if v_paid is null and s.status = 'test' and v_test then return 'test'; end if;
  if s.status = 'cancelled' then return 'cancelled'; end if;
  if v_paid is null then return 'unpaid'; end if;
  return 'lapsed';
end $$;

-- Debit orders due for a status check (not checked in the last 20 hours).
create or replace function private.payfast_to_check(p_limit int)
returns table (sub_id uuid, token text, mode text)
language sql security definer set search_path = public as $$
  select s.id, s.payfast_token, coalesce(s.payfast_mode, 'sandbox')
    from public.subscriptions s
   where s.status = 'active' and s.payfast_token is not null
     and (s.pf_checked_at is null or s.pf_checked_at < now() - interval '20 hours')
   order by s.pf_checked_at nulls first
   limit p_limit
$$;

-- Store what PayFast said. p_status null = the check itself failed (p_error says why).
create or replace function private.payfast_check_result(
  p_sub uuid, p_status text, p_reason text, p_run_date date, p_error text default null)
returns void language plpgsql security definer set search_path = public as $$
declare
  v_status text := upper(nullif(trim(coalesce(p_status, '')), ''));
begin
  if v_status is null then
    update public.subscriptions set pf_checked_at = now(), pf_check_error = left(p_error, 300) where id = p_sub;
    return;
  end if;
  update public.subscriptions set
    pf_status        = v_status,
    pf_status_reason = nullif(left(trim(coalesce(p_reason, '')), 300), ''),
    pf_run_date      = p_run_date,
    pf_checked_at    = now(),
    pf_check_error   = null,
    pf_paused_at     = case when v_status = 'PAUSED' then coalesce(pf_paused_at, now()) else null end
  where id = p_sub;
end $$;

-- Holder's debit order, for unpausing after a card update or changing the debit day.
create or replace function private.payfast_holder_order(p_uid uuid)
returns json language plpgsql stable security definer set search_path = public as $$
declare
  v_sub public.subscriptions;
begin
  select * into v_sub from public.subscriptions where owner_id = p_uid;
  if not found or v_sub.payfast_token is null or v_sub.status <> 'active' then
    raise exception 'There is no monthly debit order on your plan. Tap "Pay now" to set one up.';
  end if;
  return json_build_object('id', v_sub.id, 'token', v_sub.payfast_token, 'mode', coalesce(v_sub.payfast_mode, 'sandbox'),
                           'paused', v_sub.pf_paused_at is not null or v_sub.pf_status = 'PAUSED',
                           'failed', v_sub.payment_failed_at is not null,
                           'next_billing_date', v_sub.next_billing_date, 'billing_day', v_sub.billing_day);
end $$;

-- First date on day p_day (1–28) that is at least 2 days away and not before the current next debit.
create or replace function private.next_debit_on_day(p_day int, p_after date)
returns date language plpgsql immutable as $$
declare
  v_from date := greatest(coalesce(p_after, current_date), current_date + 2);
  v_d date := make_date(extract(year from v_from)::int, extract(month from v_from)::int, p_day);
begin
  if v_d < v_from then v_d := (v_d + interval '1 month')::date; end if;
  return v_d;
end $$;

-- After PayFast accepted the new debit date: store it, and cover the client up to it
-- (moving the date later must never make a paid-up plan look unpaid).
create or replace function private.payfast_debit_day_done(p_sub uuid, p_day int, p_run date)
returns void language sql security definer set search_path = public as $$
  update public.subscriptions set
    billing_day       = p_day,
    next_billing_date = p_run,
    pf_run_date       = p_run,
    paid_until        = greatest(paid_until, private.cover_until(p_run))
  where id = p_sub
$$;

revoke all on function private.payfast_to_check(int) from public, anon, authenticated;
revoke all on function private.payfast_check_result(uuid, text, text, date, text) from public, anon, authenticated;
revoke all on function private.payfast_holder_order(uuid) from public, anon, authenticated;
revoke all on function private.payfast_debit_day_done(uuid, int, date) from public, anon, authenticated;

-- my_billing: as before, plus the debit day and what PayFast last said.
create or replace function public.my_billing()
returns json language plpgsql stable security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
  v_set public.app_settings;
  v_sub public.subscriptions;
  v_state text;
  v_paid timestamptz;
begin
  if v_uid is null then raise exception 'Not signed in'; end if;
  select * into v_set from public.app_settings where id = 1;
  select s.* into v_sub from public.subscription_members m join public.subscriptions s on s.id = m.subscription_id where m.user_id = v_uid;
  if not found then
    return json_build_object('in_plan', false, 'is_owner', false, 'state', 'none', 'label', private.billing_label('none'),
                             'covered', false, 'price', v_set.plan_price, 'test_mode', v_set.test_mode);
  end if;
  v_state := private.billing_state(v_sub);
  v_paid := private.billing_paid_until(v_sub);
  if v_sub.owner_id <> v_uid then
    return json_build_object('in_plan', true, 'is_owner', false, 'state', v_state, 'label', private.billing_label(v_state),
      'covered', v_state in ('test', 'active', 'payment_failed', 'cancelled_paid', 'overdue'),
      'owner_name', (select full_name from public.profiles where id = v_sub.owner_id), 'test_mode', v_set.test_mode);
  end if;
  return json_build_object(
    'in_plan', true, 'is_owner', true, 'state', v_state, 'label', private.billing_label(v_state),
    'covered', v_state in ('test', 'active', 'payment_failed', 'cancelled_paid', 'overdue'),
    'price', v_set.plan_price, 'monthly_amount', v_sub.monthly_amount, 'paid_until', v_paid,
    'next_debit', case when v_paid is null or v_sub.status <> 'active' then null else v_sub.next_billing_date end,
    'grace_until', v_paid + make_interval(days => v_set.grace_days),
    'last_payment_at', case when v_paid is null then null else v_sub.last_payment_at end,
    'last_payment_amount', case when v_paid is null then null else v_sub.last_payment_amount end,
    'payment_failed_at', coalesce(v_sub.payment_failed_at, v_sub.pf_paused_at),
    'paused', v_sub.pf_paused_at is not null,
    'pf_reason', v_sub.pf_status_reason,
    'debit_day', v_sub.billing_day,
    'cancelled_at', v_sub.cancelled_at, 'mode', v_sub.payfast_mode,
    'has_debit_order', v_sub.payfast_token is not null and v_sub.status = 'active',
    'test_mode', v_set.test_mode,
    'pending_since', (select max(c.created_at) from private.payfast_checkouts c
                       where c.subscription_id = v_sub.id and c.completed_at is null and c.abandoned_at is null
                         and c.created_at > now() - interval '30 minutes'
                         and c.created_at > coalesce(v_sub.last_payment_at, '-infinity'::timestamptz)));
end $$;

-- Subscribers page: as before, plus what PayFast said and the debit day.
create or replace function public.subscribers_list()
returns json language plpgsql stable security definer set search_path = public as $$
begin
  if not exists (select 1 from public.staff where user_id = auth.uid() and role = 'admin') then
    raise exception 'Not authorised';
  end if;
  return (
    select coalesce(json_agg(row_to_json(x) order by x.rank, x.holder_name), '[]'::json)
    from (
      select s.id,
             coalesce(nullif(trim(p.full_name), ''), p.email, 'Unknown') as holder_name,
             p.phone as holder_phone,
             p.email as holder_email,
             (select count(*) from public.subscription_members m where m.subscription_id = s.id) as members,
             st.state,
             private.billing_label(st.state) as label,
             case st.state
               when 'payment_failed' then 1 when 'overdue' then 2 when 'lapsed' then 3 when 'unpaid' then 4
               when 'active' then 5 when 'cancelled_paid' then 6 when 'test' then 7 else 8 end as rank,
             private.billing_paid_until(s) as paid_until,
             s.next_billing_date,
             s.monthly_amount,
             s.last_payment_at,
             s.last_payment_amount,
             s.payment_failed_at,
             s.cancelled_at,
             s.card_expiry,
             coalesce(s.payfast_mode, 'sandbox') as payfast_mode,
             s.created_at,
             s.billing_day as debit_day,
             s.pf_status,
             s.pf_status_reason,
             s.pf_paused_at,
             s.pf_checked_at
        from public.subscriptions s
        join public.profiles p on p.id = s.owner_id
        cross join lateral (select private.billing_state(s) as state) st
    ) x);
end $$;

-- A payment that went through, or a new debit order, means it is no longer paused.
create or replace function private.subscriptions_clear_pause()
returns trigger language plpgsql as $$
begin
  if new.payfast_token is distinct from old.payfast_token
     or (new.last_payment_at is not null and new.last_payment_at is distinct from old.last_payment_at) then
    new.pf_paused_at := null;
    if new.payfast_token is distinct from old.payfast_token then
      new.pf_status := null; new.pf_status_reason := null; new.pf_checked_at := null; new.pf_check_error := null;
    elsif new.pf_status = 'PAUSED' then
      new.pf_status := 'ACTIVE'; new.pf_status_reason := null;
    end if;
  end if;
  return new;
end $$;
drop trigger if exists subscriptions_clear_pause on public.subscriptions;
create trigger subscriptions_clear_pause before update on public.subscriptions
  for each row execute function private.subscriptions_clear_pause();

-- Test mode: "paused" pretends PayFast paused the debit order; "reset" clears it too.
create or replace function public.billing_test(p_what text)
returns json language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
  v_sub public.subscriptions;
  v_grace int := coalesce((select grace_days from public.app_settings where id = 1), 7);
  v_next date;
begin
  if v_uid is null then raise exception 'Not signed in'; end if;
  if not coalesce((select test_mode from public.app_settings where id = 1), false) then
    raise exception 'Payment tests are only available in test mode.';
  end if;
  select * into v_sub from public.subscriptions where owner_id = v_uid for update;
  if not found then raise exception 'Start a family plan first.'; end if;
  if v_sub.payfast_mode = 'live' then raise exception 'This plan has real PayFast payments. Tests are not allowed on it.'; end if;
  if p_what in ('failed', 'late', 'lapsed') then
    v_next := case p_what when 'failed' then private.sa_today() when 'late' then private.sa_today() - 3 else private.sa_today() - v_grace - 3 end;
    update public.subscriptions set next_billing_date = v_next, billing_day = coalesce(billing_day, extract(day from v_next)::int),
      paid_until = private.cover_until(v_next), payment_failed_at = now(), payfast_mode = 'sandbox',
      status = case when status = 'cancelled' then 'active' else status end, cancelled_at = null
    where id = v_sub.id;
  elsif p_what = 'paused' then
    if v_sub.payfast_token is null then raise exception 'Make a PayFast test payment first, so there is a debit order to pause.'; end if;
    update public.subscriptions set pf_status = 'PAUSED', pf_status_reason = 'TEST: card expired', pf_paused_at = now(), pf_checked_at = now()
    where id = v_sub.id;
  elsif p_what = 'reset' then
    perform private.payfast_queue_cancel(v_sub.payfast_token, 'sandbox');
    update public.subscriptions set status = 'test', paid_until = null, next_billing_date = null, billing_day = null,
      payfast_token = null, payfast_mode = null, monthly_amount = null, last_payment_at = null, last_payment_amount = null,
      payment_failed_at = null, cancelled_at = null,
      pf_status = null, pf_status_reason = null, pf_run_date = null, pf_checked_at = null, pf_check_error = null, pf_paused_at = null
    where id = v_sub.id;
  else
    raise exception 'Unknown test %', p_what;
  end if;
  return public.my_billing();
end $$;

-- v29: subscribers_list also returns members_text (names, cellphones, emails of everyone on the plan)
-- for the search box on the Subscribers page. Applied live on 19 Nov 2026.
