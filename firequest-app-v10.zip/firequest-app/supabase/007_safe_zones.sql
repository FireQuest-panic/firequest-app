-- =====================================================================
-- FireQuest – safe areas (geofences)
-- * The plan holder draws safe areas (circles on a map) for himself and for
--   each person on his family plan: home, school, the farm, ...
-- * Each person switches watching on once on their own phone. The phone
--   then reports to FireQuest when it leaves or enters a safe area, even
--   when the app is closed (Android geofencing, device key like crash
--   detection).
-- * When a watched person is outside ALL their safe areas, the control room
--   gets an alert of type "safe_zone" with the location. The person on the
--   phone cannot cancel it; only the control room closes it.
-- * Needs pg_cron (already used for PayFast) for alarms held back 10 minutes.
-- Run after 006_profile_details.sql. (Also included in schema.sql.)
-- =====================================================================

alter type public.alert_type add value if not exists 'safe_zone';

-- Set when a safe-area alarm raised or joined the alert: the person cannot cancel it then.
alter table public.alerts add column if not exists safe_zone_at timestamptz;

alter table public.alerts drop constraint if exists alerts_source_check;
alter table public.alerts add constraint alerts_source_check
  check (source in ('button', 'crash_detection', 'safe_zone'));

-- Safe areas. user_id is the person who is watched.
create table if not exists public.safe_zones (
  id              uuid primary key default gen_random_uuid(),
  user_id         uuid not null references public.profiles (id) on delete cascade,
  subscription_id uuid not null references public.subscriptions (id) on delete cascade,
  name            text not null check (length(btrim(name)) between 1 and 40),
  lat             double precision not null check (lat between -90 and 90),
  lng             double precision not null check (lng between -180 and 180),
  radius_m        int not null check (radius_m between 100 and 50000),
  created_by      uuid references public.profiles (id) on delete set null,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);
create index if not exists safe_zones_user_idx on public.safe_zones (user_id);

alter table public.safe_zones enable row level security;
revoke all on public.safe_zones from anon, authenticated;
grant select on public.safe_zones to authenticated;
drop policy if exists "safe zones: own, or staff during an alert" on public.safe_zones;
create policy "safe zones: own, or staff during an alert" on public.safe_zones
  for select to authenticated
  using (user_id = auth.uid() or public.staff_can_view(user_id));

-- Watching on/off per person (set by the plan holder) and the last known state.
create table if not exists private.safe_zone_watch (
  user_id         uuid primary key references public.profiles (id) on delete cascade,
  subscription_id uuid not null references public.subscriptions (id) on delete cascade,
  enabled         boolean not null default false,
  set_by          uuid references public.profiles (id) on delete set null,
  set_at          timestamptz not null default now(),
  state           text not null default 'unknown' check (state in ('unknown', 'inside', 'outside')),
  state_at        timestamptz,
  last_lat        double precision,
  last_lng        double precision,
  last_accuracy   real,
  last_report_at  timestamptz,
  last_alert_at   timestamptz,
  -- an alarm held back (left again within 10 minutes of the previous one)
  alarm_due_at    timestamptz
);
alter table private.safe_zone_watch add column if not exists alarm_due_at timestamptz;

-- Phones that watch safe areas. Only a SHA-256 hash of the key is stored.
create table if not exists private.safe_zone_devices (
  key_hash      text primary key,
  user_id       uuid not null references public.profiles (id) on delete cascade,
  created_at    timestamptz not null default now(),
  last_seen_at  timestamptz,
  -- true once the phone confirmed that Android is watching the safe areas
  watching      boolean not null default false,
  -- what stops the phone from watching (no background location, location off, ...)
  problem       text check (length(problem) <= 200),
  app_build     int
);
create index if not exists safe_zone_devices_user_idx on private.safe_zone_devices (user_id);

revoke all on private.safe_zone_watch, private.safe_zone_devices from public, anon, authenticated;

-- Distance in metres between two points (haversine).
create or replace function private.distance_m(lat1 double precision, lng1 double precision,
                                              lat2 double precision, lng2 double precision)
returns double precision language sql immutable as $$
  select 2 * 6371008.8 * asin(least(1, sqrt(
           power(sin(radians(lat2 - lat1) / 2), 2)
           + cos(radians(lat1)) * cos(radians(lat2)) * power(sin(radians(lng2 - lng1) / 2), 2))))
$$;

-- Leaving the family plan removes that person's safe areas.
create or replace function private.safe_zones_member_left()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  delete from public.safe_zones where user_id = old.user_id and subscription_id = old.subscription_id;
  delete from private.safe_zone_watch where user_id = old.user_id and subscription_id = old.subscription_id;
  return old;
end $$;

drop trigger if exists safe_zones_member_left on public.subscription_members;
create trigger safe_zones_member_left after delete on public.subscription_members
  for each row execute function private.safe_zones_member_left();

-- The plan the signed-in person holds (null if not a plan holder).
create or replace function private.held_plan(p_uid uuid)
returns uuid language sql stable security definer set search_path = public as $$
  select id from public.subscriptions where owner_id = p_uid
$$;

-- One person's safe-area details (for the plan holder's screen or the person themselves).
create or replace function private.safe_area_person(p_uid uuid, p_viewer uuid)
returns json language sql stable security definer set search_path = public as $$
  select json_build_object(
    'user_id', p.id,
    'name', p.full_name,
    'phone', p.phone,
    'is_me', p.id = p_viewer,
    'role', m.role,
    'relationship', m.relationship,
    'home_lat', p.home_lat,
    'home_lng', p.home_lng,
    'watch', coalesce(w.enabled, false),
    -- Inside/outside is only shown to the person themselves (not a way to follow someone).
    'state', case when p.id = p_viewer then coalesce(w.state, 'unknown') end,
    'zones', coalesce((select json_agg(json_build_object('id', z.id, 'name', z.name, 'lat', z.lat, 'lng', z.lng,
                                                          'radius_m', z.radius_m) order by z.created_at)
                         from public.safe_zones z
                        where z.user_id = p.id and z.subscription_id = m.subscription_id), '[]'::json),
    'phone_status', (select json_build_object('registered', true, 'watching', d.watching,
                                              'last_seen_at', d.last_seen_at, 'problem', d.problem)
                       from private.safe_zone_devices d
                      where d.user_id = p.id
                      order by d.watching desc, d.last_seen_at desc nulls last limit 1))
  from public.subscription_members m
  join public.profiles p on p.id = m.user_id
  left join private.safe_zone_watch w on w.user_id = p.id and w.subscription_id = m.subscription_id
  where m.user_id = p_uid
$$;

-- Signed in: safe areas I manage (plan holder: everyone on the plan) or that are set for me.
create or replace function public.safe_areas()
returns json language plpgsql stable security definer set search_path = public as $$
declare
  v_uid   uuid := auth.uid();
  v_sub   uuid;
  v_owner uuid;
begin
  if v_uid is null then raise exception 'Not signed in'; end if;
  select m.subscription_id, s.owner_id into v_sub, v_owner
    from public.subscription_members m
    join public.subscriptions s on s.id = m.subscription_id
   where m.user_id = v_uid;
  if v_sub is null then
    return json_build_object('in_plan', false, 'is_owner', false, 'people', '[]'::json);
  end if;
  return json_build_object(
    'in_plan', true,
    'is_owner', v_owner = v_uid,
    'owner_name', (select full_name from public.profiles where id = v_owner),
    'test_mode', coalesce((select test_mode from public.app_settings where id = 1), true),
    'people', (select coalesce(json_agg(private.safe_area_person(m.user_id, v_uid)
                                        order by (m.user_id = v_uid) desc, m.joined_at), '[]'::json)
                 from public.subscription_members m
                where m.subscription_id = v_sub
                  and (v_owner = v_uid or m.user_id = v_uid)));
end $$;

-- Plan holder: add (p_id null) or change a safe area for someone on the plan.
create or replace function public.safe_area_save(
  p_id       uuid,
  p_user_id  uuid,
  p_name     text,
  p_lat      double precision,
  p_lng      double precision,
  p_radius_m int
) returns json language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
  v_sub uuid := private.held_plan(auth.uid());
begin
  if v_uid is null then raise exception 'Not signed in'; end if;
  if v_sub is null then raise exception 'Only the plan holder can set safe areas.'; end if;
  if not exists (select 1 from public.subscription_members where subscription_id = v_sub and user_id = p_user_id) then
    raise exception 'That person is not on your family plan.';
  end if;
  if length(btrim(coalesce(p_name, ''))) = 0 then raise exception 'Give the safe area a name, for example Home.'; end if;
  if length(btrim(p_name)) > 40 then raise exception 'The name is too long (40 letters at most).'; end if;
  if p_lat is null or p_lng is null or p_lat not between -90 and 90 or p_lng not between -180 and 180 then
    raise exception 'Place the pin on the map first.';
  end if;
  if p_radius_m is null or p_radius_m not between 100 and 50000 then
    raise exception 'The size must be between 100 m and 50 km.';
  end if;

  if p_id is null then
    if (select count(*) from public.safe_zones where user_id = p_user_id and subscription_id = v_sub) >= 5 then
      raise exception 'A person can have 5 safe areas at most. Remove one first.';
    end if;
    insert into public.safe_zones (user_id, subscription_id, name, lat, lng, radius_m, created_by)
    values (p_user_id, v_sub, btrim(p_name), p_lat, p_lng, p_radius_m, v_uid);
  else
    update public.safe_zones
       set name = btrim(p_name), lat = p_lat, lng = p_lng, radius_m = p_radius_m, updated_at = now()
     where id = p_id and user_id = p_user_id and subscription_id = v_sub;
    if not found then raise exception 'That safe area was not found.'; end if;
  end if;
  return public.safe_areas();
end $$;

-- Plan holder: remove a safe area. Watching stops when the last one is removed.
create or replace function public.safe_area_delete(p_id uuid)
returns json language plpgsql security definer set search_path = public as $$
declare
  v_sub  uuid := private.held_plan(auth.uid());
  v_user uuid;
begin
  if v_sub is null then raise exception 'Only the plan holder can change safe areas.'; end if;
  delete from public.safe_zones where id = p_id and subscription_id = v_sub returning user_id into v_user;
  if v_user is null then raise exception 'That safe area was not found.'; end if;
  if not exists (select 1 from public.safe_zones where user_id = v_user and subscription_id = v_sub) then
    update private.safe_zone_watch set enabled = false, set_by = auth.uid(), set_at = now(), state = 'unknown', state_at = null
     where user_id = v_user;
  end if;
  return public.safe_areas();
end $$;

-- Plan holder: switch watching on or off for one person.
create or replace function public.safe_area_watch(p_user_id uuid, p_on boolean)
returns json language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
  v_sub uuid := private.held_plan(auth.uid());
begin
  if v_sub is null then raise exception 'Only the plan holder can switch watching on or off.'; end if;
  if not exists (select 1 from public.subscription_members where subscription_id = v_sub and user_id = p_user_id) then
    raise exception 'That person is not on your family plan.';
  end if;
  if coalesce(p_on, false)
     and not exists (select 1 from public.safe_zones where user_id = p_user_id and subscription_id = v_sub) then
    raise exception 'Add a safe area first.';
  end if;
  insert into private.safe_zone_watch (user_id, subscription_id, enabled, set_by, set_at)
  values (p_user_id, v_sub, coalesce(p_on, false), v_uid, now())
  on conflict (user_id) do update
     set subscription_id = excluded.subscription_id, enabled = excluded.enabled,
         set_by = excluded.set_by, set_at = excluded.set_at,
         -- Start fresh: the next report from the phone sets inside/outside again.
         state = 'unknown', state_at = null;
  return public.safe_areas();
end $$;

-- Signed in: register this phone for watching my safe areas. Keeps the 3 newest phones.
create or replace function public.register_safe_zone_device()
returns text language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
  v_key text;
begin
  if v_uid is null then raise exception 'Not signed in'; end if;
  v_key := encode(extensions.gen_random_bytes(32), 'hex');
  insert into private.safe_zone_devices (key_hash, user_id, last_seen_at)
  values (encode(extensions.digest(v_key, 'sha256'), 'hex'), v_uid, now());
  delete from private.safe_zone_devices
   where user_id = v_uid
     and key_hash not in (select key_hash from private.safe_zone_devices
                           where user_id = v_uid order by created_at desc limit 3);
  return v_key;
end $$;

-- Signed in: this phone stops watching (its key stops working).
create or replace function public.unregister_safe_zone_device(p_key text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'Not signed in'; end if;
  delete from private.safe_zone_devices
   where user_id = auth.uid()
     and key_hash = encode(extensions.digest(coalesce(p_key, ''), 'sha256'), 'hex');
end $$;

-- What the phone must watch, plus whether the control room is tracking it right now.
-- "version" changes whenever watching is switched or a safe area changes, so the phone
-- registers the circles again and Android reports afresh whether it is inside or outside.
create or replace function private.safe_zone_phone_answer(p_uid uuid)
returns json language sql stable security definer set search_path = public as $$
  select json_build_object(
    'registered', true,
    'watch', coalesce(w.enabled, false) and exists (select 1 from public.safe_zones z where z.user_id = p_uid),
    'version', coalesce(to_char(w.set_at at time zone 'UTC', 'YYYYMMDDHH24MISSUS'), ''),
    'zones', case when coalesce(w.enabled, false) then
               coalesce((select json_agg(json_build_object('id', z.id, 'lat', z.lat, 'lng', z.lng, 'radius_m', z.radius_m)
                                         order by z.created_at)
                           from public.safe_zones z
                          where z.user_id = p_uid and z.subscription_id = w.subscription_id), '[]'::json)
             else '[]'::json end,
    -- The phone sends its location while the safe-area alarm is open (at most 3 hours).
    'tracking', exists (select 1 from public.alerts a
                         where a.user_id = p_uid and a.source = 'safe_zone'
                           and a.status not in ('closed', 'cancelled')
                           and a.created_at > now() - interval '3 hours'))
  from (select 1) one
  left join private.safe_zone_watch w on w.user_id = p_uid
$$;

-- Phone (device key, no login): fetch what to watch and report how the phone is doing.
create or replace function public.safe_zone_sync(
  p_key      text,
  p_watching boolean default null,
  p_problem  text default null,
  p_build    int default null
) returns json language plpgsql security definer set search_path = public as $$
declare
  v_hash text := encode(extensions.digest(coalesce(p_key, ''), 'sha256'), 'hex');
  v_uid  uuid;
begin
  update private.safe_zone_devices
     set last_seen_at = now(),
         watching = coalesce(p_watching, watching),
         problem = case when p_watching is null then problem else left(nullif(btrim(p_problem), ''), 200) end,
         app_build = coalesce(p_build, app_build)
   where key_hash = v_hash
  returning user_id into v_uid;
  if v_uid is null then return json_build_object('registered', false); end if;
  return private.safe_zone_phone_answer(v_uid);
end $$;

-- Raise the control-room alarm (or add it to the person's open alert).
create or replace function private.safe_zone_raise(
  p_uid uuid, p_lat double precision, p_lng double precision, p_accuracy real, p_note text
) returns void language plpgsql security definer set search_path = public as $$
declare
  v_alert public.alerts;
begin
  select * into v_alert from public.alerts
   where user_id = p_uid and status not in ('closed', 'cancelled')
   order by created_at desc limit 1;
  if v_alert.id is null then
    insert into public.alerts (user_id, type, is_test, source, lat, lng, accuracy_m, location_updated_at, safe_zone_at)
    values (p_uid, 'safe_zone', coalesce((select test_mode from public.app_settings where id = 1), true), 'safe_zone',
            p_lat, p_lng, p_accuracy, case when p_lat is not null then now() end, now())
    returning * into v_alert;
    insert into public.alert_events (alert_id, actor_id, actor_kind, event, note)
    values (v_alert.id, p_uid, 'system', 'raised', 'safe_zone');
    if p_lat is not null and p_lng is not null then
      insert into public.alert_locations (alert_id, lat, lng, accuracy_m) values (v_alert.id, p_lat, p_lng, p_accuracy);
    end if;
  else
    -- Joins e.g. a panic alert; that alert can then no longer be cancelled by the person.
    update public.alerts set safe_zone_at = coalesce(safe_zone_at, now()) where id = v_alert.id;
  end if;
  insert into public.alert_events (alert_id, actor_id, actor_kind, event, note)
  values (v_alert.id, p_uid, 'system', 'safe_zone_left', p_note);
  update private.safe_zone_watch set last_alert_at = now(), alarm_due_at = null where user_id = p_uid;
end $$;

-- Text for the control room: which safe area is nearest and how far away the person is.
create or replace function private.safe_zone_note(p_uid uuid, p_lat double precision, p_lng double precision)
returns text language sql stable security definer set search_path = public as $$
  select 'Left all safe areas.'
         || coalesce(' Nearest: ' || n.name || ' (' ||
              case when n.radius_m >= 1000 then round(n.radius_m / 1000.0, 1) || ' km' else n.radius_m || ' m' end
              || ' circle), now ' ||
              case when n.d >= 1000 then round((n.d / 1000.0)::numeric, 1) || ' km' else round(n.d::numeric) || ' m' end
              || ' from its centre.', '')
         || coalesce(' Safe areas set by ' || o.full_name || ' (plan holder).', '')
    from (select 1) one
    left join lateral (
      select z.name, z.radius_m, private.distance_m(z.lat, z.lng, p_lat, p_lng) as d
        from public.safe_zones z
       where z.user_id = p_uid and p_lat is not null and p_lng is not null
       order by private.distance_m(z.lat, z.lng, p_lat, p_lng) - z.radius_m
       limit 1) n on true
    left join private.safe_zone_watch w on w.user_id = p_uid
    left join public.subscriptions s on s.id = w.subscription_id
    left join public.profiles o on o.id = s.owner_id
$$;

-- Phone (device key, no login): the phone left or entered a safe area, or (while the
-- control room is tracking) sends its location. FireQuest itself works out whether the
-- person is outside ALL safe areas, using the latest areas.
--   p_event: 'enter' | 'exit' | 'location'
--   p_left:  ids of the safe areas Android says the phone has just left (trusted as left)
create or replace function public.safe_zone_report(
  p_key      text,
  p_event    text,
  p_lat      double precision,
  p_lng      double precision,
  p_accuracy real default null,
  p_at       timestamptz default null,
  p_left     text[] default null
) returns json language plpgsql security definer set search_path = public as $$
declare
  v_hash    text := encode(extensions.digest(coalesce(p_key, ''), 'sha256'), 'hex');
  v_uid     uuid;
  v_watch   private.safe_zone_watch;
  v_tol     double precision;
  v_left    text[] := case when p_event = 'exit' then coalesce(p_left, '{}') else '{}' end;
  v_rough   boolean := coalesce(p_accuracy, 0) > 1000;
  v_inside  boolean;
  v_unknown boolean := false;
  v_alert   uuid;
  v_at      timestamptz := least(coalesce(p_at, now()), now());
begin
  update private.safe_zone_devices set last_seen_at = now(), watching = true, problem = null
   where key_hash = v_hash
  returning user_id into v_uid;
  if v_uid is null then return json_build_object('registered', false); end if;
  if p_event not in ('enter', 'exit', 'location') then raise exception 'Unknown event'; end if;

  select * into v_watch from private.safe_zone_watch where user_id = v_uid for update;
  if not found or not v_watch.enabled then return private.safe_zone_phone_answer(v_uid); end if;
  if p_lat is not null and (p_lng is null or p_lat not between -90 and 90 or p_lng not between -180 and 180) then
    raise exception 'Bad position';
  end if;

  -- The open safe-area alert (if any) gets every location.
  select id into v_alert from public.alerts
   where user_id = v_uid and safe_zone_at is not null and status not in ('closed', 'cancelled')
   order by created_at desc limit 1;
  if p_lat is not null then
    if v_alert is not null then
      update public.alerts set lat = p_lat, lng = p_lng, accuracy_m = p_accuracy, location_updated_at = now()
       where id = v_alert;
      insert into public.alert_locations (alert_id, lat, lng, accuracy_m) values (v_alert, p_lat, p_lng, p_accuracy);
    end if;
    update private.safe_zone_watch
       set last_lat = p_lat, last_lng = p_lng, last_accuracy = p_accuracy, last_report_at = now()
     where user_id = v_uid;
  end if;

  -- Inside = within a safe area that Android did not just report as left (with up to 100 m
  -- leeway for GPS error). Without a usable position only Android's own report counts.
  v_tol := least(greatest(coalesce(p_accuracy, 0), 0), 100);
  if p_lat is not null and not v_rough then
    v_inside := exists (select 1 from public.safe_zones z
                         where z.user_id = v_uid and z.subscription_id = v_watch.subscription_id
                           and not (z.id::text = any (v_left))
                           and private.distance_m(z.lat, z.lng, p_lat, p_lng) <= z.radius_m + v_tol);
  elsif p_event = 'exit' then
    -- Rough or no position: outside only if Android says every safe area was left.
    v_inside := false;
    v_unknown := exists (select 1 from public.safe_zones z
                          where z.user_id = v_uid and z.subscription_id = v_watch.subscription_id
                            and not (z.id::text = any (v_left)));
  else
    return private.safe_zone_phone_answer(v_uid);
  end if;
  if v_unknown then return private.safe_zone_phone_answer(v_uid); end if;

  if v_inside then
    if v_watch.state <> 'inside' then
      update private.safe_zone_watch set state = 'inside', state_at = v_at, alarm_due_at = null where user_id = v_uid;
      if v_alert is not null then
        insert into public.alert_events (alert_id, actor_id, actor_kind, event, note)
        values (v_alert, v_uid, 'system', 'safe_zone_back_inside',
                'Back inside safe area: ' || coalesce((
                  select z.name from public.safe_zones z
                   where z.user_id = v_uid and not (z.id::text = any (v_left))
                   order by private.distance_m(z.lat, z.lng, p_lat, p_lng) - z.radius_m limit 1), '?'));
      end if;
    end if;
    return private.safe_zone_phone_answer(v_uid);
  end if;

  -- Outside every safe area.
  if v_watch.state <> 'outside' then
    update private.safe_zone_watch set state = 'outside', state_at = v_at where user_id = v_uid;
  end if;

  -- Alarm only for a real crossing (known to have been inside) and when none is open.
  -- Not twice within 10 minutes (walking along the edge): then the alarm is held back and
  -- raised by the every-minute job if the person is still outside.
  if v_watch.state = 'inside' and v_alert is null then
    if v_watch.last_alert_at is null or v_watch.last_alert_at < now() - interval '10 minutes' then
      perform private.safe_zone_raise(v_uid, p_lat, p_lng, p_accuracy, private.safe_zone_note(v_uid, p_lat, p_lng));
    else
      update private.safe_zone_watch set alarm_due_at = v_watch.last_alert_at + interval '10 minutes' where user_id = v_uid;
    end if;
  end if;

  return private.safe_zone_phone_answer(v_uid);
end $$;

-- Every minute (pg_cron): raise alarms that were held back, if the person is still outside.
create or replace function private.safe_zone_due_alarms()
returns int language plpgsql security definer set search_path = public as $$
declare
  r record;
  n int := 0;
begin
  for r in
    select w.* from private.safe_zone_watch w
     where w.alarm_due_at is not null and w.alarm_due_at <= now()
     for update skip locked
  loop
    if r.enabled and r.state = 'outside'
       and not exists (select 1 from public.alerts a
                        where a.user_id = r.user_id and a.safe_zone_at is not null
                          and a.status not in ('closed', 'cancelled')) then
      perform private.safe_zone_raise(r.user_id, r.last_lat, r.last_lng, r.last_accuracy,
        private.safe_zone_note(r.user_id, r.last_lat, r.last_lng)
        || ' (Left again soon after the previous alarm; still outside 10 minutes later.)');
      n := n + 1;
    else
      update private.safe_zone_watch set alarm_due_at = null where user_id = r.user_id;
    end if;
  end loop;
  return n;
end $$;

do $$
begin
  if exists (select 1 from pg_extension where extname = 'pg_cron') then
    perform cron.schedule('safe-zone-due', '* * * * *', 'select private.safe_zone_due_alarms()');
  end if;
end $$;

-- ---------------------------------------------------------------------
-- A panic or crash alert takes over an open safe-area alert of the same
-- person (one alert per person; the history stays together). It counts as
-- a new alert for the control room (sound, not acknowledged).
-- ---------------------------------------------------------------------
create or replace function public.raise_alert(
  p_type public.alert_type,
  p_lat double precision default null,
  p_lng double precision default null,
  p_accuracy real default null
) returns public.alerts
language plpgsql security definer set search_path = public as $$
declare
  v_uid   uuid := auth.uid();
  v_alert public.alerts;
begin
  if v_uid is null then raise exception 'Not signed in'; end if;
  if p_type = 'safe_zone' then raise exception 'Choose medical, vehicle or fire.'; end if;

  select * into v_alert from public.alerts
   where user_id = v_uid and status not in ('closed', 'cancelled')
   order by created_at desc limit 1;

  if found and v_alert.source = 'safe_zone' then
    update public.alerts
       set type = p_type, source = 'button', status = 'new', acknowledged_at = null, operator_id = null,
           is_test = coalesce((select test_mode from public.app_settings where id = 1), true)
     where id = v_alert.id returning * into v_alert;
    insert into public.alert_events (alert_id, actor_id, actor_kind, event, note)
    values (v_alert.id, v_uid, 'client', 'raised', p_type::text);
  elsif found then
    insert into public.alert_events (alert_id, actor_id, actor_kind, event, note)
    values (v_alert.id, v_uid, 'client', 'pressed_again', p_type::text);
  else
    insert into public.alerts (user_id, type, is_test)
    values (v_uid, p_type, (select test_mode from public.app_settings where id = 1))
    returning * into v_alert;

    insert into public.alert_events (alert_id, actor_id, actor_kind, event, note)
    values (v_alert.id, v_uid, 'client', 'raised', p_type::text);
  end if;

  if p_lat is not null and p_lng is not null then
    update public.alerts
       set lat = p_lat, lng = p_lng, accuracy_m = p_accuracy, location_updated_at = now()
     where id = v_alert.id
     returning * into v_alert;
    insert into public.alert_locations (alert_id, lat, lng, accuracy_m)
    values (v_alert.id, p_lat, p_lng, p_accuracy);
  end if;

  return v_alert;
end $$;

-- The person cannot cancel an alert that includes a safe-area alarm (only the control room closes it).
create or replace function public.cancel_alert(p_alert_id uuid, p_pin text)
returns boolean
language plpgsql security definer set search_path = public as $$
declare
  v_uid  uuid := auth.uid();
  v_hash text;
  v_sz   timestamptz;
begin
  select safe_zone_at into v_sz from public.alerts
   where id = p_alert_id and user_id = v_uid and status not in ('closed', 'cancelled');
  if not found then
    return false;
  end if;
  if v_sz is not null then
    raise exception 'This alert also includes a safe-area alarm, so only the FireQuest control room can close it. Phone them if you are safe.';
  end if;

  select pin_hash into v_hash from private.cancel_pins where user_id = v_uid;

  if v_hash is not null and extensions.crypt(p_pin, v_hash) = v_hash then
    update public.alerts set status = 'cancelled', cancelled_at = now() where id = p_alert_id;
    insert into public.alert_events (alert_id, actor_id, actor_kind, event)
    values (p_alert_id, v_uid, 'client', 'cancelled_by_client');
    return true;
  end if;

  insert into public.alert_events (alert_id, actor_id, actor_kind, event)
  values (p_alert_id, v_uid, 'client', 'cancel_wrong_pin');
  return false;
end $$;

create or replace function public.raise_crash_alert(
  p_key       text,
  p_lat       double precision default null,
  p_lng       double precision default null,
  p_accuracy  real default null,
  p_peak_g    real default null,
  p_speed_kmh real default null,
  p_simulated boolean default false
) returns uuid
language plpgsql security definer set search_path = public as $$
declare
  v_uid   uuid := private.crash_device_user(p_key);
  v_alert public.alerts;
  v_note  text;
begin
  if v_uid is null then
    raise exception 'Crash detection is not registered for this phone. Open FireQuest and switch it on again.';
  end if;
  update private.crash_devices set last_used_at = now()
   where key_hash = encode(extensions.digest(p_key, 'sha256'), 'hex');

  v_note := case when coalesce(p_simulated, false) then 'SIMULATED crash (test button)' else 'Crash detected by phone' end
         || coalesce(': ' || round(p_peak_g::numeric, 1) || ' g', '')
         || coalesce(' at ' || round(p_speed_kmh::numeric) || ' km/h', '');

  insert into private.crash_detections (user_id, outcome, simulated, peak_g, speed_kmh)
  values (v_uid, 'alert_sent', coalesce(p_simulated, false), p_peak_g, p_speed_kmh);

  -- Add to the client's open alert, except that a real crash never joins a TEST alert
  -- once FireQuest is live (test mode off).
  select * into v_alert from public.alerts
   where user_id = v_uid and status not in ('closed', 'cancelled')
     and (coalesce(p_simulated, false) or not is_test
          or coalesce((select test_mode from public.app_settings where id = 1), true))
   order by created_at desc limit 1;

  if not found then
    insert into public.alerts (user_id, type, is_test, source)
    values (v_uid, 'vehicle',
            coalesce((select test_mode from public.app_settings where id = 1), true) or coalesce(p_simulated, false),
            'crash_detection')
    returning * into v_alert;
    insert into public.alert_events (alert_id, actor_id, actor_kind, event, note)
    values (v_alert.id, v_uid, 'system', 'raised', 'vehicle');
  elsif v_alert.source = 'safe_zone' and not coalesce(p_simulated, false) then
    -- A real crash is more serious than leaving a safe area: a new alert for the control room.
    update public.alerts
       set type = 'vehicle', source = 'crash_detection', status = 'new', acknowledged_at = null, operator_id = null,
           is_test = coalesce((select test_mode from public.app_settings where id = 1), true)
     where id = v_alert.id returning * into v_alert;
    insert into public.alert_events (alert_id, actor_id, actor_kind, event, note)
    values (v_alert.id, v_uid, 'system', 'raised', 'vehicle');
  end if;
  insert into public.alert_events (alert_id, actor_id, actor_kind, event, note)
  values (v_alert.id, v_uid, 'system', 'crash_detected', v_note);

  if p_lat is not null and p_lng is not null then
    update public.alerts
       set lat = p_lat, lng = p_lng, accuracy_m = p_accuracy, location_updated_at = now()
     where id = v_alert.id;
    insert into public.alert_locations (alert_id, lat, lng, accuracy_m)
    values (v_alert.id, p_lat, p_lng, p_accuracy);
  end if;

  return v_alert.id;
end $$;

-- Permissions -----------------------------------------------------------
revoke execute on function
  public.safe_areas(),
  public.safe_area_save(uuid, uuid, text, double precision, double precision, int),
  public.safe_area_delete(uuid),
  public.safe_area_watch(uuid, boolean),
  public.register_safe_zone_device(),
  public.unregister_safe_zone_device(text),
  public.safe_zone_sync(text, boolean, text, int),
  public.safe_zone_report(text, text, double precision, double precision, real, timestamptz, text[])
from public, anon;

grant execute on function
  public.safe_areas(),
  public.safe_area_save(uuid, uuid, text, double precision, double precision, int),
  public.safe_area_delete(uuid),
  public.safe_area_watch(uuid, boolean),
  public.register_safe_zone_device(),
  public.unregister_safe_zone_device(text)
to authenticated;

-- The phone calls these without a login; the device key is the proof.
grant execute on function
  public.safe_zone_sync(text, boolean, text, int),
  public.safe_zone_report(text, text, double precision, double precision, real, timestamptz, text[])
to anon, authenticated;

revoke execute on function
  private.distance_m(double precision, double precision, double precision, double precision),
  private.safe_zones_member_left(),
  private.held_plan(uuid),
  private.safe_area_person(uuid, uuid),
  private.safe_zone_phone_answer(uuid),
  private.safe_zone_raise(uuid, double precision, double precision, real, text),
  private.safe_zone_note(uuid, double precision, double precision),
  private.safe_zone_due_alarms()
from public, anon, authenticated;
