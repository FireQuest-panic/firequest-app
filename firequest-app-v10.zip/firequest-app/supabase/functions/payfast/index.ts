// FireQuest – PayFast server function (Supabase Edge Function "payfast").
//
//   POST .../functions/v1/payfast            from the app (signed in): {"action":"checkout"} or {"action":"card_update"}
//   POST .../functions/v1/payfast/itn        from PayFast: payment notifications (ITN)
//   GET  .../functions/v1/payfast/form?id=   from pay.html: the signed PayFast form of one checkout (2 hours)
//   POST .../functions/v1/payfast/abandon?id= from paid.html: the client cancelled on PayFast's page
//   POST .../functions/v1/payfast/retry      every 15 minutes (pg_cron, with the database's retry key): cancel old debit orders
//   GET  .../functions/v1/payfast/health     shows the PayFast mode (no secrets)
//
// Deploy with "Verify JWT" switched OFF: PayFast cannot log in. The app's calls are checked here instead.
//
// Settings: Supabase → Edge Functions → Secrets. Leave all of them out while testing;
// PayFast's public sandbox (test) account is then used and no real money moves.
//   PAYFAST_MODE          sandbox (default) or live
//   PAYFAST_MERCHANT_ID   PayFast → Settings → Developer settings
//   PAYFAST_MERCHANT_KEY
//   PAYFAST_PASSPHRASE    the same passphrase as in PayFast's Developer settings (needed for subscriptions)
//   FIREQUEST_SITE_URL    optional; default https://firequest-panic.github.io/firequest-app/
import postgres from 'npm:postgres@3.4.5';

type Mode = 'sandbox' | 'live';
type Creds = { merchantId: string; merchantKey: string; passphrase: string; publicTestAccount?: boolean };

const env = (name: string) => (Deno.env.get(name) ?? '').trim();

const MODE: Mode = env('PAYFAST_MODE').toLowerCase() === 'live' ? 'live' : 'sandbox';
// PayFast's shared sandbox merchant (test money only). Its passphrase is not published any more,
// so forms to it are sent unsigned (PayFast accepts that) and its notifications are trusted only after
// PayFast's own validate check. With FireQuest's own PayFast details in the secrets, everything is signed.
const PUBLIC_SANDBOX: Creds = {
  merchantId: '10000100',
  merchantKey: '46f0cd694581a',
  passphrase: '',
  publicTestAccount: true,
};
const SUPABASE_URL = env('SUPABASE_URL').replace(/\/+$/, '');
const SITE = (env('FIREQUEST_SITE_URL') || 'https://firequest-panic.github.io/firequest-app/').replace(/\/*$/, '/');
const NOTIFY_URL = `${SUPABASE_URL}/functions/v1/payfast/itn`;
const ITEM_NAME = 'FireQuest Family plan';
const ITEM_DESCRIPTION = 'Monthly FireQuest emergency response cover for up to 4 people';

const sql = postgres(env('SUPABASE_DB_URL'), { prepare: false, max: 1, idle_timeout: 20, connect_timeout: 15 });

function credsFor(mode: Mode): Creds | null {
  const id = env('PAYFAST_MERCHANT_ID');
  const key = env('PAYFAST_MERCHANT_KEY');
  const pass = env('PAYFAST_PASSPHRASE');
  if (mode === MODE && id && key && pass) return { merchantId: id, merchantKey: key, passphrase: pass };
  if (mode === 'sandbox') return PUBLIC_SANDBOX;
  return null;
}

const payfastHost = (mode: Mode) => (mode === 'live' ? 'https://www.payfast.co.za' : 'https://sandbox.payfast.co.za');

// ------------------------------------------------------------------ helpers

/** PHP urlencode(): what PayFast uses when it builds signatures. */
export function phpEncode(value: string): string {
  return encodeURIComponent(value)
    .replace(/[!'()*~]/g, (c) => '%' + c.charCodeAt(0).toString(16).toUpperCase())
    .replace(/%20/g, '+');
}

/** MD5 as lowercase hex (PayFast signatures). Web Crypto has no MD5, so it is done here. */
export function md5(text: string): string {
  const bytes = new TextEncoder().encode(text);
  const bitLen = bytes.length * 8;
  const padded = new Uint8Array((((bytes.length + 8) >> 6) + 1) << 6);
  padded.set(bytes);
  padded[bytes.length] = 0x80;
  const view = new DataView(padded.buffer);
  view.setUint32(padded.length - 8, bitLen >>> 0, true);
  view.setUint32(padded.length - 4, Math.floor(bitLen / 0x100000000), true);

  const S = [7, 12, 17, 22, 5, 9, 14, 20, 4, 11, 16, 23, 6, 10, 15, 21];
  const K = new Uint32Array(64);
  for (let i = 0; i < 64; i++) K[i] = Math.floor(Math.abs(Math.sin(i + 1)) * 0x100000000) >>> 0;

  let a0 = 0x67452301, b0 = 0xefcdab89, c0 = 0x98badcfe, d0 = 0x10325476;
  for (let off = 0; off < padded.length; off += 64) {
    const M = new Uint32Array(16);
    for (let i = 0; i < 16; i++) M[i] = view.getUint32(off + i * 4, true);
    let A = a0, B = b0, C = c0, D = d0;
    for (let i = 0; i < 64; i++) {
      let F: number, g: number;
      if (i < 16) { F = (B & C) | (~B & D); g = i; }
      else if (i < 32) { F = (D & B) | (~D & C); g = (5 * i + 1) % 16; }
      else if (i < 48) { F = B ^ C ^ D; g = (3 * i + 5) % 16; }
      else { F = C ^ (B | ~D); g = (7 * i) % 16; }
      const s = S[(i >> 4) * 4 + (i % 4)];
      const sum = (A + F + K[i] + M[g]) >>> 0;
      A = D; D = C; C = B;
      B = (B + ((sum << s) | (sum >>> (32 - s)))) >>> 0;
    }
    a0 = (a0 + A) >>> 0; b0 = (b0 + B) >>> 0; c0 = (c0 + C) >>> 0; d0 = (d0 + D) >>> 0;
  }
  const out = new DataView(new ArrayBuffer(16));
  [a0, b0, c0, d0].forEach((w, i) => out.setUint32(i * 4, w, true));
  return Array.from(new Uint8Array(out.buffer), (b) => b.toString(16).padStart(2, '0')).join('');
}

/** Checkout form signature: non-blank fields in the order they are sent, then the passphrase. */
export function formSignature(fields: [string, string][], passphrase: string): string {
  let s = fields
    .filter(([k, v]) => k !== 'signature' && v.trim() !== '')
    .map(([k, v]) => `${k}=${phpEncode(v.trim())}`)
    .join('&');
  if (passphrase) s += `&passphrase=${phpEncode(passphrase.trim())}`;
  return md5(s);
}

/** ITN parameter string: every posted field, in order, up to the signature. */
export function itnParamString(pairs: [string, string][]): string {
  const parts: string[] = [];
  for (const [k, v] of pairs) {
    if (k === 'signature') break;
    parts.push(`${k}=${phpEncode(v)}`);
  }
  return parts.join('&');
}

export function itnSignature(pairs: [string, string][], passphrase: string): string {
  const s = itnParamString(pairs);
  return md5(passphrase ? `${s}&passphrase=${phpEncode(passphrase)}` : s);
}

/** API signature: header + body values and the passphrase, sorted by name. */
export function apiSignature(values: Record<string, string>, passphrase: string): string {
  const all: Record<string, string> = { ...values };
  if (passphrase) all.passphrase = passphrase;
  return md5(
    Object.keys(all)
      .sort()
      .map((k) => `${k}=${phpEncode(all[k])}`)
      .join('&'),
  );
}

export function parseForm(raw: string): [string, string][] {
  const dec = (x: string) => decodeURIComponent(x.replace(/\+/g, ' '));
  return raw
    .split('&')
    .filter(Boolean)
    .map((part) => {
      const i = part.indexOf('=');
      return i < 0 ? [dec(part), ''] : [dec(part.slice(0, i)), dec(part.slice(i + 1))];
    });
}

/** South African time (UTC+2, no daylight saving). */
function saNow(): string {
  return new Date(Date.now() + 2 * 3600 * 1000).toISOString().slice(0, 19);
}

function cleanName(s: string): string {
  return (s || '').replace(/[^\p{L}\p{M}' .-]/gu, ' ').replace(/\s+/g, ' ').trim();
}

function json(status: number, body: unknown): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
  });
}

async function fetchWithTimeout(url: string, init: RequestInit, ms: number): Promise<Response> {
  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), ms);
  try {
    return await fetch(url, { ...init, signal: ctl.signal });
  } finally {
    clearTimeout(t);
  }
}

/** Database errors raised on purpose (RAISE EXCEPTION) are written for the client; others are not shown. */
function userMessage(e: unknown): string {
  const err = e as { code?: string; message?: string };
  if (err?.code === 'P0001' && err.message) return err.message;
  console.error(e);
  return 'Something went wrong at FireQuest. Please try again in a minute.';
}

function runInBackground(p: Promise<unknown>) {
  const rt = (globalThis as { EdgeRuntime?: { waitUntil?: (p: Promise<unknown>) => void } }).EdgeRuntime;
  const safe = p.catch((e) => console.error('background task', e));
  // Keeps the function alive until the task is done (Supabase Edge Runtime).
  if (rt?.waitUntil) rt.waitUntil(safe);
}

// ------------------------------------------------------------------ signed-in app calls

function publishableKey(): string {
  try {
    const keys = JSON.parse(Deno.env.get('SUPABASE_PUBLISHABLE_KEYS') ?? '{}');
    if (keys?.default) return String(keys.default);
  } catch {
    // fall through
  }
  return env('SUPABASE_ANON_KEY');
}

async function currentUser(req: Request): Promise<{ id: string } | null> {
  const token = (req.headers.get('authorization') ?? '').replace(/^Bearer\s+/i, '').trim();
  if (token.split('.').length !== 3) return null;
  const apikey = publishableKey() || req.headers.get('apikey') || '';
  const r = await fetchWithTimeout(
    `${SUPABASE_URL}/auth/v1/user`,
    { headers: { apikey, Authorization: `Bearer ${token}` } },
    10000,
  );
  if (!r.ok) return null;
  const u = await r.json().catch(() => null);
  return u?.id ? { id: String(u.id) } : null;
}

async function startCheckout(userId: string): Promise<Response> {
  const creds = credsFor(MODE);
  if (!creds) return json(503, { error: 'Payments are not set up yet. Please phone FireQuest.' });
  const [row] = await sql`select private.payfast_start_checkout(${userId}::uuid, ${MODE}) as r`;
  const c = row.r as { m_payment_id: string; subscription_id: string; kind: string; amount: string; full_name: string; email: string };

  const names = cleanName(c.full_name).split(' ').filter(Boolean);
  const email = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(c.email ?? '') ? c.email.slice(0, 100) : '';
  const fields: [string, string][] = (
    [
      ['merchant_id', creds.merchantId],
      ['merchant_key', creds.merchantKey],
      ['return_url', `${SITE}paid.html?result=paid`],
      ['cancel_url', `${SITE}paid.html?result=cancelled&c=${c.m_payment_id}`],
      ['notify_url', NOTIFY_URL],
      ['name_first', (names[0] ?? '').slice(0, 100)],
      ['name_last', names.slice(1).join(' ').slice(0, 100)],
      ['email_address', email],
      ['m_payment_id', c.m_payment_id],
      ['amount', c.amount],
      ['item_name', ITEM_NAME],
      ['item_description', ITEM_DESCRIPTION],
      ['custom_str1', c.subscription_id],
      ['custom_str2', c.kind],
      ['subscription_type', '1'],
      ['billing_date', saNow().slice(0, 10)],
      ['recurring_amount', c.amount],
      ['frequency', '3'],
      ['cycles', '0'],
    ] as [string, string][]
  ).filter(([, v]) => v.trim() !== '');
  if (!creds.publicTestAccount) fields.push(['signature', formSignature(fields, creds.passphrase)]);

  // pay.html fetches this form from FireQuest's server by checkout id, so the page can only ever
  // send people to FireQuest's own PayFast checkout.
  await sql`select private.payfast_save_form(${c.m_payment_id}::uuid, ${sql.json({ a: `${payfastHost(MODE)}/eng/process`, f: fields })})`;
  return json(200, { url: `${SITE}pay.html#${c.m_payment_id}`, mode: MODE, amount: c.amount, kind: c.kind });
}

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

async function checkoutForm(id: string): Promise<Response> {
  if (!UUID.test(id)) return json(404, { error: 'not found' });
  const [row] = await sql`select private.payfast_checkout_form(${id}::uuid) as f`;
  if (!row?.f) return json(404, { error: 'This payment link has expired. Open the FireQuest app and tap the payment button again.' });
  return json(200, row.f);
}

async function checkoutAbandoned(id: string): Promise<Response> {
  if (UUID.test(id)) await sql`select private.payfast_checkout_abandoned(${id}::uuid)`;
  return json(200, { ok: true });
}

async function cardUpdateLink(userId: string): Promise<Response> {
  const [row] = await sql`select private.payfast_card_token(${userId}::uuid) as r`;
  const t = row.r as { token: string; mode: Mode };
  if (t.mode !== 'live') {
    return json(200, {
      unavailable: true,
      message:
        "PayFast's test system has no card-update page. On the live system this button opens PayFast's secure page, where you type your new card details. For now, test with \"Pay now\".",
    });
  }
  const back = `${SITE}paid.html?result=card`;
  return json(200, {
    url: `https://www.payfast.co.za/eng/recurring/update/${encodeURIComponent(t.token)}?return=${encodeURIComponent(back)}`,
  });
}

// ------------------------------------------------------------------ PayFast notifications (ITN)

/** 'VALID' or 'INVALID'. Anything else (an error page, a timeout) throws, so PayFast is asked to send again. */
async function confirmWithPayFast(paramString: string): Promise<'VALID' | 'INVALID'> {
  const r = await fetchWithTimeout(
    `${payfastHost(MODE)}/eng/query/validate`,
    { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: paramString },
    15000,
  );
  const body = (await r.text()).trim();
  if (r.status === 200 && (body === 'VALID' || body === 'INVALID')) return body;
  throw new Error(`PayFast validate answered HTTP ${r.status}: ${body.slice(0, 80)}`);
}

async function handleItn(req: Request): Promise<Response> {
  const raw = await req.text();
  let pairs: [string, string][];
  try {
    pairs = parseForm(raw);
  } catch {
    return new Response('Bad request', { status: 400 });
  }
  const data: Record<string, string> = {};
  for (const [k, v] of pairs) data[k] = v;

  const creds = credsFor(MODE);
  let valid = false;
  let note = '';
  if (!creds) note = 'PayFast is not set up for this mode';
  // Shared test account: its passphrase is unknown, so PayFast's validate check below is what counts.
  else if (!creds.publicTestAccount && !data.signature) note = 'no signature';
  else if (!creds.publicTestAccount && itnSignature(pairs, creds.passphrase) !== data.signature) note = 'bad signature';
  else if (data.merchant_id !== creds.merchantId) note = 'wrong merchant';
  else {
    let answer: 'VALID' | 'INVALID';
    try {
      answer = await confirmWithPayFast(itnParamString(pairs));
    } catch (e) {
      // PayFast could not be reached or gave no clear answer: reply with an error so PayFast sends it again later.
      console.error('PayFast validate failed', e);
      return new Response('Try again later', { status: 503 });
    }
    if (answer === 'VALID') valid = true;
    else note = 'PayFast said it is not genuine (INVALID)';
  }
  if (!valid) {
    const ip = (req.headers.get('x-forwarded-for') ?? '').split(',')[0].trim();
    if (ip) note += ` from ${ip}`;
  }

  const stored = { ...data };
  delete stored.signature;
  const [row] = await sql`
    select private.payfast_apply_itn(${sql.json(stored)}, ${MODE}, ${valid}, ${note || null}) as r`;
  const result = row.r as { outcome: string; cancel_token: string | null; cancel_mode: Mode | null };
  console.log('ITN', data.payment_status, data.pf_payment_id, result.outcome);

  // Stop a replaced debit order after answering PayFast (it is also retried every 15 minutes).
  const cancelToken = result.cancel_token;
  runInBackground(
    (async () => {
      if (cancelToken) {
        const [claim] = await sql`select private.payfast_claim_token(${cancelToken}) as ok`;
        if (claim?.ok) {
          const res = await cancelAtPayFast(cancelToken, result.cancel_mode ?? MODE);
          await sql`select private.payfast_token_cancel_result(${cancelToken}, ${res.ok}, ${res.error ?? null})`;
        }
      }
      await retryOldDebitOrders();
    })(),
  );
  return new Response('OK', { status: 200 });
}

// ------------------------------------------------------------------ cancelling replaced debit orders

export async function cancelAtPayFast(token: string, mode: Mode): Promise<{ ok: boolean; error?: string }> {
  const creds = credsFor(mode);
  if (!creds) return { ok: false, error: `no ${mode} PayFast details to cancel with` };
  // The shared test account cannot be used with PayFast's API (unknown passphrase); its debit orders move test money only.
  if (creds.publicTestAccount) return { ok: true };
  const headers: Record<string, string> = { 'merchant-id': creds.merchantId, version: 'v1', timestamp: `${saNow()}+02:00` };
  const signature = apiSignature(headers, creds.passphrase);
  const url = `https://api.payfast.co.za/subscriptions/${encodeURIComponent(token)}/cancel${mode === 'sandbox' ? '?testing=true' : ''}`;
  try {
    const r = await fetchWithTimeout(url, { method: 'PUT', headers: { ...headers, signature }, body: '' }, 20000);
    const body = await r.text();
    if (r.ok && /"status"\s*:\s*"success"/i.test(body)) return { ok: true };
    // Already stopped (by PayFast, the client or FireQuest): nothing left to do.
    if (r.status < 500 && /already\s+(been\s+)?cancel/i.test(body)) return { ok: true };
    return { ok: false, error: `HTTP ${r.status}: ${body.slice(0, 200)}` };
  } catch (e) {
    return { ok: false, error: String((e as Error)?.message ?? e).slice(0, 200) };
  }
}

async function retryOldDebitOrders(): Promise<void> {
  const rows = await sql`select token, mode from private.payfast_tokens_to_cancel(3)`;
  for (const r of rows) {
    const res = await cancelAtPayFast(r.token, r.mode as Mode);
    await sql`select private.payfast_token_cancel_result(${r.token}, ${res.ok}, ${res.error ?? null})`;
  }
}

// ------------------------------------------------------------------ router

Deno.serve(async (req: Request) => {
  const path = new URL(req.url).pathname.replace(/\/+$/, '');
  try {
    if (req.method === 'OPTIONS') {
      return new Response(null, {
        status: 204,
        headers: {
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Headers': 'authorization, apikey, content-type, x-client-info',
          'Access-Control-Allow-Methods': 'POST, GET, OPTIONS',
        },
      });
    }
    if (path.endsWith('/itn')) {
      if (req.method !== 'POST') return new Response('Method not allowed', { status: 405 });
      return await handleItn(req);
    }
    if (path.endsWith('/form')) {
      return await checkoutForm(new URL(req.url).searchParams.get('id') ?? '');
    }
    if (path.endsWith('/abandon')) {
      if (req.method !== 'POST') return json(405, { error: 'Method not allowed' });
      return await checkoutAbandoned(new URL(req.url).searchParams.get('id') ?? '');
    }
    if (path.endsWith('/retry')) {
      if (req.method !== 'POST') return json(405, { error: 'Method not allowed' });
      const [k] = await sql`select private.payfast_retry_key_ok(${req.headers.get('x-retry-key') ?? ''}) as ok`;
      if (!k?.ok) return json(403, { error: 'Not allowed' });
      await retryOldDebitOrders();
      return json(200, { ok: true });
    }
    if (path.endsWith('/health')) {
      const creds = credsFor(MODE);
      await sql`select 1`;
      return json(200, {
        ok: true,
        mode: MODE,
        merchant: !creds ? 'not set up' : creds.publicTestAccount ? 'PayFast public test account' : `merchant ${creds.merchantId.slice(0, 3)}…`,
        notify_url: NOTIFY_URL,
      });
    }
    if (req.method !== 'POST') return json(405, { error: 'Method not allowed' });

    const user = await currentUser(req);
    if (!user) return json(401, { error: 'Please sign in to FireQuest again.' });
    const body = await req.json().catch(() => ({}));
    if (body?.action === 'checkout') return await startCheckout(user.id);
    if (body?.action === 'card_update') return await cardUpdateLink(user.id);
    return json(400, { error: 'Unknown action' });
  } catch (e) {
    if (path.endsWith('/itn')) {
      console.error('ITN error', e);
      return new Response('Error', { status: 500 });
    }
    return json(400, { error: userMessage(e) });
  }
});
