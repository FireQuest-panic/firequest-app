package za.co.firequest.crash

import android.Manifest
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.util.Log
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequest
import androidx.work.PeriodicWorkRequest
import androidx.work.WorkManager
import com.google.android.gms.location.Geofence
import com.google.android.gms.location.GeofencingRequest
import com.google.android.gms.location.LocationServices
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.TimeUnit

/** Settings for safe areas, saved on the phone so watching works without the app. */
class SafeZoneConfig(context: Context) {
  private val prefs = context.applicationContext.getSharedPreferences("firequest_safe_zones", Context.MODE_PRIVATE)

  val supabaseUrl: String get() = prefs.getString("supabaseUrl", "") ?: ""
  val supabaseKey: String get() = prefs.getString("supabaseKey", "") ?: ""
  val deviceKey: String get() = prefs.getString("deviceKey", "") ?: ""
  val userId: String get() = prefs.getString("userId", "") ?: ""
  val isComplete: Boolean get() = supabaseUrl.isNotBlank() && supabaseKey.isNotBlank() && deviceKey.isNotBlank()

  /** The safe areas Android was last asked to watch (JSON array from the server). */
  var zonesJson: String
    get() = prefs.getString("zones", "[]") ?: "[]"
    set(v) { prefs.edit().putString("zones", v).apply() }
  /** The zones that are registered with Android right now ("" = none). */
  var registeredSignature: String
    get() = prefs.getString("registeredSig", "") ?: ""
    set(v) { prefs.edit().putString("registeredSig", v).apply() }
  var watch: Boolean
    get() = prefs.getBoolean("watch", false)
    set(v) { prefs.edit().putBoolean("watch", v).apply() }
  var tracking: Boolean
    get() = prefs.getBoolean("tracking", false)
    set(v) { prefs.edit().putBoolean("tracking", v).apply() }
  var lastSyncAt: Long
    get() = prefs.getLong("lastSyncAt", 0L)
    set(v) { prefs.edit().putLong("lastSyncAt", v).apply() }
  var lastError: String?
    get() = prefs.getString("lastError", null)
    set(v) { prefs.edit().putString("lastError", v).apply() }

  fun save(url: String, key: String, deviceKey: String, userId: String) {
    prefs.edit()
      .putString("supabaseUrl", url.trim())
      .putString("supabaseKey", key.trim())
      .putString("deviceKey", deviceKey.trim())
      .putString("userId", userId.trim())
      .putString("registeredSig", "")
      .apply()
  }

  fun clear() {
    prefs.edit().clear().apply()
  }

  companion object {
    private val QUEUE_LOCK = Any()
  }

  // Reports that could not be sent yet (no signal). Sent in order on the next chance.
  // One lock for all instances: the receiver, the service and the worker each make their own.
  fun queue(): JSONArray = synchronized(QUEUE_LOCK) {
    try { JSONArray(prefs.getString("queue", "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
  }

  fun enqueue(item: JSONObject) = synchronized(QUEUE_LOCK) {
    val q = queue()
    q.put(item)
    // Keep the newest 30 only.
    val trimmed = JSONArray()
    val from = maxOf(0, q.length() - 30)
    for (i in from until q.length()) trimmed.put(q.get(i))
    prefs.edit().putString("queue", trimmed.toString()).commit()
  }

  /** Removes the first [count] items (they were sent). */
  fun dropFirst(count: Int) = synchronized(QUEUE_LOCK) {
    val q = queue()
    val rest = JSONArray()
    for (i in count until q.length()) rest.put(q.get(i))
    prefs.edit().putString("queue", rest.toString()).commit()
  }
}

/**
 * Safe areas: Android (Google Play services) watches circles around places the plan holder
 * chose and wakes [SafeZoneReceiver] when this phone leaves or enters one. FireQuest's
 * server decides whether the person is outside ALL safe areas and alerts the control room.
 */
object SafeZones {
  private const val TAG = "FireQuestSafeZones"
  private const val PERIODIC_WORK = "fq_safe_zone_sync"
  private const val RETRY_WORK = "fq_safe_zone_retry"
  /** Leeway for GPS error at the edge of a circle (the server uses the same). */
  private const val MAX_LEEWAY_M = 100f

  private val isoFormat = object : ThreadLocal<SimpleDateFormat>() {
    override fun initialValue(): SimpleDateFormat =
      SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }
  }

  fun hasForegroundLocation(context: Context) =
    context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

  fun hasBackgroundLocation(context: Context) =
    Build.VERSION.SDK_INT < 29 ||
      context.checkSelfPermission(Manifest.permission.ACCESS_BACKGROUND_LOCATION) == PackageManager.PERMISSION_GRANTED

  fun locationOn(context: Context): Boolean = try {
    val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    if (Build.VERSION.SDK_INT >= 28) lm.isLocationEnabled
    else lm.isProviderEnabled(LocationManager.GPS_PROVIDER) || lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)
  } catch (_: Exception) {
    true
  }

  /** What stops this phone from watching, in plain words (null = nothing). */
  fun problem(context: Context): String? = when {
    !hasForegroundLocation(context) -> "Location permission is off for FireQuest"
    !hasBackgroundLocation(context) -> "Location is not set to \"Allow all the time\" for FireQuest"
    !locationOn(context) -> "Location is switched off on the phone"
    else -> null
  }

  private fun geofenceIntent(context: Context): PendingIntent {
    val intent = Intent(context, SafeZoneReceiver::class.java).setAction(SafeZoneReceiver.ACTION_GEOFENCE)
    // Google Play services adds the event to this intent, so it must be mutable.
    val flags = PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
    return PendingIntent.getBroadcast(context, 4201, intent, flags)
  }

  // ------------------------------------------------------------------ switching on / off

  fun start(context: Context, url: String, key: String, deviceKey: String, userId: String) {
    val config = SafeZoneConfig(context)
    config.save(url, key, deviceKey, userId)
    config.lastError = null
    schedulePeriodic(context)
  }

  /** Switches off on this phone. Returns the old device key (for removal on the server). */
  fun stop(context: Context): String {
    val config = SafeZoneConfig(context)
    val oldKey = config.deviceKey
    removeGeofences(context)
    try {
      WorkManager.getInstance(context).cancelUniqueWork(PERIODIC_WORK)
      WorkManager.getInstance(context).cancelUniqueWork(RETRY_WORK)
    } catch (e: Exception) {
      Log.w(TAG, "cancel work failed", e)
    }
    SafeZoneTrackingService.stop(context)
    config.clear()
    return oldKey
  }

  fun schedulePeriodic(context: Context) {
    try {
      val req = PeriodicWorkRequest.Builder(SafeZoneWorker::class.java, 15, TimeUnit.MINUTES)
        .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
        .build()
      WorkManager.getInstance(context).enqueueUniquePeriodicWork(PERIODIC_WORK, ExistingPeriodicWorkPolicy.UPDATE, req)
    } catch (e: Exception) {
      Log.w(TAG, "periodic work not scheduled", e)
    }
  }

  /** Try again as soon as there is a connection. */
  fun scheduleRetry(context: Context) {
    try {
      val req = OneTimeWorkRequest.Builder(SafeZoneWorker::class.java)
        .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
        .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
        .build()
      WorkManager.getInstance(context).enqueueUniqueWork(RETRY_WORK, ExistingWorkPolicy.REPLACE, req)
    } catch (e: Exception) {
      Log.w(TAG, "retry work not scheduled", e)
    }
  }

  // ------------------------------------------------------------------ talking to FireQuest

  /**
   * Sends waiting reports, then asks FireQuest what to watch and applies it.
   * Blocking: call from a background thread. Returns false when FireQuest could not be reached.
   */
  @Synchronized
  fun syncNow(context: Context, forceRegister: Boolean = false): Boolean {
    val config = SafeZoneConfig(context)
    if (!config.isComplete) return true
    if (!flush(context)) return false
    val problem = problem(context)
    // Watching = nothing in the way, and Android has the circles.
    val watching = problem == null && config.watch && config.registeredSignature.isNotEmpty()
    val body = JSONObject()
      .put("p_key", config.deviceKey)
      .put("p_watching", watching)
      .put("p_problem", problem ?: JSONObject.NULL)
      .put("p_build", appBuild(context))
    return try {
      val answer = JSONObject(CrashApi.call(config.supabaseUrl, config.supabaseKey, "safe_zone_sync", body))
      config.lastSyncAt = System.currentTimeMillis()
      apply(context, answer, forceRegister)
      true
    } catch (e: HttpStatusException) {
      config.lastError = "FireQuest answered: ${e.message?.take(120)}"
      Log.w(TAG, "sync refused", e)
      e.code in 400..499 // a refused request will not succeed by retrying
    } catch (e: Exception) {
      config.lastError = "No connection to FireQuest"
      Log.w(TAG, "sync failed", e)
      false
    }
  }

  /**
   * Queues a report ('enter', 'exit' or 'location') with the phone's position (if any) and,
   * for 'exit', the ids of the safe areas Android says were left.
   */
  fun queueReport(context: Context, event: String, location: Location?, leftIds: List<String>? = null) {
    if (location == null && event == "location") return
    val item = JSONObject().put("p_event", event)
    if (location != null) {
      item.put("p_lat", location.latitude)
        .put("p_lng", location.longitude)
        .put("p_accuracy", if (location.hasAccuracy()) location.accuracy.toDouble() else JSONObject.NULL)
        .put("p_at", isoFormat.get()!!.format(Date(if (location.time > 0) location.time else System.currentTimeMillis())))
    } else {
      item.put("p_lat", JSONObject.NULL).put("p_lng", JSONObject.NULL)
    }
    if (!leftIds.isNullOrEmpty()) item.put("p_left", JSONArray(leftIds))
    SafeZoneConfig(context).enqueue(item)
  }

  /** The newest position Android already has (no new GPS fix), or null. */
  fun lastKnownLocation(context: Context): Location? {
    if (!hasForegroundLocation(context)) return null
    return try {
      val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
      lm.allProviders.mapNotNull { p -> try { lm.getLastKnownLocation(p) } catch (_: SecurityException) { null } }
        .maxByOrNull { it.time }
    } catch (_: Exception) {
      null
    }
  }

  /**
   * Sends the waiting reports in order. Blocking. Returns false when FireQuest could not be
   * reached (the reports stay queued).
   */
  @Synchronized
  fun flush(context: Context): Boolean {
    val config = SafeZoneConfig(context)
    if (!config.isComplete) return true
    while (true) {
      val q = config.queue()
      if (q.length() == 0) return true
      val item = q.getJSONObject(0)
      val body = JSONObject(item.toString()).put("p_key", config.deviceKey)
      try {
        val answer = JSONObject(CrashApi.call(config.supabaseUrl, config.supabaseKey, "safe_zone_report", body))
        config.dropFirst(1)
        config.lastSyncAt = System.currentTimeMillis()
        config.lastError = null
        apply(context, answer, false)
        if (!config.isComplete) return true
      } catch (e: HttpStatusException) {
        Log.w(TAG, "report refused", e)
        // Drop only reports FireQuest can never accept; anything else is tried again later.
        val msg = e.message ?: ""
        if (e.code == 400 && (msg.contains("Unknown event") || msg.contains("Bad position"))) {
          config.dropFirst(1)
        } else {
          config.lastError = "FireQuest refused a report (${e.code}); trying again later"
          return false
        }
      } catch (e: Exception) {
        Log.w(TAG, "report failed", e)
        config.lastError = "No connection to FireQuest"
        return false
      }
    }
  }

  /** Applies FireQuest's answer: which circles to watch, and whether the control room is tracking. */
  private fun apply(context: Context, answer: JSONObject, forceRegister: Boolean) {
    val config = SafeZoneConfig(context)
    if (!answer.optBoolean("registered", false)) {
      // This phone's key was removed (switched off elsewhere, or newer phones registered).
      Log.i(TAG, "phone no longer registered: switching off")
      stop(context)
      return
    }
    val watch = answer.optBoolean("watch", false)
    val zones = answer.optJSONArray("zones") ?: JSONArray()
    config.watch = watch
    config.zonesJson = zones.toString()
    if (watch && zones.length() > 0) {
      // A new version (watching switched, areas changed) registers again, so Android reports afresh.
      val sig = answer.optString("version", "") + zones.toString()
      if (forceRegister || sig != config.registeredSignature) registerGeofences(context, zones, sig)
    } else if (config.registeredSignature.isNotEmpty()) {
      removeGeofences(context)
    }
    val tracking = answer.optBoolean("tracking", false)
    config.tracking = tracking
    if (!tracking && !SafeZoneTrackingService.checking) SafeZoneTrackingService.stop(context)
  }

  // ------------------------------------------------------------------ Android geofences

  private fun registerGeofences(context: Context, zones: JSONArray, signature: String) {
    val config = SafeZoneConfig(context)
    val problem = problem(context)
    if (!hasForegroundLocation(context) || !hasBackgroundLocation(context)) {
      config.registeredSignature = ""
      config.lastError = problem
      return
    }
    val fences = ArrayList<Geofence>()
    for (i in 0 until zones.length()) {
      val z = zones.getJSONObject(i)
      fences.add(
        Geofence.Builder()
          .setRequestId(z.getString("id"))
          .setCircularRegion(z.getDouble("lat"), z.getDouble("lng"), z.getDouble("radius_m").toFloat())
          .setExpirationDuration(Geofence.NEVER_EXPIRE)
          .setTransitionTypes(Geofence.GEOFENCE_TRANSITION_ENTER or Geofence.GEOFENCE_TRANSITION_EXIT)
          .setNotificationResponsiveness(60_000)
          .build()
      )
    }
    val request = GeofencingRequest.Builder()
      // Report straight away whether the phone is inside or outside each circle.
      .setInitialTrigger(GeofencingRequest.INITIAL_TRIGGER_ENTER or GeofencingRequest.INITIAL_TRIGGER_EXIT)
      .addGeofences(fences)
      .build()
    try {
      val client = LocationServices.getGeofencingClient(context)
      val pi = geofenceIntent(context)
      client.removeGeofences(pi).addOnCompleteListener {
        try {
          client.addGeofences(request, pi)
            .addOnSuccessListener {
              val firstTime = config.registeredSignature.isEmpty()
              config.registeredSignature = signature
              config.lastError = null
              Log.i(TAG, "watching ${fences.size} safe areas")
              // Let FireQuest (and the plan holder) know this phone is now watching.
              if (firstTime) Thread { syncNow(context) }.start()
            }
            .addOnFailureListener { e ->
              config.registeredSignature = ""
              config.lastError = "Android could not watch the safe areas (${e.message?.take(80)}). Is location on?"
              Log.w(TAG, "addGeofences failed", e)
            }
        } catch (e: SecurityException) {
          config.registeredSignature = ""
          config.lastError = "Location permission is off for FireQuest"
        }
      }
    } catch (e: Exception) {
      config.registeredSignature = ""
      config.lastError = "Android could not watch the safe areas (${e.message?.take(80)})"
      Log.w(TAG, "geofencing unavailable", e)
    }
  }

  fun removeGeofences(context: Context) {
    try {
      LocationServices.getGeofencingClient(context).removeGeofences(geofenceIntent(context))
    } catch (e: Exception) {
      Log.w(TAG, "removeGeofences failed", e)
    }
    SafeZoneConfig(context).registeredSignature = ""
  }

  /** Android forgets geofences after a restart or when location was off: register them again. */
  fun reRegister(context: Context) {
    val config = SafeZoneConfig(context)
    if (!config.isComplete || !config.watch) return
    config.registeredSignature = ""
    val zones = try { JSONArray(config.zonesJson) } catch (_: Exception) { JSONArray() }
    if (zones.length() > 0) registerGeofences(context, zones, zones.toString())
  }

  /** A fresh, precise position (good enough to decide inside / outside). */
  fun isGood(location: Location): Boolean =
    location.hasAccuracy() && location.accuracy <= 150f &&
      System.currentTimeMillis() - location.time < 3 * 60_000L

  /**
   * True when [location] is outside every saved circle (with the same GPS leeway as the server).
   * Circles in [leftIds] count as left (Android said so).
   */
  fun outsideAll(context: Context, location: Location, leftIds: List<String> = emptyList()): Boolean {
    val zones = try { JSONArray(SafeZoneConfig(context).zonesJson) } catch (_: Exception) { JSONArray() }
    if (zones.length() == 0) return false
    val leeway = if (location.hasAccuracy()) minOf(location.accuracy, MAX_LEEWAY_M) else 0f
    val result = FloatArray(1)
    for (i in 0 until zones.length()) {
      val z = zones.getJSONObject(i)
      if (z.getString("id") in leftIds) continue
      Location.distanceBetween(location.latitude, location.longitude, z.getDouble("lat"), z.getDouble("lng"), result)
      if (result[0] <= z.getDouble("radius_m") + leeway) return false
    }
    return true
  }

  @Suppress("DEPRECATION")
  private fun appBuild(context: Context): Int = try {
    val info = context.packageManager.getPackageInfo(context.packageName, 0)
    if (Build.VERSION.SDK_INT >= 28) info.longVersionCode.toInt() else info.versionCode
  } catch (_: Exception) {
    0
  }

  fun status(context: Context): Map<String, Any?> {
    val config = SafeZoneConfig(context)
    val zones = try { JSONArray(config.zonesJson).length() } catch (_: Exception) { 0 }
    return mapOf(
      "available" to true,
      "enabled" to config.isComplete,
      "userId" to config.userId,
      "watch" to config.watch,
      "zones" to zones,
      "registered" to config.registeredSignature.isNotEmpty(),
      "tracking" to config.tracking,
      "trackingRunning" to SafeZoneTrackingService.running,
      "foregroundLocation" to hasForegroundLocation(context),
      "backgroundLocation" to hasBackgroundLocation(context),
      "locationOn" to locationOn(context),
      "lastSyncAt" to config.lastSyncAt.toDouble(),
      "lastError" to (problem(context) ?: config.lastError),
    )
  }
}
