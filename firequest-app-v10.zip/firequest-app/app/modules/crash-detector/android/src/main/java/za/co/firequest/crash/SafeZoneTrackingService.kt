package za.co.firequest.crash

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import java.util.concurrent.Executors

/**
 * Started when the phone leaves a safe area.
 * 1. Checking: gets a good GPS position (up to 90 seconds) and reports the exit with it, so a
 *    rough position never decides. FireQuest then says whether it raised an alarm.
 * 2. Tracking: while the control room has the safe-area alarm open, sends the location about
 *    once a minute (at most 3 hours). Stops as soon as FireQuest says the alarm is closed.
 */
class SafeZoneTrackingService : Service(), LocationListener {
  companion object {
    private const val TAG = "FireQuestSafeZones"
    private const val NOTIFICATION_ID = 4202
    private const val CHANNEL = "fq_safe_zone"
    private const val EVERY_MS = 60_000L
    private const val CONFIRM_MS = 90_000L
    private const val MAX_MS = 3 * 3600_000L
    /** No alarm confirmed by FireQuest after this long (e.g. no signal): stop; the report stays queued. */
    private const val NO_ANSWER_MS = 10 * 60_000L

    @Volatile var running = false
      private set
    /** Waiting for a good position to report an exit (not stopped by a routine check then). */
    @Volatile var checking = false
      private set

    /** Returns false when Android does not allow the service to start right now. */
    fun start(context: Context, event: String?, location: Location?, leftIds: List<String>?): Boolean {
      if (!SafeZoneConfig(context).isComplete) return false
      if (context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) return false
      if (!SafeZones.hasBackgroundLocation(context)) return false
      val intent = Intent(context, SafeZoneTrackingService::class.java)
      if (event != null) {
        intent.putExtra("event", event)
        if (location != null) intent.putExtra("location", location)
        intent.putExtra("left", (leftIds ?: emptyList()).joinToString(","))
      }
      return try {
        if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(intent) else context.startService(intent)
        true
      } catch (e: Exception) {
        Log.w(TAG, "location service could not start", e)
        false
      }
    }

    fun stop(context: Context) {
      if (running) context.stopService(Intent(context, SafeZoneTrackingService::class.java))
    }
  }

  private val handler = Handler(Looper.getMainLooper())
  private val network = Executors.newSingleThreadExecutor()
  private var locationManager: LocationManager? = null
  private var lastSentAt = 0L
  private var listening = false

  /** An exit waiting for a good position: event, ids of the circles left, best position so far. */
  private var pendingExit: Pair<String, List<String>>? = null
    set(v) { field = v; checking = v != null }
  private var bestFix: Location? = null

  override fun onBind(intent: Intent?): IBinder? = null

  override fun onCreate() {
    super.onCreate()
    locationManager = getSystemService(Context.LOCATION_SERVICE) as? LocationManager
  }

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    // Must become a foreground service straight away, or Android stops the app.
    if (!postForeground(checking = intent?.getStringExtra("event") != null)) {
      // Could not start: still send the report the normal way.
      queueFrom(intent, immediate = true)
      SafeZones.scheduleRetry(this)
      stopSelf()
      return START_NOT_STICKY
    }
    if (!running) {
      running = true
      startLocation()
      handler.postDelayed(timeLimit, MAX_MS)
      handler.postDelayed(noAnswerLimit, NO_ANSWER_MS)
    }
    queueFrom(intent, immediate = false)
    return START_NOT_STICKY
  }

  override fun onDestroy() {
    running = false
    checking = false
    handler.removeCallbacksAndMessages(null)
    stopLocation()
    // An exit still waiting for a good position is sent with the best one there is.
    pendingExit?.let { (_, left) ->
      SafeZones.queueReport(this, "exit", bestFix ?: SafeZones.lastKnownLocation(this), left)
      SafeZones.scheduleRetry(this)
      pendingExit = null
    }
    network.shutdown()
    super.onDestroy()
  }

  private val timeLimit = Runnable {
    SafeZoneConfig(this).tracking = false
    stopSelf()
  }

  private val confirmLimit = Runnable { sendPendingExit() }

  private val noAnswerLimit = Runnable {
    if (!SafeZoneConfig(this).tracking) stopSelf()
  }

  /** Takes the exit from the start intent: sends it now if the position is good, else waits for GPS. */
  @Suppress("DEPRECATION")
  private fun queueFrom(intent: Intent?, immediate: Boolean) {
    if (intent == null) return
    val event = intent.getStringExtra("event") ?: return
    val left = (intent.getStringExtra("left") ?: "").split(",").filter { it.isNotBlank() }
    val location: Location? = if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra("location", Location::class.java)
      else intent.getParcelableExtra<Location>("location")
    if (immediate || (location != null && SafeZones.isGood(location))) {
      SafeZones.queueReport(this, event, location ?: SafeZones.lastKnownLocation(this), left)
      if (!immediate) sendNow()
      return
    }
    // Rough or no position: wait for GPS (at most 90 seconds).
    pendingExit = event to left
    bestFix = better(bestFix, location ?: SafeZones.lastKnownLocation(this))
    handler.removeCallbacks(confirmLimit)
    handler.postDelayed(confirmLimit, CONFIRM_MS)
  }

  private fun better(a: Location?, b: Location?): Location? = when {
    a == null -> b
    b == null -> a
    !b.hasAccuracy() -> a
    !a.hasAccuracy() || b.accuracy <= a.accuracy -> b
    else -> a
  }

  private fun sendPendingExit() {
    val p = pendingExit ?: return
    pendingExit = null
    handler.removeCallbacks(confirmLimit)
    SafeZones.queueReport(this, p.first, bestFix ?: SafeZones.lastKnownLocation(this), p.second)
    lastSentAt = SystemClock.elapsedRealtime()
    sendNow()
  }

  private fun postForeground(checking: Boolean): Boolean = try {
    createChannel()
    val n = notification(checking)
    if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIFICATION_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
    else startForeground(NOTIFICATION_ID, n)
    true
  } catch (e: Exception) {
    Log.w(TAG, "startForeground failed", e)
    false
  }

  private fun createChannel() {
    if (Build.VERSION.SDK_INT < 26) return
    val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    nm.createNotificationChannel(
      NotificationChannel(CHANNEL, "Safe areas", NotificationManager.IMPORTANCE_LOW).apply {
        description = "Shown while FireQuest checks your location after you left a safe area, and while the control room can see it."
        setShowBadge(false)
      }
    )
  }

  private fun notification(checking: Boolean): Notification {
    val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else Notification.Builder(this)
    val text = if (checking) "You left a safe area. FireQuest is checking your location."
      else "You are outside your safe areas. The FireQuest control room can see where you are until they close the alarm."
    b.setSmallIcon(R.drawable.ic_fq_crash)
      .setColor(0xFFD42F35.toInt())
      .setContentTitle("FireQuest safe areas")
      .setContentText(text)
      .setStyle(Notification.BigTextStyle().bigText(text))
      .setOngoing(true)
      .setShowWhen(false)
      .setCategory(Notification.CATEGORY_SERVICE)
    CrashNotifications.openApp(this, 21)?.let { b.setContentIntent(it) }
    return b.build()
  }

  private fun showTracking() {
    try {
      (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIFICATION_ID, notification(false))
    } catch (_: SecurityException) {
    }
  }

  private fun startLocation() {
    if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) return
    val lm = locationManager ?: return
    val providers = try { lm.allProviders } catch (_: Exception) { emptyList<String>() }
    for (p in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)) {
      if (p !in providers) continue
      try {
        lm.requestLocationUpdates(p, 10_000L, 0f, this, Looper.getMainLooper())
        listening = true
      } catch (e: Exception) {
        Log.w(TAG, "location $p failed", e)
      }
    }
  }

  private fun stopLocation() {
    if (!listening) return
    try { locationManager?.removeUpdates(this) } catch (_: Exception) {}
    listening = false
  }

  override fun onLocationChanged(location: Location) {
    if (pendingExit != null) {
      bestFix = better(bestFix, location)
      if (SafeZones.isGood(location)) sendPendingExit()
      return
    }
    val now = SystemClock.elapsedRealtime()
    // About once a minute; a rough network fix is skipped.
    if (now - lastSentAt < EVERY_MS - 5_000L) return
    if (location.hasAccuracy() && location.accuracy > 1000f) return
    lastSentAt = now
    SafeZones.queueReport(this, "location", location)
    sendNow()
  }

  override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
  override fun onProviderEnabled(provider: String) {}
  override fun onProviderDisabled(provider: String) {}

  /** Sends waiting reports; stops when FireQuest says there is no open safe-area alarm. */
  private fun sendNow() {
    try {
      network.execute {
        val ok = try { SafeZones.flush(this) } catch (e: Exception) { false }
        if (!ok) SafeZones.scheduleRetry(this)
        val config = SafeZoneConfig(this)
        handler.post {
          if (!ok) return@post // keep going; the next location tries again
          if (!config.isComplete || !config.tracking) {
            if (pendingExit == null) stopSelf()
          } else {
            showTracking()
          }
        }
      }
    } catch (e: Exception) {
      Log.w(TAG, "send skipped", e)
    }
  }
}
