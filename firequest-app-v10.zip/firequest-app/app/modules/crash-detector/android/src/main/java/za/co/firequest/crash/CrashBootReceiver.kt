package za.co.firequest.crash

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Starts crash detection and safe areas again after the phone restarts or FireQuest is updated. */
class CrashBootReceiver : BroadcastReceiver() {
  override fun onReceive(context: Context, intent: Intent) {
    val action = intent.action ?: return
    if (action != Intent.ACTION_BOOT_COMPLETED && action != Intent.ACTION_MY_PACKAGE_REPLACED) return
    // Safe areas: Android forgets geofences when the phone restarts.
    if (SafeZoneConfig(context).isComplete) {
      try {
        SafeZones.reRegister(context.applicationContext)
        SafeZones.schedulePeriodic(context.applicationContext)
        SafeZones.scheduleRetry(context.applicationContext)
      } catch (_: Exception) {
      }
    }
    if (!CrashConfig(context).isComplete) return
    CrashDetectionService.start(context, CrashDetectionService.ACTION_START, fromBackground = true)
  }
}
