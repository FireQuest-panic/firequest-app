package za.co.firequest.crash

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.work.Worker
import androidx.work.WorkerParameters
import com.google.android.gms.location.Geofence
import com.google.android.gms.location.GeofenceStatusCodes
import com.google.android.gms.location.GeofencingEvent

/** Google Play services calls this when the phone leaves or enters a safe area (also when FireQuest is closed). */
class SafeZoneReceiver : BroadcastReceiver() {
  companion object {
    const val ACTION_GEOFENCE = "za.co.firequest.crash.SAFE_ZONE_EVENT"
    private const val TAG = "FireQuestSafeZones"
  }

  override fun onReceive(context: Context, intent: Intent) {
    val app = context.applicationContext
    val config = SafeZoneConfig(app)
    if (!config.isComplete) return
    val event = GeofencingEvent.fromIntent(intent) ?: return
    if (event.hasError()) {
      Log.w(TAG, "geofence error ${event.errorCode}")
      if (event.errorCode == GeofenceStatusCodes.GEOFENCE_NOT_AVAILABLE) {
        // Location was switched off: Android dropped the circles. Register again later.
        config.registeredSignature = ""
        config.lastError = "Location is switched off on the phone"
        SafeZones.scheduleRetry(app)
      }
      return
    }
    val kind = when (event.geofenceTransition) {
      Geofence.GEOFENCE_TRANSITION_EXIT -> "exit"
      Geofence.GEOFENCE_TRANSITION_ENTER -> "enter"
      else -> return
    }
    val leftIds = if (kind == "exit") event.triggeringGeofences?.map { it.requestId } ?: emptyList() else emptyList()
    val location = event.triggeringLocation

    // Left a circle: start the location service right away (Android only allows this straight
    // after a safe-area event). It gets a good GPS position, reports, and keeps sending the
    // location only if FireQuest raised an alarm.
    // (Skipped when a good position shows the phone is still inside another safe area.)
    val stillInside = location != null && SafeZones.isGood(location) && !SafeZones.outsideAll(app, location, leftIds)
    if (kind == "exit" && !stillInside && SafeZoneTrackingService.start(app, kind, location, leftIds)) return

    SafeZones.queueReport(app, kind, location ?: SafeZones.lastKnownLocation(app), leftIds)
    // Backup in case this quick attempt is cut short or there is no signal.
    SafeZones.scheduleRetry(app)
    val pending = goAsync()
    Thread {
      try {
        SafeZones.flush(app)
      } catch (e: Exception) {
        Log.w(TAG, "report failed", e)
      } finally {
        pending.finish()
      }
    }.start()
  }
}

/** Location switched on again: Android dropped the circles while it was off, so register them again. */
class SafeZoneLocationReceiver : BroadcastReceiver() {
  override fun onReceive(context: Context, intent: Intent) {
    val app = context.applicationContext
    val config = SafeZoneConfig(app)
    if (!config.isComplete || !config.watch || !SafeZones.locationOn(app)) return
    SafeZones.reRegister(app)
    SafeZones.scheduleRetry(app)
  }
}

/** Runs every 15 minutes (and after a failed report): sends waiting reports and fetches changes. */
class SafeZoneWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
  override fun doWork(): Result {
    val app = applicationContext
    val config = SafeZoneConfig(app)
    if (!config.isComplete) return Result.success()
    // Android may have dropped the circles (location was off): register them again.
    val force = config.watch && config.registeredSignature.isEmpty()
    if (!SafeZones.syncNow(app, forceRegister = force)) return Result.retry()
    if (config.tracking && !SafeZoneTrackingService.running) SafeZoneTrackingService.start(app, null, null, null)
    // Circles not registered yet (e.g. location still off): try again soon rather than in 15 minutes.
    return if (config.watch && config.registeredSignature.isEmpty()) Result.retry() else Result.success()
  }
}
