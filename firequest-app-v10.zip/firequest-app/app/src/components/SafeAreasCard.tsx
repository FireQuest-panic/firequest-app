import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Alert, AppState, Pressable, Text, View } from 'react-native';
import { colors } from '../theme';
import { friendlyError } from '../lib/data';
import { openAppSettings } from '../lib/crash';
import {
  SafeAreaPerson,
  SafeAreas,
  SafeZone,
  SafeZoneStatus,
  deleteSafeArea,
  distanceLabel,
  getSafeAreas,
  phoneStatus,
  safeZonesSupported,
  saveSafeArea,
  setWatching,
  switchOffThisPhone,
  switchOnThisPhone,
  syncThisPhone,
} from '../lib/safezones';
import { SafeZoneDraft, SafeZoneEditor } from './SafeZoneEditor';
import { Body, Button, Card, ErrorText } from './ui';

function firstName(p: SafeAreaPerson): string {
  return p.is_me ? 'you' : (p.name || 'this person').split(' ')[0];
}

function ago(iso: string | null | undefined): string {
  if (!iso) return '';
  const min = Math.round((Date.now() - Date.parse(iso)) / 60000);
  if (!Number.isFinite(min)) return '';
  if (min < 2) return 'just now';
  if (min < 60) return `${min} min ago`;
  const h = Math.round(min / 60);
  if (h < 48) return `${h} hours ago`;
  return `${Math.round(h / 24)} days ago`;
}

/** What the plan holder sees about one person's phone. */
function phoneLine(p: SafeAreaPerson): { text: string; tone: 'ok' | 'warn' | 'muted' } {
  if (!p.watch) return { text: 'Not watched.', tone: 'muted' };
  const s = p.phone_status;
  const who = p.is_me ? 'your phone' : `${firstName(p)}'s phone`;
  if (!s) {
    return {
      text: p.is_me
        ? 'Switch it on below, on this phone.'
        : `Waiting for ${firstName(p)}: they must open FireQuest on their own phone, tap Account, then "Switch on on this phone" under Safe areas.`,
      tone: 'warn',
    };
  }
  if (s.problem) return { text: `Not working on ${who}: ${s.problem}.`, tone: 'warn' };
  const quietHours = s.last_seen_at ? (Date.now() - Date.parse(s.last_seen_at)) / 3600000 : 99;
  if (quietHours > 3) {
    return {
      text: `No contact with ${who} for ${ago(s.last_seen_at).replace(' ago', '')}. The phone may be off, without signal, or FireQuest may be restricted by battery saving.`,
      tone: 'warn',
    };
  }
  if (!s.watching) {
    return {
      text: `Waiting for ${who} to pick up the change (when FireQuest is opened there, or within about 15 minutes).`,
      tone: 'warn',
    };
  }
  return { text: `Watching on ${who} ✓ · last contact ${ago(s.last_seen_at)}`, tone: 'ok' };
}

/** Account-screen card: the plan holder sets safe areas; each watched person switches watching on, on their phone. */
export function SafeAreasCard({ userId }: { userId: string }) {
  const [data, setData] = useState<SafeAreas | null>(null);
  const [phone, setPhone] = useState<SafeZoneStatus | null>(phoneStatus());
  const [error, setError] = useState('');
  const [busy, setBusy] = useState<string | null>(null);
  const [editing, setEditing] = useState<{ person: SafeAreaPerson; zone: SafeZone | null } | null>(null);
  const [editError, setEditError] = useState('');

  const load = useCallback(async () => {
    try {
      setData(await getSafeAreas());
    } catch (e) {
      setError(friendlyError(e));
    }
    setPhone(phoneStatus());
  }, []);

  useEffect(() => {
    load();
    syncThisPhone().then(() => setPhone(phoneStatus()));
    const sub = AppState.addEventListener('change', (s) => s === 'active' && load());
    const timer = setInterval(() => setPhone(phoneStatus()), 5000);
    return () => {
      sub.remove();
      clearInterval(timer);
    };
  }, [load]);

  const editStart = useMemo(() => {
    const p = editing?.person;
    return p && p.home_lat != null && p.home_lng != null ? { lat: p.home_lat, lng: p.home_lng } : null;
  }, [editing]);

  if (!data || !data.in_plan) return null;
  const me = data.people.find((p) => p.is_me);
  const meWatched = Boolean(me && me.watch && me.zones.length);

  const run = async (key: string, fn: () => Promise<SafeAreas | void>) => {
    setError('');
    setBusy(key);
    try {
      const r = await fn();
      if (r) setData(r);
    } catch (e) {
      setError(friendlyError(e));
    } finally {
      setBusy(null);
    }
  };

  const save = async (d: SafeZoneDraft) => {
    if (!editing) return;
    setEditError('');
    setBusy('save');
    try {
      const r = await saveSafeArea({ id: d.id, userId: editing.person.user_id, name: d.name, lat: d.lat, lng: d.lng, radius: d.radius });
      setData(r);
      const wasFirst = !editing.person.zones.length && !editing.person.watch;
      const person = editing.person;
      setEditing(null);
      if (wasFirst) {
        Alert.alert(
          'Start watching?',
          `Switch on watching for ${person.is_me ? 'yourself' : person.name || 'this person'} now? The control room gets an alarm when ${person.is_me ? 'you are' : 'they are'} outside all safe areas.`,
          [
            { text: 'Later', style: 'cancel' },
            { text: 'Start watching', onPress: () => run('watch' + person.user_id, () => setWatching(person.user_id, true)) },
          ],
        );
      }
      if (person.is_me) syncThisPhone().then(() => setPhone(phoneStatus()));
    } catch (e) {
      setEditError(friendlyError(e));
    } finally {
      setBusy(null);
    }
  };

  const remove = () => {
    const z = editing?.zone;
    if (!z) return;
    Alert.alert('Remove this safe area?', `"${z.name}" will no longer be watched.`, [
      { text: 'Keep it', style: 'cancel' },
      {
        text: 'Remove',
        style: 'destructive',
        onPress: async () => {
          setEditing(null);
          await run('del', () => deleteSafeArea(z.id));
        },
      },
    ]);
  };

  const toggleWatch = (p: SafeAreaPerson) => {
    if (p.watch) {
      Alert.alert('Stop watching?', `The control room will not be alerted when ${p.is_me ? 'you leave' : `${firstName(p)} leaves`} the safe areas.`, [
        { text: 'Keep watching', style: 'cancel' },
        { text: 'Stop', style: 'destructive', onPress: () => run('watch' + p.user_id, () => setWatching(p.user_id, false)) },
      ]);
    } else {
      run('watch' + p.user_id, () => setWatching(p.user_id, true));
    }
  };

  const phoneOn = async () => {
    setError('');
    setBusy('phone');
    try {
      const r = await switchOnThisPhone(userId);
      if (!r.ok && r.message) setError(r.message);
    } catch (e) {
      setError(friendlyError(e));
    } finally {
      setBusy(null);
      setPhone(phoneStatus());
      setTimeout(load, 2500);
    }
  };

  const phoneOff = () =>
    Alert.alert(
      'Switch off on this phone?',
      data.is_owner
        ? 'This phone stops watching your safe areas.'
        : `This phone stops watching your safe areas. ${data.owner_name || 'Your plan holder'} will see that it is switched off.`,
      [
        { text: 'Keep on', style: 'cancel' },
        {
          text: 'Switch off',
          style: 'destructive',
          onPress: async () => {
            setBusy('phone');
            await switchOffThisPhone();
            setBusy(null);
            setPhone(phoneStatus());
            load();
          },
        },
      ],
    );

  const phoneOnHere = Boolean(phone?.enabled && phone.userId === userId);
  const phoneProblem = phoneOnHere ? phone?.lastError : null;

  // ---- this phone (for anyone whose safe areas are watched)
  const thisPhone =
    meWatched || phoneOnHere ? (
      <View style={{ gap: 6, padding: 12, borderRadius: 12, backgroundColor: colors.surfaceRaised }}>
        <Text style={{ color: colors.text, fontWeight: '700' }}>This phone</Text>
        {!safeZonesSupported ? (
          <Body>This version of FireQuest cannot watch safe areas. Install the newest version.</Body>
        ) : phoneOnHere ? (
          <>
            <Text style={{ color: phoneProblem ? colors.danger : colors.green, fontSize: 14, lineHeight: 20 }}>
              {phoneProblem
                ? `Not working: ${phoneProblem}.`
                : phone?.registered
                  ? `On ✓ – this phone is watching ${phone.zones} safe area${phone.zones === 1 ? '' : 's'}.`
                  : phone?.watch
                    ? 'On – starting…'
                    : 'On – waiting for the plan holder to switch watching on.'}
            </Text>
            {phone?.tracking ? (
              <Text style={{ color: colors.goldText, fontSize: 14 }}>The control room can see your location now (you left your safe areas).</Text>
            ) : null}
            {phoneProblem && !phone?.backgroundLocation ? (
              <Button title="Open settings (Location: Allow all the time)" variant="outline" onPress={() => openAppSettings()} />
            ) : null}
            <Button title="Switch off on this phone" variant="plain" onPress={phoneOff} disabled={busy === 'phone'} />
          </>
        ) : (
          <>
            <Body>
              {data.is_owner
                ? 'Your own safe areas are watched by your phone. Switch it on here.'
                : `${data.owner_name || 'Your plan holder'} asked FireQuest to watch your safe areas. Switch it on here, on your phone.`}{' '}
              Android will ask for location – choose "Allow all the time".
            </Body>
            <Button title="Switch on on this phone" onPress={phoneOn} loading={busy === 'phone'} />
          </>
        )}
      </View>
    ) : null;

  // ---- family member (not the plan holder)
  if (!data.is_owner) {
    if (!me || (!me.zones.length && !phoneOnHere)) return null;
    return (
      <Card>
        <Text style={{ color: colors.goldText, fontWeight: '700' }}>Safe areas</Text>
        <Body>
          {data.owner_name || 'Your plan holder'} has set {me.zones.length === 1 ? 'a safe area' : 'safe areas'} for you:{' '}
          {me.zones.map((z) => `${z.name} (${distanceLabel(z.radius_m)})`).join(', ') || 'none yet'}.
          {me.watch
            ? ' If you are outside all of them, the FireQuest control room is alerted and can see where you are.'
            : ' Watching is switched off at the moment.'}
        </Body>
        {thisPhone}
        <ErrorText>{error}</ErrorText>
      </Card>
    );
  }

  // ---- plan holder
  return (
    <Card>
      <Text style={{ color: colors.goldText, fontWeight: '700' }}>Safe areas</Text>
      <Body>
        Draw safe areas (home, school, the farm) for yourself and your family. When someone is outside all of their safe
        areas, the FireQuest control room gets an alarm with their location.
      </Body>
      {data.people.map((p) => {
        const line = phoneLine(p);
        return (
          <View key={p.user_id} style={{ gap: 6, paddingTop: 10, borderTopWidth: 1, borderTopColor: colors.border }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 8 }}>
              <Text style={{ color: colors.text, fontSize: 16, fontWeight: '700', flexShrink: 1 }}>
                {p.is_me ? `${p.name || 'You'} (you)` : p.name || 'Family member'}
              </Text>
              {p.zones.length ? (
                <Button
                  title={p.watch ? 'Watching: ON' : 'Watching: OFF'}
                  variant={p.watch ? 'gold' : 'outline'}
                  onPress={() => toggleWatch(p)}
                  loading={busy === 'watch' + p.user_id}
                  style={{ minHeight: 40, paddingHorizontal: 12 }}
                />
              ) : null}
            </View>
            {p.zones.map((z) => (
              <Pressable
                key={z.id}
                accessibilityRole="button"
                accessibilityLabel={`Change safe area ${z.name}`}
                onPress={() => {
                  setEditError('');
                  setEditing({ person: p, zone: z });
                }}
                style={{ minHeight: 44, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}
              >
                <Text style={{ color: colors.text, fontSize: 15 }}>
                  {z.name} · {distanceLabel(z.radius_m)} circle
                </Text>
                <Text style={{ color: colors.goldText, fontWeight: '700' }}>Change</Text>
              </Pressable>
            ))}
            {p.zones.length < 5 ? (
              <Button
                title={p.zones.length ? 'Add another safe area' : 'Add a safe area'}
                variant="plain"
                onPress={() => {
                  setEditError('');
                  setEditing({ person: p, zone: null });
                }}
                style={{ alignSelf: 'flex-start' }}
              />
            ) : null}
            {p.zones.length ? (
              <Text style={{ color: line.tone === 'warn' ? colors.goldText : colors.muted, fontSize: 13, lineHeight: 19 }}>{line.text}</Text>
            ) : null}
          </View>
        );
      })}
      {thisPhone}
      <ErrorText>{error}</ErrorText>
      <SafeZoneEditor
        visible={editing !== null}
        personName={editing ? (editing.person.is_me ? 'you' : editing.person.name || 'this person') : ''}
        zone={editing?.zone ?? null}
        start={editStart}
        saving={busy === 'save'}
        error={editError}
        onCancel={() => setEditing(null)}
        onSave={save}
        onDelete={remove}
      />
    </Card>
  );
}
