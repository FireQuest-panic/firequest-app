import React, { useEffect, useMemo, useRef, useState } from 'react';
import { ActivityIndicator, Alert, Modal, ScrollView, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { WebView } from 'react-native-webview';
import type { WebViewMessageEvent } from 'react-native-webview';
import * as Location from 'expo-location';
import { colors } from '../theme';
import { pinMapHtml } from '../map/pinMapHtml';
import { ensureLocationPermission, quickPosition } from '../lib/location';
import { RADIUS_CHOICES, SafeZone, distanceLabel } from '../lib/safezones';
import { Button, Chip, ErrorText, Field } from './ui';

const NAMES = ['Home', 'School', 'Work', 'Farm', 'Grandparents'];

export interface SafeZoneDraft {
  id?: string;
  name: string;
  lat: number;
  lng: number;
  radius: number;
}

/**
 * Full-screen editor for one safe area: a name, a size, and a circle on the map.
 * The plan holder moves the map until the pin is in the middle of the safe area.
 */
export function SafeZoneEditor({
  visible,
  personName,
  zone,
  start,
  saving,
  error,
  onCancel,
  onSave,
  onDelete,
}: {
  visible: boolean;
  /** "you" or the person's first name, for the texts. */
  personName: string;
  /** The safe area being changed, or null for a new one. */
  zone: SafeZone | null;
  /** Where to start the map for a new safe area (e.g. the person's home pin). */
  start: { lat: number; lng: number } | null;
  saving: boolean;
  error: string;
  onCancel: () => void;
  onSave: (draft: SafeZoneDraft) => void;
  onDelete?: () => void;
}) {
  const web = useRef<WebView>(null);
  const html = useMemo(pinMapHtml, []);
  const [center, setCenter] = useState<{ lat: number; lng: number; zoom: number } | null>(null);
  const [name, setName] = useState('');
  const [radius, setRadius] = useState(500);
  const [locating, setLocating] = useState(false);
  // Save only once the map has been moved to the right place (not the first, default view).
  const [placed, setPlaced] = useState(false);

  useEffect(() => {
    if (!visible) return;
    setName(zone?.name ?? (start ? 'Home' : ''));
    setRadius(zone?.radius_m ?? 500);
    setCenter(null);
    setPlaced(false);
  }, [visible, zone, start]);

  const js = (code: string) => web.current?.injectJavaScript(`${code}; true;`);

  // Keep the circle the chosen size.
  useEffect(() => {
    if (center) js(`window.fqSetCircle(${radius}, ${placed})`);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [radius]);

  const begin = async () => {
    const at = zone ? { lat: zone.lat, lng: zone.lng } : start ?? (await quickPosition(4000));
    if (at) js(`window.fqSetView(${at.lat}, ${at.lng}, 16); window.fqSetCircle(${zone?.radius_m ?? radius}, true)`);
    else js(`window.fqSetCircle(${radius}, false)`);
  };

  const onMessage = (e: WebViewMessageEvent) => {
    try {
      const m = JSON.parse(e.nativeEvent.data) as { type: string; lat: number; lng: number; zoom: number };
      setCenter({ lat: m.lat, lng: m.lng, zoom: m.zoom });
      if (m.type === 'ready') begin();
      else setPlaced(true);
    } catch {
      // ignore
    }
  };

  const hereNow = async () => {
    setLocating(true);
    try {
      if (!(await ensureLocationPermission())) {
        Alert.alert('Location is off', 'Allow FireQuest to use your location, or move the map by hand.');
        return;
      }
      const fix = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.High });
      js(`window.fqSetView(${fix.coords.latitude}, ${fix.coords.longitude}, 16); window.fqSetCircle(${radius}, true)`);
    } catch {
      Alert.alert('No GPS fix', 'Your phone could not find its position. Move the map by hand.');
    } finally {
      setLocating(false);
    }
  };

  const save = () => {
    if (!center || !placed) return;
    if (!name.trim()) {
      Alert.alert('Name the safe area', 'For example Home or School.');
      return;
    }
    onSave({ id: zone?.id, name: name.trim(), lat: center.lat, lng: center.lng, radius });
  };

  return (
    <Modal visible={visible} animationType="slide" onRequestClose={onCancel}>
      <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }}>
        <View style={{ paddingHorizontal: 14, paddingTop: 12, gap: 4 }}>
          <Text style={{ color: colors.text, fontSize: 20, fontWeight: '800' }}>
            {zone ? 'Change safe area' : 'New safe area'} for {personName}
          </Text>
          <Text style={{ color: colors.muted, fontSize: 14, lineHeight: 20 }}>
            Move the map until the pin is in the middle of the safe area. The yellow circle is the area.
          </Text>
        </View>
        <View style={{ flex: 1, minHeight: 240 }}>
          {visible && (
            <WebView
              ref={web}
              originWhitelist={['*']}
              source={{ html, baseUrl: 'https://firequest-panic.github.io/firequest-app/' }}
              onMessage={onMessage}
              javaScriptEnabled
              domStorageEnabled
              setBuiltInZoomControls={false}
              style={{ flex: 1, backgroundColor: colors.bg }}
              startInLoadingState
              renderLoading={() => (
                <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.bg }}>
                  <ActivityIndicator color={colors.gold} size="large" />
                </View>
              )}
            />
          )}
        </View>
        <ScrollView style={{ maxHeight: 330 }} contentContainerStyle={{ padding: 14, gap: 10 }} keyboardShouldPersistTaps="handled">
          <Text style={{ color: colors.muted, fontSize: 13 }}>Size of the circle (from the pin to the edge)</Text>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
            {RADIUS_CHOICES.map((r) => (
              <Chip key={r} label={distanceLabel(r)} selected={radius === r} onPress={() => setRadius(r)} />
            ))}
          </View>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
            {NAMES.map((n) => (
              <Chip key={n} label={n} selected={name === n} onPress={() => setName(n)} />
            ))}
          </View>
          <Field label="Name" value={name} onChangeText={setName} placeholder="For example Home" maxLength={40} autoCapitalize="words" />
          <ErrorText>{error}</ErrorText>
          <Button title="Save safe area" onPress={save} loading={saving} disabled={!center || !placed} />
          <View style={{ flexDirection: 'row', gap: 8 }}>
            <Button title="Where I am now" variant="outline" onPress={hereNow} loading={locating} style={{ flex: 1 }} />
            <Button title="Cancel" variant="outline" onPress={onCancel} style={{ flex: 1 }} />
          </View>
          {zone && onDelete ? <Button title="Remove this safe area" variant="plain" onPress={onDelete} /> : null}
        </ScrollView>
      </SafeAreaView>
    </Modal>
  );
}
