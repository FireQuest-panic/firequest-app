// Safe areas (geofences). The plan holder draws circles for each person on the plan; each
// person's own phone watches them in the background (app/modules/crash-detector, Android) and
// FireQuest alerts the control room when the person is outside all of them.
import { Alert, PermissionsAndroid, Platform } from 'react-native';
import * as Location from 'expo-location';
import CrashDetector, { SafeZoneStatus } from '../../modules/crash-detector';
import config from '../config.json';
import { supabase } from './supabase';

export type { SafeZoneStatus };

export interface SafeZone {
  id: string;
  name: string;
  lat: number;
  lng: number;
  radius_m: number;
}

export interface SafeAreaPerson {
  user_id: string;
  name: string | null;
  phone: string | null;
  is_me: boolean;
  role: 'owner' | 'member';
  relationship: string | null;
  home_lat: number | null;
  home_lng: number | null;
  watch: boolean;
  state: 'unknown' | 'inside' | 'outside';
  state_at: string | null;
  last_report_at: string | null;
  zones: SafeZone[];
  phone_status: { registered: boolean; watching: boolean; last_seen_at: string | null; problem: string | null } | null;
}

export interface SafeAreas {
  in_plan: boolean;
  is_owner: boolean;
  owner_name?: string | null;
  test_mode?: boolean;
  people: SafeAreaPerson[];
}

/** Null while the database has not been updated for safe areas yet. */
export async function getSafeAreas(): Promise<SafeAreas | null> {
  const { data, error } = await supabase.rpc('safe_areas');
  if (error) {
    if (/safe_areas/.test(error.message) || error.code === 'PGRST202') return null;
    throw error;
  }
  return data as SafeAreas;
}

export async function saveSafeArea(z: { id?: string | null; userId: string; name: string; lat: number; lng: number; radius: number }): Promise<SafeAreas> {
  const { data, error } = await supabase.rpc('safe_area_save', {
    p_id: z.id ?? null,
    p_user_id: z.userId,
    p_name: z.name,
    p_lat: z.lat,
    p_lng: z.lng,
    p_radius_m: Math.round(z.radius),
  });
  if (error) throw error;
  return data as SafeAreas;
}

export async function deleteSafeArea(id: string): Promise<SafeAreas> {
  const { data, error } = await supabase.rpc('safe_area_delete', { p_id: id });
  if (error) throw error;
  return data as SafeAreas;
}

export async function setWatching(userId: string, on: boolean): Promise<SafeAreas> {
  const { data, error } = await supabase.rpc('safe_area_watch', { p_user_id: userId, p_on: on });
  if (error) throw error;
  return data as SafeAreas;
}

// ------------------------------------------------------------------ this phone

/** True when this app build can watch safe areas in the background. */
export const safeZonesSupported = Platform.OS === 'android' && typeof CrashDetector?.safeZonesStatus === 'function';

export function phoneStatus(): SafeZoneStatus | null {
  try {
    return CrashDetector?.safeZonesStatus ? CrashDetector.safeZonesStatus() : null;
  } catch {
    return null;
  }
}

function ask(title: string, message: string, ok = 'Continue'): Promise<boolean> {
  return new Promise((resolve) =>
    Alert.alert(title, message, [
      { text: 'Not now', style: 'cancel', onPress: () => resolve(false) },
      { text: ok, onPress: () => resolve(true) },
    ]),
  );
}

export interface PhoneResult {
  ok: boolean;
  message?: string;
}

/** Asks for the location permissions step by step, registers this phone and starts watching. */
export async function switchOnThisPhone(userId: string): Promise<PhoneResult> {
  if (!safeZonesSupported || !CrashDetector?.safeZonesStart) {
    return { ok: false, message: 'This version of FireQuest cannot watch safe areas. Install the newest version.' };
  }
  const fg = await Location.requestForegroundPermissionsAsync();
  if (fg.status !== 'granted') {
    return { ok: false, message: 'Safe areas need your location. Allow location for FireQuest and try again.' };
  }
  if (fg.android?.accuracy === 'coarse') {
    return {
      ok: false,
      message: 'Safe areas need your precise location. Open FireQuest settings > Location and switch on "Use precise location".',
    };
  }
  let bg = await Location.getBackgroundPermissionsAsync();
  if (bg.status !== 'granted') {
    const go = await ask(
      'One more location setting',
      'So FireQuest can tell when you leave your safe areas while the app is closed, choose "Allow all the time" on the next screen, then come back.',
      'Open setting',
    );
    if (!go) return { ok: false, message: 'Safe areas only work with location set to "Allow all the time".' };
    try {
      bg = await Location.requestBackgroundPermissionsAsync();
    } catch {
      // some phones only allow this in Settings
    }
    if (bg.status !== 'granted') {
      return {
        ok: false,
        message: 'Location is not set to "Allow all the time" yet. Tap "Open settings", then Permissions > Location > Allow all the time.',
      };
    }
  }
  if (Platform.OS === 'android' && Number(Platform.Version) >= 33) {
    await PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.POST_NOTIFICATIONS);
  }

  // Battery saving can stop FireQuest from following the location for the control room.
  try {
    const crash = CrashDetector.getStatus();
    if (!crash.batteryUnrestricted) {
      const go = await ask(
        'Battery setting',
        'So the control room can follow your location after you leave a safe area, allow FireQuest to run without battery restrictions (tap Allow on the next screen).',
        'Open setting',
      );
      if (go) CrashDetector.openBatterySettings();
    }
  } catch {
    // not available on this phone
  }

  // Switching on again on this phone: send any waiting reports, then remove its previous key.
  try {
    await CrashDetector.safeZonesSync?.();
  } catch {
    // offline
  }
  try {
    const old = await CrashDetector.safeZonesStop?.();
    if (old?.deviceKey) await supabase.rpc('unregister_safe_zone_device', { p_key: old.deviceKey });
  } catch {
    // nothing to remove
  }

  const { data, error } = await supabase.rpc('register_safe_zone_device');
  if (error) throw error;
  const s = await CrashDetector.safeZonesStart({
    supabaseUrl: config.supabaseUrl,
    supabaseKey: config.supabaseKey,
    deviceKey: String(data),
    userId,
  });
  if (s.lastError && !s.lastSyncAt) return { ok: false, message: s.lastError };
  return { ok: true };
}

/** Stops watching on this phone and deletes its key. */
export async function switchOffThisPhone(): Promise<void> {
  let deviceKey = '';
  try {
    deviceKey = (await CrashDetector?.safeZonesStop?.())?.deviceKey ?? '';
  } catch {
    // already off
  }
  if (!deviceKey) return;
  try {
    await supabase.rpc('unregister_safe_zone_device', { p_key: deviceKey });
  } catch {
    // offline: the key is no longer on this phone anyway
  }
}

/**
 * Called when someone is signed in: fetches changes made by the plan holder, or switches
 * off if this phone was set up for someone else before.
 */
export async function resumeSafeZones(userId: string): Promise<void> {
  try {
    const s = phoneStatus();
    if (!s?.enabled) return;
    if (s.userId && s.userId !== userId) {
      await switchOffThisPhone();
      return;
    }
    await CrashDetector?.safeZonesSync?.();
  } catch {
    // shown on the Safe areas card
  }
}

export async function syncThisPhone(): Promise<SafeZoneStatus | null> {
  try {
    return (await CrashDetector?.safeZonesSync?.()) ?? null;
  } catch {
    return phoneStatus();
  }
}

export function distanceLabel(m: number): string {
  return m >= 1000 ? `${(m / 1000).toFixed(m % 1000 === 0 ? 0 : 1)} km` : `${Math.round(m)} m`;
}

export const RADIUS_CHOICES = [200, 500, 1000, 2000, 5000, 10000, 20000];
