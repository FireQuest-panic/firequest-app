import { LEAFLET_CSS, LEAFLET_JS } from './leaflet';

/**
 * A small map page for the web view: satellite photos (or a street map) with a fixed
 * red pin in the middle. The client moves the map until the pin is on their home.
 * The page reports the middle of the map to the app after every move.
 * For safe areas, window.fqSetCircle(metres, fit) draws a circle around the pin.
 */
export function pinMapHtml(): string {
  return `<!doctype html>
<html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<style>${LEAFLET_CSS}
html, body, #map { margin: 0; height: 100%; width: 100%; background: #0F0F10; }
.pin { position: absolute; left: 50%; top: 50%; width: 40px; height: 52px; margin: -52px 0 0 -20px; z-index: 1000; pointer-events: none; filter: drop-shadow(0 2px 3px rgba(0,0,0,.6)); }
.layers { position: absolute; right: 10px; top: 10px; z-index: 1002; display: flex; border-radius: 10px; overflow: hidden; border: 1px solid #4A4538; }
.layers button { background: #1A1A1C; color: #F4F1EA; border: 0; padding: 10px 14px; font: 600 15px system-ui, sans-serif; }
.layers button.on { background: #B99B52; color: #111214; }
.err { position: absolute; left: 10px; right: 10px; bottom: 34px; z-index: 1002; background: #2E1214; color: #FFB4B7; padding: 10px 12px; border-radius: 10px; font: 14px system-ui, sans-serif; display: none; }
.leaflet-control-attribution { font-size: 10px; }
</style></head>
<body>
<div id="map"></div>
<svg class="pin" viewBox="0 0 40 52" aria-hidden="true"><path d="M20 1C9.5 1 1 9.5 1 20c0 14.5 19 31 19 31s19-16.5 19-31C39 9.5 30.5 1 20 1z" fill="#D42F35" stroke="#fff" stroke-width="2"/><circle cx="20" cy="20" r="6.5" fill="#fff"/></svg>
<div class="layers"><button id="sat" class="on" type="button">Satellite</button><button id="street" type="button">Map</button></div>
<div class="err" id="err">The map cannot load. Check your internet connection.</div>
<script>${LEAFLET_JS}</script>
<script>
(function () {
  var map = L.map('map', { zoomControl: true, attributionControl: true }).setView([-29, 25], 5);
  var sat = L.layerGroup([
    L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
      maxZoom: 20, maxNativeZoom: 19, attribution: 'Imagery &copy; Esri, Maxar, Earthstar Geographics'
    }),
    L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}', {
      maxZoom: 20, maxNativeZoom: 19
    })
  ]);
  var street = L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 20, maxNativeZoom: 19, attribution: '&copy; OpenStreetMap contributors'
  });
  sat.addTo(map);

  function choose(layer) {
    var useSat = layer === 'sat';
    if (useSat) { map.removeLayer(street); sat.addTo(map); } else { map.removeLayer(sat); street.addTo(map); }
    document.getElementById('sat').className = useSat ? 'on' : '';
    document.getElementById('street').className = useSat ? '' : 'on';
  }
  document.getElementById('sat').onclick = function () { choose('sat'); };
  document.getElementById('street').onclick = function () { choose('street'); };

  var loaded = 0, failed = 0;
  function watch(layer) {
    layer.on('tileload', function () { loaded++; document.getElementById('err').style.display = 'none'; });
    layer.on('tileerror', function () { failed++; if (failed > 5 && loaded === 0) document.getElementById('err').style.display = 'block'; });
  }
  sat.eachLayer(watch); watch(street);

  function send(type) {
    var c = map.getCenter();
    if (window.ReactNativeWebView) {
      window.ReactNativeWebView.postMessage(JSON.stringify({ type: type, lat: c.lat, lng: c.lng, zoom: map.getZoom() }));
    }
  }
  map.on('moveend', function () { send('move'); });
  window.fqSetView = function (lat, lng, zoom) { map.setView([lat, lng], zoom || 18); };

  // Safe areas: a circle that stays around the pin while the map moves.
  var circle = null;
  function moveCircle() { if (circle) circle.setLatLng(map.getCenter()); }
  map.on('move', moveCircle);
  window.fqSetCircle = function (radius, fit) {
    if (!radius) { if (circle) { map.removeLayer(circle); circle = null; } return; }
    if (!circle) {
      circle = L.circle(map.getCenter(), { radius: radius, color: '#E5C46B', weight: 3, fillColor: '#E5C46B', fillOpacity: 0.15, interactive: false }).addTo(map);
    } else {
      circle.setRadius(radius); moveCircle();
    }
    if (fit) map.fitBounds(circle.getBounds(), { padding: [30, 30], animate: false });
  };
  send('ready');
})();
</script>
</body></html>`;
}
