-- =====================================================================
-- FireQuest – automatic crash detection (Android)
-- The crash-detection service on the phone keeps running when the app is
-- closed, so it cannot rely on the normal login session. When the client
-- switches crash detection on, the app registers the phone and receives a
-- long random device key. The service sends that key with a crash alert.
-- Only a SHA-256 hash of the key is stored. Switching off deletes it.
-- Run after 003_family_invites.sql. (Also included in schema.sql.)
-- =====================================================================

-- Where an alert came from: a button press, or the phone's crash detection.
alter table public.alerts add column if not exists source text not null default 'button'
  check (source in ('button', 'crash_detection'));

-- One row per phone (a person may use crash detection on up to 5 phones).
create table if not exists private.crash_devices (
  key_hash     text primary key,
  user_id      uuid not null references public.profiles (id) on delete cascade,
  created_at   timestamptz not null default now(),
  last_used_at timestamptz
);
create index if not exists crash_devices_user_idx on private.crash_devices (user_id);

-- Every detection, sent or cancelled with "I'm OK". Used to tune the detector
-- during testing. Cancelled detections store no location.
create table if not exists private.crash_detections (
  id         bigint generated always as identity primary key,
  user_id    uuid not null references public.profiles (id) on delete cascade,
  outcome    text not null check (outcome in ('alert_sent', 'cancelled')),
  simulated  boolean not null default false,
  peak_g     real,
  speed_kmh  real,
  created_at timestamptz not null default now()
);

create or replace function private.crash_device_user(p_key text)
returns uuid language sql stable security definer set search_path = public as $$
  select user_id from private.crash_devices
   where key_hash = encode(extensions.digest(coalesce(p_key, ''), 'sha256'), 'hex')
$$;

-- Signed-in client: create a device key for this phone. Keeps the 5 newest phones per person.
create or replace function public.register_crash_device()
returns text language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
  v_key text;
begin
  if v_uid is null then raise exception 'Not signed in'; end if;
  v_key := encode(extensions.gen_random_bytes(32), 'hex');
  insert into private.crash_devices (key_hash, user_id)
  values (encode(extensions.digest(v_key, 'sha256'), 'hex'), v_uid);
  delete from private.crash_devices
   where user_id = v_uid
     and key_hash not in (select key_hash from private.crash_devices
                           where user_id = v_uid order by created_at desc limit 5);
  return v_key;
end $$;

drop function if exists public.unregister_crash_device();

-- Signed-in client: switch crash detection off on one phone (that phone's key stops working).
create or replace function public.unregister_crash_device(p_key text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'Not signed in'; end if;
  delete from private.crash_devices
   where user_id = auth.uid()
     and key_hash = encode(extensions.digest(coalesce(p_key, ''), 'sha256'), 'hex');
end $$;

-- Phone service: raise a vehicle alert after a crash was detected and not cancelled.
create or replace function public.raise_crash_alert(
  p_key       text,
  p_lat       double precision default null,
  p_lng       double precision default null,
  p_accuracy  real default null,
  p_peak_g    real default null,
  p_speed_kmh real default null,
  p_simulated boolean default false
) returns uuid
language plpgsql security definer set search_path = public as $$
declare
  v_uid   uuid := private.crash_device_user(p_key);
  v_alert public.alerts;
  v_note  text;
begin
  if v_uid is null then
    raise exception 'Crash detection is not registered for this phone. Open FireQuest and switch it on again.';
  end if;
  update private.crash_devices set last_used_at = now()
   where key_hash = encode(extensions.digest(p_key, 'sha256'), 'hex');

  v_note := case when coalesce(p_simulated, false) then 'SIMULATED crash (test button)' else 'Crash detected by phone' end
         || coalesce(': ' || round(p_peak_g::numeric, 1) || ' g', '')
         || coalesce(' at ' || round(p_speed_kmh::numeric) || ' km/h', '');

  insert into private.crash_detections (user_id, outcome, simulated, peak_g, speed_kmh)
  values (v_uid, 'alert_sent', coalesce(p_simulated, false), p_peak_g, p_speed_kmh);

  -- Add to the client's open alert, except that a real crash never joins a TEST alert
  -- once FireQuest is live (test mode off).
  select * into v_alert from public.alerts
   where user_id = v_uid and status not in ('closed', 'cancelled')
     and (coalesce(p_simulated, false) or not is_test
          or coalesce((select test_mode from public.app_settings where id = 1), true))
   order by created_at desc limit 1;

  if not found then
    insert into public.alerts (user_id, type, is_test, source)
    values (v_uid, 'vehicle',
            coalesce((select test_mode from public.app_settings where id = 1), true) or coalesce(p_simulated, false),
            'crash_detection')
    returning * into v_alert;
    insert into public.alert_events (alert_id, actor_id, actor_kind, event, note)
    values (v_alert.id, v_uid, 'system', 'raised', 'vehicle');
  end if;
  insert into public.alert_events (alert_id, actor_id, actor_kind, event, note)
  values (v_alert.id, v_uid, 'system', 'crash_detected', v_note);

  if p_lat is not null and p_lng is not null then
    update public.alerts
       set lat = p_lat, lng = p_lng, accuracy_m = p_accuracy, location_updated_at = now()
     where id = v_alert.id;
    insert into public.alert_locations (alert_id, lat, lng, accuracy_m)
    values (v_alert.id, p_lat, p_lng, p_accuracy);
  end if;

  return v_alert.id;
end $$;

-- Phone service: keep the location of the open alert up to date.
create or replace function public.crash_alert_location(
  p_key      text,
  p_lat      double precision,
  p_lng      double precision,
  p_accuracy real default null
) returns void
language plpgsql security definer set search_path = public as $$
declare
  v_uid   uuid := private.crash_device_user(p_key);
  v_alert uuid;
begin
  if v_uid is null then raise exception 'Crash detection is not registered for this phone.'; end if;
  update public.alerts
     set lat = p_lat, lng = p_lng, accuracy_m = p_accuracy, location_updated_at = now()
   where id = (select id from public.alerts
                where user_id = v_uid and status not in ('closed', 'cancelled')
                order by created_at desc limit 1)
  returning id into v_alert;
  if v_alert is not null then
    insert into public.alert_locations (alert_id, lat, lng, accuracy_m)
    values (v_alert, p_lat, p_lng, p_accuracy);
  end if;
end $$;

-- Phone service: the client tapped "I'm OK" during the countdown. No alert is sent.
create or replace function public.log_crash_cancelled(
  p_key       text,
  p_peak_g    real default null,
  p_speed_kmh real default null,
  p_simulated boolean default false
) returns void
language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := private.crash_device_user(p_key);
begin
  if v_uid is null then return; end if;
  insert into private.crash_detections (user_id, outcome, simulated, peak_g, speed_kmh)
  values (v_uid, 'cancelled', coalesce(p_simulated, false), p_peak_g, p_speed_kmh);
end $$;

revoke execute on function
  public.register_crash_device(),
  public.unregister_crash_device(text),
  public.raise_crash_alert(text, double precision, double precision, real, real, real, boolean),
  public.crash_alert_location(text, double precision, double precision, real),
  public.log_crash_cancelled(text, real, real, boolean)
from public;

grant execute on function public.register_crash_device(), public.unregister_crash_device(text) to authenticated;
revoke execute on function public.register_crash_device(), public.unregister_crash_device(text) from anon;

-- The phone service calls these without a login; the device key is the proof.
grant execute on function
  public.raise_crash_alert(text, double precision, double precision, real, real, real, boolean),
  public.crash_alert_location(text, double precision, double precision, real),
  public.log_crash_cancelled(text, real, real, boolean)
to anon, authenticated;

revoke all on private.crash_devices, private.crash_detections from public, anon, authenticated;
revoke execute on function private.crash_device_user(text) from public, anon, authenticated;
