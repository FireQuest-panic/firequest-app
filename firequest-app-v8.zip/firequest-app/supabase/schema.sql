-- =====================================================================
-- FireQuest Panic – database schema (Supabase / PostgreSQL)
--
-- Run this ONCE on a new, empty Supabase project:
--   Supabase dashboard → SQL Editor → New query → paste this file → Run
--
-- What it creates
--   * Client data: profiles, medical_profiles, emergency_contacts
--   * Control room: staff, alerts, alert_locations, alert_events
--   * Settings: app_settings (test mode is ON by default)
--   * Security: row-level security on every table, plus functions that
--     are the ONLY way to raise, update, cancel or handle an alert.
-- =====================================================================

create extension if not exists pgcrypto with schema extensions;

-- ---------------------------------------------------------------------
-- Types
-- ---------------------------------------------------------------------
create type public.alert_type as enum ('medical', 'vehicle', 'fire');
create type public.alert_status as enum (
  'new', 'acknowledged', 'dispatched', 'on_scene', 'closed', 'cancelled'
);

-- ---------------------------------------------------------------------
-- Settings (single row)
-- ---------------------------------------------------------------------
create table public.app_settings (
  id          int primary key default 1 check (id = 1),
  test_mode   boolean not null default true,
  control_room_phone text not null default '',
  updated_at  timestamptz not null default now()
);
insert into public.app_settings (id) values (1);

-- ---------------------------------------------------------------------
-- Client data
-- ---------------------------------------------------------------------
create table public.profiles (
  id                    uuid primary key references auth.users (id) on delete cascade,
  email                 text,
  full_name             text not null default '',
  phone                 text not null default '',
  id_number             text,
  date_of_birth         date,
  gender                text,
  home_address          text,
  vehicle_make          text,
  vehicle_model         text,
  vehicle_colour        text,
  vehicle_registration  text,
  consent_at            timestamptz,          -- POPIA consent to process & share health info
  onboarded_at          timestamptz,          -- set when registration is complete
  created_at            timestamptz not null default now(),
  updated_at            timestamptz not null default now()
);

create table public.medical_profiles (
  user_id             uuid primary key references public.profiles (id) on delete cascade,
  blood_type          text,
  allergies           text[] not null default '{}',
  conditions          text,
  medication          text,
  medical_aid_scheme  text,
  medical_aid_plan    text,
  medical_aid_number  text,
  doctor_name         text,
  doctor_phone        text,
  updated_at          timestamptz not null default now()
);

create table public.emergency_contacts (
  id            uuid primary key default gen_random_uuid(),
  user_id       uuid not null references public.profiles (id) on delete cascade,
  name          text not null,
  relationship  text,
  phone         text not null,
  created_at    timestamptz not null default now()
);
create index emergency_contacts_user_idx on public.emergency_contacts (user_id);

-- Cancel PINs live in a schema the public API cannot reach.
create schema if not exists private;
revoke all on schema private from public, anon, authenticated;

create table private.cancel_pins (
  user_id     uuid primary key references auth.users (id) on delete cascade,
  pin_hash    text not null,
  updated_at  timestamptz not null default now()
);

-- ---------------------------------------------------------------------
-- Control room
-- ---------------------------------------------------------------------
create table public.staff (
  user_id       uuid primary key references auth.users (id) on delete cascade,
  display_name  text not null,
  role          text not null default 'operator' check (role in ('operator', 'admin')),
  created_at    timestamptz not null default now()
);

create table public.alerts (
  id                   uuid primary key default gen_random_uuid(),
  user_id              uuid not null references public.profiles (id) on delete cascade,
  type                 public.alert_type not null,
  status               public.alert_status not null default 'new',
  is_test              boolean not null default true,
  lat                  double precision,
  lng                  double precision,
  accuracy_m           real,
  location_updated_at  timestamptz,
  operator_id          uuid references public.staff (user_id),
  outcome              text,
  created_at           timestamptz not null default now(),
  acknowledged_at      timestamptz,
  dispatched_at        timestamptz,
  on_scene_at          timestamptz,
  closed_at            timestamptz,
  cancelled_at         timestamptz
);
create index alerts_user_status_idx on public.alerts (user_id, status);
create index alerts_status_created_idx on public.alerts (status, created_at desc);

create table public.alert_locations (
  id           bigint generated always as identity primary key,
  alert_id     uuid not null references public.alerts (id) on delete cascade,
  lat          double precision not null,
  lng          double precision not null,
  accuracy_m   real,
  recorded_at  timestamptz not null default now()
);
create index alert_locations_alert_idx on public.alert_locations (alert_id, recorded_at desc);

create table public.alert_events (
  id          bigint generated always as identity primary key,
  alert_id    uuid not null references public.alerts (id) on delete cascade,
  actor_id    uuid,
  actor_kind  text not null check (actor_kind in ('client', 'operator', 'system')),
  event       text not null,
  note        text,
  created_at  timestamptz not null default now()
);
create index alert_events_alert_idx on public.alert_events (alert_id, created_at);

-- ---------------------------------------------------------------------
-- Helper functions
-- ---------------------------------------------------------------------
create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end $$;

create trigger profiles_updated_at before update on public.profiles
  for each row execute function public.set_updated_at();
create trigger medical_profiles_updated_at before update on public.medical_profiles
  for each row execute function public.set_updated_at();

create or replace function public.is_staff()
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.staff where user_id = auth.uid());
$$;

-- Staff may only see a client's personal and medical details while that
-- client has an open alert, or for 24 hours after an alert was raised.
create or replace function public.staff_can_view(p_user_id uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select public.is_staff() and exists (
    select 1 from public.alerts a
    where a.user_id = p_user_id
      and (a.status not in ('closed', 'cancelled') or a.created_at > now() - interval '24 hours')
  );
$$;

create or replace function public.owns_alert(p_alert_id uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.alerts where id = p_alert_id and user_id = auth.uid());
$$;

create or replace function public.status_rank(s public.alert_status)
returns int language sql immutable as $$
  select case s
    when 'new' then 0 when 'acknowledged' then 1 when 'dispatched' then 2
    when 'on_scene' then 3 else 4 end;
$$;

-- Create a profile row automatically when someone signs up.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, email, full_name, phone)
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data ->> 'full_name', ''),
    coalesce(new.raw_user_meta_data ->> 'phone', '')
  )
  on conflict (id) do nothing;
  return new;
end $$;

create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- ---------------------------------------------------------------------
-- Row-level security
-- ---------------------------------------------------------------------
alter table public.app_settings       enable row level security;
alter table public.profiles           enable row level security;
alter table public.medical_profiles   enable row level security;
alter table public.emergency_contacts enable row level security;
alter table public.staff              enable row level security;
alter table public.alerts             enable row level security;
alter table public.alert_locations    enable row level security;
alter table public.alert_events       enable row level security;

-- Settings: anyone signed in can read; changes only from the SQL editor.
create policy "settings readable" on public.app_settings
  for select to authenticated using (true);

-- Profiles
create policy "own profile read" on public.profiles
  for select to authenticated using (id = auth.uid() or public.staff_can_view(id));
create policy "own profile insert" on public.profiles
  for insert to authenticated with check (id = auth.uid());
create policy "own profile update" on public.profiles
  for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

-- Medical profile
create policy "own medical read" on public.medical_profiles
  for select to authenticated using (user_id = auth.uid() or public.staff_can_view(user_id));
create policy "own medical insert" on public.medical_profiles
  for insert to authenticated with check (user_id = auth.uid());
create policy "own medical update" on public.medical_profiles
  for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

-- Emergency contacts
create policy "own contacts read" on public.emergency_contacts
  for select to authenticated using (user_id = auth.uid() or public.staff_can_view(user_id));
create policy "own contacts insert" on public.emergency_contacts
  for insert to authenticated with check (user_id = auth.uid());
create policy "own contacts update" on public.emergency_contacts
  for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "own contacts delete" on public.emergency_contacts
  for delete to authenticated using (user_id = auth.uid());

-- Staff list: visible to staff (and each person can see their own row).
create policy "staff read" on public.staff
  for select to authenticated using (user_id = auth.uid() or public.is_staff());

-- Alerts: clients see their own, staff see all. No direct writes –
-- every change goes through the functions below.
create policy "alerts read" on public.alerts
  for select to authenticated using (user_id = auth.uid() or public.is_staff());
create policy "alert locations read" on public.alert_locations
  for select to authenticated using (public.owns_alert(alert_id) or public.is_staff());
create policy "alert events read" on public.alert_events
  for select to authenticated using (public.owns_alert(alert_id) or public.is_staff());

-- ---------------------------------------------------------------------
-- Client functions
-- ---------------------------------------------------------------------
create or replace function public.set_cancel_pin(p_pin text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'Not signed in'; end if;
  if p_pin !~ '^[0-9]{4,6}$' then raise exception 'PIN must be 4 to 6 digits'; end if;
  insert into private.cancel_pins (user_id, pin_hash, updated_at)
  values (auth.uid(), extensions.crypt(p_pin, extensions.gen_salt('bf')), now())
  on conflict (user_id) do update set pin_hash = excluded.pin_hash, updated_at = now();
end $$;

create or replace function public.has_cancel_pin()
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from private.cancel_pins where user_id = auth.uid());
$$;

-- Raise an alert. If the client already has an open alert, that alert is
-- returned instead of creating a duplicate.
create or replace function public.raise_alert(
  p_type public.alert_type,
  p_lat double precision default null,
  p_lng double precision default null,
  p_accuracy real default null
) returns public.alerts
language plpgsql security definer set search_path = public as $$
declare
  v_uid   uuid := auth.uid();
  v_alert public.alerts;
begin
  if v_uid is null then raise exception 'Not signed in'; end if;

  select * into v_alert from public.alerts
   where user_id = v_uid and status not in ('closed', 'cancelled')
   order by created_at desc limit 1;

  if found then
    insert into public.alert_events (alert_id, actor_id, actor_kind, event, note)
    values (v_alert.id, v_uid, 'client', 'pressed_again', p_type::text);
  else
    insert into public.alerts (user_id, type, is_test)
    values (v_uid, p_type, (select test_mode from public.app_settings where id = 1))
    returning * into v_alert;

    insert into public.alert_events (alert_id, actor_id, actor_kind, event, note)
    values (v_alert.id, v_uid, 'client', 'raised', p_type::text);
  end if;

  if p_lat is not null and p_lng is not null then
    update public.alerts
       set lat = p_lat, lng = p_lng, accuracy_m = p_accuracy, location_updated_at = now()
     where id = v_alert.id
     returning * into v_alert;
    insert into public.alert_locations (alert_id, lat, lng, accuracy_m)
    values (v_alert.id, p_lat, p_lng, p_accuracy);
  end if;

  return v_alert;
end $$;

create or replace function public.update_alert_location(
  p_alert_id uuid,
  p_lat double precision,
  p_lng double precision,
  p_accuracy real default null
) returns void
language plpgsql security definer set search_path = public as $$
begin
  update public.alerts
     set lat = p_lat, lng = p_lng, accuracy_m = p_accuracy, location_updated_at = now()
   where id = p_alert_id and user_id = auth.uid()
     and status not in ('closed', 'cancelled');
  if found then
    insert into public.alert_locations (alert_id, lat, lng, accuracy_m)
    values (p_alert_id, p_lat, p_lng, p_accuracy);
  end if;
end $$;

-- Cancel with the client's PIN. Returns true when cancelled.
create or replace function public.cancel_alert(p_alert_id uuid, p_pin text)
returns boolean
language plpgsql security definer set search_path = public as $$
declare
  v_uid  uuid := auth.uid();
  v_hash text;
begin
  if not exists (
    select 1 from public.alerts
     where id = p_alert_id and user_id = v_uid and status not in ('closed', 'cancelled')
  ) then
    return false;
  end if;

  select pin_hash into v_hash from private.cancel_pins where user_id = v_uid;

  if v_hash is not null and extensions.crypt(p_pin, v_hash) = v_hash then
    update public.alerts set status = 'cancelled', cancelled_at = now() where id = p_alert_id;
    insert into public.alert_events (alert_id, actor_id, actor_kind, event)
    values (p_alert_id, v_uid, 'client', 'cancelled_by_client');
    return true;
  end if;

  insert into public.alert_events (alert_id, actor_id, actor_kind, event)
  values (p_alert_id, v_uid, 'client', 'cancel_wrong_pin');
  return false;
end $$;

-- ---------------------------------------------------------------------
-- Control room function
-- Actions: acknowledge, dispatch, on_scene, close, note,
--          navigate_opened, route_sent, called_client
-- ---------------------------------------------------------------------
create or replace function public.operator_update_alert(
  p_alert_id uuid,
  p_action text,
  p_note text default null
) returns public.alerts
language plpgsql security definer set search_path = public as $$
declare
  v_uid   uuid := auth.uid();
  v_alert public.alerts;
  v_new   public.alert_status;
begin
  if not public.is_staff() then raise exception 'Not authorised'; end if;

  select * into v_alert from public.alerts where id = p_alert_id for update;
  if not found then raise exception 'Alert not found'; end if;

  if p_action in ('acknowledge', 'dispatch', 'on_scene', 'close') then
    if v_alert.status in ('closed', 'cancelled') then
      raise exception 'This alert is already %', v_alert.status;
    end if;

    v_new := case p_action
      when 'acknowledge' then 'acknowledged'
      when 'dispatch'    then 'dispatched'
      when 'on_scene'    then 'on_scene'
      else 'closed' end;

    update public.alerts set
      status          = case when public.status_rank(v_new) > public.status_rank(status) then v_new else status end,
      operator_id     = coalesce(operator_id, v_uid),
      acknowledged_at = coalesce(acknowledged_at, now()),
      dispatched_at   = case when p_action = 'dispatch' then coalesce(dispatched_at, now()) else dispatched_at end,
      on_scene_at     = case when p_action = 'on_scene' then coalesce(on_scene_at, now()) else on_scene_at end,
      closed_at       = case when p_action = 'close' then now() else closed_at end,
      outcome         = case when p_action = 'close' then p_note else outcome end
    where id = p_alert_id
    returning * into v_alert;
  elsif p_action not in ('note', 'navigate_opened', 'route_sent', 'called_client') then
    raise exception 'Unknown action %', p_action;
  end if;

  insert into public.alert_events (alert_id, actor_id, actor_kind, event, note)
  values (p_alert_id, v_uid, 'operator', p_action, p_note);

  return v_alert;
end $$;

-- Only signed-in users may call the functions.
revoke execute on function
  public.set_cancel_pin(text),
  public.has_cancel_pin(),
  public.raise_alert(public.alert_type, double precision, double precision, real),
  public.update_alert_location(uuid, double precision, double precision, real),
  public.cancel_alert(uuid, text),
  public.operator_update_alert(uuid, text, text)
from public, anon;

grant execute on function
  public.set_cancel_pin(text),
  public.has_cancel_pin(),
  public.raise_alert(public.alert_type, double precision, double precision, real),
  public.update_alert_location(uuid, double precision, double precision, real),
  public.cancel_alert(uuid, text),
  public.operator_update_alert(uuid, text, text)
to authenticated;

-- Helper functions: fixed search path, and not callable by anonymous visitors.
alter function public.set_updated_at() set search_path = public;
alter function public.status_rank(public.alert_status) set search_path = public;

revoke execute on function
  public.handle_new_user(),
  public.is_staff(),
  public.owns_alert(uuid),
  public.staff_can_view(uuid),
  public.status_rank(public.alert_status),
  public.set_updated_at()
from public, anon;

revoke execute on function public.handle_new_user() from authenticated;

grant execute on function
  public.is_staff(),
  public.owns_alert(uuid),
  public.staff_can_view(uuid),
  public.status_rank(public.alert_status)
to authenticated;

-- ---------------------------------------------------------------------
-- Table permissions (row-level security above decides WHICH rows)
-- ---------------------------------------------------------------------
revoke all on all tables in schema public from anon, authenticated;
grant usage on schema public to authenticated;
grant select on public.app_settings, public.staff, public.alerts,
                public.alert_locations, public.alert_events to authenticated;
grant select, insert, update on public.profiles, public.medical_profiles to authenticated;
grant select, insert, update, delete on public.emergency_contacts to authenticated;

-- ---------------------------------------------------------------------
-- Live updates for the monitor and the client's alert screen
-- ---------------------------------------------------------------------
alter publication supabase_realtime add table public.alerts, public.alert_events;

-- =====================================================================
-- FireQuest – family plans (up to 4 people per subscription)
-- Each person has their own login. The account holder shares an invite
-- code; others join with it. Everything goes through the functions below.
-- (Already included at the end of schema.sql for new installs.)
-- =====================================================================

create table public.subscriptions (
  id           uuid primary key default gen_random_uuid(),
  owner_id     uuid not null unique references public.profiles (id) on delete cascade,
  plan         text not null default 'family',
  max_members  int not null default 4 check (max_members between 1 and 10),
  invite_code  text not null unique,
  status       text not null default 'active',
  created_at   timestamptz not null default now()
);

create table public.subscription_members (
  subscription_id  uuid not null references public.subscriptions (id) on delete cascade,
  user_id          uuid not null unique references public.profiles (id) on delete cascade,
  role             text not null default 'member' check (role in ('owner', 'member')),
  joined_at        timestamptz not null default now(),
  primary key (subscription_id, user_id)
);

-- No direct access from the apps: only the functions below.
alter table public.subscriptions        enable row level security;
alter table public.subscription_members enable row level security;
revoke all on public.subscriptions, public.subscription_members from anon, authenticated;

-- Random, easy-to-read 6-character code (no 0/O, 1/I/L).
create or replace function private.new_invite_code()
returns text language plpgsql security definer set search_path = public as $$
declare
  chars text := 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
  code  text;
  b     bytea;
begin
  loop
    b := extensions.gen_random_bytes(6);
    code := '';
    for i in 0..5 loop
      code := code || substr(chars, (get_byte(b, i) % length(chars)) + 1, 1);
    end loop;
    exit when not exists (select 1 from public.subscriptions where invite_code = code);
  end loop;
  return code;
end $$;

-- Everyone belongs to exactly one plan; a new person gets their own.
create or replace function private.ensure_subscription(p_uid uuid)
returns uuid language plpgsql security definer set search_path = public as $$
declare
  v_sub uuid;
begin
  select subscription_id into v_sub from public.subscription_members where user_id = p_uid;
  if v_sub is null then
    insert into public.subscriptions (owner_id, invite_code)
    values (p_uid, private.new_invite_code())
    returning id into v_sub;
    insert into public.subscription_members (subscription_id, user_id, role)
    values (v_sub, p_uid, 'owner');
  end if;
  return v_sub;
end $$;

create or replace function public.my_subscription()
returns json language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
  v_sub uuid;
  v_res json;
begin
  if v_uid is null then raise exception 'Not signed in'; end if;
  v_sub := private.ensure_subscription(v_uid);
  select json_build_object(
    'id', s.id,
    'max_members', s.max_members,
    'is_owner', s.owner_id = v_uid,
    'invite_code', case when s.owner_id = v_uid then s.invite_code end,
    'owner_name', (select full_name from public.profiles where id = s.owner_id),
    'members', (
      select coalesce(json_agg(json_build_object(
               'user_id', m.user_id, 'name', p.full_name, 'phone', p.phone,
               'email', p.email, 'role', m.role, 'is_me', m.user_id = v_uid)
             order by m.role desc, m.joined_at), '[]'::json)
      from public.subscription_members m
      join public.profiles p on p.id = m.user_id
      where m.subscription_id = s.id)
  ) into v_res
  from public.subscriptions s where s.id = v_sub;
  return v_res;
end $$;

create or replace function public.join_subscription(p_code text)
returns json language plpgsql security definer set search_path = public as $$
declare
  v_uid     uuid := auth.uid();
  v_target  public.subscriptions;
  v_current uuid;
  v_count   int;
  v_others  int;
begin
  if v_uid is null then raise exception 'Not signed in'; end if;

  select * into v_target from public.subscriptions
   where invite_code = upper(regexp_replace(coalesce(p_code, ''), '\s', '', 'g'))
   for update;
  if not found then raise exception 'That family code was not found. Check it and try again.'; end if;

  select subscription_id into v_current from public.subscription_members where user_id = v_uid;
  if v_current = v_target.id then raise exception 'You are already on this family plan.'; end if;

  select count(*) into v_count from public.subscription_members where subscription_id = v_target.id;
  if v_count >= v_target.max_members then
    raise exception 'This family plan is full (% people).', v_target.max_members;
  end if;

  if v_current is not null then
    if exists (select 1 from public.subscriptions where id = v_current and owner_id = v_uid) then
      select count(*) into v_others from public.subscription_members
       where subscription_id = v_current and user_id <> v_uid;
      if v_others > 0 then
        raise exception 'You manage a family plan with other people on it. Remove them first.';
      end if;
      delete from public.subscriptions where id = v_current;
    else
      delete from public.subscription_members where user_id = v_uid;
    end if;
  end if;

  insert into public.subscription_members (subscription_id, user_id, role)
  values (v_target.id, v_uid, 'member');
  return public.my_subscription();
end $$;

create or replace function public.remove_subscription_member(p_user_id uuid)
returns json language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
  v_sub uuid;
begin
  select id into v_sub from public.subscriptions where owner_id = v_uid;
  if v_sub is null then raise exception 'Only the plan holder can remove people.'; end if;
  if p_user_id = v_uid then raise exception 'You cannot remove yourself.'; end if;
  delete from public.subscription_members where subscription_id = v_sub and user_id = p_user_id;
  if not found then raise exception 'That person is not on your family plan.'; end if;
  return public.my_subscription();
end $$;

create or replace function public.leave_subscription()
returns json language plpgsql security definer set search_path = public as $$
declare
  v_uid   uuid := auth.uid();
  v_owner boolean;
begin
  select s.owner_id = v_uid into v_owner
    from public.subscription_members m
    join public.subscriptions s on s.id = m.subscription_id
   where m.user_id = v_uid;
  if v_owner is null then raise exception 'You are not on a family plan.'; end if;
  if v_owner then raise exception 'The plan holder cannot leave. Remove the other people instead.'; end if;
  delete from public.subscription_members where user_id = v_uid;
  return public.my_subscription();
end $$;

create or replace function public.new_subscription_code()
returns json language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
begin
  update public.subscriptions set invite_code = private.new_invite_code() where owner_id = v_uid;
  if not found then raise exception 'Only the plan holder can change the code.'; end if;
  return public.my_subscription();
end $$;

-- For the control room: the other people on the alerting client's plan.
create or replace function public.alert_family(p_alert_id uuid)
returns json language plpgsql stable security definer set search_path = public as $$
declare
  v_owner uuid;
  v_res   json;
begin
  if not public.is_staff() then raise exception 'Not authorised'; end if;
  select user_id into v_owner from public.alerts where id = p_alert_id;
  if v_owner is null then return '[]'::json; end if;
  select coalesce(json_agg(json_build_object('name', p.full_name, 'phone', p.phone, 'role', m.role)
         order by m.role desc, m.joined_at), '[]'::json)
    into v_res
    from public.subscription_members m
    join public.profiles p on p.id = m.user_id
   where m.subscription_id = (select subscription_id from public.subscription_members where user_id = v_owner)
     and m.user_id <> v_owner;
  return v_res;
end $$;

revoke execute on function
  public.my_subscription(),
  public.join_subscription(text),
  public.remove_subscription_member(uuid),
  public.leave_subscription(),
  public.new_subscription_code(),
  public.alert_family(uuid)
from public, anon;

grant execute on function
  public.my_subscription(),
  public.join_subscription(text),
  public.remove_subscription_member(uuid),
  public.leave_subscription(),
  public.new_subscription_code(),
  public.alert_family(uuid)
to authenticated;

revoke execute on function private.new_invite_code(), private.ensure_subscription(uuid) from public, anon, authenticated;


-- =====================================================================
-- FireQuest – family plans, version 2: personal invites
-- * Nobody becomes a plan holder automatically any more. A person starts
--   a plan (free while test_mode is on; through PayFast later).
-- * Only the plan holder adds people: name, cellphone number, relationship.
-- * Each invited person gets their own code. It works once, only for the
--   cellphone number the holder entered, and expires after 7 days.
-- * Members cannot invite anyone, and cannot start their own plan while
--   they are on someone else's.
-- Run after 002_family_plans.sql. (Also included in schema.sql.)
-- =====================================================================

-- The old shared code is retired: it let anyone with the code join.
alter table public.subscriptions alter column invite_code drop not null;
update public.subscriptions set invite_code = null;
alter table public.subscriptions alter column status set default 'test';
update public.subscriptions set status = 'test';

-- Plans that only ever held their owner were created automatically: remove them.
delete from public.subscriptions s
 where (select count(*) from public.subscription_members m where m.subscription_id = s.id) <= 1;

-- How each person is related to the plan holder.
alter table public.subscription_members add column if not exists relationship text
  check (relationship in ('holder', 'spouse', 'child', 'parent', 'other'));
update public.subscription_members set relationship = 'holder' where role = 'owner';

create table if not exists public.family_invites (
  id              uuid primary key default gen_random_uuid(),
  subscription_id uuid not null references public.subscriptions (id) on delete cascade,
  name            text not null check (length(trim(name)) between 1 and 80),
  phone           text not null,
  relationship    text not null check (relationship in ('spouse', 'child', 'parent', 'other')),
  code            text not null unique,
  created_at      timestamptz not null default now(),
  expires_at      timestamptz not null default now() + interval '7 days'
);
alter table public.family_invites enable row level security;
revoke all on public.family_invites from anon, authenticated;

-- Last 9 digits of a phone number, so 082 123 4567, 0821234567 and
-- +27 82 123 4567 all match. Null when there are fewer than 9 digits.
create or replace function private.phone_key(p text)
returns text language sql immutable set search_path = public as $$
  select case when length(d) >= 9 then right(d, 9) end
    from (select regexp_replace(coalesce(p, ''), '\D', '', 'g') as d) x
$$;

-- Random, easy-to-read 6-character code (no 0/O, 1/I/L).
create or replace function private.new_family_code()
returns text language plpgsql security definer set search_path = public as $$
declare
  chars  text := 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
  v_code text;
  b      bytea;
begin
  loop
    b := extensions.gen_random_bytes(6);
    v_code := '';
    for i in 0..5 loop
      v_code := v_code || substr(chars, (get_byte(b, i) % length(chars)) + 1, 1);
    end loop;
    exit when not exists (select 1 from public.family_invites f where f.code = v_code);
  end loop;
  return v_code;
end $$;

drop function if exists public.new_subscription_code();
drop function if exists private.ensure_subscription(uuid);
drop function if exists private.new_invite_code();

create or replace function public.my_subscription()
returns json language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
  v_sub uuid;
  v_res json;
begin
  if v_uid is null then raise exception 'Not signed in'; end if;
  select subscription_id into v_sub from public.subscription_members where user_id = v_uid;
  if v_sub is null then
    return json_build_object('in_plan', false, 'is_owner', false, 'max_members', 4,
                             'members', '[]'::json, 'invites', '[]'::json, 'spots_left', 0);
  end if;

  delete from public.family_invites where subscription_id = v_sub and expires_at < now();

  select json_build_object(
    'in_plan', true,
    'id', s.id,
    'status', s.status,
    'max_members', s.max_members,
    'is_owner', s.owner_id = v_uid,
    'owner_name', (select full_name from public.profiles where id = s.owner_id),
    'members', (
      select coalesce(json_agg(json_build_object(
               'user_id', m.user_id, 'name', p.full_name, 'phone', p.phone, 'email', p.email,
               'role', m.role, 'relationship', m.relationship, 'is_me', m.user_id = v_uid)
             order by m.role desc, m.joined_at), '[]'::json)
        from public.subscription_members m
        join public.profiles p on p.id = m.user_id
       where m.subscription_id = s.id),
    'invites', case when s.owner_id = v_uid then (
      select coalesce(json_agg(json_build_object(
               'id', i.id, 'name', i.name, 'phone', i.phone, 'relationship', i.relationship,
               'code', i.code, 'expires_at', i.expires_at)
             order by i.created_at), '[]'::json)
        from public.family_invites i
       where i.subscription_id = s.id) else '[]'::json end,
    'spots_left', s.max_members
      - (select count(*) from public.subscription_members m where m.subscription_id = s.id)
      - (select count(*) from public.family_invites i where i.subscription_id = s.id)
  ) into v_res
  from public.subscriptions s where s.id = v_sub;
  return v_res;
end $$;

-- Start a family plan with yourself as holder. Free while test_mode is on;
-- once FireQuest is live, plans are started through PayFast instead.
create or replace function public.start_subscription()
returns json language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
  v_sub uuid;
begin
  if v_uid is null then raise exception 'Not signed in'; end if;
  if not coalesce((select test_mode from public.app_settings where id = 1), false) then
    raise exception 'Family plans are started by subscribing with PayFast.';
  end if;
  if exists (select 1 from public.subscription_members where user_id = v_uid) then
    raise exception 'You are already on a family plan.';
  end if;
  insert into public.subscriptions (owner_id, status) values (v_uid, 'test') returning id into v_sub;
  insert into public.subscription_members (subscription_id, user_id, role, relationship)
  values (v_sub, v_uid, 'owner', 'holder');
  return public.my_subscription();
end $$;

-- Holder only: add a family member by name, cellphone number and relationship.
create or replace function public.invite_family_member(p_name text, p_phone text, p_relationship text)
returns json language plpgsql security definer set search_path = public as $$
declare
  v_uid  uuid := auth.uid();
  v_sub  public.subscriptions;
  v_name text := trim(coalesce(p_name, ''));
  v_key  text := private.phone_key(p_phone);
  v_used int;
  v_inv  uuid;
begin
  if v_uid is null then raise exception 'Not signed in'; end if;
  select * into v_sub from public.subscriptions where owner_id = v_uid for update;
  if not found then raise exception 'Only the plan holder can add family members.'; end if;
  if v_name = '' then raise exception 'Enter their name.'; end if;
  if length(v_name) > 80 then raise exception 'That name is too long.'; end if;
  if v_key is null then raise exception 'Enter their cellphone number, for example 082 123 4567.'; end if;
  if coalesce(p_relationship, '') not in ('spouse', 'child', 'parent', 'other') then
    raise exception 'Choose how they are related to you.';
  end if;

  delete from public.family_invites where subscription_id = v_sub.id and expires_at < now();

  if exists (select 1 from public.subscription_members m join public.profiles p on p.id = m.user_id
              where m.subscription_id = v_sub.id and private.phone_key(p.phone) = v_key) then
    raise exception 'Someone with that cellphone number is already on your plan.';
  end if;
  if exists (select 1 from public.family_invites
              where subscription_id = v_sub.id and private.phone_key(phone) = v_key) then
    raise exception 'That number already has an invite waiting. Tap "Send again", or cancel it first.';
  end if;

  select (select count(*) from public.subscription_members where subscription_id = v_sub.id)
       + (select count(*) from public.family_invites where subscription_id = v_sub.id)
    into v_used;
  if v_used >= v_sub.max_members then
    raise exception 'Your plan is full (% people, counting invites that are still waiting).', v_sub.max_members;
  end if;

  insert into public.family_invites (subscription_id, name, phone, relationship, code)
  values (v_sub.id, v_name, trim(p_phone), p_relationship, private.new_family_code())
  returning id into v_inv;

  return (public.my_subscription()::jsonb || jsonb_build_object('new_invite_id', v_inv))::json;
end $$;

-- Holder only: cancel an invite that has not been used yet.
create or replace function public.cancel_family_invite(p_invite_id uuid)
returns json language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
begin
  if v_uid is null then raise exception 'Not signed in'; end if;
  delete from public.family_invites i
   using public.subscriptions s
   where i.id = p_invite_id and s.id = i.subscription_id and s.owner_id = v_uid;
  if not found then raise exception 'That invite was not found.'; end if;
  return public.my_subscription();
end $$;

-- Join with a personal invite code. The cellphone number on the joiner's
-- profile must match the number the holder entered.
create or replace function public.join_subscription(p_code text)
returns json language plpgsql security definer set search_path = public as $$
declare
  v_uid     uuid := auth.uid();
  v_inv     public.family_invites;
  v_target  public.subscriptions;
  v_current public.subscriptions;
  v_phone   text;
  v_count   int;
begin
  if v_uid is null then raise exception 'Not signed in'; end if;

  select * into v_inv from public.family_invites
   where code = upper(regexp_replace(coalesce(p_code, ''), '\s', '', 'g'))
   for update;
  if not found or v_inv.expires_at < now() then
    raise exception 'That code is not valid. It may already have been used, or it expired after 7 days. Ask the plan holder to send you a new invite.';
  end if;

  select * into v_target from public.subscriptions where id = v_inv.subscription_id for update;

  select phone into v_phone from public.profiles where id = v_uid;
  if private.phone_key(v_phone) is distinct from private.phone_key(v_inv.phone) then
    raise exception 'This invite is for the cellphone number ending in %. The number on your FireQuest profile is different. Ask % to check the number, or correct your number under Medical ID > Edit.',
      right(regexp_replace(v_inv.phone, '\D', '', 'g'), 4),
      coalesce(nullif((select full_name from public.profiles where id = v_target.owner_id), ''), 'the plan holder');
  end if;

  select s.* into v_current
    from public.subscription_members m join public.subscriptions s on s.id = m.subscription_id
   where m.user_id = v_uid;
  if found then
    if v_current.id = v_target.id then raise exception 'You are already on this family plan.'; end if;
    if v_current.owner_id <> v_uid then
      raise exception 'You are on another family plan. Leave it first (Account > Family plan > Leave).';
    end if;
    if exists (select 1 from public.subscription_members where subscription_id = v_current.id and user_id <> v_uid)
       or exists (select 1 from public.family_invites where subscription_id = v_current.id) then
      raise exception 'You hold your own family plan with other people on it. Remove them and cancel their invites first.';
    end if;
    if v_current.status <> 'test' then
      raise exception 'Cancel your own FireQuest subscription first.';
    end if;
    delete from public.subscriptions where id = v_current.id;
  end if;

  select count(*) into v_count from public.subscription_members where subscription_id = v_target.id;
  if v_count >= v_target.max_members then
    raise exception 'This family plan is full (% people).', v_target.max_members;
  end if;

  insert into public.subscription_members (subscription_id, user_id, role, relationship)
  values (v_target.id, v_uid, 'member', v_inv.relationship);
  delete from public.family_invites where id = v_inv.id;
  return public.my_subscription();
end $$;

-- For the control room: the other people on the alerting client's plan.
create or replace function public.alert_family(p_alert_id uuid)
returns json language plpgsql stable security definer set search_path = public as $$
declare
  v_owner uuid;
  v_res   json;
begin
  if not public.is_staff() then raise exception 'Not authorised'; end if;
  select user_id into v_owner from public.alerts where id = p_alert_id;
  if v_owner is null then return '[]'::json; end if;
  select coalesce(json_agg(json_build_object('name', p.full_name, 'phone', p.phone, 'role', m.role,
                                             'relationship', m.relationship)
         order by m.role desc, m.joined_at), '[]'::json)
    into v_res
    from public.subscription_members m
    join public.profiles p on p.id = m.user_id
   where m.subscription_id = (select subscription_id from public.subscription_members where user_id = v_owner)
     and m.user_id <> v_owner;
  return v_res;
end $$;

revoke execute on function
  public.my_subscription(),
  public.start_subscription(),
  public.invite_family_member(text, text, text),
  public.cancel_family_invite(uuid),
  public.join_subscription(text),
  public.alert_family(uuid)
from public, anon;

grant execute on function
  public.my_subscription(),
  public.start_subscription(),
  public.invite_family_member(text, text, text),
  public.cancel_family_invite(uuid),
  public.join_subscription(text),
  public.alert_family(uuid)
to authenticated;

revoke execute on function private.phone_key(text), private.new_family_code() from public, anon, authenticated;


-- =====================================================================
-- FireQuest – automatic crash detection (Android)
-- The crash-detection service on the phone keeps running when the app is
-- closed, so it cannot rely on the normal login session. When the client
-- switches crash detection on, the app registers the phone and receives a
-- long random device key. The service sends that key with a crash alert.
-- Only a SHA-256 hash of the key is stored. Switching off deletes it.
-- Run after 003_family_invites.sql. (Also included in schema.sql.)
-- =====================================================================

-- Where an alert came from: a button press, or the phone's crash detection.
alter table public.alerts add column if not exists source text not null default 'button'
  check (source in ('button', 'crash_detection'));

-- One row per phone (a person may use crash detection on up to 5 phones).
create table if not exists private.crash_devices (
  key_hash     text primary key,
  user_id      uuid not null references public.profiles (id) on delete cascade,
  created_at   timestamptz not null default now(),
  last_used_at timestamptz
);
create index if not exists crash_devices_user_idx on private.crash_devices (user_id);

-- Every detection, sent or cancelled with "I'm OK". Used to tune the detector
-- during testing. Cancelled detections store no location.
create table if not exists private.crash_detections (
  id         bigint generated always as identity primary key,
  user_id    uuid not null references public.profiles (id) on delete cascade,
  outcome    text not null check (outcome in ('alert_sent', 'cancelled')),
  simulated  boolean not null default false,
  peak_g     real,
  speed_kmh  real,
  created_at timestamptz not null default now()
);

create or replace function private.crash_device_user(p_key text)
returns uuid language sql stable security definer set search_path = public as $$
  select user_id from private.crash_devices
   where key_hash = encode(extensions.digest(coalesce(p_key, ''), 'sha256'), 'hex')
$$;

-- Signed-in client: create a device key for this phone. Keeps the 5 newest phones per person.
create or replace function public.register_crash_device()
returns text language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
  v_key text;
begin
  if v_uid is null then raise exception 'Not signed in'; end if;
  v_key := encode(extensions.gen_random_bytes(32), 'hex');
  insert into private.crash_devices (key_hash, user_id)
  values (encode(extensions.digest(v_key, 'sha256'), 'hex'), v_uid);
  delete from private.crash_devices
   where user_id = v_uid
     and key_hash not in (select key_hash from private.crash_devices
                           where user_id = v_uid order by created_at desc limit 5);
  return v_key;
end $$;

drop function if exists public.unregister_crash_device();

-- Signed-in client: switch crash detection off on one phone (that phone's key stops working).
create or replace function public.unregister_crash_device(p_key text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'Not signed in'; end if;
  delete from private.crash_devices
   where user_id = auth.uid()
     and key_hash = encode(extensions.digest(coalesce(p_key, ''), 'sha256'), 'hex');
end $$;

-- Phone service: raise a vehicle alert after a crash was detected and not cancelled.
create or replace function public.raise_crash_alert(
  p_key       text,
  p_lat       double precision default null,
  p_lng       double precision default null,
  p_accuracy  real default null,
  p_peak_g    real default null,
  p_speed_kmh real default null,
  p_simulated boolean default false
) returns uuid
language plpgsql security definer set search_path = public as $$
declare
  v_uid   uuid := private.crash_device_user(p_key);
  v_alert public.alerts;
  v_note  text;
begin
  if v_uid is null then
    raise exception 'Crash detection is not registered for this phone. Open FireQuest and switch it on again.';
  end if;
  update private.crash_devices set last_used_at = now()
   where key_hash = encode(extensions.digest(p_key, 'sha256'), 'hex');

  v_note := case when coalesce(p_simulated, false) then 'SIMULATED crash (test button)' else 'Crash detected by phone' end
         || coalesce(': ' || round(p_peak_g::numeric, 1) || ' g', '')
         || coalesce(' at ' || round(p_speed_kmh::numeric) || ' km/h', '');

  insert into private.crash_detections (user_id, outcome, simulated, peak_g, speed_kmh)
  values (v_uid, 'alert_sent', coalesce(p_simulated, false), p_peak_g, p_speed_kmh);

  -- Add to the client's open alert, except that a real crash never joins a TEST alert
  -- once FireQuest is live (test mode off).
  select * into v_alert from public.alerts
   where user_id = v_uid and status not in ('closed', 'cancelled')
     and (coalesce(p_simulated, false) or not is_test
          or coalesce((select test_mode from public.app_settings where id = 1), true))
   order by created_at desc limit 1;

  if not found then
    insert into public.alerts (user_id, type, is_test, source)
    values (v_uid, 'vehicle',
            coalesce((select test_mode from public.app_settings where id = 1), true) or coalesce(p_simulated, false),
            'crash_detection')
    returning * into v_alert;
    insert into public.alert_events (alert_id, actor_id, actor_kind, event, note)
    values (v_alert.id, v_uid, 'system', 'raised', 'vehicle');
  end if;
  insert into public.alert_events (alert_id, actor_id, actor_kind, event, note)
  values (v_alert.id, v_uid, 'system', 'crash_detected', v_note);

  if p_lat is not null and p_lng is not null then
    update public.alerts
       set lat = p_lat, lng = p_lng, accuracy_m = p_accuracy, location_updated_at = now()
     where id = v_alert.id;
    insert into public.alert_locations (alert_id, lat, lng, accuracy_m)
    values (v_alert.id, p_lat, p_lng, p_accuracy);
  end if;

  return v_alert.id;
end $$;

-- Phone service: keep the location of the open alert up to date.
create or replace function public.crash_alert_location(
  p_key      text,
  p_lat      double precision,
  p_lng      double precision,
  p_accuracy real default null
) returns void
language plpgsql security definer set search_path = public as $$
declare
  v_uid   uuid := private.crash_device_user(p_key);
  v_alert uuid;
begin
  if v_uid is null then raise exception 'Crash detection is not registered for this phone.'; end if;
  update public.alerts
     set lat = p_lat, lng = p_lng, accuracy_m = p_accuracy, location_updated_at = now()
   where id = (select id from public.alerts
                where user_id = v_uid and status not in ('closed', 'cancelled')
                order by created_at desc limit 1)
  returning id into v_alert;
  if v_alert is not null then
    insert into public.alert_locations (alert_id, lat, lng, accuracy_m)
    values (v_alert, p_lat, p_lng, p_accuracy);
  end if;
end $$;

-- Phone service: the client tapped "I'm OK" during the countdown. No alert is sent.
create or replace function public.log_crash_cancelled(
  p_key       text,
  p_peak_g    real default null,
  p_speed_kmh real default null,
  p_simulated boolean default false
) returns void
language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := private.crash_device_user(p_key);
begin
  if v_uid is null then return; end if;
  insert into private.crash_detections (user_id, outcome, simulated, peak_g, speed_kmh)
  values (v_uid, 'cancelled', coalesce(p_simulated, false), p_peak_g, p_speed_kmh);
end $$;

revoke execute on function
  public.register_crash_device(),
  public.unregister_crash_device(text),
  public.raise_crash_alert(text, double precision, double precision, real, real, real, boolean),
  public.crash_alert_location(text, double precision, double precision, real),
  public.log_crash_cancelled(text, real, real, boolean)
from public;

grant execute on function public.register_crash_device(), public.unregister_crash_device(text) to authenticated;
revoke execute on function public.register_crash_device(), public.unregister_crash_device(text) from anon;

-- The phone service calls these without a login; the device key is the proof.
grant execute on function
  public.raise_crash_alert(text, double precision, double precision, real, real, real, boolean),
  public.crash_alert_location(text, double precision, double precision, real),
  public.log_crash_cancelled(text, real, real, boolean)
to anon, authenticated;

revoke all on private.crash_devices, private.crash_detections from public, anon, authenticated;
revoke execute on function private.crash_device_user(text) from public, anon, authenticated;
