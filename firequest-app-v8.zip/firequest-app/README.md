# FireQuest Panic – test version (Android)

Two parts:

- **FireQuest Panic app** (`app/`): the Android app for clients. Sign in, medical profile, three hold-to-send panic buttons, live GPS, cancel with PIN.
- **FireQuest Monitor** (`monitor/`): the control-room screen. Live alert list with alarm, map, client profile, Google Maps navigation, actions and alert log.

Both use one **Supabase** database (`supabase/schema.sql`).

---

## One-time setup

### 1. Database (Supabase)

1. In your Supabase project, open **SQL Editor** > **New query**.
2. Paste everything from `supabase/schema.sql` and click **Run**. You should see "Success". Run it only once.
3. Set the control-room phone number: open `supabase/settings.sql`, put in your number, and run the first `update` line.
4. **For testing only** (optional, makes sign-up quicker): Authentication > Sign In / Providers > Email > switch off **Confirm email**. Switch it back on before going live.

### 2. Control-room operators

For each person who will use the monitor:

1. Authentication > Users > **Add user** > **Create new user**. Enter their email and a password, and tick **Auto Confirm User**.
2. Open `supabase/add-operator.sql`, change the email and name, and run it in the SQL Editor.

Operators sign in to the monitor with that email and password. Client accounts cannot open the monitor.

### 3. Settings

The database address and its public ("publishable") key are already in `app/src/config.json` and `monitor/config.js`. That key is designed to sit inside apps, and the database's security rules protect the data. **Never** put the `secret` or `service_role` key in these files.

(Optional) To point a build at a different database without changing the files, add the repository variables `SUPABASE_URL`, `SUPABASE_PUBLISHABLE_KEY` and `CONTROL_ROOM_PHONE` under GitHub > Settings > Secrets and variables > Actions > Variables.

---

## Building a new test version

The repository holds the code as **one zip file** plus the build file `.github/workflows/build.yml`. This works from a phone:

1. Upload the new `firequest-app.zip` to the repository (Add file > Upload files > Commit changes).
2. GitHub builds automatically (about 20 minutes). You can follow it on the **Actions** tab.
3. Open **Releases**. The newest release ("FireQuest build N", marked **Latest**) has `FireQuest.apk` (the app) and `firequest-monitor.zip` (the monitor).

The build uses whichever zip file was uploaded most recently. `build.sh` does the actual work, including publishing the release, so the build file never needs to change. Editing only the build file does not start a build.

**Download page** (share this one): https://firequest-panic.github.io/firequest-app/
- Built from the `site/` folder and published to the `gh-pages` branch by every build.
- One-time setup: Settings > Pages > Source "Deploy from a branch", branch `gh-pages`, folder `/ (root)`, Save.
- On Android phones the Download button hands the download to Samsung Internet, because Chrome can get stuck at 100% on app files. Phones without Samsung Internet get the normal download.
- Add `?code=ABC123` to show a family code on the page. Family invites from the app do this automatically (`downloadUrl` in `app/src/config.json`).

## Automatic crash detection (Android)

- Switched on per phone: **Account > Automatic crash detection > Turn on**. Android asks for location ("Allow all the time") and notifications. For reliability, also allow FireQuest to run without battery restrictions (the card has a button).
- A native background service (`app/modules/crash-detector`, Kotlin) keeps running when the app is closed and restarts after a reboot or update. Android shows a small "Crash detection is on" notification while it runs.
- **Idle:** cheap network location only. When the phone moves at driving speed (25 km/h or more), it switches to GPS every second plus the motion sensor at 100 readings a second.
- **Crash rule:** at least 3 readings of 3 g or more within 0.3 s while driving 25 km/h or faster, not after free fall (a dropped phone), followed by the vehicle stopping (or GPS going silent). Rules and tests: `CrashDetector.kt`.
- **Countdown:** the phone rings loudly at full alarm volume with a 30-second countdown, "I'M OK" and "SEND HELP NOW". If nobody responds, it sends a Vehicle accident alert with the location (marked AUTO-DETECTED CRASH in the control room). It keeps retrying without signal and updates the location for 15 minutes.
- The service does not use the login session. Switching on registers the phone and stores a random device key on it (only a hash is kept in the database). Switching off or signing out deletes it. Database: `supabase/004_crash_detection.sql`.
- **Test without a crash:** Account > Test: simulate a crash. If not cancelled, it sends a TEST alert.
- Every detection (sent or cancelled) is logged in `private.crash_detections` (peak g, speed, no location for cancelled ones) to tune the rules during testing.

## Family plans

- Nobody is a plan holder automatically. A person taps **Account > Family plan > Start my own family plan** (free while `test_mode` is on; through PayFast later).
- Only the holder can add people: **Add a family member** > name, cellphone number, relationship. The app then shares a WhatsApp invite with a personal code.
- The code works once, only for that cellphone number (the number on the joiner's FireQuest profile must match), and expires after 7 days.
- Members can see who is on the plan and can leave. They cannot invite anyone.
- Database: `supabase/003_family_invites.sql` (run after `002_family_plans.sql`; already included in `schema.sql`).

**Direct app file** (always the newest; needs the repository to be **public**). Each release also has `FireQuest-build-N.apk`, and the download page links to that, so a phone never opens an older download by mistake:
https://github.com/FireQuest-panic/firequest-app/releases/latest/download/FireQuest.apk

## Installing on Android test phones

1. Send the download page link to the tester (WhatsApp, email or SMS).
2. On the phone, tap the link, tap **Download FireQuest**, then **Open** and **Install**. If Android asks, allow the browser to **install unknown apps**.
3. Open **FireQuest**, create an account, complete the 5 registration steps and allow location.

A newer test build installs over the old one. The tester's account and details stay.

## Running the monitor

1. Download `firequest-monitor.zip` from the latest release on the control-room computer and unzip it.
2. Open `index.html` in **Google Chrome**.
3. Sign in with an operator account and click **Start monitoring**. This switches on the alarm sound. Keep the window open and the volume up.

---

## Test script

| # | Do this | Expect |
|---|---|---|
| 1 | Tester creates an account and completes registration | Home screen with three buttons and a "TEST MODE" banner |
| 2 | Tap a button briefly | Nothing is sent (it must be held for 3 seconds) |
| 3 | Hold **Medical** for 3 seconds | Phone shows "Alert sent". Monitor rings, the alert flashes red, the map shows the phone |
| 4 | Operator clicks **Acknowledge** | Alarm stops. Phone shows "The control room has your alert" within a few seconds |
| 5 | Operator clicks **Navigate in Google Maps** | Google Maps opens with directions to the phone |
| 6 | Tester walks 100 m with the app open | Monitor map position updates about every 10 seconds |
| 7 | Operator clicks **Dispatch FireQuest team**, then **Team on scene** | Phone timeline updates |
| 8 | Tester taps **Cancel with PIN** and enters a wrong PIN | Alert stays active. Monitor shows a red "wrong PIN" warning |
| 9 | Tester enters the right PIN | Alert cancelled on both screens |
| 10 | Repeat with **Vehicle** and **Fire** | Monitor shows the right guidance for each |

Write down anything that is confusing, slow or wrong.

---

## Limits of this test version

- **Location while the app is closed:** the phone sends its location while the alert screen is open (the screen stays on). Tracking with the screen locked comes next.
- **No automatic SMS:** emergency contacts and partner services are not messaged yet. The operator phones them.
- **Map:** uses free OpenStreetMap maps. Fine for testing; for heavy use switch to a paid map service.
- **Signing key:** test builds are signed with a shared test key. A private FireQuest key is needed before release.
- **Supabase free plan:** the project sleeps after 7 days with no activity, and has no backups. Upgrade to Pro (or a FireQuest server) before real clients rely on it.
- **Test mode:** every alert is marked TEST until `test_mode` is switched off in `supabase/settings.sql`.

## Moving clients from the Base44 app (later)

Export users from Base44 as CSV and import them into Supabase. Each client then gets a "set your password" email, because passwords cannot be copied between systems. PayFast subscriptions are matched by email address.
