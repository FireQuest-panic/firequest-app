import React, { useCallback, useEffect, useState } from 'react';
import { Alert, AppState, Text, View } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { colors } from '../theme';
import { friendlyError } from '../lib/data';
import {
  COUNTDOWN_SECONDS,
  CrashStatus,
  backgroundLocationAllowed,
  crashSupported,
  disableCrashDetection,
  enableCrashDetection,
  getCrashStatus,
  onCrashEvent,
  openAppSettings,
  openBatterySettings,
  simulateCrash,
} from '../lib/crash';
import { Body, Button, Card, ErrorText } from './ui';

const STATE_TEXT: Record<string, string> = {
  idle: 'On. FireQuest starts watching when you drive.',
  driving: 'Active. Driving detected, watching for an accident.',
  countdown: 'Possible accident detected. Countdown running.',
  sending: 'Sending an accident alert…',
  sent: 'Accident alert sent to the control room.',
  off: 'Starting…',
};

/** Account-screen card to switch automatic crash detection on or off. */
export function CrashDetectionCard({ userId, controlRoomPhone }: { userId: string; controlRoomPhone: string }) {
  const [status, setStatus] = useState<CrashStatus>(getCrashStatus());
  const [bgAllowed, setBgAllowed] = useState(true);
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState('');

  const refresh = useCallback(() => {
    setStatus(getCrashStatus());
    backgroundLocationAllowed().then(setBgAllowed);
  }, []);

  useEffect(() => {
    refresh();
    const timer = setInterval(refresh, 3000);
    const off = onCrashEvent(refresh);
    const sub = AppState.addEventListener('change', (s) => s === 'active' && refresh());
    return () => {
      clearInterval(timer);
      off();
      sub.remove();
    };
  }, [refresh]);

  if (!crashSupported) return null;

  const turnOn = () =>
    Alert.alert(
      'Turn on crash detection?',
      'When you drive, FireQuest watches for a car accident, even when the app is closed.\n\n' +
        `If it detects one, your phone rings loudly for ${COUNTDOWN_SECONDS} seconds. If you do not tap I'M OK, ` +
        'FireQuest sends an accident alert with your location to the control room.\n\n' +
        'Next, Android asks for location (choose "Allow all the time") and notifications.',
      [
        { text: 'Not now', style: 'cancel' },
        {
          text: 'Turn on',
          onPress: async () => {
            setError('');
            setBusy('on');
            try {
              const r = await enableCrashDetection(userId, controlRoomPhone);
              if (!r.ok && r.message) setError(r.message);
            } catch (e) {
              setError(friendlyError(e));
            } finally {
              setBusy(null);
              setTimeout(refresh, 1500);
            }
          },
        },
      ],
    );

  const turnOff = () =>
    Alert.alert('Turn off crash detection?', 'FireQuest will no longer detect accidents by itself. The panic buttons keep working.', [
      { text: 'Keep it on', style: 'cancel' },
      {
        text: 'Turn off',
        style: 'destructive',
        onPress: async () => {
          setBusy('off');
          await disableCrashDetection();
          setBusy(null);
          refresh();
        },
      },
    ]);

  const simulate = () =>
    Alert.alert(
      'Test crash detection',
      `Your phone will ring as if it detected an accident.\n\nTap I'M OK to stop it. If you wait ${COUNTDOWN_SECONDS} seconds, ` +
        'a TEST accident alert goes to the control room.',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Start test', onPress: () => simulateCrash() },
      ],
    );

  const on = status.enabled;

  return (
    <Card>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
        <MaterialCommunityIcons name="car-emergency" size={22} color={colors.goldText} />
        <Text style={{ color: colors.goldText, fontWeight: '700', fontSize: 15, flex: 1 }}>Automatic crash detection</Text>
        <Text style={{ color: on ? colors.green : colors.faint, fontWeight: '800' }}>{on ? 'ON' : 'OFF'}</Text>
      </View>

      {!on ? (
        <>
          <Body>
            FireQuest can detect a car accident by itself, even when the app is closed, and send an accident alert if you
            cannot.
          </Body>
          <Button title="Turn on crash detection" loading={busy === 'on'} onPress={turnOn} />
        </>
      ) : (
        <>
          <Body>{status.running ? STATE_TEXT[status.state] ?? STATE_TEXT.idle : 'Not running. Tap "Start again".'}</Body>

          {!status.running && (
            <Button title="Start again" loading={busy === 'on'} onPress={turnOn} />
          )}

          {!bgAllowed && (
            <Warning
              text='Location is not set to "Allow all the time". Crash detection can stop when FireQuest is closed.'
              action="Open FireQuest settings"
              onPress={() => openAppSettings()}
            />
          )}
          {!status.notificationsEnabled && (
            <Warning
              text="Notifications are off for FireQuest. You would not see the countdown or be able to tap I'M OK from the notification."
              action="Open FireQuest settings"
              onPress={() => openAppSettings()}
            />
          )}
          {!status.batteryUnrestricted && (
            <Warning
              text="Battery saving can stop crash detection. Allow FireQuest to run without battery restrictions."
              action="Fix battery setting"
              onPress={() => openBatterySettings()}
            />
          )}

          <Button title="Test: simulate a crash" variant="outline" onPress={simulate} />
          <Button title="Turn off crash detection" variant="plain" loading={busy === 'off'} onPress={turnOff} />
        </>
      )}
      <ErrorText>{error || (on && !status.running ? status.lastError ?? '' : '')}</ErrorText>
    </Card>
  );
}

function Warning({ text, action, onPress }: { text: string; action: string; onPress: () => void }) {
  return (
    <View style={{ gap: 6, padding: 12, borderRadius: 12, backgroundColor: colors.dangerDeep }}>
      <Text style={{ color: colors.danger, fontSize: 14, lineHeight: 20 }}>{text}</Text>
      <Button title={action} variant="plain" onPress={onPress} />
    </View>
  );
}
