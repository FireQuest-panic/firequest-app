import React, { useEffect, useState } from 'react';
import { Modal, Text, View } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { colors } from '../theme';
import { crashImOk, crashSendNow, CrashEvent, getCrashStatus, onCrashEvent } from '../lib/crash';
import { Button } from './ui';

type Phase = 'none' | 'countdown' | 'sending';

/**
 * Full-screen countdown when the phone detects a possible accident while FireQuest is open.
 * (When the app is closed, the same choice is offered in the notification.)
 */
export function CrashCountdown() {
  const [phase, setPhase] = useState<Phase>('none');
  const [endsAt, setEndsAt] = useState(0);
  const [simulated, setSimulated] = useState(false);
  const [now, setNow] = useState(Date.now());

  useEffect(() => {
    const s = getCrashStatus();
    if (s.state === 'countdown' && s.countdownEndsAt > Date.now()) {
      setEndsAt(s.countdownEndsAt);
      setPhase('countdown');
    } else if (s.state === 'sending') {
      setPhase('sending');
    }
    return onCrashEvent((e: CrashEvent) => {
      if (e.type === 'countdown') {
        setEndsAt(e.endsAt ?? Date.now() + 30_000);
        setSimulated(Boolean(e.simulated));
        setPhase('countdown');
      } else if (e.type === 'sending') {
        setPhase('sending');
      } else if (e.type === 'cancelled' || e.type === 'sendFailed' || e.type === 'alertSent') {
        setPhase('none');
      } else if (e.type === 'state' && e.state !== 'countdown' && e.state !== 'sending') {
        setPhase('none');
      }
    });
  }, []);

  useEffect(() => {
    if (phase === 'none') return;
    const t = setInterval(() => {
      setNow(Date.now());
      // Safety net: never leave this screen up if the service has moved on or stopped.
      const s = getCrashStatus();
      if (s.state !== 'countdown' && s.state !== 'sending') setPhase('none');
    }, 500);
    return () => clearInterval(t);
  }, [phase]);

  if (phase === 'none') return null;
  const seconds = Math.max(0, Math.ceil((endsAt - now) / 1000));

  return (
    <Modal visible animationType="fade" statusBarTranslucent onRequestClose={() => undefined}>
      <View style={{ flex: 1, backgroundColor: colors.redDeep, padding: 24, justifyContent: 'center', gap: 18 }}>
        <View style={{ alignItems: 'center', gap: 10 }}>
          <MaterialCommunityIcons name="car-emergency" size={64} color={colors.redText} />
          <Text style={{ color: colors.text, fontSize: 26, fontWeight: '800', textAlign: 'center' }}>
            {simulated ? 'TEST: possible accident' : 'Possible accident detected'}
          </Text>
          {phase === 'countdown' ? (
            <>
              <Text style={{ color: colors.text, fontSize: 96, fontWeight: '800', fontVariant: ['tabular-nums'] }}>{seconds}</Text>
              <Text style={{ color: colors.text, fontSize: 17, textAlign: 'center', lineHeight: 24 }}>
                FireQuest will send an accident alert with your location to the control room when the countdown ends.
              </Text>
            </>
          ) : (
            <Text style={{ color: colors.text, fontSize: 18, textAlign: 'center' }}>Sending your accident alert…</Text>
          )}
        </View>
        {phase === 'countdown' && (
          <View style={{ gap: 12 }}>
            <Button title="I'M OK – DON'T SEND" onPress={() => crashImOk()} style={{ minHeight: 64, backgroundColor: colors.green }} />
            <Button title="SEND HELP NOW" variant="red" onPress={() => crashSendNow()} style={{ minHeight: 64 }} />
          </View>
        )}
      </View>
    </Modal>
  );
}
