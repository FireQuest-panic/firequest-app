// Automatic crash detection (Android). The detection itself runs in a native background
// service (app/modules/crash-detector); this file switches it on and off from the app.
import { Alert, PermissionsAndroid, Platform } from 'react-native';
import * as Location from 'expo-location';
import CrashDetector, { CrashEvent, CrashStatus } from '../../modules/crash-detector';
import config from '../config.json';
import { supabase } from './supabase';

export type { CrashEvent, CrashStatus };

export const COUNTDOWN_SECONDS = 30;
export const crashSupported = Platform.OS === 'android' && CrashDetector != null;

const OFF: CrashStatus = {
  available: false,
  enabled: false,
  userId: '',
  notificationsEnabled: true,
  running: false,
  state: 'off',
  countdownEndsAt: 0,
  batteryUnrestricted: true,
  lastError: null,
};

export function getCrashStatus(): CrashStatus {
  try {
    return CrashDetector ? CrashDetector.getStatus() : OFF;
  } catch {
    return OFF;
  }
}

export function onCrashEvent(listener: (e: CrashEvent) => void): () => void {
  if (!CrashDetector) return () => undefined;
  const sub = CrashDetector.addListener('onCrashEvent', listener);
  return () => sub.remove();
}

function ask(title: string, message: string, ok = 'Continue'): Promise<boolean> {
  return new Promise((resolve) =>
    Alert.alert(title, message, [
      { text: 'Not now', style: 'cancel', onPress: () => resolve(false) },
      { text: ok, onPress: () => resolve(true) },
    ]),
  );
}

export interface EnableResult {
  ok: boolean;
  message?: string;
}

/** Asks for the permissions step by step, registers this phone and starts the service. */
export async function enableCrashDetection(userId: string, controlRoomPhone: string): Promise<EnableResult> {
  if (!CrashDetector) return { ok: false, message: 'This version of FireQuest cannot detect crashes. Install the newest version.' };

  const fg = await Location.requestForegroundPermissionsAsync();
  if (fg.status !== 'granted') {
    return { ok: false, message: 'Crash detection needs your location. Allow location for FireQuest and try again.' };
  }
  if (fg.android?.accuracy === 'coarse') {
    return {
      ok: false,
      message: 'Crash detection needs your precise location. Open FireQuest settings > Location and switch on "Use precise location".',
    };
  }

  const bgNow = await Location.getBackgroundPermissionsAsync();
  if (bgNow.status !== 'granted') {
    const go = await ask(
      'One more location setting',
      'So crash detection keeps working when FireQuest is closed, choose "Allow all the time" on the next screen, then come back.',
      'Open setting',
    );
    if (go) {
      try {
        await Location.requestBackgroundPermissionsAsync();
      } catch {
        // Some phones only allow this in Settings; the card shows a reminder.
      }
    }
  }

  if (Platform.OS === 'android' && Number(Platform.Version) >= 33) {
    await PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.POST_NOTIFICATIONS);
  }

  // Switching on again on this phone: remove its previous key first, so old keys do not pile up
  // (the database keeps at most 5 phones per person).
  try {
    const old = await CrashDetector.stop();
    if (old?.deviceKey) await supabase.rpc('unregister_crash_device', { p_key: old.deviceKey });
  } catch {
    // nothing to remove
  }

  const { data, error } = await supabase.rpc('register_crash_device');
  if (error) throw error;

  await CrashDetector.start({
    supabaseUrl: config.supabaseUrl,
    supabaseKey: config.supabaseKey,
    deviceKey: String(data),
    countdownSeconds: COUNTDOWN_SECONDS,
    controlRoomPhone: controlRoomPhone || '',
    userId,
  });
  // The service needs a moment to start.
  for (let i = 0; i < 12; i++) {
    const s = getCrashStatus();
    if (s.running) return { ok: true };
    if (s.lastError) return { ok: false, message: s.lastError };
    await new Promise((r) => setTimeout(r, 250));
  }
  return { ok: true };
}

/** Stops the service and deletes this phone's key, so it can no longer send alerts. */
export async function disableCrashDetection(): Promise<void> {
  let deviceKey = '';
  try {
    deviceKey = (await CrashDetector?.stop())?.deviceKey ?? '';
  } catch {
    // already stopped
  }
  if (!deviceKey) return;
  try {
    await supabase.rpc('unregister_crash_device', { p_key: deviceKey });
  } catch {
    // signed out or offline: the key stays registered but is no longer on this phone
  }
}

/**
 * Called when someone is signed in. Starts the service again if it was switched on for
 * this person; switches it off if it belongs to someone else who used this phone before.
 */
export async function resumeCrashDetection(userId: string): Promise<void> {
  try {
    const s = getCrashStatus();
    if (!s.enabled) return;
    if (s.userId && s.userId !== userId) {
      await CrashDetector?.stop();
      return;
    }
    await CrashDetector?.resume();
  } catch {
    // shown on the Account card
  }
}

export const simulateCrash = () => CrashDetector?.simulate();
export const crashImOk = () => CrashDetector?.imOk();
export const crashSendNow = () => CrashDetector?.sendNow();
export const openBatterySettings = () => CrashDetector?.openBatterySettings();
export const openAppSettings = () => CrashDetector?.openAppSettings();

export async function backgroundLocationAllowed(): Promise<boolean> {
  try {
    return (await Location.getBackgroundPermissionsAsync()).status === 'granted';
  } catch {
    return false;
  }
}
