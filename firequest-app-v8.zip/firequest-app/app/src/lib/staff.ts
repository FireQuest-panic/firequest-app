import { supabase } from './supabase';
import { EmergencyContact, MedicalProfile, OPEN_STATUSES, PanicAlert, Profile } from './types';

export interface StaffInfo {
  display_name: string;
  role: string;
}

export interface StaffAlert extends PanicAlert {
  operator_id: string | null;
  outcome: string | null;
  profiles: { full_name: string; phone: string } | null;
}

export interface AlertEvent {
  id: number;
  alert_id: string;
  actor_id: string | null;
  actor_kind: 'client' | 'operator' | 'system';
  event: string;
  note: string | null;
  created_at: string;
}

export interface AlertDetail {
  profile: Profile | null;
  medical: MedicalProfile | null;
  contacts: EmergencyContact[];
  events: AlertEvent[];
  staffNames: Record<string, string>;
  /** Other people on the client's family plan. */
  family: { name: string; phone: string; role: string; relationship?: string | null }[];
}

export const EVENT_LABELS: Record<string, string> = {
  raised: 'Alert raised',
  pressed_again: 'Client pressed again',
  acknowledge: 'Acknowledged',
  dispatch: 'FireQuest team dispatched',
  on_scene: 'Team on scene',
  close: 'Closed',
  note: 'Note',
  navigate_opened: 'Navigation opened',
  route_sent: 'Route sent to team',
  called_client: 'Called client',
  cancelled_by_client: 'Cancelled by client (correct PIN)',
  cancel_wrong_pin: 'WRONG cancel PIN entered',
  crash_detected: 'Crash detected by phone',
};

export const STATUS_LABELS: Record<string, string> = {
  new: 'New – not acknowledged',
  acknowledged: 'Acknowledged',
  dispatched: 'FireQuest dispatched',
  on_scene: 'Team on scene',
  closed: 'Closed',
  cancelled: 'Cancelled by client',
};

export const STATUS_RANK: Record<string, number> = {
  new: 0,
  acknowledged: 1,
  dispatched: 2,
  on_scene: 3,
  closed: 4,
  cancelled: 4,
};

export async function getStaffInfo(userId: string): Promise<StaffInfo | null> {
  const { data, error } = await supabase
    .from('staff')
    .select('display_name, role')
    .eq('user_id', userId)
    .maybeSingle();
  if (error) return null;
  return (data as StaffInfo | null) ?? null;
}

/** Open alerts plus everything raised in the last 24 hours. */
export async function listAlerts(): Promise<StaffAlert[]> {
  const since = new Date(Date.now() - 24 * 3600 * 1000).toISOString();
  const { data, error } = await supabase
    .from('alerts')
    .select('*, profiles(full_name, phone)')
    .or(`status.in.(${OPEN_STATUSES.join(',')}),created_at.gte."${since}"`)
    .order('created_at', { ascending: false })
    .limit(200);
  if (error) throw error;
  return (data as StaffAlert[] | null) ?? [];
}

export async function loadAlertDetail(alert: StaffAlert): Promise<AlertDetail> {
  const [p, m, c, ev, st, fam] = await Promise.all([
    supabase.from('profiles').select('*').eq('id', alert.user_id).maybeSingle(),
    supabase.from('medical_profiles').select('*').eq('user_id', alert.user_id).maybeSingle(),
    supabase.from('emergency_contacts').select('*').eq('user_id', alert.user_id).order('created_at'),
    supabase.from('alert_events').select('*').eq('alert_id', alert.id).order('created_at'),
    supabase.from('staff').select('user_id, display_name'),
    supabase.rpc('alert_family', { p_alert_id: alert.id }),
  ]);
  const staffNames: Record<string, string> = {};
  for (const s of (st.data as { user_id: string; display_name: string }[] | null) ?? []) {
    staffNames[s.user_id] = s.display_name;
  }
  return {
    profile: (p.data as Profile | null) ?? null,
    medical: (m.data as MedicalProfile | null) ?? null,
    contacts: (c.data as EmergencyContact[] | null) ?? [],
    events: (ev.data as AlertEvent[] | null) ?? [],
    staffNames,
    family: Array.isArray(fam.data) ? (fam.data as AlertDetail['family']) : [],
  };
}

export async function operatorAction(alertId: string, action: string, note: string | null = null): Promise<void> {
  const { error } = await supabase.rpc('operator_update_alert', {
    p_alert_id: alertId,
    p_action: action,
    p_note: note,
  });
  if (error) throw error;
}

export function timeAgo(iso: string | null): string {
  if (!iso) return '';
  const s = Math.max(0, Math.round((Date.now() - new Date(iso).getTime()) / 1000));
  if (s < 60) return `${s}s ago`;
  const m = Math.round(s / 60);
  if (m < 60) return `${m} min ago`;
  return `${Math.floor(m / 60)} h ${m % 60} min ago`;
}

export function hhmm(iso: string | null): string {
  if (!iso) return '';
  const d = new Date(iso);
  return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
}

function ageFrom(dob: string | null | undefined): string {
  if (!dob) return '';
  const d = new Date(`${dob}T00:00:00`);
  if (Number.isNaN(d.getTime())) return '';
  const now = new Date();
  let age = now.getFullYear() - d.getFullYear();
  if (now < new Date(now.getFullYear(), d.getMonth(), d.getDate())) age -= 1;
  return age > 0 && age < 130 ? `${age} yrs` : '';
}

/** WhatsApp message for responders: location link plus the client's details. */
export function routeMessage(alert: StaffAlert, detail: AlertDetail | null): string {
  const p = detail?.profile;
  const m = detail?.medical;
  const name = p?.full_name || alert.profiles?.full_name || 'Unknown client';
  const age = ageFrom(p?.date_of_birth);
  const vehicle = p
    ? [[p.vehicle_colour, p.vehicle_make, p.vehicle_model].filter(Boolean).join(' '), p.vehicle_registration]
        .filter(Boolean)
        .join(' · ')
    : '';
  const contact = detail?.contacts[0];
  if (!detail) {
    return [
      `*FireQuest ${ALERT_LABELS_UPPER[alert.type]} alert*${alert.source === 'crash_detection' ? ' – AUTO-DETECTED CRASH, client may be unconscious' : ''}${alert.is_test ? ' (TEST – do not call outside services)' : ''}`,
      `Client: ${name}`,
      `Phone: ${alert.profiles?.phone || '—'}`,
      'Medical details: not loaded yet – ask the control room',
      alert.lat != null && alert.lng != null ? `Navigate: ${navigationUrl(alert.lat, alert.lng)}` : 'Location: waiting for GPS',
    ].join('\n');
  }
  const lines = [
    `*FireQuest ${ALERT_LABELS_UPPER[alert.type]} alert*${alert.source === 'crash_detection' ? ' – AUTO-DETECTED CRASH, client may be unconscious' : ''}${alert.is_test ? ' (TEST – do not call outside services)' : ''}`,
    `Client: ${name}${age ? `, ${age}` : ''}`,
    `Phone: ${p?.phone || alert.profiles?.phone || '—'}`,
    p?.home_address ? `Home address: ${p.home_address}` : '',
    vehicle ? `Vehicle: ${vehicle}` : '',
    `Blood type: ${m?.blood_type || '—'}`,
    `Allergies: ${m?.allergies?.length ? m.allergies.join(', ') : 'None listed'}`,
    m?.conditions ? `Conditions: ${m.conditions}` : '',
    m?.medication ? `Medication: ${m.medication}` : '',
    `Medical aid: ${m?.medical_aid_scheme ? [m.medical_aid_scheme, m.medical_aid_plan, m.medical_aid_number].filter(Boolean).join(' · ') : 'None'}`,
    contact ? `Emergency contact: ${contact.name}${contact.relationship ? ` (${contact.relationship})` : ''} ${contact.phone}` : '',
    alert.lat != null && alert.lng != null ? `Navigate: ${navigationUrl(alert.lat, alert.lng)}` : 'Location: waiting for GPS',
  ];
  return lines.filter(Boolean).join('\n');
}

const ALERT_LABELS_UPPER: Record<string, string> = {
  medical: 'MEDICAL',
  vehicle: 'VEHICLE ACCIDENT',
  fire: 'FIRE & RESCUE',
};

export function navigationUrl(lat: number, lng: number): string {
  return `https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}&travelmode=driving`;
}
