import React, { useCallback, useEffect, useState } from 'react';
import { ActivityIndicator, AppState, Pressable, Text, View } from 'react-native';
import { SafeAreaProvider, useSafeAreaInsets } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import * as SplashScreen from 'expo-splash-screen';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import type { Session } from '@supabase/supabase-js';
import { colors } from './theme';
import { controlRoomPhoneFromConfig, isConfigured, supabase } from './lib/supabase';
import { friendlyError, getOpenAlert, loadBundle, loadSettings } from './lib/data';
import { getStaffInfo, StaffInfo } from './lib/staff';
import { useControlRoom } from './lib/useControlRoom';
import { AppSettings, PanicAlert, ProfileBundle } from './lib/types';
import { AuthScreen } from './screens/AuthScreen';
import { OnboardingScreen } from './screens/OnboardingScreen';
import { HomeScreen } from './screens/HomeScreen';
import { AlertScreen } from './screens/AlertScreen';
import { MedicalIdScreen } from './screens/MedicalIdScreen';
import { AccountScreen } from './screens/AccountScreen';
import { ControlRoomScreen } from './screens/ControlRoomScreen';
import { CrashCountdown } from './components/CrashCountdown';
import { disableCrashDetection, onCrashEvent, resumeCrashDetection } from './lib/crash';
import { Body, Button, Card, ErrorText, Logo, Screen, Title } from './components/ui';

SplashScreen.preventAutoHideAsync().catch(() => undefined);

type Tab = 'panic' | 'medical' | 'account' | 'control';

export default function App() {
  return (
    <SafeAreaProvider>
      <StatusBar style="light" />
      <View style={{ flex: 1, backgroundColor: colors.bg }}>
        <Root />
        {/* Shown whatever screen is open (also while loading or signed out). */}
        <CrashCountdown />
      </View>
    </SafeAreaProvider>
  );
}

function Root() {
  const [session, setSession] = useState<Session | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const [bundle, setBundle] = useState<ProfileBundle | null>(null);
  const [settings, setSettings] = useState<AppSettings>({ test_mode: true, control_room_phone: '' });
  const [openAlert, setOpenAlert] = useState<PanicAlert | null>(null);
  const [staff, setStaff] = useState<StaffInfo | null>(null);
  const [loading, setLoading] = useState(false);
  const [loadError, setLoadError] = useState('');
  const [tab, setTab] = useState<Tab>('panic');
  const [editing, setEditing] = useState(false);
  // Lets an operator leave their own alert screen to work in the control room (handy when testing on one phone).
  const [controlOverride, setControlOverride] = useState(false);

  const isStaff = Boolean(staff);
  const feed = useControlRoom(isStaff);

  useEffect(() => {
    supabase.auth
      .getSession()
      .then(({ data }) => setSession(data.session))
      .finally(() => setAuthReady(true));
    const { data } = supabase.auth.onAuthStateChange((_event, s) => setSession(s));
    return () => data.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (authReady || !isConfigured) SplashScreen.hideAsync().catch(() => undefined);
  }, [authReady]);

  const userId = session?.user.id;

  const load = useCallback(async () => {
    if (!userId) return;
    setLoading(true);
    setLoadError('');
    try {
      const [b, st, a, s] = await Promise.all([
        loadBundle(userId),
        loadSettings(),
        getOpenAlert(userId),
        getStaffInfo(userId),
      ]);
      setBundle(b);
      setSettings(st);
      setOpenAlert(a);
      setStaff(s);
    } catch (e) {
      setLoadError(friendlyError(e));
    } finally {
      setLoading(false);
    }
  }, [userId]);

  useEffect(() => {
    if (userId) {
      load();
    } else {
      setBundle(null);
      setOpenAlert(null);
      setStaff(null);
      setEditing(false);
      setControlOverride(false);
      setTab('panic');
    }
  }, [userId, load]);

  // Crash detection keeps running in the background; make sure it is going when the app opens.
  useEffect(() => {
    if (userId) resumeCrashDetection(userId);
  }, [userId]);

  // An alert may have been raised while the app was closed (e.g. by crash detection).
  useEffect(() => {
    if (!userId) return;
    const sub = AppState.addEventListener('change', (state) => {
      if (state !== 'active') return;
      getOpenAlert(userId)
        .then((a) => a && setOpenAlert((current) => current ?? a))
        .catch(() => undefined);
    });
    return () => sub.remove();
  }, [userId]);

  // Crash detection sent an alert while the app is open: show the alert screen.
  useEffect(() => {
    if (!userId) return;
    return onCrashEvent((e) => {
      if (e.type !== 'alertSent') return;
      getOpenAlert(userId)
        .then((a) => {
          if (a) {
            setControlOverride(false);
            setOpenAlert(a);
          }
        })
        .catch(() => undefined);
    });
  }, [userId]);

  const controlRoomPhone = settings.control_room_phone || controlRoomPhoneFromConfig;

  if (!isConfigured) {
    return (
      <Screen style={{ justifyContent: 'center', alignItems: 'center' }}>
        <Logo size={160} />
        <Title>Not set up yet</Title>
        <Body center>
          This build of FireQuest is not connected to a database. Ask FireQuest for the latest
          test version.
        </Body>
      </Screen>
    );
  }

  if (!authReady) return null;
  if (!session) return <AuthScreen />;

  if (!bundle) {
    return (
      <Screen style={{ justifyContent: 'center', alignItems: 'center' }}>
        <Logo size={140} />
        {loading || !loadError ? (
          <ActivityIndicator color={colors.gold} size="large" />
        ) : (
          <>
            <ErrorText>{loadError}</ErrorText>
            <Button title="Try again" onPress={load} style={{ alignSelf: 'stretch' }} />
            <Button
              title="Sign out"
              variant="plain"
              onPress={async () => {
                await disableCrashDetection();
                await supabase.auth.signOut();
              }}
            />
          </>
        )}
      </Screen>
    );
  }

  const registered = Boolean(bundle.profile.onboarded_at && bundle.hasPin);

  // Clients must finish registration first. Operators may skip it and go straight to the control room.
  if (!registered && !isStaff) {
    return <OnboardingScreen bundle={bundle} mode="onboard" onDone={load} />;
  }

  if (openAlert && !controlOverride) {
    return (
      <AlertScreen
        key={openAlert.id}
        initialAlert={openAlert}
        controlRoomPhone={controlRoomPhone}
        onOpenControlRoom={
          isStaff
            ? () => {
                setControlOverride(true);
                setTab('control');
              }
            : undefined
        }
        onFinished={() => {
          setOpenAlert(null);
          setControlOverride(false);
          load();
        }}
      />
    );
  }

  if (editing) {
    return (
      <OnboardingScreen
        bundle={bundle}
        mode={registered ? 'edit' : 'onboard'}
        onDone={() => {
          setEditing(false);
          load();
        }}
        onCancel={() => setEditing(false)}
      />
    );
  }

  const showNewAlertBanner = isStaff && tab !== 'control' && feed.newCount > 0;

  return (
    <View style={{ flex: 1 }}>
      {showNewAlertBanner && (
        <Banner
          color={colors.red}
          text={`NEW ALERT (${feed.newCount}) – tap to open the control room`}
          onPress={() => setTab('control')}
        />
      )}
      {openAlert && controlOverride && (
        <Banner
          color={colors.gold}
          textColor={colors.ink}
          text="Your own alert is still active – tap to return to it"
          onPress={() => setControlOverride(false)}
        />
      )}
      <View style={{ flex: 1 }}>
        {tab === 'panic' &&
          (registered ? (
            <HomeScreen
              profile={bundle.profile}
              settings={settings}
              controlRoomPhone={controlRoomPhone}
              onOpenAccount={() => setTab('account')}
              onAlertRaised={(a) => {
                setControlOverride(false);
                setOpenAlert(a);
              }}
            />
          ) : (
            <Screen aboveTabBar style={{ justifyContent: 'center' }}>
              <Card>
                <Title>Finish your registration</Title>
                <Body>To use the panic buttons yourself, complete your details, medical information, emergency contacts and cancel PIN.</Body>
                <Button title="Complete registration" onPress={() => setEditing(true)} />
              </Card>
            </Screen>
          ))}
        {tab === 'medical' && <MedicalIdScreen bundle={bundle} onEdit={() => setEditing(true)} />}
        {tab === 'account' && <AccountScreen profile={bundle.profile} settings={settings} controlRoomPhone={controlRoomPhone} />}
        {tab === 'control' && isStaff && <ControlRoomScreen feed={feed} operatorName={staff?.display_name ?? ''} />}
      </View>
      <TabBar tab={tab} onChange={setTab} isStaff={isStaff} badge={feed.newCount} />
    </View>
  );
}

function Banner({
  text,
  color,
  textColor = '#FFFFFF',
  onPress,
}: {
  text: string;
  color: string;
  textColor?: string;
  onPress: () => void;
}) {
  const insets = useSafeAreaInsets();
  return (
    <Pressable
      accessibilityRole="button"
      onPress={onPress}
      style={{ backgroundColor: color, paddingTop: insets.top + 10, paddingBottom: 10, paddingHorizontal: 16 }}
    >
      <Text style={{ color: textColor, fontWeight: '800', fontSize: 15, textAlign: 'center' }}>{text}</Text>
    </Pressable>
  );
}

function TabBar({
  tab,
  onChange,
  isStaff,
  badge,
}: {
  tab: Tab;
  onChange: (t: Tab) => void;
  isStaff: boolean;
  badge: number;
}) {
  const insets = useSafeAreaInsets();
  const items: { key: Tab; label: string; icon: React.ComponentProps<typeof MaterialCommunityIcons>['name'] }[] = [
    { key: 'panic', label: 'Panic', icon: 'shield-alert-outline' },
    { key: 'medical', label: 'Medical ID', icon: 'card-account-details-outline' },
    { key: 'account', label: 'Account', icon: 'account-circle-outline' },
  ];
  if (isStaff) items.push({ key: 'control', label: 'Control room', icon: 'monitor-dashboard' });
  return (
    <View
      accessibilityRole="tablist"
      style={{
        flexDirection: 'row',
        borderTopWidth: 1,
        borderTopColor: '#24221F',
        backgroundColor: colors.bg,
        paddingBottom: Math.max(insets.bottom, 8),
        paddingTop: 6,
      }}
    >
      {items.map((it) => {
        const active = it.key === tab;
        const showBadge = it.key === 'control' && badge > 0;
        return (
          <Pressable
            key={it.key}
            accessibilityRole="tab"
            accessibilityState={{ selected: active }}
            accessibilityLabel={showBadge ? `${it.label}, ${badge} new alerts` : it.label}
            onPress={() => onChange(it.key)}
            style={{ flex: 1, alignItems: 'center', gap: 2, minHeight: 52, justifyContent: 'center' }}
          >
            <View>
              <MaterialCommunityIcons name={it.icon} size={24} color={active ? colors.goldText : colors.faint} />
              {showBadge && (
                <View
                  style={{
                    position: 'absolute',
                    top: -4,
                    right: -10,
                    minWidth: 18,
                    height: 18,
                    borderRadius: 9,
                    backgroundColor: colors.red,
                    alignItems: 'center',
                    justifyContent: 'center',
                    paddingHorizontal: 4,
                  }}
                >
                  <Text style={{ color: '#FFFFFF', fontSize: 11, fontWeight: '800' }}>{badge}</Text>
                </View>
              )}
            </View>
            <Text style={{ fontSize: 12, fontWeight: active ? '700' : '500', color: active ? colors.goldText : colors.faint }}>
              {it.label}
            </Text>
          </Pressable>
        );
      })}
    </View>
  );
}
