package za.co.firequest.crash

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Build

/** The notifications shown by crash detection. */
object CrashNotifications {
  const val STATUS_ID = 4101
  const val ALARM_ID = 4102
  const val RESULT_ID = 4103

  private const val CHANNEL_STATUS = "fq_crash_status"
  private const val CHANNEL_ALARM = "fq_crash_alarm"
  private const val CHANNEL_RESULT = "fq_crash_result"
  private const val RED = 0xFFD42F35.toInt()

  fun createChannels(context: Context) {
    if (Build.VERSION.SDK_INT < 26) return
    val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    nm.createNotificationChannel(
      NotificationChannel(CHANNEL_STATUS, "Crash detection status", NotificationManager.IMPORTANCE_LOW).apply {
        description = "Shown while FireQuest watches for a vehicle accident."
        setShowBadge(false)
      }
    )
    nm.createNotificationChannel(
      NotificationChannel(CHANNEL_ALARM, "Accident detected", NotificationManager.IMPORTANCE_HIGH).apply {
        description = "Countdown before FireQuest sends an accident alert."
        setSound(null, null) // the service plays a loud alarm itself
        enableVibration(true)
        vibrationPattern = longArrayOf(0, 800, 400, 800)
        lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        setBypassDnd(true)
        enableLights(true)
        lightColor = Color.RED
      }
    )
    nm.createNotificationChannel(
      NotificationChannel(CHANNEL_RESULT, "Accident alerts", NotificationManager.IMPORTANCE_HIGH).apply {
        description = "Whether an accident alert was sent."
      }
    )
  }

  private fun builder(context: Context, channel: String): Notification.Builder {
    val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(context, channel) else Notification.Builder(context)
    return b.setSmallIcon(R.drawable.ic_fq_crash).setColor(RED).setContentIntent(openApp(context, 0))
  }

  fun openApp(context: Context, requestCode: Int): PendingIntent? {
    val launch = context.packageManager.getLaunchIntentForPackage(context.packageName) ?: return null
    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
    return PendingIntent.getActivity(
      context, requestCode, launch, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
  }

  private fun serviceAction(context: Context, action: String, requestCode: Int): PendingIntent {
    val intent = Intent(context, CrashDetectionService::class.java).setAction(action)
    return if (Build.VERSION.SDK_INT >= 26) {
      PendingIntent.getForegroundService(context, requestCode, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    } else {
      PendingIntent.getService(context, requestCode, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }
  }

  fun status(context: Context, title: String, text: String): Notification =
    builder(context, CHANNEL_STATUS)
      .setContentTitle(title)
      .setContentText(text)
      .setOngoing(true)
      .setShowWhen(false)
      .setCategory(Notification.CATEGORY_SERVICE)
      .build()

  fun countdown(context: Context, endsAtWallClock: Long, seconds: Int, simulated: Boolean): Notification {
    val title = if (simulated) "TEST: possible accident detected" else "Possible accident detected"
    val b = builder(context, CHANNEL_ALARM)
      .setContentTitle(title)
      .setContentText("FireQuest will send an accident alert in $seconds seconds. Tap I'm OK if you are fine.")
      .setStyle(
        Notification.BigTextStyle().bigText(
          "FireQuest will send an accident alert with your location to the control room in $seconds seconds.\n" +
            "Tap I'M OK if you are fine, or SEND HELP NOW."
        )
      )
      .setOngoing(true)
      .setAutoCancel(false)
      .setCategory(Notification.CATEGORY_ALARM)
      .setPriority(Notification.PRIORITY_MAX)
      .setVisibility(Notification.VISIBILITY_PUBLIC)
      .setWhen(endsAtWallClock)
      .setShowWhen(true)
      .setUsesChronometer(true)
      .addAction(Notification.Action.Builder(null, "I'M OK", serviceAction(context, CrashDetectionService.ACTION_IM_OK, 11)).build())
      .addAction(Notification.Action.Builder(null, "SEND HELP NOW", serviceAction(context, CrashDetectionService.ACTION_SEND_NOW, 12)).build())
    if (Build.VERSION.SDK_INT >= 24) b.setChronometerCountDown(true)
    openApp(context, 13)?.let { b.setFullScreenIntent(it, true) }
    // Swiping it away (possible on Android 14+) brings it straight back while the countdown runs.
    b.setDeleteIntent(serviceAction(context, CrashDetectionService.ACTION_REPOST, 14))
    return b.build()
  }

  fun result(context: Context, title: String, text: String, ongoing: Boolean = false): Notification =
    builder(context, CHANNEL_RESULT)
      .setContentTitle(title)
      .setContentText(text)
      .setStyle(Notification.BigTextStyle().bigText(text))
      .setOngoing(ongoing)
      .setAutoCancel(!ongoing)
      .setCategory(Notification.CATEGORY_STATUS)
      .build()

  fun show(context: Context, id: Int, notification: Notification) {
    try {
      (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(id, notification)
    } catch (_: SecurityException) {
      // Notifications are switched off for FireQuest; the alarm sound still plays.
    }
  }

  fun cancel(context: Context, id: Int) {
    (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(id)
  }
}
