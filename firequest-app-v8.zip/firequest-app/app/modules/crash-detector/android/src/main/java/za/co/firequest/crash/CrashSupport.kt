package za.co.firequest.crash

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Settings saved on the phone so the service can run (and restart) without the app. */
class CrashConfig(context: Context) {
  private val prefs = context.applicationContext.getSharedPreferences("firequest_crash_detection", Context.MODE_PRIVATE)

  val supabaseUrl: String get() = prefs.getString("supabaseUrl", "") ?: ""
  val supabaseKey: String get() = prefs.getString("supabaseKey", "") ?: ""
  val deviceKey: String get() = prefs.getString("deviceKey", "") ?: ""
  val countdownSeconds: Int get() = prefs.getInt("countdownSeconds", 30).coerceIn(10, 120)
  val controlRoomPhone: String get() = prefs.getString("controlRoomPhone", "") ?: ""
  /** The FireQuest account this phone sends crash alerts for. */
  val userId: String get() = prefs.getString("userId", "") ?: ""

  /** True once crash detection has been switched on in the app. */
  val isComplete: Boolean get() = supabaseUrl.isNotBlank() && supabaseKey.isNotBlank() && deviceKey.isNotBlank()

  fun save(url: String, key: String, deviceKey: String, countdownSeconds: Int, controlRoomPhone: String, userId: String) {
    prefs.edit()
      .putString("supabaseUrl", url.trim())
      .putString("supabaseKey", key.trim())
      .putString("deviceKey", deviceKey.trim())
      .putInt("countdownSeconds", countdownSeconds)
      .putString("controlRoomPhone", controlRoomPhone.trim())
      .putString("userId", userId.trim())
      .apply()
  }

  fun clear() {
    prefs.edit().clear().apply()
  }

  // A running countdown is saved, so it still ends in an alert if Android restarts the service.
  data class SavedCountdown(val endsAtWallClock: Long, val peakG: Double?, val speedKmh: Double?, val simulated: Boolean)

  fun saveCountdown(c: SavedCountdown) {
    prefs.edit()
      .putLong("cdEndsAt", c.endsAtWallClock)
      .putFloat("cdPeakG", (c.peakG ?: -1.0).toFloat())
      .putFloat("cdSpeed", (c.speedKmh ?: -1.0).toFloat())
      .putBoolean("cdSimulated", c.simulated)
      .commit()
  }

  fun savedCountdown(): SavedCountdown? {
    val endsAt = prefs.getLong("cdEndsAt", 0L)
    if (endsAt <= 0L) return null
    val g = prefs.getFloat("cdPeakG", -1f).toDouble()
    val v = prefs.getFloat("cdSpeed", -1f).toDouble()
    return SavedCountdown(endsAt, g.takeIf { it >= 0 }, v.takeIf { it >= 0 }, prefs.getBoolean("cdSimulated", false))
  }

  fun clearCountdown() {
    prefs.edit().remove("cdEndsAt").remove("cdPeakG").remove("cdSpeed").remove("cdSimulated").commit()
  }
}

/** The database answered with an error (as opposed to no connection). */
class HttpStatusException(val code: Int, message: String) : IOException(message)

/** Calls the FireQuest database functions. Runs on a background thread only. */
object CrashApi {
  @Throws(IOException::class)
  fun call(config: CrashConfig, function: String, body: JSONObject): String {
    val url = URL(config.supabaseUrl.trimEnd('/') + "/rest/v1/rpc/" + function)
    val conn = url.openConnection() as HttpURLConnection
    try {
      conn.requestMethod = "POST"
      conn.connectTimeout = 15_000
      conn.readTimeout = 15_000
      conn.doOutput = true
      conn.setRequestProperty("apikey", config.supabaseKey)
      conn.setRequestProperty("Content-Type", "application/json")
      conn.setRequestProperty("Accept", "application/json")
      conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
      val code = conn.responseCode
      val stream = if (code in 200..299) conn.inputStream else conn.errorStream
      val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
      if (code !in 200..299) throw HttpStatusException(code, "HTTP $code: ${text.take(300)}")
      return text
    } finally {
      conn.disconnect()
    }
  }
}

/** Passes service events to the app's JavaScript while the app is open. */
object CrashEvents {
  @Volatile var listener: ((Map<String, Any?>) -> Unit)? = null
  private val main = Handler(Looper.getMainLooper())

  fun emit(type: String, data: Map<String, Any?> = emptyMap()) {
    val body = data + ("type" to type)
    main.post {
      try {
        listener?.invoke(body)
      } catch (_: Exception) {
      }
    }
  }
}
