package za.co.firequest.crash

/**
 * Crash-detection rules. Plain Kotlin with no Android code, so it can be tested
 * on a computer with recorded or simulated sensor data.
 *
 * A crash is assumed when ALL of these happen:
 *  1. The vehicle was driving: GPS speed of at least [drivingKmh] in the 15 seconds before.
 *  2. A violent jolt: at least [impactSamples] accelerometer readings of [impactG] g or more
 *     within [impactWindowMs]. (A pothole or a dropped phone gives one short spike.)
 *  3. The phone was not in free fall just before the jolt (that is a dropped phone).
 *  4. The vehicle then stops: GPS speed of [stoppedKmh] or less within [stopWindowMs],
 *     or GPS goes silent for [noGpsConfirmMs].
 * It is rejected if the vehicle is still doing [stillDrivingKmh] or more after
 * [graceMs] (the driver carried on).
 *
 * All times are milliseconds on one monotonic clock (elapsed time since boot).
 */
class CrashDetector(
  private val impactG: Double = 3.0,
  private val impactSamples: Int = 3,
  private val impactWindowMs: Long = 300,
  private val freeFallG: Double = 0.35,
  private val freeFallMinMs: Long = 150,
  private val dropRejectMs: Long = 1_000,
  private val drivingKmh: Double = 25.0,
  private val drivingLookbackMs: Long = 15_000,
  private val stoppedKmh: Double = 8.0,
  private val stillDrivingKmh: Double = 20.0,
  private val graceMs: Long = 8_000,
  private val noGpsConfirmMs: Long = 20_000,
  private val stopWindowMs: Long = 60_000,
  private val cooldownMs: Long = 120_000,
) {
  sealed class Result {
    object None : Result()
    data class Impact(val peakG: Double, val speedKmh: Double) : Result()
    data class Confirmed(val peakG: Double, val speedKmh: Double) : Result()
    data class Rejected(val reason: String) : Result()
  }

  private val speeds = ArrayDeque<Pair<Long, Double>>()
  private val strongSamples = ArrayDeque<Pair<Long, Double>>()
  private var freeFallStart = -1L
  private var lastFreeFallEnd = -1L

  private var impactAt = -1L
  private var impactPeak = 0.0
  private var impactSpeed = 0.0
  private var fixAfterImpact = false
  private var cooldownUntil = Long.MIN_VALUE

  val hasCandidate: Boolean get() = impactAt >= 0

  /** A GPS fix with speed. */
  fun onSpeed(t: Long, kmh: Double): Result {
    speeds.addLast(t to kmh)
    while (speeds.isNotEmpty() && speeds.first().first < t - 2 * drivingLookbackMs) speeds.removeFirst()

    if (impactAt < 0 || t < impactAt) return Result.None
    fixAfterImpact = true
    if (kmh <= stoppedKmh) return confirm()
    if (kmh >= stillDrivingKmh && t - impactAt >= graceMs) return reject("still driving after the jolt")
    return Result.None
  }

  /** One accelerometer reading, as total acceleration in g (1.0 = resting). */
  fun onAccel(t: Long, g: Double): Result {
    // Free fall (a dropped phone) shows as almost zero g for a moment.
    if (g < freeFallG) {
      if (freeFallStart < 0) freeFallStart = t
    } else if (freeFallStart >= 0) {
      if (t - freeFallStart >= freeFallMinMs) lastFreeFallEnd = t
      freeFallStart = -1
    }

    if (impactAt >= 0) {
      if (t - impactAt < 1_000 && g > impactPeak) impactPeak = g
      return Result.None
    }
    if (t < cooldownUntil || g < impactG) return Result.None

    strongSamples.addLast(t to g)
    while (strongSamples.isNotEmpty() && strongSamples.first().first < t - impactWindowMs) strongSamples.removeFirst()
    if (strongSamples.size < impactSamples) return Result.None

    val peak = strongSamples.maxOf { it.second }
    strongSamples.clear()
    if (lastFreeFallEnd >= 0 && t - lastFreeFallEnd <= dropRejectMs) return Result.None // phone was dropped

    val speed = maxSpeedBetween(t - drivingLookbackMs, t) ?: return Result.None
    if (speed < drivingKmh) return Result.None

    impactAt = t
    impactPeak = peak
    impactSpeed = speed
    fixAfterImpact = false
    return Result.Impact(peak, speed)
  }

  /** Call about once a second, so a crash is confirmed even when GPS stops reporting. */
  fun onTick(t: Long): Result {
    if (impactAt < 0) return Result.None
    if (!fixAfterImpact && t - impactAt >= noGpsConfirmMs) return confirm()
    if (t - impactAt >= stopWindowMs) return reject("the vehicle did not stop")
    return Result.None
  }

  /** After a countdown ends (alert sent or "I'm OK"), ignore jolts for a while. */
  fun startCooldown(t: Long) {
    cooldownUntil = t + cooldownMs
    impactAt = -1
    strongSamples.clear()
  }

  private fun maxSpeedBetween(from: Long, to: Long): Double? =
    speeds.filter { it.first in from..to }.maxOfOrNull { it.second }

  private fun confirm(): Result {
    val result = Result.Confirmed(impactPeak, impactSpeed)
    impactAt = -1
    return result
  }

  private fun reject(reason: String): Result {
    impactAt = -1
    return Result.Rejected(reason)
  }
}
