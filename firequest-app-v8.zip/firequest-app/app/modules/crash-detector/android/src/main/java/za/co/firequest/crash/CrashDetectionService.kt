package za.co.firequest.crash

import android.Manifest
import android.app.Notification
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.util.Log
import org.json.JSONObject
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.sqrt

/**
 * Runs in the background (also when the app is closed) and watches for a vehicle accident.
 *
 * Idle: low-power location (fused / network / passive) plus a short GPS check every 3 minutes,
 *       to notice when the phone moves at driving speed.
 * Driving: GPS every second plus the motion sensor at 100 readings a second.
 * A detected crash starts a loud 30-second countdown; if nobody taps "I'm OK", a vehicle
 * alert with the location is sent to the FireQuest control room.
 */
class CrashDetectionService : Service(), SensorEventListener, LocationListener {

  companion object {
    private const val TAG = "FireQuestCrash"
    const val ACTION_START = "za.co.firequest.crash.START"
    const val ACTION_IM_OK = "za.co.firequest.crash.IM_OK"
    const val ACTION_SEND_NOW = "za.co.firequest.crash.SEND_NOW"
    const val ACTION_SIMULATE = "za.co.firequest.crash.SIMULATE"
    /** The countdown notification was swiped away: show it again. */
    const val ACTION_REPOST = "za.co.firequest.crash.REPOST"

    private const val DRIVING_KMH = 25.0
    private const val STAY_ACTIVE_MS = 180_000L
    private const val PROBE_EVERY_MS = 180_000L
    private const val FOLLOW_UP_MS = 15 * 60_000L
    private const val FOLLOW_UP_EVERY_MS = 20_000L
    private const val SEND_ATTEMPTS = 60
    private const val SEND_RETRY_MS = 10_000L
    private const val STALE_COUNTDOWN_MS = 30 * 60_000L

    @Volatile var running = false
      private set
    /** off, idle, driving, countdown, sending, sent */
    @Volatile var state = "off"
      private set
    @Volatile var countdownEndsAt = 0L
      private set
    @Volatile var lastError: String? = null
      private set

    /**
     * Starts (or sends a command to) the service. Returns false without starting when it
     * could not run, because Android stops the app if such a service fails to start.
     */
    fun start(context: Context, action: String = ACTION_START, fromBackground: Boolean = false): Boolean {
      if (!CrashConfig(context).isComplete) return false
      if ((action == ACTION_IM_OK || action == ACTION_SEND_NOW || action == ACTION_REPOST) && !running) return false
      if (context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
        lastError = "Location permission is off (FireQuest needs precise location)"
        return false
      }
      if (fromBackground && Build.VERSION.SDK_INT >= 29 &&
        context.checkSelfPermission(Manifest.permission.ACCESS_BACKGROUND_LOCATION) != PackageManager.PERMISSION_GRANTED
      ) {
        lastError = "Location is not set to Allow all the time"
        return false
      }
      val intent = Intent(context, CrashDetectionService::class.java).setAction(action)
      return try {
        if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(intent) else context.startService(intent)
        true
      } catch (e: Exception) {
        lastError = "Could not start crash detection: ${e.message}"
        Log.w(TAG, lastError, e)
        false
      }
    }

    fun stop(context: Context) {
      context.stopService(Intent(context, CrashDetectionService::class.java))
    }

    fun clearError() {
      lastError = null
    }
  }

  private data class Pending(val peakG: Double?, val speedKmh: Double?, val simulated: Boolean, val endsAt: Long)

  private val handler = Handler(Looper.getMainLooper())
  private val network = Executors.newSingleThreadExecutor()
  private val detector = CrashDetector()
  private lateinit var config: CrashConfig

  private var sensorManager: SensorManager? = null
  private var locationManager: LocationManager? = null
  private var wakeLock: PowerManager.WakeLock? = null

  private var driving = false
  private var activeUntil = 0L
  private var lastFix: Location? = null
  private var lastIdleFix: Location? = null
  private var probing = false
  private var pending: Pending? = null
  private var sending = false
  private var followUpUntil = 0L
  private var lastFollowUp = 0L

  private var ringtone: Ringtone? = null
  private var savedAlarmVolume = -1
  /** The countdown notification while a countdown runs (kept on screen as the service notification). */
  private var countdownNotice: Notification? = null

  /** Slow GPS check while idle (every 3 minutes); kept separate so it can be removed on its own. */
  private val probeListener = object : LocationListener {
    override fun onLocationChanged(location: Location) = this@CrashDetectionService.onLocationChanged(location)
    @Deprecated("Deprecated in Android")
    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    override fun onProviderEnabled(provider: String) {}
    override fun onProviderDisabled(provider: String) {}
  }

  override fun onBind(intent: Intent?): IBinder? = null

  override fun onCreate() {
    super.onCreate()
    CrashNotifications.createChannels(this)
    sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
    locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
  }

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    config = CrashConfig(this)
    // Always go to the foreground first: Android requires it after startForegroundService().
    if (!postForeground(statusNotification())) {
      stopSelf()
      return START_NOT_STICKY
    }
    if (!config.isComplete) {
      // Switched off (e.g. a button on an old notification was tapped).
      CrashNotifications.cancel(this, CrashNotifications.ALARM_ID)
      stopForegroundCompat()
      stopSelf()
      return START_NOT_STICKY
    }
    if (!running) {
      running = true
      lastError = null
      enterIdle()
      handler.post(tick)
      resumeSavedCountdown()
    }
    when (intent?.action) {
      ACTION_IM_OK -> if (pending != null) cancelCountdown() else {
        stopAlarm()
        CrashNotifications.cancel(this, CrashNotifications.ALARM_ID)
      }
      ACTION_SEND_NOW -> when {
        pending != null -> sendAlert()
        !sending -> {
          // The countdown was lost (Android restarted the service), but the person asked for help.
          pending = Pending(null, null, false, SystemClock.elapsedRealtime())
          sendAlert()
        }
      }
      ACTION_SIMULATE -> startCountdown(null, null, simulated = true)
      ACTION_REPOST -> countdownNotice?.let { CrashNotifications.show(this, CrashNotifications.ALARM_ID, it) }
    }
    return START_STICKY
  }

  override fun onDestroy() {
    running = false
    countdownNotice = null
    state = "off"
    handler.removeCallbacksAndMessages(null)
    stopSensors()
    stopLocation()
    stopProbe()
    stopAlarm()
    releaseWakeLock()
    network.shutdown()
    CrashNotifications.cancel(this, CrashNotifications.ALARM_ID)
    CrashEvents.emit("state", mapOf("state" to "off"))
    super.onDestroy()
  }

  // ------------------------------------------------------------------ notifications

  /** Makes this a foreground service. Only called from onStartCommand (Android 12+ rules). */
  private fun postForeground(n: Notification): Boolean = try {
    if (Build.VERSION.SDK_INT >= 29) {
      startForeground(CrashNotifications.STATUS_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
    } else {
      startForeground(CrashNotifications.STATUS_ID, n)
    }
    true
  } catch (e: Exception) {
    lastError = "Could not start crash detection: ${e.message}"
    Log.w(TAG, lastError, e)
    false
  }

  @Suppress("DEPRECATION")
  private fun stopForegroundCompat() {
    if (Build.VERSION.SDK_INT >= 24) stopForeground(Service.STOP_FOREGROUND_REMOVE) else stopForeground(true)
  }

  private fun statusNotification(): Notification = CrashNotifications.status(
    this,
    if (driving) "Crash detection is active" else "Crash detection is on",
    if (driving) "Driving detected. FireQuest is watching for an accident." else "FireQuest will watch for an accident when you drive.",
  )

  private fun refreshStatus() {
    if (running && pending == null) CrashNotifications.show(this, CrashNotifications.STATUS_ID, statusNotification())
  }

  private fun setState(s: String) {
    if (!running) return
    state = s
    CrashEvents.emit("state", mapOf("state" to s))
  }

  // ------------------------------------------------------------------ idle / driving modes

  private fun hasLocationPermission() =
    checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

  private fun enterIdle() {
    driving = false
    stopSensors()
    stopLocation()
    releaseWakeLock()
    lastIdleFix = null
    if (!hasLocationPermission()) {
      lastError = "Location permission is off"
    } else {
      val lm = locationManager
      val providers = try { lm?.allProviders ?: emptyList() } catch (_: Exception) { emptyList<String>() }
      fun listen(provider: String, everyMs: Long) {
        if (provider !in providers) return
        try {
          lm?.requestLocationUpdates(provider, everyMs, 0f, this, Looper.getMainLooper())
        } catch (e: Exception) {
          Log.w(TAG, "idle location $provider failed", e)
        }
      }
      listen(LocationManager.PASSIVE_PROVIDER, 5_000L)
      if (Build.VERSION.SDK_INT >= 31) listen(LocationManager.FUSED_PROVIDER, 30_000L)
      listen(LocationManager.NETWORK_PROVIDER, 45_000L)
      startProbe()
    }
    setState("idle")
    refreshStatus()
  }

  private fun enterDriving() {
    activeUntil = SystemClock.elapsedRealtime() + STAY_ACTIVE_MS
    if (driving) return
    driving = true
    stopProbe()
    acquireWakeLock()
    stopLocation()
    if (hasLocationPermission()) {
      try {
        locationManager?.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1_000L, 0f, this, Looper.getMainLooper())
      } catch (e: Exception) {
        lastError = "GPS: ${e.message}"
        Log.w(TAG, "gps failed", e)
      }
    }
    sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.let {
      sensorManager?.registerListener(this, it, 10_000)
    }
    if (pending == null && !sending) setState("driving")
    refreshStatus()
  }

  private fun startProbe() {
    if (probing || !hasLocationPermission()) return
    try {
      locationManager?.requestLocationUpdates(LocationManager.GPS_PROVIDER, PROBE_EVERY_MS, 0f, probeListener, Looper.getMainLooper())
      probing = true
    } catch (e: Exception) {
      Log.w(TAG, "gps check failed", e)
    }
  }

  private fun stopProbe() {
    if (!probing) return
    try { locationManager?.removeUpdates(probeListener) } catch (_: Exception) {}
    probing = false
  }

  private fun stopSensors() {
    try { sensorManager?.unregisterListener(this) } catch (_: Exception) {}
  }

  private fun stopLocation() {
    try { locationManager?.removeUpdates(this) } catch (_: Exception) {}
  }

  private fun acquireWakeLock() {
    if (wakeLock?.isHeld == true) return
    val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
    wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "FireQuest:CrashDetection").apply {
      setReferenceCounted(false)
      acquire(30 * 60_000L)
    }
  }

  private fun releaseWakeLock() {
    try { if (wakeLock?.isHeld == true) wakeLock?.release() } catch (_: Exception) {}
    wakeLock = null
  }

  private val tick = object : Runnable {
    override fun run() {
      if (!running) return
      val now = SystemClock.elapsedRealtime()
      handle(detector.onTick(now))
      pending?.let { if (now >= it.endsAt && !sending) sendAlert() }
      if (driving && pending == null && !sending && now > activeUntil && now > followUpUntil) enterIdle()
      if (driving && wakeLock?.isHeld != true) acquireWakeLock()
      handler.postDelayed(this, 1_000L)
    }
  }

  // ------------------------------------------------------------------ sensor + GPS input

  override fun onSensorChanged(event: SensorEvent) {
    if (event.sensor.type != Sensor.TYPE_ACCELEROMETER) return
    val x = event.values[0].toDouble()
    val y = event.values[1].toDouble()
    val z = event.values[2].toDouble()
    val g = sqrt(x * x + y * y + z * z) / SensorManager.GRAVITY_EARTH
    handle(detector.onAccel(SystemClock.elapsedRealtime(), g))
  }

  override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

  override fun onLocationChanged(location: Location) {
    val now = SystemClock.elapsedRealtime()
    if (lastFix == null || location.provider == LocationManager.GPS_PROVIDER || !driving) lastFix = location
    val kmh = if (location.hasSpeed()) location.speed * 3.6 else null

    if (!driving) {
      var moving = kmh != null && kmh >= DRIVING_KMH
      val prev = lastIdleFix
      if (!moving && prev != null) {
        val seconds = (location.elapsedRealtimeNanos - prev.elapsedRealtimeNanos) / 1e9
        if (seconds in 15.0..600.0) {
          // Allow for half of the position uncertainty, so a jumpy network fix is not mistaken for driving.
          val metres = location.distanceTo(prev) - 0.5 * (location.accuracy + prev.accuracy)
          if (metres / seconds * 3.6 >= DRIVING_KMH) moving = true
        }
      }
      lastIdleFix = location
      if (moving) enterDriving()
      return
    }

    if (location.provider == LocationManager.GPS_PROVIDER && kmh != null) {
      if (kmh >= 10) activeUntil = now + STAY_ACTIVE_MS
      handle(detector.onSpeed(now, kmh))
    }
    if (now < followUpUntil && now - lastFollowUp >= FOLLOW_UP_EVERY_MS) {
      lastFollowUp = now
      sendLocationUpdate(location)
    }
  }

  @Deprecated("Deprecated in Android")
  override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}

  override fun onProviderEnabled(provider: String) {
    // Location was switched back on: listen again.
    if (running && !driving) enterIdle()
  }

  override fun onProviderDisabled(provider: String) {}

  private fun handle(result: CrashDetector.Result) {
    when (result) {
      is CrashDetector.Result.Impact -> {
        Log.i(TAG, "impact ${result.peakG} g at ${result.speedKmh} km/h")
        CrashEvents.emit("impact", mapOf("peakG" to result.peakG, "speedKmh" to result.speedKmh))
      }
      is CrashDetector.Result.Confirmed -> startCountdown(result.peakG, result.speedKmh, simulated = false)
      is CrashDetector.Result.Rejected -> Log.i(TAG, "jolt ignored: ${result.reason}")
      else -> {}
    }
  }

  // ------------------------------------------------------------------ countdown

  private fun resumeSavedCountdown() {
    val saved = config.savedCountdown() ?: return
    val overdueMs = System.currentTimeMillis() - saved.endsAtWallClock
    if (overdueMs > STALE_COUNTDOWN_MS) {
      config.clearCountdown()
      return
    }
    // Always leave at least 15 seconds to tap I'M OK after a restart.
    val endsAt = max(saved.endsAtWallClock, System.currentTimeMillis() + 15_000L)
    startCountdown(saved.peakG, saved.speedKmh, saved.simulated, endsAtWallClock = endsAt)
  }

  private fun startCountdown(peakG: Double?, speedKmh: Double?, simulated: Boolean, endsAtWallClock: Long? = null) {
    if (pending != null || sending) return
    val nowWall = System.currentTimeMillis()
    val endsWall = endsAtWallClock ?: (nowWall + config.countdownSeconds * 1_000L)
    val remainingMs = max(0L, endsWall - nowWall)
    pending = Pending(peakG, speedKmh, simulated, SystemClock.elapsedRealtime() + remainingMs)
    countdownEndsAt = endsWall
    config.saveCountdown(CrashConfig.SavedCountdown(endsWall, peakG, speedKmh, simulated))
    enterDriving() // make sure GPS is on for an accurate position
    acquireWakeLock()
    startAlarm()
    val seconds = ((remainingMs + 999) / 1_000L).toInt()
    val n = CrashNotifications.countdown(this, endsWall, seconds, simulated)
    countdownNotice = n
    CrashNotifications.show(this, CrashNotifications.ALARM_ID, n)
    setState("countdown")
    CrashEvents.emit("countdown", mapOf("endsAt" to endsWall.toDouble(), "simulated" to simulated))
  }

  private fun endCountdownUi() {
    stopAlarm()
    countdownNotice = null
    countdownEndsAt = 0L
    CrashNotifications.cancel(this, CrashNotifications.ALARM_ID)
    refreshStatus()
  }

  private fun cancelCountdown() {
    val p = pending ?: return
    pending = null
    config.clearCountdown()
    detector.startCooldown(SystemClock.elapsedRealtime())
    endCountdownUi()
    CrashNotifications.show(this, CrashNotifications.RESULT_ID,
      CrashNotifications.result(this, "No alert sent", "You tapped I'm OK, so FireQuest did not send an accident alert."))
    setState(if (driving) "driving" else "idle")
    CrashEvents.emit("cancelled")
    val body = JSONObject()
      .put("p_key", config.deviceKey)
      .put("p_peak_g", p.peakG ?: JSONObject.NULL)
      .put("p_speed_kmh", p.speedKmh ?: JSONObject.NULL)
      .put("p_simulated", p.simulated)
    runInBackground {
      try { CrashApi.call(config, "log_crash_cancelled", body) } catch (e: Exception) { Log.w(TAG, "log cancel failed", e) }
    }
  }

  private fun sendAlert() {
    val p = pending ?: return
    pending = null
    sending = true
    detector.startCooldown(SystemClock.elapsedRealtime())
    endCountdownUi()
    CrashNotifications.show(this, CrashNotifications.RESULT_ID,
      CrashNotifications.result(this, "Sending accident alert…", "Sending your location to the FireQuest control room.", ongoing = true))
    setState("sending")
    CrashEvents.emit("sending")
    val phoneHint = if (config.controlRoomPhone.isNotBlank()) " Phone FireQuest on ${config.controlRoomPhone}." else ""

    runInBackground {
      var alertId: String? = null
      var refused: String? = null
      var attempt = 0
      while (alertId == null && refused == null && attempt < SEND_ATTEMPTS && running) {
        attempt++
        val fix = lastFix?.takeIf { ageMs(it) < 5 * 60_000L }
        val body = JSONObject()
          .put("p_key", config.deviceKey)
          .put("p_lat", fix?.latitude ?: JSONObject.NULL)
          .put("p_lng", fix?.longitude ?: JSONObject.NULL)
          .put("p_accuracy", fix?.takeIf { it.hasAccuracy() }?.accuracy?.toDouble() ?: JSONObject.NULL)
          .put("p_peak_g", p.peakG ?: JSONObject.NULL)
          .put("p_speed_kmh", p.speedKmh ?: JSONObject.NULL)
          .put("p_simulated", p.simulated)
        try {
          alertId = CrashApi.call(config, "raise_crash_alert", body).trim().trim('"')
        } catch (e: HttpStatusException) {
          lastError = e.message
          if (e.code == 400 || e.code == 401 || e.code == 403 || e.code == 404) {
            refused = e.message // e.g. this phone's key was switched off: retrying will not help
          } else {
            retryNotice(attempt, phoneHint)
          }
        } catch (e: Exception) {
          Log.w(TAG, "send attempt $attempt failed", e)
          lastError = e.message
          retryNotice(attempt, phoneHint)
        }
        if (alertId == null && refused == null) {
          try { Thread.sleep(SEND_RETRY_MS) } catch (_: InterruptedException) { break }
        }
      }
      val sentId = alertId
      val refusedReason = refused
      handler.post {
        sending = false
        if (sentId != null || refusedReason != null) config.clearCountdown()
        if (sentId != null) {
          followUpUntil = SystemClock.elapsedRealtime() + FOLLOW_UP_MS
          lastFollowUp = SystemClock.elapsedRealtime()
          activeUntil = followUpUntil
          CrashNotifications.show(this, CrashNotifications.RESULT_ID,
            CrashNotifications.result(this, "Accident alert sent",
              "The FireQuest control room has your location. Open FireQuest to see updates."))
          setState("sent")
          CrashEvents.emit("alertSent", mapOf("alertId" to sentId, "simulated" to p.simulated))
        } else {
          val text = if (refusedReason != null) {
            "Crash detection is switched off for this phone, so the alert was not accepted.$phoneHint Open FireQuest and switch crash detection on again."
          } else {
            "There was no connection.$phoneHint"
          }
          CrashNotifications.show(this, CrashNotifications.RESULT_ID,
            CrashNotifications.result(this, "Could not send the accident alert", text))
          setState(if (driving) "driving" else "idle")
          CrashEvents.emit("sendFailed", mapOf("error" to (lastError ?: "")))
        }
      }
    }
  }

  private fun retryNotice(attempt: Int, phoneHint: String) {
    handler.post {
      CrashNotifications.show(this, CrashNotifications.RESULT_ID,
        CrashNotifications.result(this, "Still trying to send the alert",
          "No connection yet (attempt $attempt). FireQuest keeps trying.$phoneHint", ongoing = true))
    }
  }

  private fun sendLocationUpdate(location: Location) {
    val body = JSONObject()
      .put("p_key", config.deviceKey)
      .put("p_lat", location.latitude)
      .put("p_lng", location.longitude)
      .put("p_accuracy", if (location.hasAccuracy()) location.accuracy.toDouble() else JSONObject.NULL)
    runInBackground {
      try { CrashApi.call(config, "crash_alert_location", body) } catch (e: Exception) { Log.w(TAG, "location update failed", e) }
    }
  }

  /** Network work off the main thread; ignored once the service is stopping. */
  private fun runInBackground(work: () -> Unit) {
    try {
      network.execute(work)
    } catch (e: Exception) {
      Log.w(TAG, "background work skipped", e)
    }
  }

  private fun ageMs(location: Location) =
    (SystemClock.elapsedRealtimeNanos() - location.elapsedRealtimeNanos) / 1_000_000L

  // ------------------------------------------------------------------ alarm sound + vibration

  @Suppress("DEPRECATION")
  private fun startAlarm() {
    if (ringtone != null) return
    try {
      val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
      savedAlarmVolume = audio.getStreamVolume(AudioManager.STREAM_ALARM)
      audio.setStreamVolume(AudioManager.STREAM_ALARM, audio.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0)
    } catch (e: Exception) {
      savedAlarmVolume = -1
    }
    try {
      val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
        ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
      ringtone = RingtoneManager.getRingtone(this, uri)?.apply {
        audioAttributes = AudioAttributes.Builder()
          .setUsage(AudioAttributes.USAGE_ALARM)
          .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
          .build()
        if (Build.VERSION.SDK_INT >= 28) isLooping = true
        play()
      }
    } catch (e: Exception) {
      Log.w(TAG, "alarm sound failed", e)
    }
    try {
      val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
      val pattern = longArrayOf(0, 800, 400)
      if (Build.VERSION.SDK_INT >= 26) vibrator.vibrate(VibrationEffect.createWaveform(pattern, 0)) else vibrator.vibrate(pattern, 0)
    } catch (e: Exception) {
      Log.w(TAG, "vibration failed", e)
    }
  }

  @Suppress("DEPRECATION")
  private fun stopAlarm() {
    try { ringtone?.stop() } catch (_: Exception) {}
    ringtone = null
    try { (getSystemService(Context.VIBRATOR_SERVICE) as Vibrator).cancel() } catch (_: Exception) {}
    if (savedAlarmVolume >= 0) {
      try {
        (getSystemService(Context.AUDIO_SERVICE) as AudioManager).setStreamVolume(AudioManager.STREAM_ALARM, savedAlarmVolume, 0)
      } catch (_: Exception) {}
      savedAlarmVolume = -1
    }
  }
}
