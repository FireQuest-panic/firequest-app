import { requireOptionalNativeModule } from 'expo';

/** off: switched off · idle: waiting for driving · driving: watching · countdown · sending · sent */
export type CrashState = 'off' | 'idle' | 'driving' | 'countdown' | 'sending' | 'sent';

export interface CrashStatus {
  available: boolean;
  /** Switched on in the app (settings saved on the phone). */
  enabled: boolean;
  /** The FireQuest account this phone sends crash alerts for. */
  userId: string;
  notificationsEnabled: boolean;
  /** The background service is running right now. */
  running: boolean;
  state: CrashState;
  /** End of the countdown, in milliseconds since 1970 (0 when no countdown). */
  countdownEndsAt: number;
  batteryUnrestricted: boolean;
  lastError: string | null;
}

export interface CrashEvent {
  type: 'state' | 'impact' | 'countdown' | 'cancelled' | 'sending' | 'alertSent' | 'sendFailed';
  state?: CrashState;
  endsAt?: number;
  simulated?: boolean;
  alertId?: string;
  error?: string;
  peakG?: number;
  speedKmh?: number;
}

export interface CrashStartOptions {
  supabaseUrl: string;
  supabaseKey: string;
  deviceKey: string;
  countdownSeconds: number;
  controlRoomPhone: string;
  userId: string;
}

interface CrashDetectorNative {
  getStatus(): CrashStatus;
  start(options: CrashStartOptions): Promise<CrashStatus>;
  resume(): Promise<CrashStatus>;
  /** Returns the status plus the device key that was removed. */
  stop(): Promise<CrashStatus & { deviceKey: string }>;
  simulate(): Promise<boolean>;
  imOk(): Promise<boolean>;
  sendNow(): Promise<boolean>;
  openBatterySettings(): boolean;
  openAppSettings(): boolean;
  addListener(event: 'onCrashEvent', listener: (event: CrashEvent) => void): { remove(): void };
}

/** Null when the native part is missing (web, or an app build without crash detection). */
const CrashDetector = requireOptionalNativeModule<CrashDetectorNative>('CrashDetector');
export default CrashDetector;
