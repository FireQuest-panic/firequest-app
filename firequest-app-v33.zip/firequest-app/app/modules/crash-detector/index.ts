import { requireOptionalNativeModule } from 'expo';

/** off: switched off · idle: waiting for driving · driving: watching · countdown · sending · sent */
export type CrashState = 'off' | 'idle' | 'driving' | 'countdown' | 'sending' | 'sent';

export interface CrashStatus {
  available: boolean;
  /** Switched on in the app (settings saved on the phone). */
  enabled: boolean;
  /** The FireQuest account this phone sends crash alerts for. */
  userId: string;
  notificationsEnabled: boolean;
  /** The background service is running right now. */
  running: boolean;
  state: CrashState;
  /** End of the countdown, in milliseconds since 1970 (0 when no countdown). */
  countdownEndsAt: number;
  batteryUnrestricted: boolean;
  lastError: string | null;
}

export interface CrashEvent {
  type: 'state' | 'impact' | 'countdown' | 'cancelled' | 'sending' | 'alertSent' | 'sendFailed';
  state?: CrashState;
  endsAt?: number;
  simulated?: boolean;
  alertId?: string;
  error?: string;
  peakG?: number;
  speedKmh?: number;
}

export interface CrashStartOptions {
  supabaseUrl: string;
  supabaseKey: string;
  deviceKey: string;
  countdownSeconds: number;
  controlRoomPhone: string;
  userId: string;
}

export interface ControlRoomAlarmStatus {
  available: boolean;
  /** Switched on on this phone. */
  enabled: boolean;
  userId: string;
  /** The background service is running right now. */
  running: boolean;
  /** Last successful check with FireQuest (ms since 1970, 0 = never). */
  lastPollAt: number;
  /** Alerts nobody has acknowledged yet. */
  openAlerts: number;
  notificationsEnabled: boolean;
  batteryUnrestricted: boolean;
  lastError: string | null;
  /** Android 14+: allowed to show the flashing alarm page over the lock screen. */
  fullScreenAllowed?: boolean;
}

export interface ControlRoomStartOptions {
  supabaseUrl: string;
  supabaseKey: string;
  deviceKey: string;
  userId: string;
}

/** Smoke detectors: FireQuest reading Smart Life's alarm notifications on a control-room phone. */
export interface SmokeStatus {
  /** The reader is built into this app (FireQuest Control Room only). */
  included?: boolean;
  /** Switched on under Android Settings > Notification access. */
  accessGranted: boolean;
  /** Android has the reader running right now. */
  connected: boolean;
  smartLifeInstalled: boolean;
  /** Last Smart Life detector message (ms since 1970, 0 = never). */
  lastAt: number;
  lastKind: 'alarm' | 'test' | 'other' | null;
  lastDevice: string | null;
  /** What happened with it, e.g. "Test received (Jan Botha)". */
  lastResult: string | null;
  /** Messages still waiting to reach FireQuest (no connection). */
  pending: number;
}

interface CrashDetectorNative {
  getStatus(): CrashStatus;
  start(options: CrashStartOptions): Promise<CrashStatus>;
  resume(): Promise<CrashStatus>;
  /** Returns the status plus the device key that was removed. */
  stop(): Promise<CrashStatus & { deviceKey: string }>;
  simulate(): Promise<boolean>;
  imOk(): Promise<boolean>;
  sendNow(): Promise<boolean>;
  openBatterySettings(): boolean;
  openAppSettings(): boolean;
  controlRoomStatus?(): ControlRoomAlarmStatus;
  controlRoomStart?(options: ControlRoomStartOptions): Promise<ControlRoomAlarmStatus>;
  controlRoomResume?(): Promise<ControlRoomAlarmStatus>;
  controlRoomCheckNow?(): void;
  openFullScreenSettings?(): boolean;
  smokeStatus?(): SmokeStatus;
  smokeRefresh?(): SmokeStatus;
  openNotificationAccess?(): boolean;
  controlRoomStop?(): Promise<ControlRoomAlarmStatus & { deviceKey: string }>;
  addListener(event: 'onCrashEvent', listener: (event: CrashEvent) => void): { remove(): void };
}

/** Null when the native part is missing (web, or an app build without crash detection). */
const CrashDetector = requireOptionalNativeModule<CrashDetectorNative>('CrashDetector');
export default CrashDetector;
