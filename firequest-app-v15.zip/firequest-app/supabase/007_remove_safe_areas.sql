-- =====================================================================
-- FireQuest – remove safe areas (geofences) again (decided 23 Oct)
-- Only needed for a database that ran the safe-area update (version 10).
-- * Removes the safe-area tables, functions, the every-minute job and the
--   test safe-area alerts.
-- * Puts the panic, cancel and crash-alert functions back as they were.
-- (The value 'safe_zone' stays in the alert-type list; Postgres cannot remove
-- it easily and nothing uses it.)
-- =====================================================================

do $$
begin
  if exists (select 1 from pg_extension where extname = 'pg_cron') then
    execute 'select cron.unschedule(jobid) from cron.job where jobname = ''safe-zone-due''';
  end if;
end $$;

drop trigger if exists safe_zones_member_left on public.subscription_members;

drop function if exists public.safe_areas();
drop function if exists public.safe_area_save(uuid, uuid, text, double precision, double precision, int);
drop function if exists public.safe_area_delete(uuid);
drop function if exists public.safe_area_watch(uuid, boolean);
drop function if exists public.register_safe_zone_device();
drop function if exists public.unregister_safe_zone_device(text);
drop function if exists public.safe_zone_sync(text, boolean, text, int);
drop function if exists public.safe_zone_report(text, text, double precision, double precision, real, timestamptz, text[]);
drop function if exists public.safe_zone_report(text, text, double precision, double precision, real, timestamptz);
drop function if exists private.safe_zone_due_alarms();
drop function if exists private.safe_zone_raise(uuid, double precision, double precision, real, text);
drop function if exists private.safe_zone_note(uuid, double precision, double precision);
drop function if exists private.safe_zone_phone_answer(uuid);
drop function if exists private.safe_area_person(uuid, uuid);
drop function if exists private.held_plan(uuid);
drop function if exists private.safe_zones_member_left();
drop function if exists private.distance_m(double precision, double precision, double precision, double precision);

drop table if exists public.safe_zones;
drop table if exists private.safe_zone_watch;
drop table if exists private.safe_zone_devices;

-- The test safe-area alerts (their events and locations go with them).
delete from public.alert_events where alert_id in (select id from public.alerts where type::text = 'safe_zone' or source = 'safe_zone');
delete from public.alert_locations where alert_id in (select id from public.alerts where type::text = 'safe_zone' or source = 'safe_zone');
delete from public.alerts where type::text = 'safe_zone' or source = 'safe_zone';

alter table public.alerts drop column if exists safe_zone_at;
alter table public.alerts drop constraint if exists alerts_source_check;
alter table public.alerts add constraint alerts_source_check check (source in ('button', 'crash_detection'));

-- Panic, cancel and crash alerts as before safe areas.
create or replace function public.raise_alert(
  p_type public.alert_type,
  p_lat double precision default null,
  p_lng double precision default null,
  p_accuracy real default null
) returns public.alerts
language plpgsql security definer set search_path = public as $$
declare
  v_uid   uuid := auth.uid();
  v_alert public.alerts;
begin
  if v_uid is null then raise exception 'Not signed in'; end if;

  select * into v_alert from public.alerts
   where user_id = v_uid and status not in ('closed', 'cancelled')
   order by created_at desc limit 1;

  if found then
    insert into public.alert_events (alert_id, actor_id, actor_kind, event, note)
    values (v_alert.id, v_uid, 'client', 'pressed_again', p_type::text);
  else
    insert into public.alerts (user_id, type, is_test)
    values (v_uid, p_type, (select test_mode from public.app_settings where id = 1))
    returning * into v_alert;

    insert into public.alert_events (alert_id, actor_id, actor_kind, event, note)
    values (v_alert.id, v_uid, 'client', 'raised', p_type::text);
  end if;

  if p_lat is not null and p_lng is not null then
    update public.alerts
       set lat = p_lat, lng = p_lng, accuracy_m = p_accuracy, location_updated_at = now()
     where id = v_alert.id
     returning * into v_alert;
    insert into public.alert_locations (alert_id, lat, lng, accuracy_m)
    values (v_alert.id, p_lat, p_lng, p_accuracy);
  end if;

  return v_alert;
end $$;

create or replace function public.cancel_alert(p_alert_id uuid, p_pin text)
returns boolean
language plpgsql security definer set search_path = public as $$
declare
  v_uid  uuid := auth.uid();
  v_hash text;
begin
  if not exists (
    select 1 from public.alerts
     where id = p_alert_id and user_id = v_uid and status not in ('closed', 'cancelled')
  ) then
    return false;
  end if;

  select pin_hash into v_hash from private.cancel_pins where user_id = v_uid;

  if v_hash is not null and extensions.crypt(p_pin, v_hash) = v_hash then
    update public.alerts set status = 'cancelled', cancelled_at = now() where id = p_alert_id;
    insert into public.alert_events (alert_id, actor_id, actor_kind, event)
    values (p_alert_id, v_uid, 'client', 'cancelled_by_client');
    return true;
  end if;

  insert into public.alert_events (alert_id, actor_id, actor_kind, event)
  values (p_alert_id, v_uid, 'client', 'cancel_wrong_pin');
  return false;
end $$;

create or replace function public.raise_crash_alert(
  p_key       text,
  p_lat       double precision default null,
  p_lng       double precision default null,
  p_accuracy  real default null,
  p_peak_g    real default null,
  p_speed_kmh real default null,
  p_simulated boolean default false
) returns uuid
language plpgsql security definer set search_path = public as $$
declare
  v_uid   uuid := private.crash_device_user(p_key);
  v_alert public.alerts;
  v_note  text;
begin
  if v_uid is null then
    raise exception 'Crash detection is not registered for this phone. Open FireQuest and switch it on again.';
  end if;
  update private.crash_devices set last_used_at = now()
   where key_hash = encode(extensions.digest(p_key, 'sha256'), 'hex');

  v_note := case when coalesce(p_simulated, false) then 'SIMULATED crash (test button)' else 'Crash detected by phone' end
         || coalesce(': ' || round(p_peak_g::numeric, 1) || ' g', '')
         || coalesce(' at ' || round(p_speed_kmh::numeric) || ' km/h', '');

  insert into private.crash_detections (user_id, outcome, simulated, peak_g, speed_kmh)
  values (v_uid, 'alert_sent', coalesce(p_simulated, false), p_peak_g, p_speed_kmh);

  -- Add to the client's open alert, except that a real crash never joins a TEST alert
  -- once FireQuest is live (test mode off).
  select * into v_alert from public.alerts
   where user_id = v_uid and status not in ('closed', 'cancelled')
     and (coalesce(p_simulated, false) or not is_test
          or coalesce((select test_mode from public.app_settings where id = 1), true))
   order by created_at desc limit 1;

  if not found then
    insert into public.alerts (user_id, type, is_test, source)
    values (v_uid, 'vehicle',
            coalesce((select test_mode from public.app_settings where id = 1), true) or coalesce(p_simulated, false),
            'crash_detection')
    returning * into v_alert;
    insert into public.alert_events (alert_id, actor_id, actor_kind, event, note)
    values (v_alert.id, v_uid, 'system', 'raised', 'vehicle');
  end if;
  insert into public.alert_events (alert_id, actor_id, actor_kind, event, note)
  values (v_alert.id, v_uid, 'system', 'crash_detected', v_note);

  if p_lat is not null and p_lng is not null then
    update public.alerts
       set lat = p_lat, lng = p_lng, accuracy_m = p_accuracy, location_updated_at = now()
     where id = v_alert.id;
    insert into public.alert_locations (alert_id, lat, lng, accuracy_m)
    values (v_alert.id, p_lat, p_lng, p_accuracy);
  end if;

  return v_alert.id;
end $$;
