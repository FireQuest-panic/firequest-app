-- =====================================================================
-- FireQuest – control-room alarm on staff phones, also when the app is closed
-- A FireQuest staff member switches "Alarm when the app is closed" on, on
-- their phone (Control room tab). The phone then runs a background service
-- that asks FireQuest every 20 seconds for alerts nobody has acknowledged,
-- and rings loudly until one is acknowledged. Like crash detection, the
-- service uses its own device key (no login); only a hash is stored.
-- Run after 007_remove_safe_areas.sql (or 006 on a database that never had safe areas). Also included in schema.sql.
-- =====================================================================

create table if not exists private.control_room_devices (
  key_hash     text primary key,
  user_id      uuid not null references public.profiles (id) on delete cascade,
  created_at   timestamptz not null default now(),
  last_seen_at timestamptz
);
create index if not exists control_room_devices_user_idx on private.control_room_devices (user_id);
revoke all on private.control_room_devices from public, anon, authenticated;

-- Staff, signed in: register this phone. Keeps the 3 newest phones per staff member.
create or replace function public.register_control_room_device()
returns text language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
  v_key text;
begin
  if v_uid is null or not public.is_staff() then raise exception 'Only FireQuest control-room staff can do this.'; end if;
  v_key := encode(extensions.gen_random_bytes(32), 'hex');
  insert into private.control_room_devices (key_hash, user_id, last_seen_at)
  values (encode(extensions.digest(v_key, 'sha256'), 'hex'), v_uid, now());
  delete from private.control_room_devices
   where user_id = v_uid
     and key_hash not in (select key_hash from private.control_room_devices
                           where user_id = v_uid order by created_at desc limit 3);
  return v_key;
end $$;

-- Signed in: switch off on this phone.
create or replace function public.unregister_control_room_device(p_key text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'Not signed in'; end if;
  delete from private.control_room_devices
   where user_id = auth.uid()
     and key_hash = encode(extensions.digest(coalesce(p_key, ''), 'sha256'), 'hex');
end $$;

-- Phone service (device key, no login): alerts nobody has acknowledged yet.
create or replace function public.control_room_poll(p_key text)
returns json language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid;
begin
  update private.control_room_devices d set last_seen_at = now()
   where d.key_hash = encode(extensions.digest(coalesce(p_key, ''), 'sha256'), 'hex')
     and exists (select 1 from public.staff s where s.user_id = d.user_id)
  returning d.user_id into v_uid;
  if v_uid is null then return json_build_object('registered', false); end if;
  return json_build_object(
    'registered', true,
    'alerts', coalesce((
      select json_agg(json_build_object(
               'id', a.id, 'type', a.type, 'source', a.source, 'is_test', a.is_test,
               'created_at', a.created_at, 'client', coalesce(p.full_name, 'Unknown client'))
             order by a.created_at)
        from public.alerts a
        left join public.profiles p on p.id = a.user_id
       where a.status = 'new' and a.created_at > now() - interval '24 hours'), '[]'::json));
end $$;

-- Staff, signed in: which staff phones will ring (for the Control room tab).
create or replace function public.control_room_listeners()
returns json language plpgsql stable security definer set search_path = public as $$
begin
  if not public.is_staff() then raise exception 'Not authorised'; end if;
  return coalesce((
    select json_agg(json_build_object('name', coalesce(s.display_name, p.full_name), 'last_seen_at', d.last_seen_at,
                                      'mine', d.user_id = auth.uid())
           order by d.last_seen_at desc nulls last)
      from private.control_room_devices d
      join public.staff s on s.user_id = d.user_id
      left join public.profiles p on p.id = d.user_id), '[]'::json);
end $$;

revoke execute on function
  public.register_control_room_device(),
  public.unregister_control_room_device(text),
  public.control_room_poll(text),
  public.control_room_listeners()
from public, anon;
grant execute on function
  public.register_control_room_device(),
  public.unregister_control_room_device(text),
  public.control_room_listeners()
to authenticated;
-- The phone service calls this without a login; the device key is the proof.
grant execute on function public.control_room_poll(text) to anon, authenticated;
