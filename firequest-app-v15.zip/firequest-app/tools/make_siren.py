import numpy as np
from scipy import signal
from scipy.io import wavfile
sr = 44100

def wail_curve(n, lo, hi):
    # Electronic wail: rises quickly (motor spin-up feel), lingers at the top, falls more slowly.
    x = np.linspace(0, 1, n, endpoint=False)
    up = 0.38
    k = np.where(x < up, np.sin(0.5 * np.pi * x / up), np.cos(0.5 * np.pi * (x - up) / (1 - up)) ** 1.6)
    return lo + (hi - lo) * k

def yelp_curve(n, lo, hi, cycles):
    x = (np.arange(n) / n * cycles) % 1.0
    k = np.where(x < 0.5, x / 0.5, 1 - (x - 0.5) / 0.5)
    k = 0.5 - 0.5 * np.cos(np.pi * k)
    return lo + (hi - lo) * k

# One loop: wail, wail, yelp (like a South African ambulance / police cycle).
wail_s, yelp_s = 4.2, 4.0
f = np.concatenate([
    wail_curve(int(sr * wail_s), 620, 1380),
    wail_curve(int(sr * wail_s), 620, 1380),
    yelp_curve(int(sr * yelp_s), 640, 1420, cycles=13),
])
# Smooth the joins between sections.
f = signal.savgol_filter(f, 801, 2)
# Whole number of periods per loop, so it repeats without a click.
total = f.sum() / sr
f *= round(total) / total
phase = 2 * np.pi * np.cumsum(f) / sr

# Electronic siren drivers make a harsh, square-ish tone (odd harmonics, a little even).
tone = np.zeros_like(phase)
for h, a in [(1, 1.0), (2, 0.12), (3, 0.42), (4, 0.06), (5, 0.24), (7, 0.13), (9, 0.07), (11, 0.04)]:
    tone += a * np.sin(h * phase)
# Horn loudspeaker: strong between ~700 Hz and 4 kHz, little bass.
loop = np.tile(tone, 2)  # filter two loops and keep the second: steady state, no click at the joint
b, a = signal.butter(2, [550, 4200], btype='bandpass', fs=sr)
loop = signal.lfilter(b, a, loop)
# Horn resonance around 2.2 kHz.
b2, a2 = signal.iirpeak(2200, 2.5, fs=sr)
loop = loop + 0.35 * signal.lfilter(b2, a2, loop)
# Driven hard: soft clipping, as in a real amplifier/horn.
loop = np.tanh(2.2 * loop / np.max(np.abs(loop)))
one = loop[len(tone):]
n = len(one)
# Street echoes (buildings) – circular, so the loop stays seamless.
out = one.copy()
for delay_ms, gain in [(37, 0.32), (83, 0.22), (151, 0.14), (243, 0.09), (390, 0.05)]:
    out += gain * np.roll(one, int(sr * delay_ms / 1000))
# A slow, slight level wobble (the sound moving a little), whole cycles per loop.
wob_cycles = 3
out *= 1 - 0.08 * (0.5 + 0.5 * np.sin(2 * np.pi * wob_cycles * np.arange(n) / n))
out = out / np.max(np.abs(out)) * 0.97
wavfile.write('siren2.wav', sr, (out * 32767).astype(np.int16))
print(n / sr, 'seconds; joint step:', abs(out[0] - out[-1]))
