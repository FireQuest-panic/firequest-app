package za.co.firequest.crash

import android.app.Activity
import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Full-screen alarm page for the control room: turns the screen on at full brightness, shows
 * over the lock screen and flashes red / white while the siren sounds. Closes by itself when
 * the alert is acknowledged (the siren stops).
 */
class ControlRoomAlarmActivity : Activity() {
  private val handler = Handler(Looper.getMainLooper())
  private lateinit var root: LinearLayout
  private lateinit var titleView: TextView
  private lateinit var textView: TextView
  private var bright = false

  @Suppress("DEPRECATION")
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    if (Build.VERSION.SDK_INT >= 27) {
      setShowWhenLocked(true)
      setTurnScreenOn(true)
    } else {
      window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON)
    }
    window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    // Full brightness while this page is showing.
    window.attributes = window.attributes.apply { screenBrightness = 1f }

    val pad = (24 * resources.displayMetrics.density).toInt()
    root = LinearLayout(this).apply {
      orientation = LinearLayout.VERTICAL
      gravity = Gravity.CENTER
      setPadding(pad, pad, pad, pad)
    }
    titleView = TextView(this).apply {
      textSize = 30f
      typeface = Typeface.DEFAULT_BOLD
      gravity = Gravity.CENTER
    }
    textView = TextView(this).apply {
      textSize = 20f
      gravity = Gravity.CENTER
      setPadding(0, pad / 2, 0, pad)
    }
    val open = Button(this).apply {
      text = "OPEN FIREQUEST"
      textSize = 20f
      setOnClickListener {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        if (launch != null) {
          launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
          // Ask to unlock first if the phone is locked, then open FireQuest.
          val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
          if (Build.VERSION.SDK_INT >= 26 && km.isKeyguardLocked) {
            km.requestDismissKeyguard(this@ControlRoomAlarmActivity, object : KeyguardManager.KeyguardDismissCallback() {
              override fun onDismissSucceeded() {
                startActivity(launch)
                finish()
              }
            })
          } else {
            startActivity(launch)
            finish()
          }
        }
      }
    }
    val silence = Button(this).apply {
      text = "SILENCE 2 MIN"
      textSize = 16f
      setOnClickListener {
        val i = Intent(this@ControlRoomAlarmActivity, ControlRoomAlarmService::class.java)
          .setAction(ControlRoomAlarmService.ACTION_SILENCE)
        try {
          if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        } catch (_: Exception) {
        }
        finish()
      }
    }
    root.addView(titleView)
    root.addView(textView)
    root.addView(open, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
    root.addView(silence, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
      topMargin = pad / 2
    })
    setContentView(root)
    handler.post(tick)
  }

  /** Flashes the screen twice a second and closes the page once the siren has stopped. */
  private val tick: Runnable = object : Runnable {
    override fun run() {
      if (!ControlRoomAlarmService.sounding) {
        finish()
        return
      }
      bright = !bright
      root.setBackgroundColor(if (bright) Color.WHITE else Color.rgb(212, 47, 53))
      val fg = if (bright) Color.rgb(212, 47, 53) else Color.WHITE
      titleView.setTextColor(fg)
      textView.setTextColor(fg)
      titleView.text = ControlRoomAlarmService.alarmTitle.ifBlank { "NEW ALERT" }
      textView.text = ControlRoomAlarmService.alarmText
      handler.postDelayed(this, 500)
    }
  }

  override fun onDestroy() {
    handler.removeCallbacksAndMessages(null)
    super.onDestroy()
  }
}
