package za.co.firequest.crash

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Starts crash detection and the control-room alarm again after the phone restarts or FireQuest is updated. */
class CrashBootReceiver : BroadcastReceiver() {
  override fun onReceive(context: Context, intent: Intent) {
    val action = intent.action ?: return
    if (action != Intent.ACTION_BOOT_COMPLETED && action != Intent.ACTION_MY_PACKAGE_REPLACED) return
    // Control room: keep ringing for new alerts after a restart.
    if (ControlRoomConfig(context).isComplete) {
      ControlRoomAlarmService.start(context.applicationContext)
      ControlRoomAlarmService.scheduleWatchdog(context.applicationContext)
    }
    if (!CrashConfig(context).isComplete) return
    CrashDetectionService.start(context, CrashDetectionService.ACTION_START, fromBackground = true)
  }
}
