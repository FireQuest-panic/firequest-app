package za.co.firequest.crash

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.os.VibrationAttributes
import android.os.VibrationEffect
import android.os.Vibrator
import android.util.Log
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequest
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/** Settings for the control-room alarm on a staff phone. */
class ControlRoomConfig(context: Context) {
  private val prefs = context.applicationContext.getSharedPreferences("firequest_control_room", Context.MODE_PRIVATE)
  val supabaseUrl: String get() = prefs.getString("supabaseUrl", "") ?: ""
  val supabaseKey: String get() = prefs.getString("supabaseKey", "") ?: ""
  val deviceKey: String get() = prefs.getString("deviceKey", "") ?: ""
  val userId: String get() = prefs.getString("userId", "") ?: ""
  val isComplete: Boolean get() = supabaseUrl.isNotBlank() && supabaseKey.isNotBlank() && deviceKey.isNotBlank()

  fun save(url: String, key: String, deviceKey: String, userId: String) {
    prefs.edit().putString("supabaseUrl", url.trim()).putString("supabaseKey", key.trim())
      .putString("deviceKey", deviceKey.trim()).putString("userId", userId.trim()).apply()
  }

  fun clear() {
    prefs.edit().clear().apply()
  }
}

/**
 * Control-room alarm: while switched on, this service asks FireQuest every 20 seconds for
 * alerts nobody has acknowledged, also when the app is closed. When there is one, the phone
 * sounds a loud siren (alarm volume) and shows the alert until someone acknowledges it.
 * "Silence 2 min" stops the sound for two minutes only.
 */
class ControlRoomAlarmService : Service() {
  companion object {
    private const val TAG = "FireQuestControlRoom"
    const val ACTION_START = "za.co.firequest.crash.CONTROL_ROOM_START"
    const val ACTION_SILENCE = "za.co.firequest.crash.CONTROL_ROOM_SILENCE"
    /** Check FireQuest straight away (e.g. right after an alert was acknowledged in the app). */
    const val ACTION_CHECK = "za.co.firequest.crash.CONTROL_ROOM_CHECK"
    private const val STATUS_ID = 4301
    private const val ALARM_ID = 4302
    private const val CHANNEL_STATUS = "fq_control_room_status"
    private const val CHANNEL_ALARM = "fq_control_room_alarm"
    private const val POLL_MS = 20_000L
    /** While the siren is sounding: check often, so it stops soon after someone acknowledges (also on the computer). */
    private const val POLL_RINGING_MS = 5_000L
    private const val SILENCE_MS = 2 * 60_000L
    private const val WORK = "fq_control_room_watchdog"

    @Volatile var running = false
      private set
    @Volatile var lastPollAt = 0L
      private set
    @Volatile var lastError: String? = null
      private set
    @Volatile var openAlerts = 0
      private set
    /** The siren is sounding right now (the alarm screen closes when it stops). */
    @Volatile var sounding = false
      private set
    @Volatile var alarmTitle = ""
      private set
    @Volatile var alarmText = ""
      private set

    fun start(context: Context): Boolean {
      if (!ControlRoomConfig(context).isComplete) return false
      val intent = Intent(context, ControlRoomAlarmService::class.java).setAction(ACTION_START)
      return try {
        if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(intent) else context.startService(intent)
        true
      } catch (e: Exception) {
        lastError = "Could not start: ${e.message}"
        Log.w(TAG, "start failed", e)
        false
      }
    }

    /** Asks the running service to check now. Does nothing when it is not running. */
    fun requestCheck(context: Context) {
      if (!running) return
      try {
        val intent = Intent(context, ControlRoomAlarmService::class.java).setAction(ACTION_CHECK)
        if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(intent) else context.startService(intent)
      } catch (e: Exception) {
        Log.w(TAG, "check now failed", e)
      }
    }

    fun stop(context: Context) {
      context.stopService(Intent(context, ControlRoomAlarmService::class.java))
      try { WorkManager.getInstance(context).cancelUniqueWork(WORK) } catch (_: Exception) {}
    }

    /** Every 15 minutes: start the service again if Android stopped it. */
    fun scheduleWatchdog(context: Context) {
      try {
        val req = PeriodicWorkRequest.Builder(ControlRoomWatchdog::class.java, 15, TimeUnit.MINUTES).build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(WORK, ExistingPeriodicWorkPolicy.KEEP, req)
      } catch (e: Exception) {
        Log.w(TAG, "watchdog not scheduled", e)
      }
    }

    fun status(context: Context): Map<String, Any?> {
      val config = ControlRoomConfig(context)
      val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
      val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
      return mapOf(
        "available" to true,
        "enabled" to config.isComplete,
        "userId" to config.userId,
        "running" to running,
        "lastPollAt" to lastPollAt.toDouble(),
        "openAlerts" to openAlerts,
        "notificationsEnabled" to nm.areNotificationsEnabled(),
        "batteryUnrestricted" to pm.isIgnoringBatteryOptimizations(context.packageName),
        "lastError" to lastError,
        // Android 14+: may this phone show the alarm screen over the lock screen?
        "fullScreenAllowed" to (Build.VERSION.SDK_INT < 34 || nm.canUseFullScreenIntent()),
      )
    }
  }

  private val handler = Handler(Looper.getMainLooper())
  private val network = Executors.newSingleThreadExecutor()
  private var wakeLock: PowerManager.WakeLock? = null
  private var siren: MediaPlayer? = null
  private var screenLock: PowerManager.WakeLock? = null
  private var savedAlarmVolume = -1
  private var silencedUntil = 0L
  private val alerted = HashSet<String>()
  private var polling = false

  override fun onBind(intent: Intent?): IBinder? = null

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    if (!ControlRoomConfig(this).isComplete) {
      stopSelf()
      return START_NOT_STICKY
    }
    createChannels()
    try {
      val n = statusNotification("Listening for new alerts. Keep this phone on the charger.")
      if (Build.VERSION.SDK_INT >= 34) startForeground(STATUS_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
      else startForeground(STATUS_ID, n)
    } catch (e: Exception) {
      lastError = "Could not start: ${e.message}"
      Log.w(TAG, "startForeground failed", e)
      stopSelf()
      return START_NOT_STICKY
    }
    if (intent?.action == ACTION_SILENCE) {
      silencedUntil = SystemClock.elapsedRealtime() + SILENCE_MS
      stopSound()
    }
    if (!running) {
      running = true
      lastError = null
      scheduleWatchdog(this)
      handler.post(poll)
    } else if (intent?.action == ACTION_CHECK) {
      handler.removeCallbacks(poll)
      handler.post(poll)
    }
    // Restarted by Android after being stopped (START_STICKY).
    return START_STICKY
  }

  override fun onDestroy() {
    running = false
    handler.removeCallbacksAndMessages(null)
    stopSound()
    cancel(ALARM_ID)
    try { wakeLock?.release() } catch (_: Exception) {}
    network.shutdown()
    super.onDestroy()
  }

  private val poll: Runnable = object : Runnable {
    override fun run() {
      if (!running) return
      keepAwake()
      if (!polling) {
        polling = true
        try {
          network.execute { checkNow() }
        } catch (e: Exception) {
          polling = false
        }
      }
      handler.postDelayed(this, if (openAlerts > 0) POLL_RINGING_MS else POLL_MS)
    }
  }

  private fun keepAwake() {
    // Checking every 20 seconds needs the phone to stay awake (it should be on the charger).
    try {
      if (wakeLock == null) {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "FireQuest:ControlRoom").apply { setReferenceCounted(false) }
      }
      wakeLock?.acquire(2 * 60_000L)
    } catch (e: Exception) {
      Log.w(TAG, "wake lock failed", e)
    }
  }

  private fun checkNow() {
    val config = ControlRoomConfig(this)
    try {
      val answer = JSONObject(
        CrashApi.call(config.supabaseUrl, config.supabaseKey, "control_room_poll", JSONObject().put("p_key", config.deviceKey))
      )
      lastPollAt = System.currentTimeMillis()
      if (!answer.optBoolean("registered", false)) {
        lastError = "This phone is no longer registered (or you are no longer control-room staff). Switch it on again in the app."
        config.clear()
        handler.post { stopSelf() }
        return
      }
      lastError = null
      val alerts = answer.optJSONArray("alerts") ?: JSONArray()
      handler.post { show(alerts) }
    } catch (e: Exception) {
      lastError = "No connection to FireQuest – alerts cannot arrive on this phone right now"
      Log.w(TAG, "poll failed", e)
      handler.post { showStatus("NO CONNECTION to FireQuest. New alerts cannot arrive on this phone.") }
    } finally {
      polling = false
    }
  }

  private fun show(alerts: JSONArray) {
    openAlerts = alerts.length()
    if (alerts.length() == 0) {
      alerted.clear()
      stopSound()
      cancel(ALARM_ID)
      silencedUntil = 0L
      showStatus("Listening for new alerts. Keep this phone on the charger.")
      return
    }
    val newest = alerts.getJSONObject(alerts.length() - 1)
    var fresh = false
    for (i in 0 until alerts.length()) if (alerted.add(alerts.getJSONObject(i).getString("id"))) fresh = true
    if (fresh) silencedUntil = 0L // a new alert always rings, even after "Silence"
    val title = (if (alerts.length() > 1) "${alerts.length()} NEW ALERTS – " else "NEW ALERT – ") + label(newest)
    val text = "${newest.optString("client", "Client")}${if (newest.optBoolean("is_test", false)) " (TEST)" else ""}. Open FireQuest and acknowledge."
    alarmTitle = title
    alarmText = text
    show(ALARM_ID, alarmNotification(title, text))
    showStatus("$title – not acknowledged yet")
    if (SystemClock.elapsedRealtime() >= silencedUntil) {
      startSound()
      lightUpScreen()
      if (fresh) openAlarmScreen()
    }
  }

  /** Turns the screen on (and keeps it on while the siren sounds, even if someone switches it off). */
  @Suppress("DEPRECATION")
  private fun lightUpScreen() {
    try {
      if (screenLock == null) {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        screenLock = pm.newWakeLock(
          PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP or PowerManager.ON_AFTER_RELEASE,
          "FireQuest:ControlRoomScreen",
        ).apply { setReferenceCounted(false) }
      }
      // Re-acquired at every check while ringing: wakes the screen again if it was switched off.
      screenLock?.release()
      screenLock?.acquire(15_000L)
    } catch (e: Exception) {
      Log.w(TAG, "screen wake failed", e)
    }
  }

  /** The full-screen alarm page (bright flashing screen over the lock screen). */
  private fun openAlarmScreen() {
    try {
      startActivity(
        Intent(this, ControlRoomAlarmActivity::class.java)
          .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
      )
    } catch (e: Exception) {
      // Android may block this from the background; the full-screen notification opens it instead.
      Log.w(TAG, "alarm screen not opened directly", e)
    }
  }

  private fun label(a: JSONObject): String {
    val source = a.optString("source", "")
    return when {
      source == "crash_detection" -> "AUTO-DETECTED CRASH"
      a.optString("type") == "medical" -> "MEDICAL"
      a.optString("type") == "vehicle" -> "VEHICLE ACCIDENT"
      a.optString("type") == "fire" -> "FIRE & RESCUE"
      else -> a.optString("type", "ALERT").uppercase()
    }
  }

  // ------------------------------------------------------------------ notifications

  private fun createChannels() {
    if (Build.VERSION.SDK_INT < 26) return
    val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    nm.createNotificationChannel(
      NotificationChannel(CHANNEL_STATUS, "Control room listening", NotificationManager.IMPORTANCE_LOW).apply {
        description = "Shown while this phone listens for new FireQuest alerts."
        setShowBadge(false)
      }
    )
    nm.createNotificationChannel(
      NotificationChannel(CHANNEL_ALARM, "New alerts (control room)", NotificationManager.IMPORTANCE_HIGH).apply {
        description = "A new FireQuest alert that nobody has acknowledged yet."
        setSound(null, null) // the service plays the alarm sound itself
        enableVibration(false)
        lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        setBypassDnd(true)
      }
    )
  }

  private fun builder(channel: String): Notification.Builder {
    val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, channel) else Notification.Builder(this)
    b.setSmallIcon(R.drawable.ic_fq_crash).setColor(0xFFD42F35.toInt())
    CrashNotifications.openApp(this, 31)?.let { b.setContentIntent(it) }
    return b
  }

  private fun statusNotification(text: String): Notification =
    builder(CHANNEL_STATUS)
      .setContentTitle("FireQuest control room")
      .setContentText(text)
      .setStyle(Notification.BigTextStyle().bigText(text))
      .setOngoing(true)
      .setShowWhen(false)
      .setCategory(Notification.CATEGORY_SERVICE)
      .build()

  private fun showStatus(text: String) = show(STATUS_ID, statusNotification(text))

  private fun alarmNotification(title: String, text: String): Notification {
    val silenceIntent = Intent(this, ControlRoomAlarmService::class.java).setAction(ACTION_SILENCE)
    val silence = if (Build.VERSION.SDK_INT >= 26) {
      PendingIntent.getForegroundService(this, 32, silenceIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    } else {
      PendingIntent.getService(this, 32, silenceIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }
    val b = builder(CHANNEL_ALARM)
      .setContentTitle(title)
      .setContentText(text)
      .setStyle(Notification.BigTextStyle().bigText(text))
      .setOngoing(true)
      .setAutoCancel(false)
      .setCategory(Notification.CATEGORY_ALARM)
      .setPriority(Notification.PRIORITY_MAX)
      .setVisibility(Notification.VISIBILITY_PUBLIC)
      .addAction(Notification.Action.Builder(null, "SILENCE 2 MIN", silence).build())
    // Full-screen: opens the flashing alarm page over the lock screen and turns the screen on.
    val alarmPage = Intent(this, ControlRoomAlarmActivity::class.java)
      .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
    b.setFullScreenIntent(
      PendingIntent.getActivity(this, 33, alarmPage, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE),
      true,
    )
    return b.build()
  }

  private fun show(id: Int, n: Notification) {
    try {
      (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(id, n)
    } catch (_: SecurityException) {
      // notifications switched off: the sound still plays
    }
  }

  private fun cancel(id: Int) {
    (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(id)
  }

  // ------------------------------------------------------------------ sound

  @Suppress("DEPRECATION")
  private fun startSound() {
    if (siren?.isPlaying == true) return
    try {
      val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
      if (savedAlarmVolume < 0) savedAlarmVolume = audio.getStreamVolume(AudioManager.STREAM_ALARM)
      audio.setStreamVolume(AudioManager.STREAM_ALARM, audio.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0)
    } catch (_: Exception) {
    }
    val attributes = AudioAttributes.Builder()
      .setUsage(AudioAttributes.USAGE_ALARM)
      .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
      .build()
    // FireQuest's own siren (res/raw/fq_siren.ogg) on the alarm volume, over and over.
    val sirenUri = Uri.parse("android.resource://$packageName/${R.raw.fq_siren}")
    val fallbackUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
    for (uri in listOfNotNull(sirenUri, fallbackUri)) {
      try {
        siren = MediaPlayer().apply {
          setAudioAttributes(attributes)
          setDataSource(this@ControlRoomAlarmService, uri)
          isLooping = true
          prepare()
          start()
        }
        break
      } catch (e: Exception) {
        Log.w(TAG, "siren failed for $uri", e)
        try { siren?.release() } catch (_: Exception) {}
        siren = null
      }
    }
    sounding = true
    startVibration()
  }

  /** Strong, long vibration, marked as an alarm so Android does not mute it in the background. */
  @Suppress("DEPRECATION")
  private fun startVibration() {
    try {
      val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
      val timings = longArrayOf(0, 1000, 300, 1000, 300)
      if (Build.VERSION.SDK_INT >= 26) {
        val amplitudes = intArrayOf(0, 255, 0, 255, 0)
        val effect = VibrationEffect.createWaveform(timings, amplitudes, 1)
        if (Build.VERSION.SDK_INT >= 33) {
          vibrator.vibrate(effect, VibrationAttributes.createForUsage(VibrationAttributes.USAGE_ALARM))
        } else {
          val attrs = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
          vibrator.vibrate(effect, attrs)
        }
      } else {
        vibrator.vibrate(timings, 1)
      }
    } catch (e: Exception) {
      Log.w(TAG, "vibration failed", e)
    }
  }

  private fun stopSound() {
    sounding = false
    try { screenLock?.release() } catch (_: Exception) {}
    try { siren?.stop() } catch (_: Exception) {}
    try { siren?.release() } catch (_: Exception) {}
    siren = null
    try { (getSystemService(Context.VIBRATOR_SERVICE) as Vibrator).cancel() } catch (_: Exception) {}
    if (savedAlarmVolume >= 0) {
      try {
        (getSystemService(Context.AUDIO_SERVICE) as AudioManager).setStreamVolume(AudioManager.STREAM_ALARM, savedAlarmVolume, 0)
      } catch (_: Exception) {}
      savedAlarmVolume = -1
    }
  }
}

/** Starts the control-room alarm again if Android stopped it. */
class ControlRoomWatchdog(context: Context, params: WorkerParameters) : Worker(context, params) {
  override fun doWork(): Result {
    if (ControlRoomConfig(applicationContext).isComplete && !ControlRoomAlarmService.running) {
      ControlRoomAlarmService.start(applicationContext)
    }
    return Result.success()
  }
}
