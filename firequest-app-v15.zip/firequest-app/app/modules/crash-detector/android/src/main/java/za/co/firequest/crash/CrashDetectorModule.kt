package za.co.firequest.crash

import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition

/** JavaScript bridge: `requireNativeModule('CrashDetector')`. */
class CrashDetectorModule : Module() {
  private val context: Context
    get() = requireNotNull(appContext.reactContext) { "The app is not ready yet" }.applicationContext

  override fun definition() = ModuleDefinition {
    Name("CrashDetector")
    Events("onCrashEvent")

    OnCreate {
      CrashEvents.listener = { body -> sendEvent("onCrashEvent", body) }
      removeOldSafeAreas()
    }
    OnDestroy {
      CrashEvents.listener = null
    }

    Function("getStatus") {
      status()
    }

    /** Saves the settings and starts the service. Called from the app (in the foreground). */
    AsyncFunction("start") { options: Map<String, Any?> ->
      val url = options["supabaseUrl"] as? String ?: ""
      val key = options["supabaseKey"] as? String ?: ""
      val deviceKey = options["deviceKey"] as? String ?: ""
      val seconds = (options["countdownSeconds"] as? Number)?.toInt() ?: 30
      val phone = options["controlRoomPhone"] as? String ?: ""
      val userId = options["userId"] as? String ?: ""
      require(url.isNotBlank() && key.isNotBlank() && deviceKey.isNotBlank()) { "Missing crash detection settings" }
      CrashConfig(context).save(url, key, deviceKey, seconds, phone, userId)
      CrashDetectionService.clearError()
      CrashDetectionService.start(context)
      status()
    }

    /** Starts the service again if it was switched on before (e.g. after it was stopped). */
    AsyncFunction("resume") {
      if (CrashConfig(context).isComplete && !CrashDetectionService.running) CrashDetectionService.start(context)
      status()
    }

    /** Switches off on this phone. Returns the old device key so the app can delete it from the database. */
    AsyncFunction("stop") {
      val config = CrashConfig(context)
      val oldKey = config.deviceKey
      config.clear()
      CrashDetectionService.stop(context)
      status() + ("deviceKey" to oldKey)
    }

    AsyncFunction("simulate") {
      CrashDetectionService.start(context, CrashDetectionService.ACTION_SIMULATE)
    }

    AsyncFunction("imOk") {
      CrashDetectionService.start(context, CrashDetectionService.ACTION_IM_OK)
    }

    AsyncFunction("sendNow") {
      CrashDetectionService.start(context, CrashDetectionService.ACTION_SEND_NOW)
    }

    // ---------------------------------------------------------------- control-room alarm

    Function("controlRoomStatus") {
      ControlRoomAlarmService.status(context)
    }

    AsyncFunction("controlRoomStart") { options: Map<String, Any?> ->
      val url = options["supabaseUrl"] as? String ?: ""
      val key = options["supabaseKey"] as? String ?: ""
      val deviceKey = options["deviceKey"] as? String ?: ""
      val userId = options["userId"] as? String ?: ""
      require(url.isNotBlank() && key.isNotBlank() && deviceKey.isNotBlank()) { "Missing control-room settings" }
      ControlRoomConfig(context).save(url, key, deviceKey, userId)
      ControlRoomAlarmService.start(context)
      ControlRoomAlarmService.status(context)
    }

    /** Starts the service again if it was switched on before. */
    AsyncFunction("controlRoomResume") {
      if (ControlRoomConfig(context).isComplete && !ControlRoomAlarmService.running) ControlRoomAlarmService.start(context)
      ControlRoomAlarmService.status(context)
    }

    /** Check FireQuest now (after an alert was acknowledged), so the siren stops straight away. */
    Function("controlRoomCheckNow") {
      ControlRoomAlarmService.requestCheck(context)
    }

    /** Android 14+: the setting that lets the alarm page show over the lock screen. */
    Function("openFullScreenSettings") {
      val attempts = if (Build.VERSION.SDK_INT >= 34) listOf(
        Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:${context.packageName}")),
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}")),
      ) else listOf(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}")))
      attempts.any { intent ->
        try {
          context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
          true
        } catch (_: Exception) {
          false
        }
      }
    }

    AsyncFunction("controlRoomStop") {
      val config = ControlRoomConfig(context)
      val oldKey = config.deviceKey
      config.clear()
      ControlRoomAlarmService.stop(context)
      ControlRoomAlarmService.status(context) + ("deviceKey" to oldKey)
    }

    /** Asks Android to let FireQuest run without battery restrictions. */
    Function("openBatterySettings") {
      val pkg = context.packageName
      val attempts = listOf(
        Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$pkg")),
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg")),
      )
      attempts.any { intent ->
        try {
          context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
          true
        } catch (_: Exception) {
          false
        }
      }
    }

    Function("openAppSettings") {
      try {
        context.startActivity(
          Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        true
      } catch (_: Exception) {
        false
      }
    }
  }

  /** Safe areas were removed (version 13): clear what version 10 left on this phone. */
  private fun removeOldSafeAreas() {
    try {
      val ctx = appContext.reactContext?.applicationContext ?: return
      val prefs = ctx.getSharedPreferences("firequest_safe_zones", Context.MODE_PRIVATE)
      if (prefs.all.isEmpty()) return
      prefs.edit().clear().apply()
      val wm = androidx.work.WorkManager.getInstance(ctx)
      wm.cancelUniqueWork("fq_safe_zone_sync")
      wm.cancelUniqueWork("fq_safe_zone_retry")
    } catch (_: Exception) {
    }
  }

  private fun status(): Map<String, Any?> {
    val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
    val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    val config = CrashConfig(context)
    return mapOf(
      "available" to true,
      "enabled" to config.isComplete,
      "userId" to config.userId,
      "notificationsEnabled" to nm.areNotificationsEnabled(),
      "running" to CrashDetectionService.running,
      "state" to CrashDetectionService.state,
      "countdownEndsAt" to CrashDetectionService.countdownEndsAt.toDouble(),
      "batteryUnrestricted" to pm.isIgnoringBatteryOptimizations(context.packageName),
      "lastError" to CrashDetectionService.lastError,
    )
  }
}
