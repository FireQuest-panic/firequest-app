// Control-room alarm on staff phones: a background service (app/modules/crash-detector,
// Android) that rings for new alerts also when FireQuest is closed.
import { Alert, PermissionsAndroid, Platform } from 'react-native';
import CrashDetector, { ControlRoomAlarmStatus } from '../../modules/crash-detector';
import config from '../config.json';
import { supabase } from './supabase';

export type { ControlRoomAlarmStatus };

export const controlRoomAlarmSupported =
  Platform.OS === 'android' && typeof CrashDetector?.controlRoomStatus === 'function';

export function alarmStatus(): ControlRoomAlarmStatus | null {
  try {
    return CrashDetector?.controlRoomStatus ? CrashDetector.controlRoomStatus() : null;
  } catch {
    return null;
  }
}

export interface Listener {
  name: string | null;
  last_seen_at: string | null;
  mine: boolean;
}

/** Staff phones that will ring (null while the database has no control-room alarm yet). */
export async function listeners(): Promise<Listener[] | null> {
  const { data, error } = await supabase.rpc('control_room_listeners');
  if (error) return null;
  return (data as Listener[]) ?? [];
}

function ask(title: string, message: string, ok: string): Promise<boolean> {
  return new Promise((resolve) =>
    Alert.alert(title, message, [
      { text: 'Not now', style: 'cancel', onPress: () => resolve(false) },
      { text: ok, onPress: () => resolve(true) },
    ]),
  );
}

/** Asks for notifications and battery, registers this phone and starts listening. */
export async function switchOnAlarm(userId: string): Promise<{ ok: boolean; message?: string }> {
  if (!controlRoomAlarmSupported || !CrashDetector?.controlRoomStart) {
    return { ok: false, message: 'This version of FireQuest cannot do this. Install the newest version.' };
  }
  if (Number(Platform.Version) >= 33) {
    const r = await PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.POST_NOTIFICATIONS);
    if (r !== PermissionsAndroid.RESULTS.GRANTED) {
      return { ok: false, message: 'Allow notifications for FireQuest, so new alerts can show on this phone.' };
    }
  }
  try {
    if (!CrashDetector.getStatus().batteryUnrestricted) {
      const go = await ask(
        'Battery setting',
        'So Android never stops the alarm, allow FireQuest to run without battery restrictions (tap Allow on the next screen).',
        'Open setting',
      );
      if (go) CrashDetector.openBatterySettings();
    }
  } catch {
    // not available
  }
  try {
    if (CrashDetector.controlRoomStatus?.().fullScreenAllowed === false) {
      const go = await ask(
        'Light up the screen',
        'So the screen lights up and flashes when an alert comes in, allow FireQuest to show full-screen notifications (switch it on, on the next screen).',
        'Open setting',
      );
      if (go) CrashDetector.openFullScreenSettings?.();
    }
  } catch {
    // older Android: always allowed
  }
  try {
    const old = await CrashDetector.controlRoomStop?.();
    if (old?.deviceKey) await supabase.rpc('unregister_control_room_device', { p_key: old.deviceKey });
  } catch {
    // nothing to remove
  }
  const { data, error } = await supabase.rpc('register_control_room_device');
  if (error) throw error;
  await CrashDetector.controlRoomStart({
    supabaseUrl: config.supabaseUrl,
    supabaseKey: config.supabaseKey,
    deviceKey: String(data),
    userId,
  });
  for (let i = 0; i < 12; i++) {
    const s = alarmStatus();
    if (s?.running) return { ok: true };
    if (s?.lastError) return { ok: false, message: s.lastError };
    await new Promise((r) => setTimeout(r, 250));
  }
  return { ok: true };
}

export async function switchOffAlarm(): Promise<void> {
  let deviceKey = '';
  try {
    deviceKey = (await CrashDetector?.controlRoomStop?.())?.deviceKey ?? '';
  } catch {
    // already off
  }
  if (!deviceKey) return;
  try {
    await supabase.rpc('unregister_control_room_device', { p_key: deviceKey });
  } catch {
    // offline
  }
}

/** Android 14+: setting that lets the flashing alarm page light up the screen over the lock screen. */
export function openFullScreenSettings(): void {
  try {
    CrashDetector?.openFullScreenSettings?.();
  } catch {
    // older app build
  }
}

/** After an alert was acknowledged (or changed) in the app: the background siren checks at once and stops. */
export function alarmCheckNow(): void {
  try {
    CrashDetector?.controlRoomCheckNow?.();
  } catch {
    // older app build
  }
}

/** When someone signs in: keep the alarm running for them, or switch it off if it was someone else's. */
export async function resumeAlarm(userId: string): Promise<void> {
  try {
    const s = alarmStatus();
    if (!s?.enabled) return;
    if (s.userId && s.userId !== userId) {
      await switchOffAlarm();
      return;
    }
    await CrashDetector?.controlRoomResume?.();
  } catch {
    // shown on the card
  }
}
