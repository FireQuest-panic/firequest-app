import React, { useCallback, useEffect, useState } from 'react';
import { ActivityIndicator, Text, View } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { colors } from '../theme';
import { MyReferral, STATE_TEXT, applySignupCode, cleanCode, getMyReferral, shareReferral, redeemReferralCode } from '../lib/referral';
import { Body, Button, Card, ErrorText, Field } from './ui';

const STATE_COLOR = {
  waiting: colors.muted,
  paid_once: colors.goldText,
  counted: colors.green,
  too_late: colors.muted,
  rejected: colors.danger,
};

/** Account screen: "Refer 2 households, keep R49 for 2027". Plan holders only. */
export function ReferralCard({ version }: { version: number }) {
  const [info, setInfo] = useState<MyReferral | null>(null);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [entering, setEntering] = useState(false);
  const [code, setCode] = useState('');
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    try {
      const msg = await applySignupCode();
      if (msg) setNotice(msg);
      setInfo(await getMyReferral());
    } catch (e) {
      setError((e as Error).message);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load, version]);

  const save = async () => {
    setError('');
    setBusy(true);
    try {
      const who = await redeemReferralCode(code);
      setNotice(`Thank you! Your referral from ${who} is saved.`);
      setEntering(false);
      setCode('');
      setInfo(await getMyReferral());
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  if (!info) return error ? <ErrorText>{error}</ErrorText> : <ActivityIndicator color={colors.gold} />;
  if (info.family_member) return null;
  // After the offer: only show clients who took part.
  if (!info.open && info.referrals.length === 0) return null;

  const counted = info.referrals.filter((r) => r.state === 'counted').length;
  const paid = info.referrals.filter((r) => r.state === 'counted' || r.state === 'paid_once').length;

  return (
    <Card style={{ gap: 10 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
        <MaterialCommunityIcons name="gift-outline" size={24} color={colors.goldText} />
        <Text style={{ color: colors.text, fontSize: 17, fontWeight: '800', flex: 1 }}>Refer 2 friends, keep R49</Text>
      </View>

      {info.keeps_r49 === 'confirmed' ? (
        <Text style={{ color: colors.green, fontWeight: '700', fontSize: 15 }}>
          ✓ You keep R49 a month for the whole of 2027. Thank you!
        </Text>
      ) : info.keeps_r49 === 'provisional' ? (
        <Text style={{ color: colors.goldText, fontWeight: '700', fontSize: 15 }}>
          Almost there: you keep R49 once your friends have made their 2nd payment.
        </Text>
      ) : info.open ? (
        <Body>
          From 1 February 2027 the app is R75 a month. Refer 2 new households that join and pay before 31 January
          2027, and you keep paying R49 for the whole of 2027.
        </Body>
      ) : null}

      {info.code && info.open ? (
        <>
          <View
            style={{
              alignItems: 'center',
              paddingVertical: 10,
              borderRadius: 12,
              borderWidth: 1,
              borderColor: colors.gold,
              backgroundColor: colors.goldDeep,
            }}
          >
            <Text style={{ color: colors.muted, fontSize: 12 }}>Your referral code</Text>
            <Text selectable style={{ color: colors.goldText, fontSize: 30, fontWeight: '900', letterSpacing: 4 }}>
              {info.code}
            </Text>
          </View>
          <Button title="Share on WhatsApp" onPress={() => shareReferral(info.code!)} />
        </>
      ) : null}

      <Text style={{ color: colors.text, fontWeight: '700' }}>
        {counted} of {info.needed} friends counted{paid > counted ? ` · ${paid - counted} paid once` : ''}
      </Text>
      {info.referrals.map((r, i) => (
        <View key={`${r.name}-${i}`} style={{ flexDirection: 'row', gap: 8 }}>
          <Text style={{ color: colors.text, fontSize: 14, minWidth: 80 }}>{r.name}</Text>
          <Text style={{ color: STATE_COLOR[r.state], fontSize: 14, flex: 1 }}>{STATE_TEXT[r.state]}</Text>
        </View>
      ))}
      {info.open ? (
        <Text style={{ color: colors.muted, fontSize: 12, lineHeight: 17 }}>
          A friend counts after their 2nd monthly payment. They must live at a different address and not be a
          FireQuest client already.
        </Text>
      ) : null}

      {info.referred_by ? (
        <Text style={{ color: colors.muted, fontSize: 13 }}>You were referred by {info.referred_by}.</Text>
      ) : info.can_enter_code ? (
        entering ? (
          <>
            <Field
              label="Referral code of the friend who told you about FireQuest"
              value={code}
              onChangeText={(t) => setCode(cleanCode(t))}
              autoCapitalize="characters"
              placeholder="e.g. FQ7K3M"
              maxLength={6}
            />
            <Button title="Save code" onPress={save} loading={busy} />
            <Button title="Cancel" variant="plain" onPress={() => setEntering(false)} />
          </>
        ) : (
          <Button title="Did a friend refer you? Enter their code" variant="outline" onPress={() => setEntering(true)} />
        )
      ) : null}

      {notice ? <Text style={{ color: colors.green, fontSize: 13 }}>{notice}</Text> : null}
      <ErrorText>{error}</ErrorText>
    </Card>
  );
}
