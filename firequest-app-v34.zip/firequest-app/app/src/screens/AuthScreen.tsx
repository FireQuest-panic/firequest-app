import React, { useState } from 'react';
import { KeyboardAvoidingView, Platform, Text, View } from 'react-native';
import { colors } from '../theme';
import { downloadUrl, supabase, supabaseKey, supabaseUrl } from '../lib/supabase';
import { friendlyError } from '../lib/data';
import { cleanCode } from '../lib/referral';
import { familySignIn, familyUseCode } from '../lib/familyLogin';
import { Body, Button, ErrorText, Field, Logo, Screen, Title } from '../components/ui';

type Mode = 'welcome' | 'signin' | 'signup' | 'forgot' | 'familyChoice' | 'family' | 'familyCode';

export function AuthScreen() {
  const [mode, setMode] = useState<Mode>('welcome');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [code, setCode] = useState('');
  const [pin, setPin] = useState('');
  const [pin2, setPin2] = useState('');
  const [referral, setReferral] = useState('');

  const go = (m: Mode) => {
    setMode(m);
    setError('');
    setNotice('');
  };

  const signIn = async () => {
    setError('');
    if (!email.trim() || !password) return setError('Enter your email and password.');
    setBusy(true);
    const { error: err } = await supabase.auth.signInWithPassword({
      email: email.trim().toLowerCase(),
      password,
    });
    setBusy(false);
    if (err) setError(friendlyError(err));
  };

  // Forgot password: Supabase emails a link to reset.html on the FireQuest site,
  // where the client types a new password. Called directly (not through the app's
  // login client) so the link works in the phone's browser.
  const sendReset = async () => {
    setError('');
    const addr = email.trim().toLowerCase();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(addr)) return setError('Enter the email address you signed up with.');
    if (/@family\.firequest\.co\.za$/.test(addr)) return setError('Family members sign in with their cellphone number and PIN.');
    setBusy(true);
    try {
      const redirect = `${downloadUrl.replace(/\/*$/, '/')}reset.html`;
      const r = await fetch(`${supabaseUrl}/auth/v1/recover?redirect_to=${encodeURIComponent(redirect)}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', apikey: supabaseKey },
        body: JSON.stringify({ email: addr }),
      });
      if (r.status === 429) {
        setError('An email was sent a moment ago. Wait a minute, then check your inbox and spam folder before asking again.');
      } else if (!r.ok && r.status >= 500) {
        setError('Could not send the email. Please try again in a few minutes.');
      } else {
        setNotice(
          `If ${addr} has a FireQuest account, we have emailed it a link. ` +
            'Open the email on this phone (check your spam folder too), tap the link and choose a new password. Then come back here and sign in.',
        );
        setPassword('');
        setMode('signin');
      }
    } catch {
      setError('No internet connection. Check your connection and try again.');
    } finally {
      setBusy(false);
    }
  };

  const familyGo = async () => {
    setError('');
    if (mode === 'familyCode' && pin !== pin2) return setError('The two PINs are not the same.');
    setBusy(true);
    const err = mode === 'family' ? await familySignIn(phone, pin) : await familyUseCode(phone, code, pin);
    setBusy(false);
    if (err) setError(err);
  };

  const signUp = async () => {
    setError('');
    if (!fullName.trim()) return setError('Enter your full name.');
    if (!phone.trim()) return setError('Enter your mobile number.');
    if (!email.trim()) return setError('Enter your email address.');
    if (password.length < 8) return setError('Choose a password of at least 8 characters.');
    if (referral && !/^FQ[A-Z0-9]{4}$/.test(referral))
      return setError('The referral code starts with FQ and has 6 characters, e.g. FQ7K3M. Leave it empty if you have none.');
    setBusy(true);
    const { data, error: err } = await supabase.auth.signUp({
      email: email.trim().toLowerCase(),
      password,
      // A referral code is used the first time the Account screen opens (see lib/referral.ts).
      options: { data: { full_name: fullName.trim(), phone: phone.trim(), ...(referral ? { referral_code: referral } : {}) } },
    });
    setBusy(false);
    if (err) return setError(friendlyError(err));
    if (!data.session) {
      setNotice('Account created. Check your email for a confirmation link, then sign in here.');
      setMode('signin');
    }
  };

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <Screen style={{ justifyContent: mode === 'welcome' ? 'space-between' : 'flex-start' }}>
        {mode === 'welcome' ? (
          <>
            <View style={{ alignItems: 'center', gap: 24, paddingTop: 48 }}>
              <Logo size={220} />
              <View style={{ gap: 10, alignItems: 'center' }}>
                <Title>Help at the press of a button</Title>
                <Body center>
                  24/7 response to fire, medical emergencies and vehicle accidents by the FireQuest
                  team.
                </Body>
              </View>
            </View>
            <View style={{ gap: 12, paddingBottom: 8 }}>
              <Button title="Create account" onPress={() => go('signup')} />
              <Button title="I'm a FireQuest client – sign in" variant="outline" onPress={() => go('signin')} />
              <Button title="I'm a family member" variant="outline" onPress={() => go('familyChoice')} />
            </View>
          </>
        ) : mode === 'forgot' ? (
          <>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12, paddingTop: 8 }}>
              <Logo size={56} />
              <Title>Forgot password</Title>
            </View>
            <Body>Type the email address you signed up with. We will email you a link to choose a new password.</Body>
            <Field label="Email" value={email} onChangeText={setEmail} keyboardType="email-address" autoCapitalize="none" autoComplete="email" />
            <ErrorText>{error}</ErrorText>
            <Button title="Email me a link" onPress={sendReset} loading={busy} />
            <Button title="Back to sign in" variant="plain" onPress={() => go('signin')} />
          </>
        ) : mode === 'familyChoice' ? (
          <>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12, paddingTop: 8 }}>
              <Logo size={56} />
              <Title>Family member</Title>
            </View>
            <Body>Has the plan holder sent you a code? Then this is your first time – start with the code.</Body>
            <View style={{ gap: 12 }}>
              <Button title="I have a code (first time)" onPress={() => go('familyCode')} />
              <Text style={{ color: colors.muted, fontSize: 14, lineHeight: 20 }}>
                You enter your cellphone number and the code, then choose your own 6-digit PIN.
              </Text>
            </View>
            <View style={{ gap: 12, marginTop: 8 }}>
              <Button title="I already chose my PIN – sign in" variant="outline" onPress={() => go('family')} />
              <Text style={{ color: colors.muted, fontSize: 14, lineHeight: 20 }}>
                Forgot your PIN? Ask the plan holder for a new code, then tap "I have a code".
              </Text>
            </View>
            <Button title="Back" variant="plain" onPress={() => go('welcome')} />
          </>
        ) : mode === 'family' || mode === 'familyCode' ? (
          <>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12, paddingTop: 8 }}>
              <Logo size={56} />
              <Title>{mode === 'family' ? 'Sign in with your PIN' : 'Use your code'}</Title>
            </View>
            <Body>
              {mode === 'family'
                ? 'Sign in with your cellphone number and your 6-digit PIN.'
                : 'Enter the code the plan holder sent you and choose a 6-digit PIN. You will use your cellphone number and this PIN to sign in.'}
            </Body>
            <Field label="Cellphone number" value={phone} onChangeText={setPhone} keyboardType="phone-pad" placeholder="e.g. 082 123 4567" autoComplete="tel" />
            {mode === 'familyCode' && (
              <Field label="Code from the plan holder" value={code} onChangeText={(v) => setCode(v.toUpperCase())} autoCapitalize="characters" maxLength={8} placeholder="e.g. K7M2QX" />
            )}
            <Field
              label={mode === 'family' ? 'PIN' : 'Choose a 6-digit PIN'}
              value={pin}
              onChangeText={(v) => setPin(v.replace(/\D/g, ''))}
              keyboardType="number-pad"
              secureTextEntry
              maxLength={6}
            />
            {mode === 'familyCode' && (
              <Field label="Type the PIN again" value={pin2} onChangeText={(v) => setPin2(v.replace(/\D/g, ''))} keyboardType="number-pad" secureTextEntry maxLength={6} />
            )}
            <ErrorText>{error}</ErrorText>
            <Button title={mode === 'family' ? 'Sign in' : 'Continue'} onPress={familyGo} loading={busy} />
            <Button
              title={mode === 'family' ? "Haven't chosen a PIN yet? Use your code" : 'I already chose my PIN – sign in'}
              variant="plain"
              onPress={() => go(mode === 'family' ? 'familyCode' : 'family')}
            />
            <Button title="Back" variant="plain" onPress={() => go('familyChoice')} />
          </>
        ) : (
          <>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12, paddingTop: 8 }}>
              <Logo size={56} />
              <Title>{mode === 'signin' ? 'Sign in' : 'Create account'}</Title>
            </View>
            {notice ? <Body>{notice}</Body> : null}
            {mode === 'signup' && (
              <>
                <Field label="Full name" value={fullName} onChangeText={setFullName} autoCapitalize="words" autoComplete="name" />
                <Field label="Mobile number" value={phone} onChangeText={setPhone} keyboardType="phone-pad" placeholder="e.g. 082 123 4567" autoComplete="tel" />
              </>
            )}
            <Field label="Email" value={email} onChangeText={setEmail} keyboardType="email-address" autoCapitalize="none" autoComplete="email" />
            <Field label="Password" value={password} onChangeText={setPassword} secureTextEntry autoCapitalize="none" autoComplete={mode === 'signin' ? 'password' : 'new-password'} />
            {mode === 'signup' && (
              <Field
                label="Referral code (optional)"
                value={referral}
                onChangeText={(t) => setReferral(cleanCode(t))}
                autoCapitalize="characters"
                placeholder="From the friend who told you about FireQuest"
                maxLength={6}
              />
            )}
            <ErrorText>{error}</ErrorText>
            <Button
              title={mode === 'signin' ? 'Sign in' : 'Create account'}
              onPress={mode === 'signin' ? signIn : signUp}
              loading={busy}
            />
            {mode === 'signin' && <Button title="Forgot password?" variant="plain" onPress={() => go('forgot')} />}
            <Button
              title={mode === 'signin' ? 'New to FireQuest? Create an account' : 'Already have an account? Sign in'}
              variant="plain"
              onPress={() => go(mode === 'signin' ? 'signup' : 'signin')}
            />
            <Button title="Back" variant="plain" onPress={() => go('welcome')} />
          </>
        )}
      </Screen>
    </KeyboardAvoidingView>
  );
}
