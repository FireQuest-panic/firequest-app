import React, { useCallback, useEffect, useState } from 'react';
import { ActivityIndicator, Alert, BackHandler, Pressable, Text, View } from 'react-native';
import { colors } from '../theme';
import { supabase } from '../lib/supabase';
import { friendlyError } from '../lib/data';
import { longDate } from '../lib/billing';
import { ReferralState, STATE_TEXT } from '../lib/referral';
import { Button, Card, ErrorText, Screen, Title } from '../components/ui';

interface Referred {
  referred_id: string;
  name: string;
  phone: string | null;
  address: string | null;
  joined: string;
  payments: number;
  state: ReferralState;
  rejected_reason: string | null;
}
interface Referrer {
  referrer_id: string;
  referrer_name: string;
  referrer_phone: string | null;
  keeps_r49: 'confirmed' | 'provisional' | null;
  referred: Referred[];
}

const KEEPS = {
  confirmed: { text: 'KEEPS R49 IN 2027', fg: colors.green, bg: colors.greenDeep },
  provisional: { text: 'R49 – WAITING FOR 2ND PAYMENTS', fg: colors.goldText, bg: colors.goldDeep },
};

/** FireQuest admins: who referred whom, and who keeps R49 in 2027. */
export function ReferralsScreen({ onBack }: { onBack: () => void }) {
  const [rows, setRows] = useState<Referrer[] | null>(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    setBusy(true);
    setError('');
    const { data, error: e } = await supabase.rpc('referrals_list');
    if (e) setError(friendlyError(e));
    else setRows((data as Referrer[]) ?? []);
    setBusy(false);
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      onBack();
      return true;
    });
    return () => sub.remove();
  }, [onBack]);

  const setRejected = async (r: Referred, reason: string | null) => {
    const { error: e } = await supabase.rpc('referral_set_rejected', { p_referred: r.referred_id, p_reason: reason });
    if (e) setError(friendlyError(e));
    load();
  };

  const askReject = (r: Referred) =>
    Alert.alert('Do not count this referral?', `${r.name} will no longer count for this client.`, [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Same household', onPress: () => setRejected(r, 'Same household') },
      { text: 'Not a new client', onPress: () => setRejected(r, 'Not a new client') },
    ]);

  const all = rows ?? [];
  const keeps = all.filter((r) => r.keeps_r49 === 'confirmed').length;
  const almost = all.filter((r) => r.keeps_r49 === 'provisional').length;

  return (
    <Screen aboveTabBar>
      <Pressable accessibilityRole="button" onPress={onBack} style={{ paddingVertical: 6 }}>
        <Text style={{ color: colors.goldText, fontWeight: '700', fontSize: 15 }}>‹ Subscribers</Text>
      </Pressable>
      <Title>Referrals</Title>
      <Text style={{ color: colors.muted, fontSize: 13, lineHeight: 18 }}>
        A friend counts after their 2nd payment, if their first payment was by 31 January 2027. Clients with 2
        counted friends keep R49 for 2027.
      </Text>
      {rows ? (
        <Text style={{ color: colors.text, fontWeight: '700' }}>
          {all.length} clients referred someone · {keeps} keep R49 · {almost} almost
        </Text>
      ) : null}

      <ErrorText>{error}</ErrorText>
      {rows === null && !error ? <ActivityIndicator color={colors.gold} /> : null}
      {rows !== null && all.length === 0 ? <Text style={{ color: colors.muted }}>No referrals yet.</Text> : null}

      {all.map((c) => (
        <Card key={c.referrer_id} style={{ gap: 8 }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
            <Text style={{ color: colors.text, fontSize: 17, fontWeight: '700', flex: 1 }}>{c.referrer_name}</Text>
            {c.keeps_r49 ? (
              <View style={{ backgroundColor: KEEPS[c.keeps_r49].bg, borderRadius: 8, paddingHorizontal: 8, paddingVertical: 4 }}>
                <Text style={{ color: KEEPS[c.keeps_r49].fg, fontSize: 11, fontWeight: '800' }}>{KEEPS[c.keeps_r49].text}</Text>
              </View>
            ) : null}
          </View>
          {c.referrer_phone ? <Text style={{ color: colors.muted, fontSize: 13 }}>{c.referrer_phone}</Text> : null}
          {c.referred.map((r) => (
            <View key={r.referred_id} style={{ borderTopWidth: 1, borderTopColor: colors.border, paddingTop: 6, gap: 2 }}>
              <Text style={{ color: colors.text, fontWeight: '700' }}>{r.name}</Text>
              <Text style={{ color: colors.muted, fontSize: 13 }}>
                {[r.phone, r.address].filter(Boolean).join(' · ')}
              </Text>
              <Text style={{ color: colors.muted, fontSize: 13 }}>
                Joined {longDate(r.joined)} · {r.payments} payment{r.payments === 1 ? '' : 's'}
              </Text>
              <Text style={{ color: r.state === 'counted' ? colors.green : r.state === 'rejected' ? colors.danger : colors.goldText, fontSize: 13 }}>
                {STATE_TEXT[r.state]}
                {r.rejected_reason ? ` (${r.rejected_reason})` : ''}
              </Text>
              <Pressable
                accessibilityRole="button"
                onPress={() => (r.rejected_reason ? setRejected(r, null) : askReject(r))}
                style={{ paddingVertical: 4 }}
              >
                <Text style={{ color: colors.goldText, fontWeight: '700', fontSize: 13 }}>
                  {r.rejected_reason ? 'Count it again' : 'Do not count this referral'}
                </Text>
              </Pressable>
            </View>
          ))}
        </Card>
      ))}

      <Button title="Refresh" variant="outline" onPress={load} loading={busy} />
    </Screen>
  );
}
