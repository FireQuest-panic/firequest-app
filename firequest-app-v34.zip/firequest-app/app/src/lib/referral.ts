import { Share } from 'react-native';
import { downloadUrl, supabase } from './supabase';
import { friendlyError } from './data';

/** Where friends download the FireQuest app (shared with the referral code). */
export const DOWNLOAD_LINK = downloadUrl || 'https://firequest-panic.github.io/firequest-app/';

export type ReferralState = 'waiting' | 'paid_once' | 'counted' | 'too_late' | 'rejected';

export interface MyReferral {
  family_member: boolean;
  /** The client's own code, e.g. FQ7K3M (null for family members). */
  code: string | null;
  deadline: string;
  open: boolean;
  needed: number;
  /** 'confirmed': 2 friends counted. 'provisional': 2 friends paid once, 2nd payment still to come. */
  keeps_r49: 'confirmed' | 'provisional' | null;
  referrals: { name: string; joined: string; state: ReferralState }[];
  /** First name of the person who referred this client. */
  referred_by: string | null;
  can_enter_code: boolean;
}

export const STATE_TEXT: Record<ReferralState, string> = {
  waiting: 'Joined – waiting for first payment',
  paid_once: 'Paid once – counts after the 2nd payment',
  counted: 'Counted ✓',
  too_late: 'Paid after 31 January – does not count',
  rejected: 'Not counted',
};

export async function getMyReferral(): Promise<MyReferral> {
  const { data, error } = await supabase.rpc('my_referral');
  if (error) throw new Error(friendlyError(error));
  return data as MyReferral;
}

/** Returns the first name of the friend whose code it is. */
export async function redeemReferralCode(code: string): Promise<string> {
  const { data, error } = await supabase.rpc('use_referral_code', { p_code: code });
  if (error) throw new Error(friendlyError(error));
  return (data as { referrer?: string })?.referrer ?? 'your friend';
}

/** Normalises what people type: "fq 7k3m" -> "FQ7K3M". */
export const cleanCode = (t: string) => t.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 6);

export function shareReferral(code: string) {
  const message =
    `I use the FireQuest app for 24/7 fire, medical and accident response in Vanderbijlpark and surrounds. ` +
    `One press of the panic button sends your exact location to the FireQuest control room.\n\n` +
    `Download it here: ${DOWNLOAD_LINK}\n` +
    `When you create your account, enter my referral code: ${code}`;
  return Share.share({ message }).catch(() => undefined);
}

/**
 * A code typed at sign-up is kept with the account (user metadata) and used
 * here the first time the Account screen opens.
 */
export async function applySignupCode(): Promise<string | null> {
  const { data } = await supabase.auth.getUser();
  const pending = (data.user?.user_metadata as { referral_code?: string } | undefined)?.referral_code;
  if (!pending) return null;
  let result: string | null = null;
  try {
    const who = await redeemReferralCode(pending);
    result = `Referral code ${pending} from ${who} saved. Thank you!`;
  } catch (e) {
    result = `Referral code ${pending} could not be used: ${(e as Error).message}`;
  }
  await supabase.auth.updateUser({ data: { referral_code: null } }).catch(() => undefined);
  return result;
}
