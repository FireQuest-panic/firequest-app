package za.co.firequest.crash

import android.app.Notification
import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executors

/**
 * Smoke detectors, the free way: client Wi-Fi detectors are in FireQuest's own Smart Life
 * account on the control-room phone. Smart Life shows a notification when one goes off:
 *   real alarm: "Alarm events"      – "The Smoke alarm from FQ 082 123 4567 Kitchen ."
 *   test:       "Test Alarm Events" – "The Smoke Test Alarm from FQ 082 123 4567 Kitchen ."
 * This service (allowed in Android's "Notification access" setting) reads those and reports
 * them to FireQuest with the control-room device key. A real alarm becomes a FIRE alert and
 * the control-room alarm rings. Other apps' notifications are ignored and never stored.
 */
class SmokeAlarmListener : NotificationListenerService() {
  companion object {
    private const val TAG = "FireQuestSmoke"
    /** Smart Life and Tuya Smart (same notifications). */
    val SMART_APPS = setOf("com.tuya.smartlife", "com.tuya.smart", "com.tuya.smartiot")

    @Volatile var connected = false
      private set

    fun accessGranted(context: Context): Boolean {
      val flat = Settings.Secure.getString(context.contentResolver, "enabled_notification_listeners") ?: return false
      val me = ComponentName(context, SmokeAlarmListener::class.java)
      return flat.split(":").any { ComponentName.unflattenFromString(it) == me }
    }

    fun smartLifeInstalled(context: Context): Boolean = SMART_APPS.any {
      try {
        context.packageManager.getPackageInfo(it, 0)
        true
      } catch (_: PackageManager.NameNotFoundException) {
        false
      }
    }

    /**
     * "The Smoke alarm from FQ 082 Kitchen ." -> ("alarm", "FQ 082 Kitchen").
     * Decides from the title and the words BEFORE "from", so a detector called "FQ-TEST …"
     * still gives a real alarm. Null when the message is not about a detector.
     */
    fun parse(title: String, text: String): Pair<String, String>? {
      val m = Regex("^(.*?)\\s+from\\s+(.+?)[\\s.]*$", RegexOption.IGNORE_CASE).find(text.trim()) ?: return null
      val what = (title + " " + m.groupValues[1]).lowercase()
      val device = m.groupValues[2].trim()
      if (device.isEmpty()) return null
      val kind = when {
        what.contains("test") -> "test"
        Regex("battery|offline|online|tamper|removed|dismantl").containsMatchIn(what) -> "other"
        Regex("smoke|fire|alarm|carbon|\\bco\\b|gas|heat").containsMatchIn(what) -> "alarm"
        else -> "other"
      }
      return kind to device
    }

    /** False in the client app: the reader is only built into FireQuest Control Room. */
    fun includedInApp(context: Context): Boolean = try {
      context.packageManager.getServiceInfo(ComponentName(context, SmokeAlarmListener::class.java), 0)
      true
    } catch (_: Exception) {
      false
    }

    fun status(context: Context): Map<String, Any?> {
      val log = SmokeReports.prefs(context)
      return mapOf(
        "included" to includedInApp(context),
        "accessGranted" to accessGranted(context),
        "connected" to connected,
        "smartLifeInstalled" to smartLifeInstalled(context),
        "lastAt" to log.getLong("lastAt", 0L).toDouble(),
        "lastKind" to log.getString("lastKind", null),
        "lastDevice" to log.getString("lastDevice", null),
        "lastResult" to log.getString("lastResult", null),
        "pending" to SmokeReports.pendingCount(context),
      )
    }

    /** Asks Android to connect the listener again (after an update, or when it was dropped). */
    fun rebind(context: Context) {
      if (Build.VERSION.SDK_INT >= 24 && accessGranted(context)) {
        try {
          NotificationListenerService.requestRebind(ComponentName(context, SmokeAlarmListener::class.java))
        } catch (e: Exception) {
          Log.w(TAG, "rebind failed", e)
        }
      }
    }
  }

  override fun onListenerConnected() {
    connected = true
    SmokeReports.flush(this)
  }

  override fun onListenerDisconnected() {
    connected = false
    rebind(this)
  }

  override fun onNotificationPosted(sbn: StatusBarNotification?) {
    if (sbn == null || sbn.packageName !in SMART_APPS) return
    val n = sbn.notification ?: return
    if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
    val extras = n.extras ?: return
    val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
    val text = (extras.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: extras.getCharSequence(Notification.EXTRA_TEXT))?.toString() ?: ""
    val (kind, device) = parse(title, text) ?: return
    SmokeReports.add(this, kind, device, "$title – $text".take(300), sbn.postTime)
  }
}

/**
 * Reports waiting to go to FireQuest. Kept on the phone until FireQuest confirms, so an alarm
 * during a Wi-Fi drop is sent as soon as the connection is back (also retried at every
 * control-room check, every 20 seconds).
 */
object SmokeReports {
  private const val TAG = "FireQuestSmoke"
  private val network = Executors.newSingleThreadExecutor()

  fun prefs(context: Context) = context.applicationContext.getSharedPreferences("firequest_smoke", Context.MODE_PRIVATE)

  private fun queue(context: Context): JSONArray =
    try { JSONArray(prefs(context).getString("queue", "[]")) } catch (_: Exception) { JSONArray() }

  fun pendingCount(context: Context): Int = queue(context).length()

  @Synchronized
  fun add(context: Context, kind: String, device: String, message: String, postedAt: Long) {
    val p = prefs(context)
    // Smart Life updates the same notification (and several phones see the same alarm):
    // the same detector and kind within 60 seconds is one report.
    val dupKey = "$kind|$device"
    if (p.getString("lastKey", "") == dupKey && System.currentTimeMillis() - p.getLong("lastKeyAt", 0L) < 60_000L) return
    val q = queue(context)
    q.put(JSONObject().put("kind", kind).put("device", device).put("message", message).put("at", postedAt))
    while (q.length() > 50) q.remove(0)
    p.edit().putString("queue", q.toString()).putString("lastKey", dupKey).putLong("lastKeyAt", System.currentTimeMillis())
      .putLong("lastAt", System.currentTimeMillis()).putString("lastKind", kind).putString("lastDevice", device)
      .putString("lastResult", "Sending to FireQuest…").apply()
    flush(context)
  }

  /** Sends everything waiting. Safe to call often. */
  fun flush(context: Context) {
    val app = context.applicationContext
    if (pendingCount(app) == 0) return
    try {
      network.execute { sendAll(app) }
    } catch (e: Exception) {
      Log.w(TAG, "flush failed", e)
    }
  }

  private fun sendAll(context: Context) {
    val config = ControlRoomConfig(context)
    if (!config.isComplete) {
      prefs(context).edit().putString("lastResult", "NOT SENT – switch on \"Alarm when the app is closed\" in the Control room tab").apply()
      return
    }
    var rang = false
    while (true) {
      val item = synchronized(this) { queue(context).optJSONObject(0) } ?: break
      // Older than 24 hours: no longer useful as an alarm.
      val tooOld = System.currentTimeMillis() - item.optLong("at", 0L) > 24 * 3600_000L
      val result = if (tooOld) "Dropped (older than 24 hours)" else try {
        val answer = JSONObject(
          CrashApi.call(
            config.supabaseUrl, config.supabaseKey, "smoke_alarm_report",
            JSONObject().put("p_key", config.deviceKey).put("p_device", item.optString("device"))
              .put("p_kind", item.optString("kind")).put("p_message", item.optString("message")),
          )
        )
        if (!answer.optBoolean("ok", false)) {
          "NOT ACCEPTED: ${answer.optString("error")} – switch the control-room alarm on again"
        } else {
          if (item.optString("kind") == "alarm") rang = true
          val who = if (answer.optBoolean("linked")) answer.optString("client") else "detector not linked to a client"
          when (item.optString("kind")) {
            "alarm" -> "ALARM sent to FireQuest ($who)"
            "test" -> "Test received ($who)"
            else -> "Message received ($who)"
          }
        }
      } catch (e: Exception) {
        // No connection: keep it and try again at the next check.
        Log.w(TAG, "report failed", e)
        prefs(context).edit().putString("lastResult", "WAITING FOR CONNECTION – will send as soon as FireQuest can be reached").apply()
        break
      }
      synchronized(this) {
        val q = queue(context)
        if (q.length() > 0) q.remove(0)
        prefs(context).edit().putString("queue", q.toString()).putString("lastResult", result).apply()
      }
    }
    // Ring straight away instead of waiting for the next 20-second check.
    if (rang) ControlRoomAlarmService.requestCheck(context)
  }
}
