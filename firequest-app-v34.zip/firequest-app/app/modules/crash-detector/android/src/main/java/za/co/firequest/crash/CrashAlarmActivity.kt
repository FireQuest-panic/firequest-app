package za.co.firequest.crash

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.max

/**
 * The client's accident screen: opens by itself when crash detection starts the countdown,
 * also over the lock screen or another app (maps, music). Shows WHY the phone is ringing,
 * the seconds left, and big I'M OK / SEND HELP NOW buttons. Closes when the countdown ends.
 */
class CrashAlarmActivity : Activity() {
  private val handler = Handler(Looper.getMainLooper())
  private lateinit var root: LinearLayout
  private lateinit var secondsView: TextView
  private lateinit var textView: TextView
  private var flash = false

  @Suppress("DEPRECATION")
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    if (Build.VERSION.SDK_INT >= 27) {
      setShowWhenLocked(true)
      setTurnScreenOn(true)
    } else {
      window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON)
    }
    window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    window.attributes = window.attributes.apply { screenBrightness = 1f }

    val d = resources.displayMetrics.density
    val pad = (24 * d).toInt()
    root = LinearLayout(this).apply {
      orientation = LinearLayout.VERTICAL
      gravity = Gravity.CENTER
      setPadding(pad, pad, pad, pad)
      setBackgroundColor(RED)
    }
    val title = TextView(this).apply {
      text = if (CrashDetectionService.countdownSimulated) "TEST\nPOSSIBLE ACCIDENT DETECTED" else "POSSIBLE ACCIDENT DETECTED"
      textSize = 28f
      typeface = Typeface.DEFAULT_BOLD
      gravity = Gravity.CENTER
      setTextColor(Color.WHITE)
    }
    secondsView = TextView(this).apply {
      textSize = 96f
      typeface = Typeface.DEFAULT_BOLD
      gravity = Gravity.CENTER
      setTextColor(Color.WHITE)
    }
    textView = TextView(this).apply {
      textSize = 19f
      gravity = Gravity.CENTER
      setTextColor(Color.WHITE)
      setPadding(0, 0, 0, pad)
    }
    val ok = bigButton("I'M OK – CANCEL", Color.rgb(31, 138, 76), Color.WHITE) {
      sendToService(CrashDetectionService.ACTION_IM_OK)
      finish()
    }
    val help = bigButton("SEND HELP NOW", Color.WHITE, RED) {
      sendToService(CrashDetectionService.ACTION_SEND_NOW)
      finish()
    }
    root.addView(title)
    root.addView(secondsView)
    root.addView(textView)
    root.addView(ok, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, (88 * d).toInt()))
    root.addView(help, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, (64 * d).toInt()).apply {
      topMargin = pad / 2
    })
    setContentView(root)
    handler.post(tick)
  }

  private fun bigButton(label: String, bg: Int, fg: Int, onTap: () -> Unit) = Button(this).apply {
    text = label
    textSize = 22f
    typeface = Typeface.DEFAULT_BOLD
    setTextColor(fg)
    isAllCaps = false
    background = GradientDrawable().apply {
      setColor(bg)
      cornerRadius = 18 * resources.displayMetrics.density
      setStroke((2 * resources.displayMetrics.density).toInt(), Color.WHITE)
    }
    setOnClickListener { onTap() }
  }

  private fun sendToService(action: String) {
    CrashDetectionService.start(this, action)
  }

  /** Updates the seconds and closes the page once the countdown is over (cancelled or sent). */
  private val tick: Runnable = object : Runnable {
    override fun run() {
      val endsAt = CrashDetectionService.countdownEndsAt
      if (CrashDetectionService.state != "countdown" || endsAt == 0L) {
        finish()
        return
      }
      val left = max(0L, (endsAt - System.currentTimeMillis() + 999) / 1000L)
      secondsView.text = left.toString()
      textView.text = "FireQuest will send an accident alert with your location to the control room in $left seconds.\n\n" +
        "Tap I'M OK if you are fine."
      flash = !flash
      root.setBackgroundColor(if (flash) RED else DARK_RED)
      handler.postDelayed(this, 500)
    }
  }

  // Back button: do nothing – the person must choose I'M OK or SEND HELP NOW.
  @Deprecated("Deprecated in Java")
  override fun onBackPressed() {}

  override fun onDestroy() {
    handler.removeCallbacksAndMessages(null)
    super.onDestroy()
  }

  companion object {
    private val RED = Color.rgb(212, 47, 53)
    private val DARK_RED = Color.rgb(150, 20, 26)

    fun intent(context: android.content.Context): Intent =
      Intent(context, CrashAlarmActivity::class.java)
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NO_USER_ACTION)
  }
}
