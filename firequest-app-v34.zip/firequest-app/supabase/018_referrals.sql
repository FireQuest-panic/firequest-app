-- =====================================================================
-- FireQuest – referrals: "Refer 2 households, keep R49 for 2027"
--   * Every client has a personal code (e.g. FQ7K3M), shared on WhatsApp.
--   * A NEW plan holder enters the code once (at sign-up or in Account),
--     before 31 January 2027.
--   * Not allowed: your own code, your own family plan, the same cellphone
--     number or the same home address, clients moved over from Base44.
--   * A referral COUNTS when the friend has made 2 payments, and their first
--     payment was on or before 31 January 2027.
--   * keeps_r49:
--       'confirmed'   – 2 referrals counted
--       'provisional' – 2 referrals each paid at least once by 31 January
--                       (the 2nd payment is still to come)
--   The February price change (still to be built) keeps these clients on R49.
--   FireQuest admins can reject a referral (with a reason) or undo that.
-- =====================================================================

-- Clients moved over from the old Base44 app are not "new households".
alter table public.subscriptions add column if not exists imported_from text;

create table if not exists private.referral_codes (
  user_id    uuid primary key references public.profiles (id) on delete cascade,
  code       text not null unique,
  created_at timestamptz not null default now()
);

create table if not exists private.referrals (
  referred_id     uuid primary key references public.profiles (id) on delete cascade,
  referrer_id     uuid not null references public.profiles (id) on delete cascade,
  code            text not null,
  created_at      timestamptz not null default now(),
  rejected_at     timestamptz,
  rejected_reason text,
  rejected_by     uuid
);
create index if not exists referrals_referrer_idx on private.referrals (referrer_id);
revoke all on private.referral_codes, private.referrals from public, anon, authenticated;

create or replace function private.referral_deadline() returns timestamptz
language sql immutable as $$ select timestamptz '2027-02-01 00:00:00+02' $$;

-- The plan a person holds (null when they are not a plan holder).
create or replace function private.held_plan(p_uid uuid) returns uuid
language sql stable security definer set search_path = public as $$
  select s.id from public.subscriptions s where s.owner_id = p_uid order by s.created_at limit 1
$$;

-- Payments received for a person's plan: (count, first payment time).
create or replace function private.plan_payments(p_uid uuid, out n int, out first_at timestamptz)
language sql stable security definer set search_path = public as $$
  select count(distinct e.pf_payment_id)::int, min(e.received_at)
    from private.payfast_events e
   where e.subscription_id = private.held_plan(p_uid)
     and e.valid and e.payment_status = 'COMPLETE' and e.outcome like 'applied: paid%'
$$;

-- 'counted' | 'paid_once' | 'waiting' | 'too_late' | 'rejected'
create or replace function private.referral_state(r private.referrals) returns text
language plpgsql stable security definer set search_path = public as $$
declare v record;
begin
  if r.rejected_at is not null then return 'rejected'; end if;
  select * into v from private.plan_payments(r.referred_id);
  if v.n = 0 then
    return case when now() >= private.referral_deadline() then 'too_late' else 'waiting' end;
  end if;
  if v.first_at >= private.referral_deadline() then return 'too_late'; end if;
  return case when v.n >= 2 then 'counted' else 'paid_once' end;
end $$;

create or replace function private.referral_keeps_r49(p_uid uuid) returns text
language sql stable security definer set search_path = public as $$
  select case
           when count(*) filter (where st = 'counted') >= 2 then 'confirmed'
           when count(*) filter (where st in ('counted', 'paid_once')) >= 2 then 'provisional'
         end
    from (select private.referral_state(r) st from private.referrals r where r.referrer_id = p_uid) x
$$;

create or replace function private.new_referral_code() returns text
language plpgsql volatile as $$
declare
  v_chars text := 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';  -- no 0/O, 1/I
  v_code text;
begin
  loop
    v_code := 'FQ';
    for i in 1..4 loop
      v_code := v_code || substr(v_chars, 1 + floor(random() * length(v_chars))::int, 1);
    end loop;
    exit when not exists (select 1 from private.referral_codes where code = v_code);
  end loop;
  return v_code;
end $$;

-- Normalised home address, for "not the same household".
create or replace function private.address_key(p text) returns text
language sql immutable as $$ select nullif(regexp_replace(lower(coalesce(p, '')), '[^a-z0-9]', '', 'g'), '') $$;

-- ---------------------------------------------------------------- client

-- The signed-in client's referral page.
create or replace function public.my_referral()
returns json language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
  v_code text;
  v_ref private.referrals;
  v_member boolean;
begin
  if v_uid is null then raise exception 'Not signed in'; end if;
  -- Family members (on someone else's plan) have no code of their own.
  v_member := exists (select 1 from public.subscription_members m join public.subscriptions s on s.id = m.subscription_id
                       where m.user_id = v_uid and s.owner_id <> v_uid);
  if not v_member then
    select code into v_code from private.referral_codes where user_id = v_uid;
    if v_code is null then
      insert into private.referral_codes (user_id, code) values (v_uid, private.new_referral_code())
      on conflict (user_id) do nothing;
      select code into v_code from private.referral_codes where user_id = v_uid;
    end if;
  end if;
  select * into v_ref from private.referrals where referred_id = v_uid;

  return json_build_object(
    'family_member', v_member,
    'code', v_code,
    'deadline', private.referral_deadline(),
    'open', now() < private.referral_deadline(),
    'needed', 2,
    'keeps_r49', private.referral_keeps_r49(v_uid),
    'referrals', coalesce((
      select json_agg(json_build_object(
               'name', split_part(coalesce(nullif(trim(p.full_name), ''), 'A friend'), ' ', 1),
               'joined', r.created_at,
               'state', private.referral_state(r))
             order by r.created_at)
        from private.referrals r join public.profiles p on p.id = r.referred_id
       where r.referrer_id = v_uid), '[]'::json),
    'referred_by', (select split_part(coalesce(nullif(trim(p.full_name), ''), 'a FireQuest client'), ' ', 1)
                      from public.profiles p where p.id = v_ref.referrer_id),
    'can_enter_code', not v_member and v_ref.referred_id is null and now() < private.referral_deadline()
                      and not exists (select 1 from public.subscriptions s where s.owner_id = v_uid and s.imported_from is not null)
                      and coalesce((select n from private.plan_payments(v_uid)), 0) <= 1
  );
end $$;

-- A new client enters the code of the friend who referred them.
create or replace function public.use_referral_code(p_code text)
returns json language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
  v_code text := upper(regexp_replace(coalesce(p_code, ''), '[^A-Za-z0-9]', '', 'g'));
  v_referrer uuid;
  v_me public.profiles;
  v_them public.profiles;
begin
  if v_uid is null then raise exception 'Not signed in'; end if;
  if now() >= private.referral_deadline() then raise exception 'The referral offer ended on 31 January 2027.'; end if;
  if exists (select 1 from private.referrals where referred_id = v_uid) then
    raise exception 'You have already entered a referral code.';
  end if;
  if exists (select 1 from public.subscription_members m join public.subscriptions s on s.id = m.subscription_id
              where m.user_id = v_uid and s.owner_id <> v_uid) then
    raise exception 'You are on a family plan. Only the plan holder can enter a referral code.';
  end if;
  if exists (select 1 from public.subscriptions s where s.owner_id = v_uid and s.imported_from is not null) then
    raise exception 'Referral codes are for new FireQuest clients.';
  end if;
  if coalesce((select n from private.plan_payments(v_uid)), 0) > 1 then
    raise exception 'Referral codes can only be entered by new clients (before their second payment).';
  end if;
  if v_code !~ '^FQ[A-Z0-9]{4}$' then raise exception 'That code does not look right. It starts with FQ, e.g. FQ7K3M.'; end if;

  select user_id into v_referrer from private.referral_codes where code = v_code;
  if v_referrer is null then raise exception 'Code % was not found. Check it with the person who sent it.', v_code; end if;
  if v_referrer = v_uid then raise exception 'You cannot use your own code.'; end if;
  -- Same family plan?
  if exists (select 1 from public.subscription_members a join public.subscription_members b on a.subscription_id = b.subscription_id
              where a.user_id = v_uid and b.user_id = v_referrer) then
    raise exception 'You are on the same family plan as the person who sent the code.';
  end if;
  select * into v_me from public.profiles where id = v_uid;
  select * into v_them from public.profiles where id = v_referrer;
  if private.phone_key(v_me.phone) is not null and private.phone_key(v_me.phone) = private.phone_key(v_them.phone) then
    raise exception 'This code belongs to someone with the same cellphone number.';
  end if;
  if private.address_key(v_me.home_address) is not null
     and private.address_key(v_me.home_address) = private.address_key(v_them.home_address) then
    raise exception 'Referrals must be a different household (different home address).';
  end if;

  insert into private.referrals (referred_id, referrer_id, code) values (v_uid, v_referrer, v_code);
  return json_build_object('ok', true,
    'referrer', split_part(coalesce(nullif(trim(v_them.full_name), ''), 'your friend'), ' ', 1));
end $$;

-- ---------------------------------------------------------------- admin

create or replace function public.referrals_list()
returns json language plpgsql stable security definer set search_path = public as $$
begin
  if not exists (select 1 from public.staff where user_id = auth.uid() and role = 'admin') then
    raise exception 'Not authorised';
  end if;
  return (
    select coalesce(json_agg(x order by x.keeps_r49 nulls last, x.referrer_name), '[]'::json)
      from (
        select rp.id as referrer_id,
               coalesce(nullif(trim(rp.full_name), ''), rp.email) as referrer_name,
               rp.phone as referrer_phone,
               private.referral_keeps_r49(rp.id) as keeps_r49,
               (select json_agg(json_build_object(
                         'referred_id', r.referred_id,
                         'name', coalesce(nullif(trim(p.full_name), ''), p.email),
                         'phone', p.phone,
                         'address', p.home_address,
                         'joined', r.created_at,
                         'payments', (select n from private.plan_payments(r.referred_id)),
                         'state', private.referral_state(r),
                         'rejected_reason', r.rejected_reason)
                       order by r.created_at)
                  from private.referrals r join public.profiles p on p.id = r.referred_id
                 where r.referrer_id = rp.id) as referred
          from public.profiles rp
         where exists (select 1 from private.referrals r where r.referrer_id = rp.id)
      ) x
  );
end $$;

-- Reject (p_reason) or undo a rejection (p_reason null).
create or replace function public.referral_set_rejected(p_referred uuid, p_reason text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not exists (select 1 from public.staff where user_id = auth.uid() and role = 'admin') then
    raise exception 'Not authorised';
  end if;
  update private.referrals
     set rejected_at = case when nullif(trim(p_reason), '') is null then null else now() end,
         rejected_reason = nullif(trim(p_reason), ''),
         rejected_by = case when nullif(trim(p_reason), '') is null then null else auth.uid() end
   where referred_id = p_referred;
end $$;

revoke execute on function public.my_referral(), public.use_referral_code(text), public.referrals_list(),
  public.referral_set_rejected(uuid, text) from public, anon;
grant execute on function public.my_referral(), public.use_referral_code(text), public.referrals_list(),
  public.referral_set_rejected(uuid, text) to authenticated;
revoke execute on function private.referral_deadline(), private.held_plan(uuid), private.plan_payments(uuid),
  private.referral_state(private.referrals), private.referral_keeps_r49(uuid), private.new_referral_code(),
  private.address_key(text) from public, anon, authenticated;
