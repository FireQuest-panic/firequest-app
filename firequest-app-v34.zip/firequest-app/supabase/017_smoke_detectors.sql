-- =====================================================================
-- FireQuest – Wi-Fi smoke detectors (Smart Life), the free way
-- Client detectors are added to FireQuest's own Smart Life account. On the
-- control-room phone(s), FireQuest reads Smart Life's notifications
-- ("The Smoke alarm from FQ 082 123 4567 Kitchen .") and reports them here
-- with the control-room device key (see 008_control_room_alarm.sql).
-- The cellphone number in the detector's name links it to the client.
--   alarm -> a FIRE alert (source 'smoke_detector'), the control room rings
--   test  -> only recorded (last test time), no alert
--   other -> only recorded (low battery, offline …)
-- Several control-room phones report the same alarm: one alert only.
-- =====================================================================

alter table public.alerts drop constraint if exists alerts_source_check;
alter table public.alerts add constraint alerts_source_check
  check (source in ('button', 'crash_detection', 'smoke_detector'));
-- Short description shown with the alert, e.g. "Smoke alarm – Kitchen (FQ 082 123 4567 Kitchen)".
alter table public.alerts add column if not exists detail text;

-- Every detector FireQuest has heard from, by its Smart Life name.
create table if not exists public.smoke_detectors (
  device_name   text primary key,
  user_id       uuid references public.profiles (id) on delete set null,
  room          text,
  first_seen_at timestamptz not null default now(),
  last_test_at  timestamptz,
  last_alarm_at timestamptz,
  last_other_at timestamptz,
  last_other    text
);
alter table public.smoke_detectors enable row level security;
revoke all on public.smoke_detectors from anon, authenticated;
grant select on public.smoke_detectors to authenticated;
drop policy if exists smoke_detectors_staff on public.smoke_detectors;
create policy smoke_detectors_staff on public.smoke_detectors for select to authenticated using (public.is_staff());

-- Every Smart Life message received (kept 90 days), for checking afterwards.
create table if not exists private.smoke_events (
  id          bigint generated always as identity primary key,
  device_name text not null,
  kind        text not null,
  message     text,
  staff_id    uuid,
  alert_id    uuid,
  received_at timestamptz not null default now()
);
create index if not exists smoke_events_device_idx on private.smoke_events (device_name, received_at desc);
revoke all on private.smoke_events from public, anon, authenticated;

-- "FQ 082 123 4567 Kitchen" -> the client (by the last 9 digits of the first cellphone number).
create or replace function private.smoke_detector_client(p_name text)
returns uuid language sql stable security definer set search_path = public as $$
  select p.id
    from public.profiles p
   where private.phone_key(p.phone) = private.phone_key(substring(coalesce(p_name, '') from '\+?\d[\d\s-]{7,}\d'))
   order by p.onboarded_at nulls last, p.created_at
   limit 1
$$;

-- The room: whatever is left of the name after "FQ" and the number.
create or replace function private.smoke_detector_room(p_name text)
returns text language sql immutable set search_path = public as $$
  select nullif(btrim(regexp_replace(regexp_replace(regexp_replace(coalesce(p_name, ''), '^\s*FQ[\s:_,-]*', '', 'i'),
                                     '\+?\d[\d\s-]{7,}\d', ''), '\s+', ' ', 'g'), ' -–_:,.'), '')
$$;

-- Control-room phone (device key, no login): Smart Life said something about a detector.
create or replace function public.smoke_alarm_report(p_key text, p_device text, p_kind text, p_message text default null)
returns json language plpgsql security definer set search_path = public as $$
declare
  v_staff  uuid;
  v_kind   text := lower(coalesce(p_kind, 'other'));
  v_device text := left(btrim(coalesce(p_device, '')), 120);
  v_client uuid;
  v_room   text;
  v_alert  public.alerts;
  v_detail text;
  v_lat    double precision;
  v_lng    double precision;
begin
  select d.user_id into v_staff
    from private.control_room_devices d
   where d.key_hash = encode(extensions.digest(coalesce(p_key, ''), 'sha256'), 'hex')
     and exists (select 1 from public.staff s where s.user_id = d.user_id);
  if v_staff is null then return json_build_object('ok', false, 'error', 'not_registered'); end if;
  if v_device = '' then return json_build_object('ok', false, 'error', 'no_device'); end if;
  if v_kind not in ('alarm', 'test', 'other') then v_kind := 'other'; end if;

  v_client := private.smoke_detector_client(v_device);
  v_room := private.smoke_detector_room(v_device);

  insert into public.smoke_detectors as s (device_name, user_id, room)
  values (v_device, v_client, v_room)
  on conflict (device_name) do update set user_id = coalesce(excluded.user_id, s.user_id), room = excluded.room;

  if v_kind = 'test' then
    update public.smoke_detectors set last_test_at = now() where device_name = v_device;
  elsif v_kind = 'other' then
    update public.smoke_detectors set last_other_at = now(), last_other = left(p_message, 200) where device_name = v_device;
  else
    update public.smoke_detectors set last_alarm_at = now() where device_name = v_device;
    -- Same detector already has an open alert (another phone, or Smart Life repeating): use that one.
    select a.* into v_alert
      from private.smoke_events e
      join public.alerts a on a.id = e.alert_id
     where e.device_name = v_device
       and e.received_at > now() - interval '30 minutes'
       and a.status not in ('closed', 'cancelled')
     order by e.received_at desc limit 1;
    if not found then
      v_detail := 'Smoke alarm' || coalesce(' – ' || v_room, '')
                  || case when v_client is null then ' – DETECTOR NOT LINKED TO A CLIENT' else '' end
                  || ' (' || v_device || ')';
      select home_lat, home_lng into v_lat, v_lng from public.profiles where id = v_client;
      insert into public.alerts (user_id, type, is_test, source, detail, lat, lng, location_updated_at)
      values (coalesce(v_client, v_staff), 'fire', coalesce((select test_mode from public.app_settings where id = 1), true),
              'smoke_detector', v_detail, v_lat, v_lng, case when v_lat is not null then now() end)
      returning * into v_alert;
      insert into public.alert_events (alert_id, actor_id, actor_kind, event, note)
      values (v_alert.id, v_staff, 'system', 'raised', 'fire – ' || v_detail);
    end if;
  end if;

  insert into private.smoke_events (device_name, kind, message, staff_id, alert_id)
  values (v_device, v_kind, left(p_message, 300), v_staff, v_alert.id);
  delete from private.smoke_events where received_at < now() - interval '90 days';

  return json_build_object('ok', true, 'kind', v_kind, 'linked', v_client is not null,
                           'client', (select full_name from public.profiles where id = v_client),
                           'alert_id', v_alert.id);
end $$;

revoke execute on function public.smoke_alarm_report(text, text, text, text) from public;
-- The control-room phone service calls this without a login; the device key is the proof.
grant execute on function public.smoke_alarm_report(text, text, text, text) to anon, authenticated;
revoke execute on function private.smoke_detector_client(text), private.smoke_detector_room(text) from public, anon, authenticated;
