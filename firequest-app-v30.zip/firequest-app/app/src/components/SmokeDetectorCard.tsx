import React, { useCallback, useEffect, useState } from 'react';
import { Alert, AppState, Platform, Pressable, Switch, Text, View } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import CrashDetector, { SmokeStatus } from '../../modules/crash-detector';
import { colors } from '../theme';
import { supabase } from '../lib/supabase';
import { alarmStatus } from '../lib/controlRoomAlarm';
import { Card } from './ui';

interface Detector {
  device_name: string;
  user_id: string | null;
  room: string | null;
  last_test_at: string | null;
  last_alarm_at: string | null;
  last_other_at: string | null;
  last_other: string | null;
  profiles?: { full_name: string | null } | null;
}

const supported = Platform.OS === 'android' && typeof CrashDetector?.smokeStatus === 'function';

function smokeStatus(): SmokeStatus | null {
  try {
    return CrashDetector?.smokeStatus?.() ?? null;
  } catch {
    return null;
  }
}

function ago(ms: number | string | null): string {
  if (!ms) return 'never';
  const t = typeof ms === 'number' ? ms : Date.parse(ms);
  const s = Math.round((Date.now() - t) / 1000);
  if (s < 90) return `${Math.max(s, 0)} s ago`;
  if (s < 5400) return `${Math.round(s / 60)} min ago`;
  if (s < 172800) return `${Math.round(s / 3600)} h ago`;
  return `${Math.round(s / 86400)} days ago`;
}

/** Days since the detector was last tested (or heard from). */
const staleDays = (d: Detector) => {
  const last = Math.max(Date.parse(d.last_test_at ?? '') || 0, Date.parse(d.last_alarm_at ?? '') || 0);
  return last ? Math.floor((Date.now() - last) / 86400000) : null;
};

/**
 * Control room: Wi-Fi smoke detectors in FireQuest's Smart Life account. This phone reads
 * Smart Life's alarm notifications and turns a real alarm into a FIRE alert.
 */
export function SmokeDetectorCard() {
  const [status, setStatus] = useState<SmokeStatus | null>(smokeStatus());
  const [detectors, setDetectors] = useState<Detector[] | null>(null);
  const [showList, setShowList] = useState(false);

  const refresh = useCallback(() => {
    try {
      setStatus(CrashDetector?.smokeRefresh?.() ?? smokeStatus());
    } catch {
      setStatus(smokeStatus());
    }
    supabase
      .from('smoke_detectors')
      .select('*, profiles(full_name)')
      .order('device_name')
      .then(({ data, error }) => setDetectors(error ? null : ((data as Detector[]) ?? [])));
  }, []);

  useEffect(() => {
    refresh();
    const t = setInterval(refresh, 15000);
    const sub = AppState.addEventListener('change', (s) => s === 'active' && refresh());
    return () => {
      clearInterval(t);
      sub.remove();
    };
  }, [refresh]);

  if (!supported) return null;
  const on = Boolean(status?.accessGranted);
  const alarmOn = Boolean(alarmStatus()?.enabled);

  const openAccess = () =>
    Alert.alert(
      on ? 'Switch off smoke detectors?' : 'Read Smart Life alarms',
      on
        ? 'On the next screen, switch off "FireQuest smoke alarms". This phone will then no longer pass smoke alarms to FireQuest.'
        : 'On the next screen, switch on "FireQuest smoke alarms" and tap Allow.\n\n' +
            'If it is greyed out or says "Restricted setting": go to Settings › Apps › FireQuest, tap ⋮ (top right) › "Allow restricted settings", then try again.\n\n' +
            'FireQuest only reads Smart Life detector messages. Other notifications are ignored and never stored.',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Open setting', onPress: () => CrashDetector?.openNotificationAccess?.() },
      ],
    );

  const problems: string[] = [];
  if (on && status && !status.smartLifeInstalled) problems.push('Smart Life is not installed on this phone.');
  if (on && !alarmOn) problems.push('Switch on "Alarm when app is closed" above, otherwise smoke alarms cannot reach FireQuest.');
  if (on && status && !status.connected) problems.push('Android has not connected the reader yet. Restart the phone if this stays.');
  if (status?.pending) problems.push(`${status.pending} message(s) waiting for a connection to FireQuest.`);

  const unlinked = (detectors ?? []).filter((d) => !d.user_id).length;
  const untested = (detectors ?? []).filter((d) => {
    const days = staleDays(d);
    return days === null || days > 35;
  }).length;

  return (
    <Card style={[{ paddingVertical: 12, gap: 8 }, problems.length ? { borderColor: '#7A2A2E' } : null]}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
        <MaterialCommunityIcons name="smoke-detector-variant" size={22} color={on ? colors.goldText : colors.danger} />
        <View style={{ flex: 1 }}>
          <Text style={{ color: colors.text, fontWeight: '700', fontSize: 15 }}>Smoke detectors (Smart Life)</Text>
          <Text style={{ color: colors.muted, fontSize: 12 }}>
            {on ? `On · ${detectors?.length ?? '…'} detector${detectors?.length === 1 ? '' : 's'}` : 'Off on this phone'}
          </Text>
        </View>
        <Switch
          accessibilityLabel="Smoke detectors"
          value={on}
          onValueChange={openAccess}
          trackColor={{ false: colors.borderStrong, true: colors.gold }}
          thumbColor={on ? colors.goldText : colors.muted}
        />
      </View>

      {problems.map((p) => (
        <Text key={p} style={{ color: colors.danger, fontSize: 13, lineHeight: 18 }}>
          {p}
        </Text>
      ))}

      {status?.lastAt ? (
        <Text style={{ color: status.lastKind === 'alarm' ? colors.redText : colors.muted, fontSize: 13, lineHeight: 18 }}>
          Last message {ago(status.lastAt)}: {status.lastDevice}
          {'\n'}
          {status.lastResult}
        </Text>
      ) : on ? (
        <Text style={{ color: colors.muted, fontSize: 13 }}>Press TEST on a detector to check that it comes through.</Text>
      ) : null}

      {detectors && detectors.length > 0 ? (
        <>
          {unlinked || untested ? (
            <Text style={{ color: colors.goldText, fontSize: 13 }}>
              {[unlinked ? `${unlinked} not linked to a client` : '', untested ? `${untested} not tested in 5 weeks` : '']
                .filter(Boolean)
                .join(' · ')}
            </Text>
          ) : null}
          <Pressable accessibilityRole="button" onPress={() => setShowList((v) => !v)} style={{ paddingVertical: 4 }}>
            <Text style={{ color: colors.goldText, fontWeight: '700', fontSize: 13 }}>
              {showList ? 'Hide detectors ‹' : 'Show detectors ›'}
            </Text>
          </Pressable>
          {showList
            ? detectors.map((d) => {
                const days = staleDays(d);
                return (
                  <View key={d.device_name} style={{ borderTopWidth: 1, borderTopColor: colors.border, paddingTop: 6, gap: 2 }}>
                    <Text style={{ color: colors.text, fontWeight: '700', fontSize: 14 }}>{d.device_name}</Text>
                    <Text style={{ color: d.user_id ? colors.muted : colors.danger, fontSize: 12 }}>
                      {d.user_id ? d.profiles?.full_name || 'Client' : 'Not linked: put the client\'s cellphone number in the name'}
                    </Text>
                    <Text style={{ color: days === null || days > 35 ? colors.goldText : colors.muted, fontSize: 12 }}>
                      Last test {ago(d.last_test_at)}
                      {d.last_alarm_at ? ` · last alarm ${ago(d.last_alarm_at)}` : ''}
                      {d.last_other ? `\n${d.last_other} (${ago(d.last_other_at)})` : ''}
                    </Text>
                  </View>
                );
              })
            : null}
        </>
      ) : null}
    </Card>
  );
}
